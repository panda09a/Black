From: <Saved by Blink>
Snapshot-Content-Location: https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh
Subject: =?utf-8?Q?home-termux-1/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___?=
 =?utf-8?Q?xbcnsml__xdpen__xnwwl___.sh=20at=20master=20=C2=B7=20xlyze/home?=
 =?utf-8?Q?-termux-1?=
Date: Tue, 21 Dec 2021 01:11:55 -0000
MIME-Version: 1.0
Content-Type: multipart/related;
	type="text/html";
	boundary="----MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----"


------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/html
Content-ID: <frame-50176DC9C277E11803B5BEAD65E34CC7@mhtml.blink>
Content-Transfer-Encoding: binary
Content-Location: https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh

<!DOCTYPE html><html lang="en" data-color-mode="auto" data-light-theme="light" data-dark-theme="dark"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" href="cid:css-faa02a40-fa40-44ce-93ab-22f9432d1113@mhtml.blink" />
    
  <link rel="dns-prefetch" href="https://github.githubassets.com/">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com/">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com/">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com/" crossorigin="">
  <link rel="preconnect" href="https://avatars.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/light-00a4b22ce27a010c3401f127b3575c75.css"><link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/dark-a0349787ff32dba0ea6d0ecef2c75de8.css">
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-f73ad64a961ad5f0948ddeeca7af56e1.css">
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/behaviors-70fcbf0f7f153bb886a34c9570d4a6d9.css">
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/tab-size-fix-30224561f6d0a13e045c2e9a5b1e5682.css">
  
  
  
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/github-25bf40139dbecd8ef14cfee484cd801e.css">

  
    
    
  
  
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
  


  <meta name="viewport" content="width=device-width">
  
  <title>home-termux-1/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh at master · xlyze/home-termux-1</title>
    <meta name="description" content="Tools untuk merubah tampilan  home pertama termux. Contribute to xlyze/home-termux-1 development by creating an account on GitHub.">
    <link rel="search" type="application/opensearchdescription+xml" href="https://github.com/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">
  <meta name="apple-itunes-app" content="app-id=1477376905">
    <meta name="twitter:image:src" content="https://opengraph.githubassets.com/17cdb15ea48a1aeecabcca3159847c10d409bac38a40c8a83c50932ad629d37c/xlyze/home-termux-1"><meta name="twitter:site" content="@github"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="home-termux-1/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh at master · xlyze/home-termux-1"><meta name="twitter:description" content="Tools untuk merubah tampilan  home pertama termux. Contribute to xlyze/home-termux-1 development by creating an account on GitHub.">
    <meta property="og:image" content="https://opengraph.githubassets.com/17cdb15ea48a1aeecabcca3159847c10d409bac38a40c8a83c50932ad629d37c/xlyze/home-termux-1"><meta property="og:image:alt" content="Tools untuk merubah tampilan  home pertama termux. Contribute to xlyze/home-termux-1 development by creating an account on GitHub."><meta property="og:image:width" content="1200"><meta property="og:image:height" content="600"><meta property="og:site_name" content="GitHub"><meta property="og:type" content="object"><meta property="og:title" content="home-termux-1/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh at master · xlyze/home-termux-1"><meta property="og:url" content="https://github.com/xlyze/home-termux-1"><meta property="og:description" content="Tools untuk merubah tampilan  home pertama termux. Contribute to xlyze/home-termux-1 development by creating an account on GitHub.">
    



    

  <link rel="assets" href="https://github.githubassets.com/">
    <link rel="shared-web-socket" href="wss://alive.github.com/_sockets/u/96439587/ws?session=eyJ2IjoiVjMiLCJ1Ijo5NjQzOTU4NywicyI6ODAzMDYwNDE2LCJjIjo4MTAxNzA1NDUsInQiOjE2NDAwNDkxMTJ9--e0b36d9bdafca4ee7c261c628a5befac3d1a4e1835306a8c28f8c1d5579f850e" data-refresh-url="/_alive" data-session-id="01a3682bf065d71303d8ea317eaf6591bba8870bddf3b4f4fb0edb8db125dbaa">
    <link rel="shared-web-socket-src" href="https://github.com/assets-cdn/worker/socket-worker-9c817d86.js">
  <link rel="sudo-modal" href="https://github.com/sessions/sudo_modal">

  <meta name="request-id" content="332B:42B6:8D5384:AA8E7A:61C129C7" data-pjax-transient="true"><meta name="html-safe-nonce" content="45e2a962b52d720efe94f04a77ebab5bf0587da26688e9b21d91d22c7ba8f8f8" data-pjax-transient="true"><meta name="visitor-payload" content="eyJyZWZlcnJlciI6bnVsbCwicmVxdWVzdF9pZCI6IjMzMkI6NDJCNjo4RDUzODQ6QUE4RTdBOjYxQzEyOUM3IiwidmlzaXRvcl9pZCI6IjU4MDk0MTk3NDAyNjY4Mzg4NjMiLCJyZWdpb25fZWRnZSI6InNvdXRoZWFzdGFzaWEiLCJyZWdpb25fcmVuZGVyIjoiaWFkIn0=" data-pjax-transient="true"><meta name="visitor-hmac" content="b2a05abc91a26cd6a0d4c0fa3fe9e6d395da6ca9446eb2c99a8dcf03b69937a2" data-pjax-transient="true">

    <meta name="hovercard-subject-tag" content="repository:198098423" data-pjax-transient="">


  <meta name="github-keyboard-shortcuts" content="repository,source-code" data-pjax-transient="true">

  

  <meta name="selected-link" value="repo_source" data-pjax-transient="">

    <meta name="google-site-verification" content="c1kuD-K2HIVF635lypcsWPoD4kilo5-jA_wBFyT4uMY">
  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

<meta name="octolytics-url" content="https://collector.githubapp.com/github/collect"><meta name="octolytics-actor-id" content="96439587"><meta name="octolytics-actor-login" content="Din121212"><meta name="octolytics-actor-hash" content="8e056f9aa84a7cb2822359e31ba983fb38813fefea8e47c27091530b78759c74">

  <meta name="analytics-location" content="/<user-name>/<repo-name>/blob/show" data-pjax-transient="true">

  



  <meta name="optimizely-datafile" content="{&quot;version&quot;: &quot;4&quot;, &quot;rollouts&quot;: [], &quot;typedAudiences&quot;: [], &quot;anonymizeIP&quot;: true, &quot;projectId&quot;: &quot;16737760170&quot;, &quot;variables&quot;: [], &quot;featureFlags&quot;: [], &quot;experiments&quot;: [{&quot;status&quot;: &quot;Running&quot;, &quot;audienceIds&quot;: [], &quot;variations&quot;: [{&quot;variables&quot;: [], &quot;id&quot;: &quot;20438636352&quot;, &quot;key&quot;: &quot;control&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;20484957397&quot;, &quot;key&quot;: &quot;treatment&quot;}], &quot;id&quot;: &quot;20479227424&quot;, &quot;key&quot;: &quot;growth_ghec_onboarding_experience&quot;, &quot;layerId&quot;: &quot;20467848595&quot;, &quot;trafficAllocation&quot;: [{&quot;entityId&quot;: &quot;20484957397&quot;, &quot;endOfRange&quot;: 1000}, {&quot;entityId&quot;: &quot;20484957397&quot;, &quot;endOfRange&quot;: 3000}, {&quot;entityId&quot;: &quot;20484957397&quot;, &quot;endOfRange&quot;: 5000}, {&quot;entityId&quot;: &quot;20484957397&quot;, &quot;endOfRange&quot;: 6000}, {&quot;entityId&quot;: &quot;20484957397&quot;, &quot;endOfRange&quot;: 8000}, {&quot;entityId&quot;: &quot;20484957397&quot;, &quot;endOfRange&quot;: 10000}], &quot;forcedVariations&quot;: {&quot;85e2238ce2b9074907d7a3d91d6feeae&quot;: &quot;control&quot;}}, {&quot;status&quot;: &quot;Running&quot;, &quot;audienceIds&quot;: [], &quot;variations&quot;: [{&quot;variables&quot;: [], &quot;id&quot;: &quot;20667381018&quot;, &quot;key&quot;: &quot;control&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;20680930759&quot;, &quot;key&quot;: &quot;treatment&quot;}], &quot;id&quot;: &quot;20652570897&quot;, &quot;key&quot;: &quot;project_genesis&quot;, &quot;layerId&quot;: &quot;20672300363&quot;, &quot;trafficAllocation&quot;: [{&quot;entityId&quot;: &quot;20667381018&quot;, &quot;endOfRange&quot;: 5000}, {&quot;entityId&quot;: &quot;20680930759&quot;, &quot;endOfRange&quot;: 10000}], &quot;forcedVariations&quot;: {&quot;83356e17066d336d1803024138ecb683&quot;: &quot;treatment&quot;, &quot;18e31c8a9b2271332466133162a4aa0d&quot;: &quot;treatment&quot;, &quot;10f8ab3fbc5ebe989a36a05f79d48f32&quot;: &quot;treatment&quot;, &quot;1686089f6d540cd2deeaec60ee43ecf7&quot;: &quot;treatment&quot;}}], &quot;audiences&quot;: [{&quot;conditions&quot;: &quot;[\&quot;or\&quot;, {\&quot;match\&quot;: \&quot;exact\&quot;, \&quot;name\&quot;: \&quot;$opt_dummy_attribute\&quot;, \&quot;type\&quot;: \&quot;custom_attribute\&quot;, \&quot;value\&quot;: \&quot;$opt_dummy_value\&quot;}]&quot;, &quot;id&quot;: &quot;$opt_dummy_audience&quot;, &quot;name&quot;: &quot;Optimizely-Generated Audience for Backwards Compatibility&quot;}], &quot;groups&quot;: [], &quot;sdkKey&quot;: &quot;WTc6awnGuYDdG98CYRban&quot;, &quot;environmentKey&quot;: &quot;production&quot;, &quot;attributes&quot;: [{&quot;id&quot;: &quot;16822470375&quot;, &quot;key&quot;: &quot;user_id&quot;}, {&quot;id&quot;: &quot;17143601254&quot;, &quot;key&quot;: &quot;spammy&quot;}, {&quot;id&quot;: &quot;18175660309&quot;, &quot;key&quot;: &quot;organization_plan&quot;}, {&quot;id&quot;: &quot;18813001570&quot;, &quot;key&quot;: &quot;is_logged_in&quot;}, {&quot;id&quot;: &quot;19073851829&quot;, &quot;key&quot;: &quot;geo&quot;}, {&quot;id&quot;: &quot;20175462351&quot;, &quot;key&quot;: &quot;requestedCurrency&quot;}, {&quot;id&quot;: &quot;20785470195&quot;, &quot;key&quot;: &quot;country_code&quot;}], &quot;botFiltering&quot;: false, &quot;accountId&quot;: &quot;16737760170&quot;, &quot;events&quot;: [{&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;17911811441&quot;, &quot;key&quot;: &quot;hydro_click.dashboard.teacher_toolbox_cta&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18124116703&quot;, &quot;key&quot;: &quot;submit.organizations.complete_sign_up&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18145892387&quot;, &quot;key&quot;: &quot;no_metric.tracked_outside_of_optimizely&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18178755568&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.add_repo&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18180553241&quot;, &quot;key&quot;: &quot;submit.repository_imports.create&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18186103728&quot;, &quot;key&quot;: &quot;click.help.learn_more_about_repository_creation&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18188530140&quot;, &quot;key&quot;: &quot;test_event.do_not_use_in_production&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18191963644&quot;, &quot;key&quot;: &quot;click.empty_org_repo_cta.transfer_repository&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18195612788&quot;, &quot;key&quot;: &quot;click.empty_org_repo_cta.import_repository&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18210945499&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.invite_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18211063248&quot;, &quot;key&quot;: &quot;click.empty_org_repo_cta.create_repository&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18215721889&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.update_profile&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18224360785&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.dismiss&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18234832286&quot;, &quot;key&quot;: &quot;submit.organization_activation.complete&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18252392383&quot;, &quot;key&quot;: &quot;submit.org_repository.create&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18257551537&quot;, &quot;key&quot;: &quot;submit.org_member_invitation.create&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18259522260&quot;, &quot;key&quot;: &quot;submit.organization_profile.update&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18564603625&quot;, &quot;key&quot;: &quot;view.classroom_select_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18568612016&quot;, &quot;key&quot;: &quot;click.classroom_sign_in_click&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18572592540&quot;, &quot;key&quot;: &quot;view.classroom_name&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18574203855&quot;, &quot;key&quot;: &quot;click.classroom_create_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18582053415&quot;, &quot;key&quot;: &quot;click.classroom_select_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18589463420&quot;, &quot;key&quot;: &quot;click.classroom_create_classroom&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18591323364&quot;, &quot;key&quot;: &quot;click.classroom_create_first_classroom&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18591652321&quot;, &quot;key&quot;: &quot;click.classroom_grant_access&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18607131425&quot;, &quot;key&quot;: &quot;view.classroom_creation&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;18831680583&quot;, &quot;key&quot;: &quot;upgrade_account_plan&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19064064515&quot;, &quot;key&quot;: &quot;click.signup&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19075373687&quot;, &quot;key&quot;: &quot;click.view_account_billing_page&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19077355841&quot;, &quot;key&quot;: &quot;click.dismiss_signup_prompt&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19079713938&quot;, &quot;key&quot;: &quot;click.contact_sales&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19120963070&quot;, &quot;key&quot;: &quot;click.compare_account_plans&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19151690317&quot;, &quot;key&quot;: &quot;click.upgrade_account_cta&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19424193129&quot;, &quot;key&quot;: &quot;click.open_account_switcher&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19520330825&quot;, &quot;key&quot;: &quot;click.visit_account_profile&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19540970635&quot;, &quot;key&quot;: &quot;click.switch_account_context&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19730198868&quot;, &quot;key&quot;: &quot;submit.homepage_signup&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19820830627&quot;, &quot;key&quot;: &quot;click.homepage_signup&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19988571001&quot;, &quot;key&quot;: &quot;click.create_enterprise_trial&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20036538294&quot;, &quot;key&quot;: &quot;click.create_organization_team&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20040653299&quot;, &quot;key&quot;: &quot;click.input_enterprise_trial_form&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20062030003&quot;, &quot;key&quot;: &quot;click.continue_with_team&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20068947153&quot;, &quot;key&quot;: &quot;click.create_organization_free&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20086636658&quot;, &quot;key&quot;: &quot;click.signup_continue.username&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20091648988&quot;, &quot;key&quot;: &quot;click.signup_continue.create_account&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20103637615&quot;, &quot;key&quot;: &quot;click.signup_continue.email&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20111574253&quot;, &quot;key&quot;: &quot;click.signup_continue.password&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20120044111&quot;, &quot;key&quot;: &quot;view.pricing_page&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20152062109&quot;, &quot;key&quot;: &quot;submit.create_account&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20165800992&quot;, &quot;key&quot;: &quot;submit.upgrade_payment_form&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20171520319&quot;, &quot;key&quot;: &quot;submit.create_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20222645674&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.discuss_your_needs&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20227443657&quot;, &quot;key&quot;: &quot;submit.verify_primary_user_email&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20234607160&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.try_enterprise&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20238175784&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.team&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20239847212&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.continue_free&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20251097193&quot;, &quot;key&quot;: &quot;recommended_plan&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20438619534&quot;, &quot;key&quot;: &quot;click.pricing_calculator.1_member&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20456699683&quot;, &quot;key&quot;: &quot;click.pricing_calculator.15_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20467868331&quot;, &quot;key&quot;: &quot;click.pricing_calculator.10_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20476267432&quot;, &quot;key&quot;: &quot;click.trial_days_remaining&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20476357660&quot;, &quot;key&quot;: &quot;click.discover_feature&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20479287901&quot;, &quot;key&quot;: &quot;click.pricing_calculator.custom_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20481107083&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.apply_teacher_benefits&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20483089392&quot;, &quot;key&quot;: &quot;click.pricing_calculator.5_members&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;, &quot;20652570897&quot;], &quot;id&quot;: &quot;20484283944&quot;, &quot;key&quot;: &quot;click.onboarding_task&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20484996281&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.apply_student_benefits&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20486713726&quot;, &quot;key&quot;: &quot;click.onboarding_task_breadcrumb&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20490791319&quot;, &quot;key&quot;: &quot;click.upgrade_to_enterprise&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20491786766&quot;, &quot;key&quot;: &quot;click.talk_to_us&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20494144087&quot;, &quot;key&quot;: &quot;click.dismiss_enterprise_trial&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;, &quot;20652570897&quot;], &quot;id&quot;: &quot;20499722759&quot;, &quot;key&quot;: &quot;completed_all_tasks&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;, &quot;20652570897&quot;], &quot;id&quot;: &quot;20500710104&quot;, &quot;key&quot;: &quot;completed_onboarding_tasks&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20513160672&quot;, &quot;key&quot;: &quot;click.read_doc&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20516196762&quot;, &quot;key&quot;: &quot;actions_enabled&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20518980986&quot;, &quot;key&quot;: &quot;click.dismiss_trial_banner&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20535446721&quot;, &quot;key&quot;: &quot;click.issue_actions_prompt.dismiss_prompt&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20557002247&quot;, &quot;key&quot;: &quot;click.issue_actions_prompt.setup_workflow&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20595070227&quot;, &quot;key&quot;: &quot;click.pull_request_setup_workflow&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20626600314&quot;, &quot;key&quot;: &quot;click.seats_input&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20642310305&quot;, &quot;key&quot;: &quot;click.decrease_seats_number&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20662990045&quot;, &quot;key&quot;: &quot;click.increase_seats_number&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20679620969&quot;, &quot;key&quot;: &quot;click.public_product_roadmap&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20761240940&quot;, &quot;key&quot;: &quot;click.dismiss_survey_banner&quot;}, {&quot;experimentIds&quot;: [&quot;20479227424&quot;], &quot;id&quot;: &quot;20767210721&quot;, &quot;key&quot;: &quot;click.take_survey&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20795281201&quot;, &quot;key&quot;: &quot;click.archive_list&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20966790249&quot;, &quot;key&quot;: &quot;contact_sales.submit&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20996500333&quot;, &quot;key&quot;: &quot;contact_sales.existing_customer&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20996890162&quot;, &quot;key&quot;: &quot;contact_sales.blank_message_field&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21000470317&quot;, &quot;key&quot;: &quot;contact_sales.personal_email&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21002790172&quot;, &quot;key&quot;: &quot;contact_sales.blank_phone_field&quot;}], &quot;revision&quot;: &quot;1018&quot;}">
  <!-- To prevent page flashing, the optimizely JS needs to be loaded in the
    <head> tag before the DOM renders -->
  



  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="Din121212">


      <meta name="expected-hostname" content="github.com">

      <meta name="js-proxy-site-detection-payload" content="OWE5ZGMwMjBiODdkNTNlOGE1NGI2NGIwNWQzMmQwMzk3YzMzYzkyMDc0NjBjNTk4MjM2MGYwNTA5YzE5MjQ4Nnx7InJlbW90ZV9hZGRyZXNzIjoiMTgwLjI0NC4xNjEuMjkiLCJyZXF1ZXN0X2lkIjoiMzMyQjo0MkI2OjhENTM4NDpBQThFN0E6NjFDMTI5QzciLCJ0aW1lc3RhbXAiOjE2NDAwNDkxMTIsImhvc3QiOiJnaXRodWIuY29tIn0=">
      <meta name="keyboard-shortcuts-preference" content="all">
      

    <meta name="enabled-features" content="ACTIONS_CALLABLE_WORKFLOWS,MARKETPLACE_PENDING_INSTALLATIONS,FILE_UPLOAD_CURSOR_POSITION,LINKIFY_SELECTED_TEXT_ON_URL_PASTE,PRESENCE_IDLE">


  <meta http-equiv="x-pjax-version" content="be73507bd60279255b2ac4d863b99349f549aab499e62f6889372662186c6b3d">
  <meta http-equiv="x-pjax-csp-version" content="9ea82e8060ac9d44365bfa193918b70ed58abd9413362ba412abb161b3a8d1b6">
  <meta http-equiv="x-pjax-css-version" content="9d74a89bdb762b31efa033097d2f1c7d7943bfb29ecdd923fd0772f1007c792e">
  <meta http-equiv="x-pjax-js-version" content="fe46975a1268a3f25e7344f7981e8dda9c42a8ad549f0a062f138cc649947577">
  

    
  <meta name="go-import" content="github.com/xlyze/home-termux-1 git https://github.com/xlyze/home-termux-1.git">

  <meta name="octolytics-dimension-user_id" content="53153472"><meta name="octolytics-dimension-user_login" content="xlyze"><meta name="octolytics-dimension-repository_id" content="198098423"><meta name="octolytics-dimension-repository_nwo" content="xlyze/home-termux-1"><meta name="octolytics-dimension-repository_public" content="true"><meta name="octolytics-dimension-repository_is_fork" content="true"><meta name="octolytics-dimension-repository_parent_id" content="164990487"><meta name="octolytics-dimension-repository_parent_nwo" content="Rusmana-ID/home-termux"><meta name="octolytics-dimension-repository_network_root_id" content="164990487"><meta name="octolytics-dimension-repository_network_root_nwo" content="Rusmana-ID/home-termux">



    <link rel="canonical" href="https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" data-pjax-transient="">


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <meta name="browser-optimizely-client-errors-url" content="https://api.github.com/_private/browser/optimizely_client/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark">


  <link rel="manifest" href="https://github.com/manifest.json" crossorigin="use-credentials">

  </head>

  <body class="logged-in env-production page-responsive page-blob" style="word-wrap: break-word;">
    

    <div class="position-relative js-header-wrapper ">
      <a href="https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh#start-of-content" class="p-3 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>
      <span data-view-component="true" class="progress-pjax-loader js-pjax-loader-bar Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      


        

            <header class="Header js-details-container Details px-3 px-md-4 px-lg-5 flex-wrap flex-md-nowrap" role="banner">
    <div class="Header-item mt-n1 mb-n1  d-none d-md-flex">
      <a class="Header-link " href="https://github.com/" data-hotkey="g d" aria-label="Homepage " data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;go to dashboard&quot;,&quot;label&quot;:&quot;icon:logo&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="5767182ae69140f4c79506f4da6b8f1550645625cfe57f8c66cdf3423a5dc454" data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;go to dashboard&quot;,&quot;label&quot;:&quot;icon:logo&quot;}">
  <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github v-align-middle">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
</a>

    </div>

    <div class="Header-item d-md-none">
      <button aria-label="Toggle navigation" aria-expanded="false" type="button" data-view-component="true" class="Header-link js-details-target btn-link">  <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-three-bars">
    <path fill-rule="evenodd" d="M1 2.75A.75.75 0 011.75 2h12.5a.75.75 0 110 1.5H1.75A.75.75 0 011 2.75zm0 5A.75.75 0 011.75 7h12.5a.75.75 0 110 1.5H1.75A.75.75 0 011 7.75zM1.75 12a.75.75 0 100 1.5h12.5a.75.75 0 100-1.5H1.75z"></path>
</svg>
</button>    </div>

    <div class="Header-item Header-item--full flex-column flex-md-row width-full flex-order-2 flex-md-order-none mr-0 mr-md-3 mt-3 mt-md-0 Details-content--hidden-not-important d-md-flex">
          



<div class="header-search flex-auto js-site-search position-relative flex-self-stretch flex-md-self-auto mb-3 mb-md-0 mr-0 mr-md-3 scoped-search site-scoped-search">
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --><form class="js-site-search-form" role="search" aria-label="Site" data-scope-type="Repository" data-scope-id="198098423" data-scoped-search-url="/xlyze/home-termux-1/search" data-owner-scoped-search-url="/users/xlyze/search" data-unscoped-search-url="/search" action="https://github.com/xlyze/home-termux-1/search" accept-charset="UTF-8" method="get">
      <label class="form-control input-sm header-search-wrapper p-0 js-chromeless-input-container">
            <a class="header-search-scope no-underline" href="https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">This repository</a>
        <input type="text" class="form-control input-sm header-search-input  js-site-search-focus js-site-search-field is-clearable" data-hotkey="s,/" name="q" data-test-selector="nav-search-input" placeholder="Search" data-unscoped-placeholder="Search GitHub" data-scoped-placeholder="Search" autocapitalize="off" aria-label="Search this repository">
        
        
      </label>
</form>  </div>
</div>

        <nav class="d-flex flex-column flex-md-row flex-self-stretch flex-md-self-auto" aria-label="Global">
      <a class="Header-link py-md-3 d-block d-md-none py-2 border-top border-md-top-0 border-white-fade" data-ga-click="Header, click, Nav menu - item:dashboard:user" aria-label="Dashboard" href="https://github.com/dashboard">
        Dashboard
</a>
    <a class="js-selected-navigation-item Header-link mt-md-n3 mb-md-n3 py-2 py-md-3 mr-0 mr-md-3 border-top border-md-top-0 border-white-fade" data-hotkey="g p" data-ga-click="Header, click, Nav menu - item:pulls context:user" aria-label="Pull requests you created" data-selected-links="/pulls /pulls/assigned /pulls/mentioned /pulls" href="https://github.com/pulls">
        Pull<span class="d-inline d-md-none d-lg-inline"> request</span>s
</a>
    <a class="js-selected-navigation-item Header-link mt-md-n3 mb-md-n3 py-2 py-md-3 mr-0 mr-md-3 border-top border-md-top-0 border-white-fade" data-hotkey="g i" data-ga-click="Header, click, Nav menu - item:issues context:user" aria-label="Issues you created" data-selected-links="/issues /issues/assigned /issues/mentioned /issues" href="https://github.com/issues">
      Issues
</a>
      <div class="d-flex position-relative">
        <a class="js-selected-navigation-item Header-link flex-auto mt-md-n3 mb-md-n3 py-2 py-md-3 mr-0 mr-md-3 border-top border-md-top-0 border-white-fade" data-ga-click="Header, click, Nav menu - item:marketplace context:user" data-octo-click="marketplace_click" data-octo-dimensions="location:nav_bar" data-selected-links=" /marketplace" href="https://github.com/marketplace">
          Marketplace
</a>      </div>

    <a class="js-selected-navigation-item Header-link mt-md-n3 mb-md-n3 py-2 py-md-3 mr-0 mr-md-3 border-top border-md-top-0 border-white-fade" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship showcases showcases_search showcases_landing /explore" href="https://github.com/explore">
      Explore
</a>
    <a class="js-selected-navigation-item Header-link d-block d-md-none py-2 py-md-3 border-top border-md-top-0 border-white-fade" data-ga-click="Header, click, Nav menu - item:workspaces context:user" data-selected-links="/codespaces /codespaces" href="https://github.com/codespaces">
      Codespaces
</a>
      <a class="js-selected-navigation-item Header-link d-block d-md-none py-2 py-md-3 border-top border-md-top-0 border-white-fade" data-ga-click="Header, click, Nav menu - item:Sponsors" data-hydro-click="{&quot;event_type&quot;:&quot;sponsors.button_click&quot;,&quot;payload&quot;:{&quot;button&quot;:&quot;HEADER_SPONSORS_DASHBOARD&quot;,&quot;sponsorable_login&quot;:&quot;Din121212&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="3c5d4eb9f3ba60dd33a7d4f41a2d57e53a554af2ad39fc99affdd67be884b842" data-selected-links=" /sponsors/accounts" href="https://github.com/sponsors/accounts">Sponsors</a>

    <a class="Header-link d-block d-md-none mr-0 mr-md-3 py-2 py-md-3 border-top border-md-top-0 border-white-fade" href="https://github.com/settings/profile">
      Settings
</a>
    <a class="Header-link d-block d-md-none mr-0 mr-md-3 py-2 py-md-3 border-top border-md-top-0 border-white-fade" href="https://github.com/Din121212">
      <img class="avatar avatar-user" loading="lazy" decoding="async" src="https://avatars.githubusercontent.com/u/96439587?s=40&amp;v=4" width="20" height="20" alt="@Din121212">
      Din121212
</a>
    <!-- '"` --><!-- </textarea></xmp> --><form action="https://github.com/logout" accept-charset="UTF-8" method="post">
      <button type="submit" class="Header-link mr-0 mr-md-3 py-2 py-md-3 border-top border-md-top-0 border-white-fade d-md-none btn-link d-block width-full text-left" style="padding-left: 2px;" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;sign out&quot;,&quot;label&quot;:&quot;icon:logout&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="e02d0abe9dff5aa16dd095c9ee71b024195eff507ff3b9d95e16237f47ba7c90" data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;sign out&quot;,&quot;label&quot;:&quot;icon:logout&quot;}">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-sign-out v-align-middle">
    <path fill-rule="evenodd" d="M2 2.75C2 1.784 2.784 1 3.75 1h2.5a.75.75 0 010 1.5h-2.5a.25.25 0 00-.25.25v10.5c0 .138.112.25.25.25h2.5a.75.75 0 010 1.5h-2.5A1.75 1.75 0 012 13.25V2.75zm10.44 4.5H6.75a.75.75 0 000 1.5h5.69l-1.97 1.97a.75.75 0 101.06 1.06l3.25-3.25a.75.75 0 000-1.06l-3.25-3.25a.75.75 0 10-1.06 1.06l1.97 1.97z"></path>
</svg>
        Sign out
      </button>
</form></nav>

    </div>

    <div class="Header-item Header-item--full flex-justify-center d-md-none position-relative">
        <a class="Header-link " href="https://github.com/" data-hotkey="g d" aria-label="Homepage " data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;go to dashboard&quot;,&quot;label&quot;:&quot;icon:logo&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="5767182ae69140f4c79506f4da6b8f1550645625cfe57f8c66cdf3423a5dc454" data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;go to dashboard&quot;,&quot;label&quot;:&quot;icon:logo&quot;}">
  <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github v-align-middle">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
</a>

    </div>

    <div class="Header-item mr-0 mr-md-3 flex-order-1 flex-md-order-none">
        


      <notification-indicator class="js-socket-channel" data-test-selector="notifications-indicator" data-channel="eyJjIjoibm90aWZpY2F0aW9uLWNoYW5nZWQ6OTY0Mzk1ODciLCJ0IjoxNjQwMDQ5MTEyfQ==--cede1d3396c8d1c270bbafd827c411d0c45fc0a6b2d7d1323949e8fda6d30668" data-catalyst="">
        <a href="https://github.com/notifications" class="Header-link notification-indicator position-relative tooltipped tooltipped-sw" aria-label="You have no unread notifications" data-hotkey="g n" data-ga-click="Header, go to notifications, icon:read" data-target="notification-indicator.link">
          <span class="mail-status  " data-target="notification-indicator.modifier"></span>
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bell">
    <path d="M8 16a2 2 0 001.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 008 16z"></path><path fill-rule="evenodd" d="M8 1.5A3.5 3.5 0 004.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.018.018 0 00-.003.01l.001.006c0 .002.002.004.004.006a.017.017 0 00.006.004l.007.001h10.964l.007-.001a.016.016 0 00.006-.004.016.016 0 00.004-.006l.001-.007a.017.017 0 00-.003-.01l-1.703-2.554a1.75 1.75 0 01-.294-.97V5A3.5 3.5 0 008 1.5zM3 5a5 5 0 0110 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.518 1.518 0 0113.482 13H2.518a1.518 1.518 0 01-1.263-2.36l1.703-2.554A.25.25 0 003 7.947V5z"></path>
</svg>
        </a>
      </notification-indicator>

    </div>


    <div class="Header-item position-relative d-none d-md-flex">
        <details class="details-overlay details-reset">
  <summary class="Header-link" aria-label="Create new…" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;create new&quot;,&quot;label&quot;:&quot;icon:add&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="aedcf80c5b583643933a75179cf575cb4743acbaf3b29e504d9c76484a558add" data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;create new&quot;,&quot;label&quot;:&quot;icon:add&quot;}" aria-haspopup="menu" role="button">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus">
    <path fill-rule="evenodd" d="M7.75 2a.75.75 0 01.75.75V7h4.25a.75.75 0 110 1.5H8.5v4.25a.75.75 0 11-1.5 0V8.5H2.75a.75.75 0 010-1.5H7V2.75A.75.75 0 017.75 2z"></path>
</svg> <span class="dropdown-caret"></span>
  </summary>
  <details-menu class="dropdown-menu dropdown-menu-sw" role="menu">
    
<a role="menuitem" class="dropdown-item" href="https://github.com/new" data-ga-click="Header, create new repository">
  New repository
</a>

  <a role="menuitem" class="dropdown-item" href="https://github.com/new/import" data-ga-click="Header, import a repository">
    Import repository
  </a>

<a role="menuitem" class="dropdown-item" href="https://gist.github.com/" data-ga-click="Header, create new gist">
  New gist
</a>

  <a role="menuitem" class="dropdown-item" href="https://github.com/organizations/new" data-ga-click="Header, create new organization">
    New organization
  </a>



  </details-menu>
</details>

    </div>

    <div class="Header-item position-relative mr-0 d-none d-md-flex">
        
  <details class="details-overlay details-reset js-feature-preview-indicator-container" data-feature-preview-indicator-src="/users/Din121212/feature_preview/indicator_check">

  <summary class="Header-link" aria-label="View profile and more" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;show menu&quot;,&quot;label&quot;:&quot;icon:avatar&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="61ccf6c24feb0ea0175faa046afdb922eb791911182f32561fe11d57d444acee" data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;show menu&quot;,&quot;label&quot;:&quot;icon:avatar&quot;}" aria-haspopup="menu" role="button">
    <img src="https://avatars.githubusercontent.com/u/96439587?s=40&amp;v=4" alt="@Din121212" size="20" height="20" width="20" data-view-component="true" class="avatar avatar-small circle">
      
    <span class="dropdown-caret"></span>
  </summary>
  <details-menu class="dropdown-menu dropdown-menu-sw" style="width: 180px" src="/users/96439587/menu" preload="" role="menu">
      <include-fragment>
        <p class="text-center mt-3" data-hide-on-error="">
          <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke"></circle>
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>
</svg>
        </p>
        <p class="ml-1 mb-2 mt-2 color-fg-default" data-show-on-error="">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
          Sorry, something went wrong.
        </p>
      </include-fragment>
  </details-menu>
</details>

    </div>
</header>

            
    </div>

  <div id="start-of-content" class="show-on-focus"></div>







    <div data-pjax-replace="" id="js-flash-container">


  <template class="js-flash-template">
    <div class="flash flash-full  {{ className }}">
  <div class=" px-2">
    <button class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    
      <div>{{ message }}</div>

  </div>
</div>
  </template>
</div>


    

  <include-fragment class="js-notification-shelf-include-fragment" data-base-src="https://github.com/notifications/beta/shelf"></include-fragment>




      <details class="details-reset details-overlay details-overlay-dark js-command-palette-dialog">
  <summary class="command-palette-details-summary" aria-label="command palette trigger" role="button">
  </summary>
  <details-dialog class="command-palette-details-dialog d-flex flex-column flex-justify-center height-fit" aria-label="command palette" role="dialog" aria-modal="true">
    <command-palette class="command-palette color-bg-default rounded-3" data-return-to="/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" data-user-id="96439587" data-catalyst="">
      
      <iframe class="d-none js-command-palette-commands" sandbox="allow-scripts allow-same-origin" src="cid:frame-5B39253A2AEADC7375343C68344218FF@mhtml.blink" aria-hidden="true" data-url="https://github.com"></iframe>
      
      

        <command-palette-mode data-char="#" data-scope-types="[&quot;&quot;]" data-placeholder="Search issues and pull requests" data-catalyst=""></command-palette-mode>
        <command-palette-mode data-char="#" data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]" data-placeholder="Search issues, pull requests, discussions, and projects" data-catalyst=""></command-palette-mode>
        <command-palette-mode data-char="!" data-scope-types="[&quot;owner&quot;,&quot;repository&quot;]" data-placeholder="Search projects" data-catalyst=""></command-palette-mode>
        <command-palette-mode data-char="@" data-scope-types="[&quot;&quot;]" data-placeholder="Search or jump to a user, organization, or repository" data-catalyst=""></command-palette-mode>
        <command-palette-mode data-char="@" data-scope-types="[&quot;owner&quot;]" data-placeholder="Search or jump to a repository" data-catalyst=""></command-palette-mode>
        <command-palette-mode data-char="/" data-scope-types="[&quot;repository&quot;]" data-placeholder="Search files" data-catalyst=""></command-palette-mode>
        <command-palette-mode data-char="?" data-catalyst="" data-placeholder="" data-scope-types=""></command-palette-mode>
        <command-palette-mode data-char=">" data-placeholder="Run a command" data-catalyst="" data-scope-types=""></command-palette-mode>
        <command-palette-mode data-char="" data-scope-types="[&quot;owner&quot;]" data-placeholder="Search or jump to..." data-catalyst=""></command-palette-mode>
      <command-palette-mode class="js-command-palette-default-mode" data-char="" data-placeholder="Search or jump to..." data-catalyst="" data-scope-types=""></command-palette-mode>

      <command-palette-input placeholder="Search or jump to..." data-catalyst="" class="d-flex flex-items-center flex-nowrap py-1 pl-3 pr-2 border-bottom">
        <div class="js-search-icon d-flex flex-items-center mr-2" style="height: 26px">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search color-fg-muted">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
        </div>
        
        <command-palette-scope data-catalyst="" class="Truncate d-inline-flex">
              <command-palette-token data-text="xlyze" data-id="MDQ6VXNlcjUzMTUzNDcy" data-type="owner" data-value="xlyze" data-targets="command-palette-scope.tokens" class="color-fg-default text-semibold" id="" data-catalyst="">xlyze<span class="color-fg-subtle text-normal">&nbsp;&nbsp;/&nbsp;&nbsp;</span></command-palette-token>
              <command-palette-token data-text="home-termux-1" data-id="MDEwOlJlcG9zaXRvcnkxOTgwOTg0MjM=" data-type="repository" data-value="home-termux-1" data-targets="command-palette-scope.tokens" class="color-fg-default text-semibold" id="" data-catalyst="">home-termux-1<span class="color-fg-subtle text-normal">&nbsp;&nbsp;/&nbsp;&nbsp;</span></command-palette-token>
        </command-palette-scope>
      
        <div class="command-palette-input-group flex-1 form-control border-0 box-shadow-none" style="z-index: 0">
          <div class="command-palette-typeahead position-absolute d-flex flex-items-center Truncate">
            <span class="typeahead-segment input-mirror" data-target="command-palette-input.mirror"></span>
            <span class="Truncate-text" data-target="command-palette-input.typeaheadText"></span>
            <span class="typeahead-segment" data-target="command-palette-input.typeaheadPlaceholder"></span>
          </div>
          <input class="js-overlay-input typeahead-input d-none" disabled="" tabindex="-1" aria-label="Hidden input for typeahead">
          <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="js-input typeahead-input form-control border-0 box-shadow-none input-block width-full" aria-label="Command palette input" aria-haspopup="listbox" aria-expanded="false" aria-autocomplete="list" aria-controls="command-palette-item-stack" role="combobox" placeholder="Search or jump to...">
        </div>
        <button class="js-clear btn-link color-fg-muted no-underline px-2 tooltipped tooltipped-w" role="button" tabindex="0" aria-label="Ctrl + Backspace">
          Clear
        </button>
      </command-palette-input>

        <command-palette-item-stack id="command-palette-item-stack" class="item-stack-transition-height rounded-bottom-2" role="listbox" aria-label="Command palette results" data-catalyst="" data-top-group-threshold="6.5" data-max-height-vh="65">
          
          
          
          
          

            
            
            
            
            
            
            
            
            
            
            
            
            
            
        </command-palette-item-stack>

      

      <server-defined-provider data-type="search-links" data-catalyst="" data-supported-modes="" data-fetch-debounce="" data-supported-scope-types="" data-src="" data-supports-commands=""></server-defined-provider>
      <server-defined-provider data-type="help" data-catalyst="" data-supported-modes="" data-fetch-debounce="" data-supported-scope-types="" data-src="" data-supports-commands="">
          
          
          
          
          
          
          
          
          
          
          
          
          
      </server-defined-provider>
        <server-defined-provider data-type="prefetched" data-fetch-debounce="0" data-src="/command_palette/commands" data-supported-modes="[&quot;>&quot;]" data-supports-commands="" data-catalyst="" data-supported-scope-types=""></server-defined-provider>
        <server-defined-provider data-type="prefetched" data-fetch-debounce="0" data-src="/command_palette/jump_to_page_navigation" data-supported-modes="[&quot;&quot;]" data-catalyst="" data-supported-scope-types="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/issues" data-supported-modes="[&quot;#&quot;,&quot;#&quot;]" data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;,&quot;&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/jump_to" data-supported-modes="[&quot;@&quot;,&quot;@&quot;]" data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/jump_to_members_only" data-supported-modes="[&quot;&quot;]" data-catalyst="" data-supported-scope-types="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="prefetched" data-fetch-debounce="0" data-src="/command_palette/jump_to_members_only_prefetched" data-supported-modes="[&quot;@&quot;,&quot;@&quot;,&quot;&quot;]" data-supported-scope-types="[&quot;&quot;,&quot;owner&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="files" data-fetch-debounce="0" data-src="/command_palette/files" data-supported-modes="[&quot;/&quot;]" data-supported-scope-types="[&quot;repository&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/discussions" data-supported-modes="[&quot;#&quot;]" data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/projects" data-supported-modes="[&quot;#&quot;,&quot;!&quot;]" data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="prefetched" data-fetch-debounce="0" data-src="/command_palette/recent_issues" data-supported-modes="[&quot;#&quot;,&quot;#&quot;]" data-supported-scope-types="[&quot;owner&quot;,&quot;repository&quot;,&quot;&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/teams" data-supported-modes="[&quot;@&quot;,&quot;&quot;]" data-supported-scope-types="[&quot;owner&quot;]" data-catalyst="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="remote" data-fetch-debounce="200" data-src="/command_palette/name_with_owner_repository" data-supported-modes="[&quot;&quot;]" data-catalyst="" data-supported-scope-types="" data-supports-commands=""></server-defined-provider>
        <server-defined-provider data-type="main-window-commands" data-fetch-debounce="0" data-supported-modes="[&quot;>&quot;]" data-supports-commands="" data-catalyst="" data-supported-scope-types="" data-src=""></server-defined-provider>
    </command-palette>
  </details-dialog>
</details>

<div class="position-fixed bottom-0 left-0 ml-5 mb-5 js-command-palette-toasts" style="z-index: 1000">
  

  

  


  

  
</div>

      


  <div class="application-main " data-commit-hovercards-enabled="" data-discussion-hovercards-enabled="" data-issue-and-pr-hovercards-enabled="">
        <div itemscope="" itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" data-pjax-container="">
      

    







  <div id="repository-container-header" class="pt-3 hide-full-screen mb-5" style="background-color: var(--color-page-header-bg);" data-pjax-replace="">

      <div class="d-flex mb-3 px-3 px-md-4 px-lg-5">

        <div class="flex-auto min-width-0 width-fit mr-3">
            <h1 class=" d-flex flex-wrap flex-items-center wb-break-word f3 text-normal">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked color-fg-muted mr-2">
    <path fill-rule="evenodd" d="M5 3.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm0 2.122a2.25 2.25 0 10-1.5 0v.878A2.25 2.25 0 005.75 8.5h1.5v2.128a2.251 2.251 0 101.5 0V8.5h1.5a2.25 2.25 0 002.25-2.25v-.878a2.25 2.25 0 10-1.5 0v.878a.75.75 0 01-.75.75h-4.5A.75.75 0 015 6.25v-.878zm3.75 7.378a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm3-8.75a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
</svg>
  <span class="author flex-self-stretch" itemprop="author">
    <a class="url fn" rel="author" data-hovercard-type="user" data-hovercard-url="/users/xlyze/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="https://github.com/xlyze">xlyze</a>
  </span>
  <span class="mx-1 flex-self-stretch color-fg-muted">/</span>
  <strong itemprop="name" class="mr-2 flex-self-stretch">
    <a data-pjax="#repo-content-pjax-container" href="https://github.com/xlyze/home-termux-1">home-termux-1</a>
  </strong>

  <span></span><span class="Label Label--secondary v-align-middle mr-1">Public</span>
</h1>
  <span class="text-small lh-condensed-ultra no-wrap mt-1" data-repository-hovercards-enabled="">
    forked from <a data-hovercard-type="repository" data-hovercard-url="/Rusmana-ID/home-termux/hovercard" href="https://github.com/Rusmana-ID/home-termux">Rusmana-ID/home-termux</a>
  </span>

        </div>

          <ul class="pagehead-actions flex-shrink-0 d-none d-md-inline" style="padding: 2px 0;">

  <li>
        <notifications-list-subscription-form class="f5 position-relative " data-catalyst="">
      <details class="details-reset details-overlay f5 position-relative" data-target="notifications-list-subscription-form.details" data-action="toggle:notifications-list-subscription-form#detailsToggled">

      <summary data-hydro-click="{&quot;event_type&quot;:&quot;repository.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;WATCH_BUTTON&quot;,&quot;repository_id&quot;:198098423,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="1ea791267f7dd5e42ccd74390384b0d71d071a4c16ace2d49d24e81024b51dec" data-ga-click="Repository, click Watch settings, action:blob#show" aria-label="Notification settings" data-view-component="true" class="btn-sm btn" role="button" aria-haspopup="menu">  <span data-menu-button="">
            
            
            <span data-target="notifications-list-subscription-form.watchButtonCopy">
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-eye">
    <path fill-rule="evenodd" d="M1.679 7.932c.412-.621 1.242-1.75 2.366-2.717C5.175 4.242 6.527 3.5 8 3.5c1.473 0 2.824.742 3.955 1.715 1.124.967 1.954 2.096 2.366 2.717a.119.119 0 010 .136c-.412.621-1.242 1.75-2.366 2.717C10.825 11.758 9.473 12.5 8 12.5c-1.473 0-2.824-.742-3.955-1.715C2.92 9.818 2.09 8.69 1.679 8.068a.119.119 0 010-.136zM8 2c-1.981 0-3.67.992-4.933 2.078C1.797 5.169.88 6.423.43 7.1a1.619 1.619 0 000 1.798c.45.678 1.367 1.932 2.637 3.024C4.329 13.008 6.019 14 8 14c1.981 0 3.67-.992 4.933-2.078 1.27-1.091 2.187-2.345 2.637-3.023a1.619 1.619 0 000-1.798c-.45-.678-1.367-1.932-2.637-3.023C11.671 2.992 9.981 2 8 2zm0 8a2 2 0 100-4 2 2 0 000 4z"></path>
</svg>
              Watch
            </span>
          </span>
            <span id="repo-notifications-counter" data-target="notifications-list-subscription-form.socialCount" data-pjax-replace="true" title="1" data-view-component="true" class="Counter">1</span>
          <span class="dropdown-caret"></span>
</summary>
        <details-menu class="SelectMenu  " role="menu" data-target="notifications-list-subscription-form.menu">
          <div class="SelectMenu-modal notifications-component-menu-modal">
            <header class="SelectMenu-header">
              <h3 class="SelectMenu-title">Notifications</h3>
              <button class="SelectMenu-closeButton" type="button" aria-label="Close menu" data-action="click:notifications-list-subscription-form#closeMenu">
                <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
              </button>
            </header>

            <div class="SelectMenu-list">
              <form data-target="notifications-list-subscription-form.form" data-action="submit:notifications-list-subscription-form#submitForm" action="https://github.com/notifications/subscribe" accept-charset="UTF-8" method="post">

                

                <button type="submit" name="do" value="included" class="SelectMenu-item flex-items-start" role="menuitemradio" aria-checked="true" data-targets="notifications-list-subscription-form.subscriptionButtons">
                  <span class="f5">
                    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
                  </span>
                  <div>
                    <div class="f5 text-bold">
                      Participating and @mentions
                    </div>
                    <div class="text-small color-fg-muted text-normal pb-1">
                      Only receive notifications from this repository when participating or @mentioned.
                    </div>
                  </div>
                </button>

                <button type="submit" name="do" value="subscribed" class="SelectMenu-item flex-items-start" role="menuitemradio" aria-checked="false" data-targets="notifications-list-subscription-form.subscriptionButtons">
                  <span class="f5">
                    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
                  </span>
                  <div>
                    <div class="f5 text-bold">
                      All Activity
                    </div>
                    <div class="text-small color-fg-muted text-normal pb-1">
                      Notified of all notifications on this repository.
                    </div>
                  </div>
                </button>

                <button type="submit" name="do" value="ignore" class="SelectMenu-item flex-items-start" role="menuitemradio" aria-checked="false" data-targets="notifications-list-subscription-form.subscriptionButtons">
                  <span class="f5">
                    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
                  </span>
                  <div>
                    <div class="f5 text-bold">
                      Ignore
                    </div>
                    <div class="text-small color-fg-muted text-normal pb-1">
                      Never be notified.
                    </div>
                  </div>
                </button>
</form>
              <button class="SelectMenu-item flex-items-start pr-3" type="button" role="menuitemradio" data-target="notifications-list-subscription-form.customButton" data-action="click:notifications-list-subscription-form#openCustomDialog" aria-haspopup="true" aria-checked="false">
                <span class="f5">
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
                </span>
                <div>
                  <div class="d-flex flex-items-start flex-justify-between">
                    <div class="f5 text-bold">Custom</div>
                    <div class="f5 pr-1">
                      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-arrow-right">
    <path fill-rule="evenodd" d="M8.22 2.97a.75.75 0 011.06 0l4.25 4.25a.75.75 0 010 1.06l-4.25 4.25a.75.75 0 01-1.06-1.06l2.97-2.97H3.75a.75.75 0 010-1.5h7.44L8.22 4.03a.75.75 0 010-1.06z"></path>
</svg>
                    </div>
                  </div>
                  <div class="text-small color-fg-muted text-normal pb-1">
                    Select events you want to be notified of in addition to participating and @mentions.
                  </div>
                </div>
              </button>

                <div class="px-3 py-2 d-flex color-bg-subtle flex-items-center">
                  <span class="f5">
                    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-device-mobile SelectMenu-icon SelectMenu-icon--device-mobile">
    <path fill-rule="evenodd" d="M3.75 0A1.75 1.75 0 002 1.75v12.5c0 .966.784 1.75 1.75 1.75h8.5A1.75 1.75 0 0014 14.25V1.75A1.75 1.75 0 0012.25 0h-8.5zM3.5 1.75a.25.25 0 01.25-.25h8.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25h-8.5a.25.25 0 01-.25-.25V1.75zM8 13a1 1 0 100-2 1 1 0 000 2z"></path>
</svg>
                  </span>
                  <span classname="text-small color-fg-muted text-normal pb-1">
                    Get push notifications on <a target="_blank" rel="noopener noreferrer" href="https://apps.apple.com/app/apple-store/id1477376905?ct=watch-dropdown&amp;mt=8&amp;pt=524675">iOS</a> or <a target="_blank" rel="noopener noreferrer" href="https://play.google.com/store/apps/details?id=com.github.android&amp;referrer=utm_campaign%3Dwatch-dropdown%26utm_medium%3Dweb%26utm_source%3Dgithub">Android</a>.
                  </span>
                </div>
            </div>
          </div>
        </details-menu>

        
        <div class="notifications-component-dialog-overlay"></div>
      </details>
    </notifications-list-subscription-form>



  </li>


    <li>
              <form class="btn-with-count" action="https://github.com/xlyze/home-termux-1/fork" accept-charset="UTF-8" method="post">
        <button data-hydro-click="{&quot;event_type&quot;:&quot;repository.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;FORK_BUTTON&quot;,&quot;repository_id&quot;:198098423,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="3f79916e97e5af119bfbe52e0b613d4f2f50072337ce366a520c14aa7f19aede" data-ga-click="Repository, show fork modal, action:blob#show; text:Fork" aria-label="Fork your own copy of xlyze/home-termux-1 to your account" type="submit" data-view-component="true" class="btn-sm btn">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked mr-2">
    <path fill-rule="evenodd" d="M5 3.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm0 2.122a2.25 2.25 0 10-1.5 0v.878A2.25 2.25 0 005.75 8.5h1.5v2.128a2.251 2.251 0 101.5 0V8.5h1.5a2.25 2.25 0 002.25-2.25v-.878a2.25 2.25 0 10-1.5 0v.878a.75.75 0 01-.75.75h-4.5A.75.75 0 015 6.25v-.878zm3.75 7.378a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm3-8.75a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
</svg>Fork
            <span id="repo-network-counter" data-pjax-replace="true" title="18" data-view-component="true" class="Counter">18</span>
</button></form>

    </li>

    <li>
          
  <div data-view-component="true" class="js-toggler-container js-social-container starring-container BtnGroup d-flex">
    <form class="starred js-social-form BtnGroup-parent flex-auto" action="https://github.com/xlyze/home-termux-1/unstar" accept-charset="UTF-8" method="post">
      
      <button data-hydro-click="{&quot;event_type&quot;:&quot;repository.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;UNSTAR_BUTTON&quot;,&quot;repository_id&quot;:198098423,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="9ad3c68e75e2d5845f0c81d4dd5ae80d8380298f359e1c1b2a71f56a44fc67e5" data-ga-click="Repository, click unstar button, action:blob#show; text:Unstar" aria-label="Unstar this repository" type="submit" data-view-component="true" class="js-toggler-target rounded-left-2 border-right-0 btn-sm btn BtnGroup-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star-fill starred-button-icon d-inline-block mr-2">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25z"></path>
</svg><span data-view-component="true" class="d-inline">
          Starred
</span>          <span id="repo-stars-counter-unstar" aria-label="0 users starred this repository" data-singular-suffix="user starred this repository" data-plural-suffix="users starred this repository" data-pjax-replace="true" title="0" data-view-component="true" class="Counter js-social-count">0</span>
</button></form>
    <form class="unstarred js-social-form BtnGroup-parent flex-auto" action="https://github.com/xlyze/home-termux-1/star" accept-charset="UTF-8" method="post">
      
      <button data-hydro-click="{&quot;event_type&quot;:&quot;repository.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;STAR_BUTTON&quot;,&quot;repository_id&quot;:198098423,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="2975cd0c2e7719d093769e39931fc31816994c97e554ac6a3fb9861a203ebe98" data-ga-click="Repository, click star button, action:blob#show; text:Star" aria-label="Star this repository" type="submit" data-view-component="true" class="js-toggler-target rounded-left-2 btn-sm btn BtnGroup-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star d-inline-block mr-2">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"></path>
</svg><span data-view-component="true" class="d-inline">
          Star
</span>          <span id="repo-stars-counter-star" aria-label="0 users starred this repository" data-singular-suffix="user starred this repository" data-plural-suffix="users starred this repository" data-pjax-replace="true" title="0" data-view-component="true" class="Counter js-social-count">0</span>
</button></form>
      <details id="details-cf1dcc" data-view-component="true" class="details-reset details-overlay BtnGroup-parent js-user-list-menu d-inline-block position-relative">
      <summary aria-label="Add this repository to a list" data-view-component="true" class="btn-sm btn BtnGroup-item px-2 float-none" aria-haspopup="menu" role="button">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="M4.427 7.427l3.396 3.396a.25.25 0 00.354 0l3.396-3.396A.25.25 0 0011.396 7H4.604a.25.25 0 00-.177.427z"></path>
</svg>
</summary>    <template class="js-user-list-create-dialog-template" data-label="Create list">
  <div class="Box-header">
    <h2 class="Box-title">Create list</h2>
  </div>
  <form class="Box-body d-flex flex-column p-3 js-user-list-form" action="https://github.com/stars/Din121212/lists" accept-charset="UTF-8" method="post">
        <p class="color-fg-subtle mb-3">Create a list to organize your starred repositories.</p>
      

  <div class="form-group mx-0 mt-0 mb-2 js-user-list-input-container js-characters-remaining-container position-relative">
    <auto-check src="/stars/Din121212/list-check?attr=name" required="">
      <text-expander keys=":" data-emoji-url="/autocomplete/emoji">
        <input type="text" name="user_list[name]" class="form-control js-user-list-input js-characters-remaining-field" placeholder="⭐️ Name this list" value="" aria-label="List name" maxlength="32" data-maxlength="32" autofocus="" required="">
      </text-expander>
      
    </auto-check>
    
    
  </div>
  <div class="form-group mx-0 mt-0 mb-2 js-user-list-input-container js-characters-remaining-container position-relative">
    <text-expander keys=":" data-emoji-url="/autocomplete/emoji">
      <textarea name="user_list[description]" class="form-control js-user-list-input js-characters-remaining-field" placeholder="Write a description" aria-label="List description" maxlength="160" data-maxlength="160" style="height: 74px; min-height: 74px"></textarea>
    </text-expander>
    
    
  </div>
        <button disabled="disabled" data-disable-invalid="true" data-submitting-message="Creating..." type="submit" data-view-component="true" class="btn-primary btn btn-block mt-2">  Create
</button>

  <p class="note mt-2 mb-0">
    <strong>Tip:</strong> type <code>:</code> to add emoji to the name or description.
  </p>
</form>
  <div data-view-component="true" class="Box-footer Box-row--gray text-small color-fg-muted d-flex flex-items-baseline py-2">
  <span title="Feature Release Label: Beta" aria-label="Feature Release Label: Beta" data-view-component="true" class="Label Label--success Label--inline px-2 mr-2">Beta</span>
  <span class="mr-1">Lists are currently in beta.</span>
  <a href="https://github.com/github/feedback/discussions/categories/lists-feedback">Share feedback and report bugs.</a>
</div>
</template>


  <details-menu class="SelectMenu right-0" src="/xlyze/home-termux-1/lists" role="menu">
    <div class="SelectMenu-modal">
        <button class="SelectMenu-closeButton position-absolute right-0 m-2" type="button" aria-label="Close menu" data-toggle-for="details-cf1dcc">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
        </button>
      <div id="filter-menu-cf1dcc" class="d-flex flex-column flex-1 overflow-hidden">
        <div class="SelectMenu-list">

            <include-fragment class="SelectMenu-loading" aria-label="Loading">
              <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke"></circle>
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>
</svg>
            </include-fragment>
        </div>
        
      </div>
    </div>
  </details-menu>
</details>
</div>
    </li>


  <li>
    

  </li>
</ul>

      </div>

      <div id="responsive-meta-container" data-pjax-replace="">
</div>


        
<nav data-pjax="#js-repo-pjax-container" aria-label="Repository" data-view-component="true" class="js-repo-nav js-sidenav-container-pjax UnderlineNav px-3 px-md-4 px-lg-5">

  <ul data-view-component="true" class="UnderlineNav-body list-style-none">
      <li data-view-component="true" class="d-inline-flex">
  <a id="code-tab" href="https://github.com/xlyze/home-termux-1" data-tab-item="i0code-tab" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /xlyze/home-termux-1" data-pjax="#repo-content-pjax-container" data-hotkey="g c" data-ga-click="Repository, Navigation click, Code tab" aria-current="page" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item selected">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M4.72 3.22a.75.75 0 011.06 1.06L2.06 8l3.72 3.72a.75.75 0 11-1.06 1.06L.47 8.53a.75.75 0 010-1.06l4.25-4.25zm6.56 0a.75.75 0 10-1.06 1.06L13.94 8l-3.72 3.72a.75.75 0 101.06 1.06l4.25-4.25a.75.75 0 000-1.06l-4.25-4.25z"></path>
</svg>
          <span data-content="Code">Code</span>
            <span id="code-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="pull-requests-tab" href="https://github.com/xlyze/home-termux-1/pulls" data-tab-item="i1pull-requests-tab" data-selected-links="repo_pulls checks /xlyze/home-termux-1/pulls" data-pjax="#repo-content-pjax-container" data-hotkey="g p" data-ga-click="Repository, Navigation click, Pull requests tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"></path>
</svg>
          <span data-content="Pull requests">Pull requests</span>
            


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="actions-tab" href="https://github.com/xlyze/home-termux-1/actions" data-tab-item="i2actions-tab" data-selected-links="repo_actions /xlyze/home-termux-1/actions" data-pjax="#repo-content-pjax-container" data-hotkey="g a" data-ga-click="Repository, Navigation click, Actions tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0zM8 0a8 8 0 100 16A8 8 0 008 0zM6.379 5.227A.25.25 0 006 5.442v5.117a.25.25 0 00.379.214l4.264-2.559a.25.25 0 000-.428L6.379 5.227z"></path>
</svg>
          <span data-content="Actions">Actions</span>
            <span id="actions-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="projects-tab" href="https://github.com/xlyze/home-termux-1/projects?type=beta" data-tab-item="i3projects-tab" data-selected-links="repo_projects new_repo_project repo_project /xlyze/home-termux-1/projects?type=beta" data-pjax="#repo-content-pjax-container" data-hotkey="g b" data-ga-click="Repository, Navigation click, Projects tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v3.585a.746.746 0 010 .83v8.085A1.75 1.75 0 0114.25 16H6.309a.748.748 0 01-1.118 0H1.75A1.75 1.75 0 010 14.25V6.165a.746.746 0 010-.83V1.75zM1.5 6.5v7.75c0 .138.112.25.25.25H5v-8H1.5zM5 5H1.5V1.75a.25.25 0 01.25-.25H5V5zm1.5 1.5v8h7.75a.25.25 0 00.25-.25V6.5h-8zm8-1.5h-8V1.5h7.75a.25.25 0 01.25.25V5z"></path>
</svg>
          <span data-content="Projects">Projects</span>
            


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="wiki-tab" href="https://github.com/xlyze/home-termux-1/wiki" data-tab-item="i4wiki-tab" data-selected-links="repo_wiki /xlyze/home-termux-1/wiki" data-pjax="#repo-content-pjax-container" data-hotkey="g w" data-ga-click="Repository, Navigation click, Wikis tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-book UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M0 1.75A.75.75 0 01.75 1h4.253c1.227 0 2.317.59 3 1.501A3.744 3.744 0 0111.006 1h4.245a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-4.507a2.25 2.25 0 00-1.591.659l-.622.621a.75.75 0 01-1.06 0l-.622-.621A2.25 2.25 0 005.258 13H.75a.75.75 0 01-.75-.75V1.75zm8.755 3a2.25 2.25 0 012.25-2.25H14.5v9h-3.757c-.71 0-1.4.201-1.992.572l.004-7.322zm-1.504 7.324l.004-5.073-.002-2.253A2.25 2.25 0 005.003 2.5H1.5v9h3.757a3.75 3.75 0 011.994.574z"></path>
</svg>
          <span data-content="Wiki">Wiki</span>
            <span id="wiki-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="security-tab" href="https://github.com/xlyze/home-termux-1/security" data-tab-item="i5security-tab" data-selected-links="security overview alerts policy token_scanning code_scanning /xlyze/home-termux-1/security" data-pjax="#repo-content-pjax-container" data-hotkey="g s" data-ga-click="Repository, Navigation click, Security tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M7.467.133a1.75 1.75 0 011.066 0l5.25 1.68A1.75 1.75 0 0115 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.7 1.7 0 01-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 011.217-1.667l5.25-1.68zm.61 1.429a.25.25 0 00-.153 0l-5.25 1.68a.25.25 0 00-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.2.2 0 00.154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.25.25 0 00-.174-.237l-5.25-1.68zM9 10.5a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.75a.75.75 0 10-1.5 0v3a.75.75 0 001.5 0v-3z"></path>
</svg>
          <span data-content="Security">Security</span>
            

    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="insights-tab" href="https://github.com/xlyze/home-termux-1/pulse" data-tab-item="i6insights-tab" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /xlyze/home-termux-1/pulse" data-pjax="#repo-content-pjax-container" data-ga-click="Repository, Navigation click, Insights tab" data-view-component="true" class="UnderlineNav-item hx_underlinenav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 1.75a.75.75 0 00-1.5 0v12.5c0 .414.336.75.75.75h14.5a.75.75 0 000-1.5H1.5V1.75zm14.28 2.53a.75.75 0 00-1.06-1.06L10 7.94 7.53 5.47a.75.75 0 00-1.06 0L3.22 8.72a.75.75 0 001.06 1.06L7 7.06l2.47 2.47a.75.75 0 001.06 0l5.25-5.25z"></path>
</svg>
          <span data-content="Insights">Insights</span>
            <span id="insights-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
</ul>
    <div style="visibility:hidden;" data-view-component="true" class="UnderlineNav-actions js-responsive-underlinenav-overflow position-absolute pr-3 pr-md-4 pr-lg-5 right-0">      <details data-view-component="true" class="details-overlay details-reset position-relative">
  <summary role="button" data-view-component="true">          <div class="UnderlineNav-item mr-0 border-0">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM1.5 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm13 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
</svg>
            <span class="sr-only">More</span>
          </div>
</summary>
  <div data-view-component="true">          <details-menu role="menu" data-view-component="true" class="dropdown-menu dropdown-menu-sw">
  
            <ul>
                
                
                
                
                
                
                
            </ul>

</details-menu></div>
</details></div>
</nav>
  </div>



<div class="clearfix new-discussion-timeline container-xl px-3 px-md-4 px-lg-5">
  <div id="repo-content-pjax-container" class="repository-content ">

      <a href="https://github.dev/" class="d-none js-github-dev-shortcut" data-hotkey=".">Open in github.dev</a>
  <a href="https://github.dev/" class="d-none js-github-dev-new-tab-shortcut" data-hotkey="Shift+.,Shift+>,>" target="_blank">Open in a new github.dev tab</a>



    
      
  
  
<div>
  



    <a class="d-none js-permalink-shortcut" data-hotkey="y" href="https://github.com/xlyze/home-termux-1/blob/15bc2ec6bea720649a4b53259ee1ad8cf6d68871/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">Permalink</a>


    <div class="d-flex flex-items-start flex-shrink-0 pb-3 flex-wrap flex-md-nowrap flex-justify-between flex-md-justify-start">
      
<div class="position-relative">
  <details class="details-reset details-overlay mr-0 mb-0 " id="branch-select-menu">
    <summary class="btn css-truncate" data-hotkey="w" title="Switch branches or tags">
      <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-branch">
    <path fill-rule="evenodd" d="M11.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122V6A2.5 2.5 0 0110 8.5H6a1 1 0 00-1 1v1.128a2.251 2.251 0 11-1.5 0V5.372a2.25 2.25 0 111.5 0v1.836A2.492 2.492 0 016 7h4a1 1 0 001-1v-.628A2.25 2.25 0 019.5 3.25zM4.25 12a.75.75 0 100 1.5.75.75 0 000-1.5zM3.5 3.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0z"></path>
</svg>
      <span class="css-truncate-target" data-menu-button="">master</span>
      <span class="dropdown-caret"></span>
    </summary>

      
<div class="SelectMenu">
  <div class="SelectMenu-modal">
    <header class="SelectMenu-header">
      <span class="SelectMenu-title">Switch branches/tags</span>
      <button class="SelectMenu-closeButton" type="button" data-toggle-for="branch-select-menu"><svg aria-label="Close menu" aria-hidden="false" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg></button>
    </header>

    <input-demux data-action="tab-container-change:input-demux#storeInput tab-container-changed:input-demux#updateInput" data-catalyst="">
      <tab-container class="d-flex flex-column js-branches-tags-tabs" style="min-height: 0;">
        <div class="SelectMenu-filter">
          <input data-target="input-demux.source" id="context-commitish-filter-field" class="SelectMenu-input form-control" aria-owns="ref-list-branches" data-controls-ref-menu-id="ref-list-branches" autofocus="" autocomplete="off" aria-label="Filter branches/tags" placeholder="Filter branches/tags" type="text">
        </div>

        <div class="SelectMenu-tabs" role="tablist" data-target="input-demux.control">
          <button class="SelectMenu-tab" type="button" role="tab" aria-selected="true" tabindex="0">Branches</button>
          <button class="SelectMenu-tab" type="button" role="tab" aria-selected="false" tabindex="-1">Tags</button>
        </div>

        <div role="tabpanel" id="ref-list-branches" data-filter-placeholder="Filter branches/tags" class="d-flex flex-column flex-auto overflow-auto" tabindex="">
          <ref-selector type="branch" data-targets="input-demux.sinks" data-action="
              input-entered:ref-selector#inputEntered
              tab-selected:ref-selector#tabSelected
              focus-list:ref-selector#focusFirstListMember
            " query-endpoint="/xlyze/home-termux-1/refs" cache-key="v0:1613516200.846046" current-committish="bWFzdGVy" default-branch="bWFzdGVy" name-with-owner="eGx5emUvaG9tZS10ZXJtdXgtMQ==" prefetch-on-mouseover="" data-catalyst="">

            <template data-target="ref-selector.fetchFailedTemplate">
              <div class="SelectMenu-message" data-index="{{ index }}">Could not load branches</div>
            </template>

              <template data-target="ref-selector.noMatchTemplate">
    <div class="SelectMenu-message">Nothing to show</div>
</template>


            <!-- TODO: this max-height is necessary or else the branch list won't scroll.  why? -->
            <div data-target="ref-selector.listContainer" role="menu" class="SelectMenu-list " style="max-height: 330px" data-pjax="#repo-content-pjax-container">
              <div class="SelectMenu-loading pt-3 pb-0 overflow-hidden" aria-label="Menu is loading">
                <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke"></circle>
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>
</svg>
              </div>
            </div>

              <template data-target="ref-selector.itemTemplate">
  <a href="https://github.com/xlyze/home-termux-1/blob/%7B%7B%20urlEncodedRefName%20%7D%7D/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" class="SelectMenu-item" role="menuitemradio" rel="nofollow" aria-checked="{{ isCurrent }}" data-index="{{ index }}">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    <span class="flex-1 css-truncate css-truncate-overflow {{ isFilteringClass }}">{{ refName }}</span>
    
  </a>
</template>


              <footer class="SelectMenu-footer"><a href="https://github.com/xlyze/home-termux-1/branches">View all branches</a></footer>
          </ref-selector>

        </div>

        
      </tab-container>
    </input-demux>
  </div>
</div>

  </details>

</div>

      <h2 id="blob-path" class="breadcrumb flex-auto flex-self-center min-width-0 text-normal mx-2 width-full width-md-auto flex-order-1 flex-md-order-none mt-3 mt-md-0">
        <span class="js-repo-root text-bold"><span class="js-path-segment d-inline-block wb-break-all"><a data-pjax="#repo-content-pjax-container" href="https://github.com/xlyze/home-termux-1"><span>home-termux-1</span></a></span></span><span class="separator">/</span><strong class="final-path">__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh</strong>
      </h2>
      <a href="https://github.com/xlyze/home-termux-1/find/master" class="js-pjax-capture-input btn mr-2 d-none d-md-block" data-pjax="" data-hotkey="t">
        Go to file
      </a>

      <details id="blob-more-options-details" data-view-component="true" class="details-overlay details-reset position-relative">
  <summary role="button" data-view-component="true" class="btn">  <svg aria-label="More options" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM1.5 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm13 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
</svg>
</summary>
  <div data-view-component="true">          <ul class="dropdown-menu dropdown-menu-sw">
            <li class="d-block d-md-none">
              <a class="dropdown-item d-flex flex-items-baseline" data-hydro-click="{&quot;event_type&quot;:&quot;repository.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;FIND_FILE_BUTTON&quot;,&quot;repository_id&quot;:198098423,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="f912c15799df87449abf420b2a31010cf743e18b6174e5662b52513e8effc0a8" data-ga-click="Repository, find file, location:repo overview" data-hotkey="t" data-pjax="true" href="https://github.com/xlyze/home-termux-1/find/master">
                <span class="flex-auto">Go to file</span>
                <span class="text-small color-fg-muted" aria-hidden="true">T</span>
</a>            </li>
            <li data-toggle-for="blob-more-options-details">
              <button data-toggle-for="jumpto-line-details-dialog" type="button" data-view-component="true" class="dropdown-item btn-link">  <span class="d-flex flex-items-baseline">
                  <span class="flex-auto">Go to line</span>
                  <span class="text-small color-fg-muted" aria-hidden="true">L</span>
                </span>
</button>            </li>
            <li class="dropdown-divider" role="none"></li>
            <li>
              <clipboard-copy data-toggle-for="blob-more-options-details" aria-label="Copy path" value="__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" data-view-component="true" class="dropdown-item cursor-pointer" tabindex="0" role="button">
    
                Copy path

</clipboard-copy>            </li>
            <li>
              <clipboard-copy data-toggle-for="blob-more-options-details" aria-label="Copy permalink" value="https://github.com/xlyze/home-termux-1/blob/15bc2ec6bea720649a4b53259ee1ad8cf6d68871/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" data-view-component="true" class="dropdown-item cursor-pointer" tabindex="0" role="button">
    
                <span class="d-flex flex-items-baseline">
                  <span class="flex-auto">Copy permalink</span>
                </span>

</clipboard-copy>            </li>
          </ul>
</div>
</details>    </div>




    <div class="Box d-flex flex-column flex-shrink-0 mb-3">
      

  <div class="Box-header Details js-details-container">
      <div class="d-flex flex-items-center">
        <span class="flex-shrink-0 ml-n1 mr-n1 mt-n1 mb-n1">
          <a rel="contributor" data-skip-pjax="true" href="https://github.com/Rusmana-ID"><img class="avatar avatar-user" skip_hovercard="20" src="https://avatars.githubusercontent.com/u/41493567?s=48&amp;v=4" width="24" height="24" alt="@Rusmana-ID"></a>
        </span>
        <div class="flex-1 d-flex flex-items-center ml-3 min-width-0">
          <div class="css-truncate css-truncate-overflow">
            <a class="text-bold Link--primary" rel="contributor" href="https://github.com/Rusmana-ID">Rusmana-ID</a>

              <span class="markdown-title">
                <a data-pjax="true" title="Add files via upload" class="Link--secondary" href="https://github.com/xlyze/home-termux-1/commit/47b8e322ada6af138d811e8d439eef716645ab1a">Add files via upload</a>
              </span>
          </div>


          <span class="ml-2">
            
          </span>
        </div>
        <div class="ml-3 d-flex flex-shrink-0 flex-items-center flex-justify-end color-fg-muted no-wrap">
          <span class="d-none d-md-inline">
            <span>Latest commit</span>
            <a class="text-small text-mono Link--secondary" href="https://github.com/xlyze/home-termux-1/commit/47b8e322ada6af138d811e8d439eef716645ab1a" data-pjax="">47b8e32</a>
            <span itemprop="dateModified"><relative-time datetime="2019-01-10T04:38:25Z" class="no-wrap" title="10 Jan 2019 11.38 WIB">on 10 Jan 2019</relative-time></span>
          </span>

          <a data-pjax="" href="https://github.com/xlyze/home-termux-1/commits/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" class="ml-3 no-wrap Link--primary no-underline">
            <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-history">
    <path fill-rule="evenodd" d="M1.643 3.143L.427 1.927A.25.25 0 000 2.104V5.75c0 .138.112.25.25.25h3.646a.25.25 0 00.177-.427L2.715 4.215a6.5 6.5 0 11-1.18 4.458.75.75 0 10-1.493.154 8.001 8.001 0 101.6-5.684zM7.75 4a.75.75 0 01.75.75v2.992l2.028.812a.75.75 0 01-.557 1.392l-2.5-1A.75.75 0 017 8.25v-3.5A.75.75 0 017.75 4z"></path>
</svg>
            <span class="d-none d-sm-inline">
              <strong>History</strong>
            </span>
          </a>
        </div>
      </div>

  </div>

  <div class="Box-body d-flex flex-items-center flex-auto border-bottom-0 flex-wrap">
    <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default float-left mr-3" id="blob_contributors_box">
      <summary class="Link--primary" role="button">
        <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-people">
    <path fill-rule="evenodd" d="M5.5 3.5a2 2 0 100 4 2 2 0 000-4zM2 5.5a3.5 3.5 0 115.898 2.549 5.507 5.507 0 013.034 4.084.75.75 0 11-1.482.235 4.001 4.001 0 00-7.9 0 .75.75 0 01-1.482-.236A5.507 5.507 0 013.102 8.05 3.49 3.49 0 012 5.5zM11 4a.75.75 0 100 1.5 1.5 1.5 0 01.666 2.844.75.75 0 00-.416.672v.352a.75.75 0 00.574.73c1.2.289 2.162 1.2 2.522 2.372a.75.75 0 101.434-.44 5.01 5.01 0 00-2.56-3.012A3 3 0 0011 4z"></path>
</svg>
        <strong>1</strong>
        
        contributor
      </summary>
      <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast" aria-label="Users who have contributed to this file" src="/xlyze/home-termux-1/contributors-list/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" preload="" role="dialog" aria-modal="true">
        <div class="Box-header">
          <button class="Box-btn-octicon btn-octicon float-right" type="button" aria-label="Close dialog" data-close-dialog="">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
          </button>
          <h3 class="Box-title">
            Users who have contributed to this file
          </h3>
        </div>
        <include-fragment>
          <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="my-3 mx-auto d-block anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke"></circle>
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>
</svg>
        </include-fragment>
      </details-dialog>
    </details>
  </div>
    </div>


      







  
    <div data-target="readme-toc.content" class="Box mt-3 position-relative">
      
  <div class="Box-header py-2 pr-2 d-flex flex-shrink-0 flex-md-row flex-items-center">


  <div class="text-mono f6 flex-auto pr-3 flex-order-2 flex-md-order-1">

      9 lines (8 sloc)
      <span class="file-info-divider"></span>
    3.41 KB
  </div>

  <div class="d-flex py-1 py-md-0 flex-auto flex-order-1 flex-md-order-2 flex-sm-grow-0 flex-justify-between hide-sm hide-md">
      

    <div class="BtnGroup">
      <a href="https://github.com/xlyze/home-termux-1/raw/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" id="raw-url" data-view-component="true" class="btn-sm btn BtnGroup-item">  Raw
</a>
        <a href="https://github.com/xlyze/home-termux-1/blame/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" data-hotkey="b" data-view-component="true" class="js-update-url-with-hash btn-sm btn BtnGroup-item">  Blame
</a>
    </div>

    <div>

        
          <!-- '"` --><!-- </textarea></xmp> --><form class="inline-form js-update-url-with-hash" action="https://github.com/xlyze/home-termux-1/edit/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" accept-charset="UTF-8" method="post">
            <button class="btn-octicon tooltipped tooltipped-nw" type="submit" aria-label="Fork this project and edit the file" data-hotkey="e" data-disable-with="">
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-pencil">
    <path fill-rule="evenodd" d="M11.013 1.427a1.75 1.75 0 012.474 0l1.086 1.086a1.75 1.75 0 010 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 01-.927-.928l.929-3.25a1.75 1.75 0 01.445-.758l8.61-8.61zm1.414 1.06a.25.25 0 00-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 000-.354l-1.086-1.086zM11.189 6.25L9.75 4.81l-6.286 6.287a.25.25 0 00-.064.108l-.558 1.953 1.953-.558a.249.249 0 00.108-.064l6.286-6.286z"></path>
</svg>
            </button>
</form>
          <!-- '"` --><!-- </textarea></xmp> --><form class="inline-form" action="https://github.com/xlyze/home-termux-1/delete/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" accept-charset="UTF-8" method="post">
            <button class="btn-octicon btn-octicon-danger tooltipped tooltipped-nw" type="submit" aria-label="Fork this project and delete the file" data-disable-with="">
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-trash">
    <path fill-rule="evenodd" d="M6.5 1.75a.25.25 0 01.25-.25h2.5a.25.25 0 01.25.25V3h-3V1.75zm4.5 0V3h2.25a.75.75 0 010 1.5H2.75a.75.75 0 010-1.5H5V1.75C5 .784 5.784 0 6.75 0h2.5C10.216 0 11 .784 11 1.75zM4.496 6.675a.75.75 0 10-1.492.15l.66 6.6A1.75 1.75 0 005.405 15h5.19c.9 0 1.652-.681 1.741-1.576l.66-6.6a.75.75 0 00-1.492-.149l-.66 6.6a.25.25 0 01-.249.225h-5.19a.25.25 0 01-.249-.225l-.66-6.6z"></path>
</svg>
            </button>
</form>    </div>
  </div>

    <div class="d-flex hide-lg hide-xl flex-order-2 flex-grow-0">
      <details class="dropdown details-reset details-overlay d-inline-block">
        <summary class="btn-octicon" aria-haspopup="true" aria-label="possible actions">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM1.5 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm13 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
</svg>
        </summary>

        <ul class="dropdown-menu dropdown-menu-sw" style="width: 175px">
          <li>
            <a class="dropdown-item" href="https://github.com/xlyze/home-termux-1/raw/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">
              View raw
            </a>
          </li>
            <li>
                          </li>
            <li>
              <a class="dropdown-item" href="https://github.com/xlyze/home-termux-1/blame/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">
                View blame
              </a>
            </li>

              <li class="dropdown-divider" role="none"></li>
              <li>
                <a class="dropdown-item" href="https://github.com/xlyze/home-termux-1/edit/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">Edit file</a>
              </li>
              <li>
                <a class="dropdown-item menu-item-danger" href="https://github.com/xlyze/home-termux-1/delete/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">Delete file</a>
              </li>
        </ul>
      </details>
    </div>
</div>


      
  <div itemprop="text" class="Box-body p-0 blob-wrapper data type-shell  gist-border-0">

      
<div class="blob-code-content">
  <template class="js-file-alert-template">
  <div data-view-component="true" class="flash flash-warn flash-full d-flex flex-items-center">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
  
    <span>
      This file contains bidirectional Unicode text that may be interpreted or compiled differently than what appears below. To review, open the file in an editor that reveals hidden Unicode characters.
      <a href="https://github.co/hiddenchars" target="_blank">Learn more about bidirectional Unicode characters</a>
    </span>


  <div data-view-component="true" class="flash-action">        <a href="https://github.com/xlyze/home-termux-1/blob/master/%7B%7B%20revealButtonHref%20%7D%7D" data-view-component="true" class="btn-sm btn">  Show hidden characters
</a>
</div>
</div></template>
<template class="js-line-alert-template">
  <span aria-label="This line has hidden Unicode characters" data-view-component="true" class="bidi-line-alert tooltipped tooltipped-e">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
</span></template>

  <table class="highlight tab-size js-file-line-container js-code-nav-container js-tagsearch-file" data-tab-size="8" data-paste-markdown-skip="" data-tagsearch-lang="Shell" data-tagsearch-path="__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">
        <tbody><tr>
          <td id="L1" class="blob-num js-line-number js-code-nav-line-number" data-line-number="1"></td>
          <td id="LC1" class="blob-code blob-code-inner js-file-line"><span class="pl-c"><span class="pl-c">#</span> Coders by : Mr.Tr3v!0n</span></td>
        </tr>
        <tr>
          <td id="L2" class="blob-num js-line-number js-code-nav-line-number" data-line-number="2"></td>
          <td id="LC2" class="blob-code blob-code-inner js-file-line"><span class="pl-c"><span class="pl-c">#</span> buat : Kamis, 10 jan 2019 [10:28]</span></td>
        </tr>
        <tr>
          <td id="L3" class="blob-num js-line-number js-code-nav-line-number" data-line-number="3"></td>
          <td id="LC3" class="blob-code blob-code-inner js-file-line">
</td>
        </tr>
        <tr>
          <td id="L4" class="blob-num js-line-number js-code-nav-line-number" data-line-number="4"></td>
          <td id="LC4" class="blob-code blob-code-inner js-file-line">z=<span class="pl-s"><span class="pl-pds">"</span></span></td>
        </tr>
        <tr>
          <td id="L5" class="blob-num js-line-number js-code-nav-line-number" data-line-number="5"></td>
          <td id="LC5" class="blob-code blob-code-inner js-file-line"><span class="pl-s">";tz='""';Wz='ate ';Sz='e +%';nCz=' col';oCz='or';bCz='Inst';EBz='◢${p';JDz='fi';KBz='WRON';WCz='" ${';yz='${pu';bz='TANG';RBz='(){ ';LDz='(){';GCz='ll D';cBz='Crac';PBz='}';KDz='main';FCz='{h}I';fz='N=`d';VBz='"${m';GBz='{k}┌';JCz='"${p';mCz=']: "';QBz='home';SBz='p 2';dCz='Home';Cz='33;1';SCz='exit';Ez='m="\';DCz=' .ba';wCz='r = ';HBz='${b}';hz='TAHU';NBz='!!!';tCz='] ||';CDz='|| [';wBz='ME';jz='clea';UCz='er()';IDz='er';nz='){';Kz='p="\';ez='BULA';uBz='e___';dBz='k Ho';xBz='Load';pCz='if [';WBz='}[ $';Uz='MENI';lCz='[Y/N';gz='+%m`';fCz='e${h';BCz='cd';IBz='∩${k';qCz=' $co';RCz='ter ';cCz='all ';vCz='colo';PCz=' lal';GDz='else';JBz='}┐';jCz='" In';Iz='[39;';iz='+%Y`';pz='p 0.';xz='{k}┐';UBz=' -e ';Nz='34;1';TCz='bann';Gz='pu="';CCz='mv _';hBz='Clea';Bz='033[';Lz='36;1';LBz='G IN';lBz='ll C';XBz='{pu}';kz='r';aCz='}] $';iCz=' -p ';OCz='l +d';ACz='p 1';bBz=']"';aBz='... ';pBz='}]"';Fz='31;1';lz='loop';gBz='m}]"';Vz='T=`d';iBz='r Ho';vBz=' $HO';cz='GAL=';rz='prin';uCz=' [ $';eCz=' Tim';LCz='{p}T';az='+%S`';xCz='y ];';rCz='lor ';jBz='{p}I';eBz='me..';Hz='\033';MBz='PUT ';FBz='u})$';rBz='__ho';KCz='u}"';vz='	┌${';nBz='s...';HCz='one√';DDz='= n ';ADz='elif';DBz='${m}';Zz='K=`d';tBz='_pag';MCz='ekan';TBz='echo';mBz='oder';Dz='m"';wz='b}∩$';Yz='DETI';kBz='nsta';qBz='cp _';sz='tf "';BDz='N ] ';uz='${k}';NCz=' Ctr';yBz='ing.';EDz='];th';yCz='then';sCz='= Y ';Tz='H`';kCz='put ';VCz='{';dz='d`';Mz='b="\';ICz='√ ${';ZCz='1${b';Pz='32;1';ZBz='ess.';hCz='read';YCz='{h}0';Qz='JAM=';FDz='en';QCz='u en';Rz='`dat';Az='k="\';oz='slee';sBz='me__';OBz='"""';gCz='}√"';CBz='{k}_';HDz='ing';mz='ing(';BBz='m}◣$';fBz='. ${';Jz='1m"';XCz='b}[$';YBz='Pros';Oz='h="\';ABz='}(${';oBz=' ${m';qz='5';Xz='+%M`';ECz='shrc';</span></td>
        </tr>
        <tr>
          <td id="L6" class="blob-num js-line-number js-code-nav-line-number" data-line-number="6"></td>
          <td id="LC6" class="blob-code blob-code-inner js-file-line"><span class="pl-s">eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Hz$Iz$Jz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Bz$Pz$Dz$z$Qz$Rz$Sz$Tz$z$Uz$Vz$Wz$Xz$z$Yz$Zz$Wz$az$z$bz$cz$Rz$Sz$dz$z$ez$fz$Wz$gz$z$hz$fz$Wz$iz$z$jz$kz$z$lz$mz$nz$z$oz$pz$qz$z$rz$sz$tz$z$uz$vz$wz$xz$yz$ABz$BBz$CBz$DBz$EBz$FBz$GBz$HBz$IBz$JBz$z$DBz$KBz$LBz$MBz$NBz$z$OBz$z$PBz$z$jz$kz$z$QBz$RBz$jz$kz$z$oz$SBz$z$TBz$UBz$VBz$WBz$XBz$YBz$ZBz$aBz$DBz$bBz$z$oz$SBz$z$TBz$UBz$VBz$WBz$XBz$cBz$dBz$eBz$fBz$gBz$z$oz$SBz$z$TBz$UBz$VBz$WBz$XBz$hBz$iBz$eBz$fBz$gBz$z$TBz$z$TBz$UBz$VBz$WBz$jBz$kBz$lBz$mBz$nBz$oBz$pBz$z$oz$SBz$z$qBz$rBz$sBz$tBz$uBz$vBz$wBz$z$TBz$UBz$VBz$WBz$XBz$xBz$yBz$aBz$DBz$bBz$z$oz$ACz$z$BCz$z$oz$SBz$z$CCz$rBz$sBz$tBz$uBz$DCz$ECz$z$TBz$z$oz$SBz$z$TBz$UBz$VBz$WBz$FCz$kBz$GCz$HCz$ICz$gBz$z$oz$ACz$z$TBz$UBz$JCz$KCz$z$TBz$UBz$VBz$WBz$LCz$MCz$NCz$OCz$PCz$QCz$RCz$DBz$bBz$z$TBz$z$SCz$z$PBz$z$TCz$UCz$VCz$z$jz$kz$z$TBz$z$TBz$z$TBz$UBz$WCz$XCz$YCz$ZCz$aCz$XBz$bCz$cCz$dCz$eCz$fCz$gCz$z$TBz$UBz$JCz$KCz$z$hCz$iCz$jCz$kCz$lCz$mCz$nCz$oCz$z$pCz$qCz$rCz$sCz$tCz$uCz$vCz$wCz$xCz$yCz$z$QBz$z$ADz$uCz$vCz$wCz$BDz$CDz$qCz$rCz$DDz$EDz$FDz$z$SCz$z$GDz$z$lz$HDz$z$oz$ACz$z$TCz$IDz$z$JDz$z$PBz$z$KDz$LDz$z$TCz$IDz$z$lz$HDz$z$PBz$z$KDz" </span></td>
        </tr>
        <tr>
          <td id="L7" class="blob-num js-line-number js-code-nav-line-number" data-line-number="7"></td>
          <td id="LC7" class="blob-code blob-code-inner js-file-line"><span class="pl-s">z=<span class="pl-pds">"</span></span></td>
        </tr>
        <tr>
          <td id="L8" class="blob-num js-line-number js-code-nav-line-number" data-line-number="8"></td>
          <td id="LC8" class="blob-code blob-code-inner js-file-line"><span class="pl-s"><span class="pl-pds">"</span>;cz='tari';hz='e[1m';dz='ya P';Iz='e[36';Yz='1mDe';Hz='t  \';Uz='e[0m';Fz=' -e ';fz='it\e';Bz='r';Wz='m<span class="pl-pds">"</span></span><span class="pl-s"><span class="pl-pds">'</span>;Nz=<span class="pl-pds">'</span></span>By <span class="pl-cce">\'</span><span class="pl-k">;</span>Jz=<span class="pl-s"><span class="pl-pds">'</span>m\e[<span class="pl-pds">'</span></span><span class="pl-k">;</span>gz=<span class="pl-s"><span class="pl-pds">'</span>[0m\<span class="pl-pds">'</span></span><span class="pl-k">;</span>Gz=<span class="pl-s"><span class="pl-pds">'</span>"\t\<span class="pl-pds">'</span></span><span class="pl-k">;</span>Zz=<span class="pl-s"><span class="pl-pds">'</span>velo<span class="pl-pds">'</span></span><span class="pl-k">;</span>bz=<span class="pl-s"><span class="pl-pds">'</span>1mSu<span class="pl-pds">'</span></span><span class="pl-k">;</span>Rz=<span class="pl-s"><span class="pl-pds">'</span>cker<span class="pl-pds">'</span></span><span class="pl-k">;</span>Dz=<span class="pl-s"><span class="pl-pds">'</span>slee<span class="pl-pds">'</span></span><span class="pl-k">;</span>Oz=<span class="pl-s"><span class="pl-pds">'</span>e[33<span class="pl-pds">'</span></span><span class="pl-k">;</span>Vz=<span class="pl-s"><span class="pl-pds">'</span>\e[1<span class="pl-pds">'</span></span><span class="pl-k">;</span>Lz=<span class="pl-s"><span class="pl-pds">'</span>cryp<span class="pl-pds">'</span></span><span class="pl-k">;</span>Xz=<span class="pl-s"><span class="pl-pds">'</span>p 1<span class="pl-pds">'</span></span><span class="pl-k">;</span>az=<span class="pl-s"><span class="pl-pds">'</span>ped <span class="pl-pds">'</span></span><span class="pl-k">;</span>Ez=<span class="pl-s"><span class="pl-pds">'</span>p 2<span class="pl-pds">'</span></span><span class="pl-k">;</span>Mz=<span class="pl-s"><span class="pl-pds">'</span>ted <span class="pl-pds">'</span></span><span class="pl-k">;</span>Sz=<span class="pl-s"><span class="pl-pds">'</span> Too<span class="pl-pds">'</span></span><span class="pl-k">;</span>Pz=<span class="pl-s"><span class="pl-pds">'</span>mBas<span class="pl-pds">'</span></span><span class="pl-k">;</span>Cz=<span class="pl-s"><span class="pl-pds">'</span>echo<span class="pl-pds">'</span></span><span class="pl-k">;</span>iz=<span class="pl-s"><span class="pl-pds">'</span>"<span class="pl-pds">'</span></span><span class="pl-k">;</span>Tz=<span class="pl-s"><span class="pl-pds">'</span>ls \<span class="pl-pds">'</span></span><span class="pl-k">;</span>ez=<span class="pl-s"><span class="pl-pds">'</span>arix<span class="pl-pds">'</span></span><span class="pl-k">;</span>Qz=<span class="pl-s"><span class="pl-pds">'</span>h Lo<span class="pl-pds">'</span></span><span class="pl-k">;</span>Az=<span class="pl-s"><span class="pl-pds">'</span>clea<span class="pl-pds">'</span></span><span class="pl-k">;</span>Kz=<span class="pl-s"><span class="pl-pds">'</span>1mEn<span class="pl-pds">'</span></span><span class="pl-k">;</span></td>
        </tr>
        <tr>
          <td id="L9" class="blob-num js-line-number js-code-nav-line-number" data-line-number="9"></td>
          <td id="LC9" class="blob-code blob-code-inner js-file-line"><span class="pl-c1">eval</span> <span class="pl-s"><span class="pl-pds">"</span><span class="pl-smi">$Az$Bz$z$Cz$z$Dz$Ez$z$Cz$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$z$Cz$z$Dz$Xz$z$Cz$Fz$Gz$Hz$Iz$Jz$Yz$Zz$az$Nz$Oz$Jz$bz$cz$dz$ez$fz$gz$hz$iz$z$Cz$z$Dz$Ez</span><span class="pl-pds">"</span></span></td>
        </tr>
  </tbody></table>
</div>

  <details class="details-reset details-overlay BlobToolbar position-absolute js-file-line-actions dropdown d-none" aria-hidden="true">
    <summary class="btn-octicon ml-0 px-2 p-0 color-bg-default border color-border-default rounded-1" aria-label="Inline file action toolbar" aria-haspopup="menu" role="button">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM1.5 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm13 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
</svg>
    </summary>
    <details-menu role="menu">

      <ul class="BlobToolbar-dropdown dropdown-menu dropdown-menu-se ml-2 mt-2" style="width:185px">
        <li>
          <clipboard-copy role="menuitem" class="dropdown-item" id="js-copy-lines" style="cursor:pointer;" aria-label="Copy lines" tabindex="0">
            Copy lines
          </clipboard-copy>
        </li>
        <li>
          <clipboard-copy role="menuitem" class="dropdown-item" id="js-copy-permalink" style="cursor:pointer;" aria-label="Copy permalink" tabindex="0">
            Copy permalink
          </clipboard-copy>
        </li>
        <li><a class="dropdown-item js-update-url-with-hash" id="js-view-git-blame" role="menuitem" href="https://github.com/xlyze/home-termux-1/blame/15bc2ec6bea720649a4b53259ee1ad8cf6d68871/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh">View git blame</a></li>
      </ul>
    </details-menu>
  </details>

  </div>

    </div>


  

  <details class="details-reset details-overlay details-overlay-dark" id="jumpto-line-details-dialog">
    <summary data-hotkey="l" aria-label="Jump to line" role="button"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast linejump" aria-label="Jump to line" role="dialog" aria-modal="true">
      <!-- '"` --><!-- </textarea></xmp> --><form class="js-jump-to-line-form Box-body d-flex" action="https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh" accept-charset="UTF-8" method="get">
        <input class="form-control flex-auto mr-3 linejump-input js-jump-to-line-field" type="text" placeholder="Jump to line…" aria-label="Jump to line" autofocus="">
        <button data-close-dialog="" type="submit" data-view-component="true" class="btn">  Go
</button>
</form>    </details-dialog>
  </details>


</div>



  </div>
</div>

    </main>
  </div>

  </div>

            <footer class="footer width-full container-xl p-responsive" role="contentinfo">


  <div class="position-relative d-flex flex-items-center pb-2 f6 color-fg-muted border-top color-border-muted flex-column-reverse flex-lg-row flex-wrap flex-lg-nowrap mt-6 pt-6">
    <ul class="list-style-none d-flex flex-wrap col-0 col-lg-2 flex-justify-start flex-lg-justify-between mb-2 mb-lg-0">
      <li class="mt-2 mt-lg-0 d-flex flex-items-center">
        <a aria-label="Homepage" title="GitHub" class="footer-octicon mr-2" href="https://github.com/">
          <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
</a>        <span>
        © 2021 GitHub, Inc.
        </span>
      </li>
    </ul>
    <ul class="list-style-none d-flex flex-wrap col-12 col-lg-8 flex-justify-start flex-lg-justify-between mb-2 mb-lg-0">
        <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/en/github/site-policy/github-terms-of-service" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to terms&quot;,&quot;label&quot;:&quot;text:terms&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="260670ce60fcc6a459b47d68c9ac1aaa0bb2f3f8f08f22fbffde8166c8b55550" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}">Terms</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/en/github/site-policy/github-privacy-statement" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="05b9f38bf9cd93ecad875778f834e2ad7166a5af3ae3c2c8fb3e5b25403950da" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}">Privacy</a></li>
        <li class="mr-3 mr-lg-0"><a data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="bd084991568d86217fdc991f7a48af885bea82c053252e2c8c158e7263ddfc8b" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}" href="https://github.com/security">Security</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://www.githubstatus.com/" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="411a2b2fcb2e4ad68f177376541eaf62b06c02097b999a0093f78ce0d21fbd6f" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;}">Status</a></li>
        <li class="mr-3 mr-lg-0"><a data-ga-click="Footer, go to help, text:Docs" href="https://docs.github.com/">Docs</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://support.github.com/?tags=dotcom-footer" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="ce38c2acce3d7c7506347e0ec704912f39e88eebce0cdc7a3b5b14d81ac2c825" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;}">Contact GitHub</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://github.com/pricing" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Pricing&quot;,&quot;label&quot;:&quot;text:Pricing&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="61f1328625e7ca4f40f4827c36acf55bb0ad023bbe77cf5adbed897d9cb6e801" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Pricing&quot;,&quot;label&quot;:&quot;text:Pricing&quot;}">Pricing</a></li>
      <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to api&quot;,&quot;label&quot;:&quot;text:api&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="1bbb7c4df4eb0af37f898f4b84e9014809ab69a6b8d8b830dd79f730c2f1050b" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to api&quot;,&quot;label&quot;:&quot;text:api&quot;}">API</a></li>
      <li class="mr-3 mr-lg-0"><a href="https://services.github.com/" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to training&quot;,&quot;label&quot;:&quot;text:training&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="4749d28c3d97bf24d85a011d74cee01923a9e474baa73361b1d194caa8ad4e36" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to training&quot;,&quot;label&quot;:&quot;text:training&quot;}">Training</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://github.blog/" data-hydro-click="{&quot;event_type&quot;:&quot;analytics.event&quot;,&quot;payload&quot;:{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to blog&quot;,&quot;label&quot;:&quot;text:blog&quot;,&quot;originating_url&quot;:&quot;https://github.com/xlyze/home-termux-1/blob/master/__xlsn__xslwp__xsnwlo__xwbwl___xncdlep__xbsvel___xbcnsml__xdpen__xnwwl___.sh&quot;,&quot;user_id&quot;:96439587}}" data-hydro-click-hmac="21c5e2c095fac2d8b54051ec4f3a8628682f63621a832e608a9ac1795fd8d75d" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to blog&quot;,&quot;label&quot;:&quot;text:blog&quot;}">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>
    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 color-fg-muted"></span>
  </div>
</footer>




  

  
    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open="">
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal" aria-labelledby="box-title">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog="">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0 tooltipped-no-delay" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path fill-rule="evenodd" d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 010 1.5h-1.5a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-1.5a.75.75 0 011.5 0v1.5A1.75 1.75 0 019.25 16h-7.5A1.75 1.75 0 010 14.25v-7.5z"></path><path fill-rule="evenodd" d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0114.25 11h-7.5A1.75 1.75 0 015 9.25v-7.5zm1.75-.25a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-7.5a.25.25 0 00-.25-.25h-7.5z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>


    


  


<div aria-live="polite" class="sr-only"></div></body></html>
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: cid:css-faa02a40-fa40-44ce-93ab-22f9432d1113@mhtml.blink

@charset "utf-8";

.user-mention[href$="/Din121212"] { color: var(--color-user-mention-fg); background-color: var(--color-user-mention-bg); border-radius: 2px; margin-left: -2px; margin-right: -2px; padding: 0px 2px; }
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://github.githubassets.com/assets/light-00a4b22ce27a010c3401f127b3575c75.css

@charset "utf-8";

:root, [data-color-mode="light"][data-light-theme="light"], [data-color-mode="dark"][data-dark-theme="light"] { }

:root, [data-color-mode="light"][data-light-theme="light"], [data-color-mode="dark"][data-dark-theme="light"] { --color-canvas-default-transparent: rgba(255,255,255,0); --color-marketing-icon-primary: #218bff; --color-marketing-icon-secondary: #54aeff; --color-diff-blob-addition-num-text: #24292f; --color-diff-blob-addition-fg: #24292f; --color-diff-blob-addition-num-bg: #CCFFD8; --color-diff-blob-addition-line-bg: #E6FFEC; --color-diff-blob-addition-word-bg: #ABF2BC; --color-diff-blob-deletion-num-text: #24292f; --color-diff-blob-deletion-fg: #24292f; --color-diff-blob-deletion-num-bg: #FFD7D5; --color-diff-blob-deletion-line-bg: #FFEBE9; --color-diff-blob-deletion-word-bg: rgba(255,129,130,0.4); --color-diff-blob-hunk-num-bg: rgba(84,174,255,0.4); --color-diff-blob-expander-icon: #57606a; --color-diff-blob-selected-line-highlight-mix-blend-mode: multiply; --color-diffstat-deletion-border: rgba(27,31,36,0.15); --color-diffstat-addition-border: rgba(27,31,36,0.15); --color-diffstat-addition-bg: #2da44e; --color-search-keyword-hl: #fff8c5; --color-prettylights-syntax-comment: #6e7781; --color-prettylights-syntax-constant: #0550ae; --color-prettylights-syntax-entity: #8250df; --color-prettylights-syntax-storage-modifier-import: #24292f; --color-prettylights-syntax-entity-tag: #116329; --color-prettylights-syntax-keyword: #cf222e; --color-prettylights-syntax-string: #0a3069; --color-prettylights-syntax-variable: #953800; --color-prettylights-syntax-brackethighlighter-unmatched: #82071e; --color-prettylights-syntax-invalid-illegal-text: #f6f8fa; --color-prettylights-syntax-invalid-illegal-bg: #82071e; --color-prettylights-syntax-carriage-return-text: #f6f8fa; --color-prettylights-syntax-carriage-return-bg: #cf222e; --color-prettylights-syntax-string-regexp: #116329; --color-prettylights-syntax-markup-list: #3b2300; --color-prettylights-syntax-markup-heading: #0550ae; --color-prettylights-syntax-markup-italic: #24292f; --color-prettylights-syntax-markup-bold: #24292f; --color-prettylights-syntax-markup-deleted-text: #82071e; --color-prettylights-syntax-markup-deleted-bg: #FFEBE9; --color-prettylights-syntax-markup-inserted-text: #116329; --color-prettylights-syntax-markup-inserted-bg: #dafbe1; --color-prettylights-syntax-markup-changed-text: #953800; --color-prettylights-syntax-markup-changed-bg: #ffd8b5; --color-prettylights-syntax-markup-ignored-text: #eaeef2; --color-prettylights-syntax-markup-ignored-bg: #0550ae; --color-prettylights-syntax-meta-diff-range: #8250df; --color-prettylights-syntax-brackethighlighter-angle: #57606a; --color-prettylights-syntax-sublimelinter-gutter-mark: #8c959f; --color-prettylights-syntax-constant-other-reference-link: #0a3069; --color-codemirror-text: #24292f; --color-codemirror-bg: #ffffff; --color-codemirror-gutters-bg: #ffffff; --color-codemirror-guttermarker-text: #ffffff; --color-codemirror-guttermarker-subtle-text: #6e7781; --color-codemirror-linenumber-text: #57606a; --color-codemirror-cursor: #24292f; --color-codemirror-selection-bg: rgba(84,174,255,0.4); --color-codemirror-activeline-bg: rgba(234,238,242,0.5); --color-codemirror-matchingbracket-text: #24292f; --color-codemirror-lines-bg: #ffffff; --color-codemirror-syntax-comment: #24292f; --color-codemirror-syntax-constant: #0550ae; --color-codemirror-syntax-entity: #8250df; --color-codemirror-syntax-keyword: #cf222e; --color-codemirror-syntax-storage: #cf222e; --color-codemirror-syntax-string: #0a3069; --color-codemirror-syntax-support: #0550ae; --color-codemirror-syntax-variable: #953800; --color-checks-bg: #24292f; --color-checks-run-border-width: 0px; --color-checks-container-border-width: 0px; --color-checks-text-primary: #f6f8fa; --color-checks-text-secondary: #8c959f; --color-checks-text-link: #54aeff; --color-checks-btn-icon: #afb8c1; --color-checks-btn-hover-icon: #f6f8fa; --color-checks-btn-hover-bg: rgba(255,255,255,0.125); --color-checks-input-text: #eaeef2; --color-checks-input-placeholder-text: #8c959f; --color-checks-input-focus-text: #8c959f; --color-checks-input-bg: #32383f; --color-checks-input-shadow: none; --color-checks-donut-error: #fa4549; --color-checks-donut-pending: #bf8700; --color-checks-donut-success: #2da44e; --color-checks-donut-neutral: #afb8c1; --color-checks-dropdown-text: #afb8c1; --color-checks-dropdown-bg: #32383f; --color-checks-dropdown-border: #424a53; --color-checks-dropdown-shadow: rgba(27,31,36,0.3); --color-checks-dropdown-hover-text: #f6f8fa; --color-checks-dropdown-hover-bg: #424a53; --color-checks-dropdown-btn-hover-text: #f6f8fa; --color-checks-dropdown-btn-hover-bg: #32383f; --color-checks-scrollbar-thumb-bg: #57606a; --color-checks-header-label-text: #d0d7de; --color-checks-header-label-open-text: #f6f8fa; --color-checks-header-border: #32383f; --color-checks-header-icon: #8c959f; --color-checks-line-text: #d0d7de; --color-checks-line-num-text: rgba(140,149,159,0.75); --color-checks-line-timestamp-text: #8c959f; --color-checks-line-hover-bg: #32383f; --color-checks-line-selected-bg: rgba(33,139,255,0.15); --color-checks-line-selected-num-text: #54aeff; --color-checks-line-dt-fm-text: #24292f; --color-checks-line-dt-fm-bg: #9a6700; --color-checks-gate-bg: rgba(125,78,0,0.15); --color-checks-gate-text: #d0d7de; --color-checks-gate-waiting-text: #afb8c1; --color-checks-step-header-open-bg: #32383f; --color-checks-step-error-text: #ff8182; --color-checks-step-warning-text: #d4a72c; --color-checks-logline-text: #8c959f; --color-checks-logline-num-text: rgba(140,149,159,0.75); --color-checks-logline-debug-text: #c297ff; --color-checks-logline-error-text: #d0d7de; --color-checks-logline-error-num-text: #ff8182; --color-checks-logline-error-bg: rgba(164,14,38,0.15); --color-checks-logline-warning-text: #d0d7de; --color-checks-logline-warning-num-text: #d4a72c; --color-checks-logline-warning-bg: rgba(125,78,0,0.15); --color-checks-logline-command-text: #54aeff; --color-checks-logline-section-text: #4ac26b; --color-checks-ansi-black: #24292f; --color-checks-ansi-black-bright: #32383f; --color-checks-ansi-white: #d0d7de; --color-checks-ansi-white-bright: #d0d7de; --color-checks-ansi-gray: #8c959f; --color-checks-ansi-red: #ff8182; --color-checks-ansi-red-bright: #ffaba8; --color-checks-ansi-green: #4ac26b; --color-checks-ansi-green-bright: #6fdd8b; --color-checks-ansi-yellow: #d4a72c; --color-checks-ansi-yellow-bright: #eac54f; --color-checks-ansi-blue: #54aeff; --color-checks-ansi-blue-bright: #80ccff; --color-checks-ansi-magenta: #c297ff; --color-checks-ansi-magenta-bright: #d8b9ff; --color-checks-ansi-cyan: #76e3ea; --color-checks-ansi-cyan-bright: #b3f0ff; --color-project-header-bg: #24292f; --color-project-sidebar-bg: #ffffff; --color-project-gradient-in: #ffffff; --color-project-gradient-out: rgba(255,255,255,0); --color-mktg-btn-bg: #1b1f23; --color-mktg-btn-shadow-outline: rgb(0 0 0 / 15%) 0 0 0 1px inset; --color-mktg-btn-shadow-focus: rgb(0 0 0 / 15%) 0 0 0 4px; --color-mktg-btn-shadow-hover: 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02); --color-mktg-btn-shadow-hover-muted: rgb(0 0 0 / 70%) 0 0 0 2px inset; --color-avatar-bg: #ffffff; --color-avatar-border: rgba(27,31,36,0.15); --color-avatar-stack-fade: #afb8c1; --color-avatar-stack-fade-more: #d0d7de; --color-avatar-child-shadow: -2px -2px 0 rgba(255,255,255,0.8); --color-topic-tag-border: rgba(0,0,0,0); --color-counter-border: rgba(0,0,0,0); --color-select-menu-backdrop-border: rgba(0,0,0,0); --color-select-menu-tap-highlight: rgba(175,184,193,0.5); --color-select-menu-tap-focus-bg: #b6e3ff; --color-overlay-shadow: 0 1px 3px rgba(27,31,36,0.12), 0 8px 24px rgba(66,74,83,0.12); --color-header-text: rgba(255,255,255,0.7); --color-header-bg: #24292f; --color-header-divider: #57606a; --color-header-logo: #ffffff; --color-header-search-bg: #24292f; --color-header-search-border: #57606a; --color-sidenav-selected-bg: #ffffff; --color-menu-bg-active: rgba(0,0,0,0); --color-input-disabled-bg: rgba(175,184,193,0.2); --color-timeline-badge-bg: #eaeef2; --color-ansi-black: #24292f; --color-ansi-black-bright: #57606a; --color-ansi-white: #6e7781; --color-ansi-white-bright: #8c959f; --color-ansi-gray: #6e7781; --color-ansi-red: #cf222e; --color-ansi-red-bright: #a40e26; --color-ansi-green: #116329; --color-ansi-green-bright: #1a7f37; --color-ansi-yellow: #4d2d00; --color-ansi-yellow-bright: #633c01; --color-ansi-blue: #0969da; --color-ansi-blue-bright: #218bff; --color-ansi-magenta: #8250df; --color-ansi-magenta-bright: #a475f9; --color-ansi-cyan: #1b7c83; --color-ansi-cyan-bright: #3192aa; --color-btn-text: #24292f; --color-btn-bg: #f6f8fa; --color-btn-border: rgba(27,31,36,0.15); --color-btn-shadow: 0 1px 0 rgba(27,31,36,0.04); --color-btn-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.25); --color-btn-hover-bg: #f3f4f6; --color-btn-hover-border: rgba(27,31,36,0.15); --color-btn-active-bg: hsla(220,14%,93%,1); --color-btn-active-border: rgba(27,31,36,0.15); --color-btn-selected-bg: hsla(220,14%,94%,1); --color-btn-focus-bg: #f6f8fa; --color-btn-focus-border: rgba(27,31,36,0.15); --color-btn-focus-shadow: 0 0 0 3px rgba(9,105,218,0.3); --color-btn-shadow-active: inset 0 0.15em 0.3em rgba(27,31,36,0.15); --color-btn-shadow-input-focus: 0 0 0 0.2em rgba(9,105,218,0.3); --color-btn-counter-bg: rgba(27,31,36,0.08); --color-btn-primary-text: #ffffff; --color-btn-primary-bg: #2da44e; --color-btn-primary-border: rgba(27,31,36,0.15); --color-btn-primary-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-primary-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-primary-hover-bg: #2c974b; --color-btn-primary-hover-border: rgba(27,31,36,0.15); --color-btn-primary-selected-bg: hsla(137,55%,36%,1); --color-btn-primary-selected-shadow: inset 0 1px 0 rgba(0,45,17,0.2); --color-btn-primary-disabled-text: rgba(255,255,255,0.8); --color-btn-primary-disabled-bg: #94d3a2; --color-btn-primary-disabled-border: rgba(27,31,36,0.15); --color-btn-primary-focus-bg: #2da44e; --color-btn-primary-focus-border: rgba(27,31,36,0.15); --color-btn-primary-focus-shadow: 0 0 0 3px rgba(45,164,78,0.4); --color-btn-primary-icon: rgba(255,255,255,0.8); --color-btn-primary-counter-bg: rgba(255,255,255,0.2); --color-btn-outline-text: #0969da; --color-btn-outline-hover-text: #ffffff; --color-btn-outline-hover-bg: #0969da; --color-btn-outline-hover-border: rgba(27,31,36,0.15); --color-btn-outline-hover-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-outline-hover-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-outline-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-outline-selected-text: #ffffff; --color-btn-outline-selected-bg: hsla(212,92%,42%,1); --color-btn-outline-selected-border: rgba(27,31,36,0.15); --color-btn-outline-selected-shadow: inset 0 1px 0 rgba(0,33,85,0.2); --color-btn-outline-disabled-text: rgba(9,105,218,0.5); --color-btn-outline-disabled-bg: #f6f8fa; --color-btn-outline-disabled-counter-bg: rgba(9,105,218,0.05); --color-btn-outline-focus-border: rgba(27,31,36,0.15); --color-btn-outline-focus-shadow: 0 0 0 3px rgba(5,80,174,0.4); --color-btn-outline-counter-bg: rgba(9,105,218,0.1); --color-btn-danger-text: #cf222e; --color-btn-danger-hover-text: #ffffff; --color-btn-danger-hover-bg: #a40e26; --color-btn-danger-hover-border: rgba(27,31,36,0.15); --color-btn-danger-hover-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-danger-hover-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-danger-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-danger-selected-text: #ffffff; --color-btn-danger-selected-bg: hsla(356,72%,44%,1); --color-btn-danger-selected-border: rgba(27,31,36,0.15); --color-btn-danger-selected-shadow: inset 0 1px 0 rgba(76,0,20,0.2); --color-btn-danger-disabled-text: rgba(207,34,46,0.5); --color-btn-danger-disabled-bg: #f6f8fa; --color-btn-danger-disabled-counter-bg: rgba(207,34,46,0.05); --color-btn-danger-focus-border: rgba(27,31,36,0.15); --color-btn-danger-focus-shadow: 0 0 0 3px rgba(164,14,38,0.4); --color-btn-danger-counter-bg: rgba(207,34,46,0.1); --color-btn-danger-icon: #cf222e; --color-btn-danger-hover-icon: #ffffff; --color-underlinenav-icon: #6e7781; --color-underlinenav-border-hover: rgba(175,184,193,0.2); --color-action-list-item-inline-divider: rgba(208,215,222,0.48); --color-action-list-item-default-hover-bg: rgba(208,215,222,0.32); --color-action-list-item-default-active-bg: rgba(208,215,222,0.48); --color-action-list-item-default-selected-bg: rgba(208,215,222,0.24); --color-action-list-item-danger-hover-bg: rgba(255,235,233,0.64); --color-action-list-item-danger-active-bg: #FFEBE9; --color-action-list-item-danger-hover-text: #cf222e; --color-fg-default: #24292f; --color-fg-muted: #57606a; --color-fg-subtle: #6e7781; --color-fg-on-emphasis: #ffffff; --color-canvas-default: #ffffff; --color-canvas-overlay: #ffffff; --color-canvas-inset: #f6f8fa; --color-canvas-subtle: #f6f8fa; --color-border-default: #d0d7de; --color-border-muted: hsla(210,18%,87%,1); --color-border-subtle: rgba(27,31,36,0.15); --color-shadow-small: 0 1px 0 rgba(27,31,36,0.04); --color-shadow-medium: 0 3px 6px rgba(140,149,159,0.15); --color-shadow-large: 0 8px 24px rgba(140,149,159,0.2); --color-shadow-extra-large: 0 12px 28px rgba(140,149,159,0.3); --color-neutral-emphasis-plus: #24292f; --color-neutral-emphasis: #6e7781; --color-neutral-muted: rgba(175,184,193,0.2); --color-neutral-subtle: rgba(234,238,242,0.5); --color-accent-fg: #0969da; --color-accent-emphasis: #0969da; --color-accent-muted: rgba(84,174,255,0.4); --color-accent-subtle: #ddf4ff; --color-success-fg: #1a7f37; --color-success-emphasis: #2da44e; --color-success-muted: rgba(74,194,107,0.4); --color-success-subtle: #dafbe1; --color-attention-fg: #9a6700; --color-attention-emphasis: #bf8700; --color-attention-muted: rgba(212,167,44,0.4); --color-attention-subtle: #fff8c5; --color-severe-fg: #bc4c00; --color-severe-emphasis: #bc4c00; --color-severe-muted: rgba(251,143,68,0.4); --color-severe-subtle: #fff1e5; --color-danger-fg: #cf222e; --color-danger-emphasis: #cf222e; --color-danger-muted: rgba(255,129,130,0.4); --color-danger-subtle: #FFEBE9; --color-done-fg: #8250df; --color-done-emphasis: #8250df; --color-done-muted: rgba(194,151,255,0.4); --color-done-subtle: #fbefff; --color-sponsors-fg: #bf3989; --color-sponsors-emphasis: #bf3989; --color-sponsors-muted: rgba(255,128,200,0.4); --color-sponsors-subtle: #ffeff7; --color-primer-fg-disabled: #8c959f; --color-primer-canvas-backdrop: rgba(27,31,36,0.5); --color-primer-canvas-sticky: rgba(255,255,255,0.95); --color-primer-border-active: #FD8C73; --color-primer-border-contrast: rgba(27,31,36,0.1); --color-primer-shadow-highlight: inset 0 1px 0 rgba(255,255,255,0.25); --color-primer-shadow-inset: inset 0 1px 0 rgba(208,215,222,0.2); --color-primer-shadow-focus: 0 0 0 3px rgba(9,105,218,0.3); --color-scale-black: #1b1f24; --color-scale-white: #ffffff; --color-scale-gray-0: #f6f8fa; --color-scale-gray-1: #eaeef2; --color-scale-gray-2: #d0d7de; --color-scale-gray-3: #afb8c1; --color-scale-gray-4: #8c959f; --color-scale-gray-5: #6e7781; --color-scale-gray-6: #57606a; --color-scale-gray-7: #424a53; --color-scale-gray-8: #32383f; --color-scale-gray-9: #24292f; --color-scale-blue-0: #ddf4ff; --color-scale-blue-1: #b6e3ff; --color-scale-blue-2: #80ccff; --color-scale-blue-3: #54aeff; --color-scale-blue-4: #218bff; --color-scale-blue-5: #0969da; --color-scale-blue-6: #0550ae; --color-scale-blue-7: #033d8b; --color-scale-blue-8: #0a3069; --color-scale-blue-9: #002155; --color-scale-green-0: #dafbe1; --color-scale-green-1: #aceebb; --color-scale-green-2: #6fdd8b; --color-scale-green-3: #4ac26b; --color-scale-green-4: #2da44e; --color-scale-green-5: #1a7f37; --color-scale-green-6: #116329; --color-scale-green-7: #044f1e; --color-scale-green-8: #003d16; --color-scale-green-9: #002d11; --color-scale-yellow-0: #fff8c5; --color-scale-yellow-1: #fae17d; --color-scale-yellow-2: #eac54f; --color-scale-yellow-3: #d4a72c; --color-scale-yellow-4: #bf8700; --color-scale-yellow-5: #9a6700; --color-scale-yellow-6: #7d4e00; --color-scale-yellow-7: #633c01; --color-scale-yellow-8: #4d2d00; --color-scale-yellow-9: #3b2300; --color-scale-orange-0: #fff1e5; --color-scale-orange-1: #ffd8b5; --color-scale-orange-2: #ffb77c; --color-scale-orange-3: #fb8f44; --color-scale-orange-4: #e16f24; --color-scale-orange-5: #bc4c00; --color-scale-orange-6: #953800; --color-scale-orange-7: #762c00; --color-scale-orange-8: #5c2200; --color-scale-orange-9: #471700; --color-scale-red-0: #FFEBE9; --color-scale-red-1: #ffcecb; --color-scale-red-2: #ffaba8; --color-scale-red-3: #ff8182; --color-scale-red-4: #fa4549; --color-scale-red-5: #cf222e; --color-scale-red-6: #a40e26; --color-scale-red-7: #82071e; --color-scale-red-8: #660018; --color-scale-red-9: #4c0014; --color-scale-purple-0: #fbefff; --color-scale-purple-1: #ecd8ff; --color-scale-purple-2: #d8b9ff; --color-scale-purple-3: #c297ff; --color-scale-purple-4: #a475f9; --color-scale-purple-5: #8250df; --color-scale-purple-6: #6639ba; --color-scale-purple-7: #512a97; --color-scale-purple-8: #3e1f79; --color-scale-purple-9: #2e1461; --color-scale-pink-0: #ffeff7; --color-scale-pink-1: #ffd3eb; --color-scale-pink-2: #ffadda; --color-scale-pink-3: #ff80c8; --color-scale-pink-4: #e85aad; --color-scale-pink-5: #bf3989; --color-scale-pink-6: #99286e; --color-scale-pink-7: #772057; --color-scale-pink-8: #611347; --color-scale-pink-9: #4d0336; --color-scale-coral-0: #FFF0EB; --color-scale-coral-1: #FFD6CC; --color-scale-coral-2: #FFB4A1; --color-scale-coral-3: #FD8C73; --color-scale-coral-4: #EC6547; --color-scale-coral-5: #C4432B; --color-scale-coral-6: #9E2F1C; --color-scale-coral-7: #801F0F; --color-scale-coral-8: #691105; --color-scale-coral-9: #510901; }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme="light"] { --color-canvas-default-transparent: rgba(255,255,255,0); --color-marketing-icon-primary: #218bff; --color-marketing-icon-secondary: #54aeff; --color-diff-blob-addition-num-text: #24292f; --color-diff-blob-addition-fg: #24292f; --color-diff-blob-addition-num-bg: #CCFFD8; --color-diff-blob-addition-line-bg: #E6FFEC; --color-diff-blob-addition-word-bg: #ABF2BC; --color-diff-blob-deletion-num-text: #24292f; --color-diff-blob-deletion-fg: #24292f; --color-diff-blob-deletion-num-bg: #FFD7D5; --color-diff-blob-deletion-line-bg: #FFEBE9; --color-diff-blob-deletion-word-bg: rgba(255,129,130,0.4); --color-diff-blob-hunk-num-bg: rgba(84,174,255,0.4); --color-diff-blob-expander-icon: #57606a; --color-diff-blob-selected-line-highlight-mix-blend-mode: multiply; --color-diffstat-deletion-border: rgba(27,31,36,0.15); --color-diffstat-addition-border: rgba(27,31,36,0.15); --color-diffstat-addition-bg: #2da44e; --color-search-keyword-hl: #fff8c5; --color-prettylights-syntax-comment: #6e7781; --color-prettylights-syntax-constant: #0550ae; --color-prettylights-syntax-entity: #8250df; --color-prettylights-syntax-storage-modifier-import: #24292f; --color-prettylights-syntax-entity-tag: #116329; --color-prettylights-syntax-keyword: #cf222e; --color-prettylights-syntax-string: #0a3069; --color-prettylights-syntax-variable: #953800; --color-prettylights-syntax-brackethighlighter-unmatched: #82071e; --color-prettylights-syntax-invalid-illegal-text: #f6f8fa; --color-prettylights-syntax-invalid-illegal-bg: #82071e; --color-prettylights-syntax-carriage-return-text: #f6f8fa; --color-prettylights-syntax-carriage-return-bg: #cf222e; --color-prettylights-syntax-string-regexp: #116329; --color-prettylights-syntax-markup-list: #3b2300; --color-prettylights-syntax-markup-heading: #0550ae; --color-prettylights-syntax-markup-italic: #24292f; --color-prettylights-syntax-markup-bold: #24292f; --color-prettylights-syntax-markup-deleted-text: #82071e; --color-prettylights-syntax-markup-deleted-bg: #FFEBE9; --color-prettylights-syntax-markup-inserted-text: #116329; --color-prettylights-syntax-markup-inserted-bg: #dafbe1; --color-prettylights-syntax-markup-changed-text: #953800; --color-prettylights-syntax-markup-changed-bg: #ffd8b5; --color-prettylights-syntax-markup-ignored-text: #eaeef2; --color-prettylights-syntax-markup-ignored-bg: #0550ae; --color-prettylights-syntax-meta-diff-range: #8250df; --color-prettylights-syntax-brackethighlighter-angle: #57606a; --color-prettylights-syntax-sublimelinter-gutter-mark: #8c959f; --color-prettylights-syntax-constant-other-reference-link: #0a3069; --color-codemirror-text: #24292f; --color-codemirror-bg: #ffffff; --color-codemirror-gutters-bg: #ffffff; --color-codemirror-guttermarker-text: #ffffff; --color-codemirror-guttermarker-subtle-text: #6e7781; --color-codemirror-linenumber-text: #57606a; --color-codemirror-cursor: #24292f; --color-codemirror-selection-bg: rgba(84,174,255,0.4); --color-codemirror-activeline-bg: rgba(234,238,242,0.5); --color-codemirror-matchingbracket-text: #24292f; --color-codemirror-lines-bg: #ffffff; --color-codemirror-syntax-comment: #24292f; --color-codemirror-syntax-constant: #0550ae; --color-codemirror-syntax-entity: #8250df; --color-codemirror-syntax-keyword: #cf222e; --color-codemirror-syntax-storage: #cf222e; --color-codemirror-syntax-string: #0a3069; --color-codemirror-syntax-support: #0550ae; --color-codemirror-syntax-variable: #953800; --color-checks-bg: #24292f; --color-checks-run-border-width: 0px; --color-checks-container-border-width: 0px; --color-checks-text-primary: #f6f8fa; --color-checks-text-secondary: #8c959f; --color-checks-text-link: #54aeff; --color-checks-btn-icon: #afb8c1; --color-checks-btn-hover-icon: #f6f8fa; --color-checks-btn-hover-bg: rgba(255,255,255,0.125); --color-checks-input-text: #eaeef2; --color-checks-input-placeholder-text: #8c959f; --color-checks-input-focus-text: #8c959f; --color-checks-input-bg: #32383f; --color-checks-input-shadow: none; --color-checks-donut-error: #fa4549; --color-checks-donut-pending: #bf8700; --color-checks-donut-success: #2da44e; --color-checks-donut-neutral: #afb8c1; --color-checks-dropdown-text: #afb8c1; --color-checks-dropdown-bg: #32383f; --color-checks-dropdown-border: #424a53; --color-checks-dropdown-shadow: rgba(27,31,36,0.3); --color-checks-dropdown-hover-text: #f6f8fa; --color-checks-dropdown-hover-bg: #424a53; --color-checks-dropdown-btn-hover-text: #f6f8fa; --color-checks-dropdown-btn-hover-bg: #32383f; --color-checks-scrollbar-thumb-bg: #57606a; --color-checks-header-label-text: #d0d7de; --color-checks-header-label-open-text: #f6f8fa; --color-checks-header-border: #32383f; --color-checks-header-icon: #8c959f; --color-checks-line-text: #d0d7de; --color-checks-line-num-text: rgba(140,149,159,0.75); --color-checks-line-timestamp-text: #8c959f; --color-checks-line-hover-bg: #32383f; --color-checks-line-selected-bg: rgba(33,139,255,0.15); --color-checks-line-selected-num-text: #54aeff; --color-checks-line-dt-fm-text: #24292f; --color-checks-line-dt-fm-bg: #9a6700; --color-checks-gate-bg: rgba(125,78,0,0.15); --color-checks-gate-text: #d0d7de; --color-checks-gate-waiting-text: #afb8c1; --color-checks-step-header-open-bg: #32383f; --color-checks-step-error-text: #ff8182; --color-checks-step-warning-text: #d4a72c; --color-checks-logline-text: #8c959f; --color-checks-logline-num-text: rgba(140,149,159,0.75); --color-checks-logline-debug-text: #c297ff; --color-checks-logline-error-text: #d0d7de; --color-checks-logline-error-num-text: #ff8182; --color-checks-logline-error-bg: rgba(164,14,38,0.15); --color-checks-logline-warning-text: #d0d7de; --color-checks-logline-warning-num-text: #d4a72c; --color-checks-logline-warning-bg: rgba(125,78,0,0.15); --color-checks-logline-command-text: #54aeff; --color-checks-logline-section-text: #4ac26b; --color-checks-ansi-black: #24292f; --color-checks-ansi-black-bright: #32383f; --color-checks-ansi-white: #d0d7de; --color-checks-ansi-white-bright: #d0d7de; --color-checks-ansi-gray: #8c959f; --color-checks-ansi-red: #ff8182; --color-checks-ansi-red-bright: #ffaba8; --color-checks-ansi-green: #4ac26b; --color-checks-ansi-green-bright: #6fdd8b; --color-checks-ansi-yellow: #d4a72c; --color-checks-ansi-yellow-bright: #eac54f; --color-checks-ansi-blue: #54aeff; --color-checks-ansi-blue-bright: #80ccff; --color-checks-ansi-magenta: #c297ff; --color-checks-ansi-magenta-bright: #d8b9ff; --color-checks-ansi-cyan: #76e3ea; --color-checks-ansi-cyan-bright: #b3f0ff; --color-project-header-bg: #24292f; --color-project-sidebar-bg: #ffffff; --color-project-gradient-in: #ffffff; --color-project-gradient-out: rgba(255,255,255,0); --color-mktg-btn-bg: #1b1f23; --color-mktg-btn-shadow-outline: rgb(0 0 0 / 15%) 0 0 0 1px inset; --color-mktg-btn-shadow-focus: rgb(0 0 0 / 15%) 0 0 0 4px; --color-mktg-btn-shadow-hover: 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02); --color-mktg-btn-shadow-hover-muted: rgb(0 0 0 / 70%) 0 0 0 2px inset; --color-avatar-bg: #ffffff; --color-avatar-border: rgba(27,31,36,0.15); --color-avatar-stack-fade: #afb8c1; --color-avatar-stack-fade-more: #d0d7de; --color-avatar-child-shadow: -2px -2px 0 rgba(255,255,255,0.8); --color-topic-tag-border: rgba(0,0,0,0); --color-counter-border: rgba(0,0,0,0); --color-select-menu-backdrop-border: rgba(0,0,0,0); --color-select-menu-tap-highlight: rgba(175,184,193,0.5); --color-select-menu-tap-focus-bg: #b6e3ff; --color-overlay-shadow: 0 1px 3px rgba(27,31,36,0.12), 0 8px 24px rgba(66,74,83,0.12); --color-header-text: rgba(255,255,255,0.7); --color-header-bg: #24292f; --color-header-divider: #57606a; --color-header-logo: #ffffff; --color-header-search-bg: #24292f; --color-header-search-border: #57606a; --color-sidenav-selected-bg: #ffffff; --color-menu-bg-active: rgba(0,0,0,0); --color-input-disabled-bg: rgba(175,184,193,0.2); --color-timeline-badge-bg: #eaeef2; --color-ansi-black: #24292f; --color-ansi-black-bright: #57606a; --color-ansi-white: #6e7781; --color-ansi-white-bright: #8c959f; --color-ansi-gray: #6e7781; --color-ansi-red: #cf222e; --color-ansi-red-bright: #a40e26; --color-ansi-green: #116329; --color-ansi-green-bright: #1a7f37; --color-ansi-yellow: #4d2d00; --color-ansi-yellow-bright: #633c01; --color-ansi-blue: #0969da; --color-ansi-blue-bright: #218bff; --color-ansi-magenta: #8250df; --color-ansi-magenta-bright: #a475f9; --color-ansi-cyan: #1b7c83; --color-ansi-cyan-bright: #3192aa; --color-btn-text: #24292f; --color-btn-bg: #f6f8fa; --color-btn-border: rgba(27,31,36,0.15); --color-btn-shadow: 0 1px 0 rgba(27,31,36,0.04); --color-btn-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.25); --color-btn-hover-bg: #f3f4f6; --color-btn-hover-border: rgba(27,31,36,0.15); --color-btn-active-bg: hsla(220,14%,93%,1); --color-btn-active-border: rgba(27,31,36,0.15); --color-btn-selected-bg: hsla(220,14%,94%,1); --color-btn-focus-bg: #f6f8fa; --color-btn-focus-border: rgba(27,31,36,0.15); --color-btn-focus-shadow: 0 0 0 3px rgba(9,105,218,0.3); --color-btn-shadow-active: inset 0 0.15em 0.3em rgba(27,31,36,0.15); --color-btn-shadow-input-focus: 0 0 0 0.2em rgba(9,105,218,0.3); --color-btn-counter-bg: rgba(27,31,36,0.08); --color-btn-primary-text: #ffffff; --color-btn-primary-bg: #2da44e; --color-btn-primary-border: rgba(27,31,36,0.15); --color-btn-primary-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-primary-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-primary-hover-bg: #2c974b; --color-btn-primary-hover-border: rgba(27,31,36,0.15); --color-btn-primary-selected-bg: hsla(137,55%,36%,1); --color-btn-primary-selected-shadow: inset 0 1px 0 rgba(0,45,17,0.2); --color-btn-primary-disabled-text: rgba(255,255,255,0.8); --color-btn-primary-disabled-bg: #94d3a2; --color-btn-primary-disabled-border: rgba(27,31,36,0.15); --color-btn-primary-focus-bg: #2da44e; --color-btn-primary-focus-border: rgba(27,31,36,0.15); --color-btn-primary-focus-shadow: 0 0 0 3px rgba(45,164,78,0.4); --color-btn-primary-icon: rgba(255,255,255,0.8); --color-btn-primary-counter-bg: rgba(255,255,255,0.2); --color-btn-outline-text: #0969da; --color-btn-outline-hover-text: #ffffff; --color-btn-outline-hover-bg: #0969da; --color-btn-outline-hover-border: rgba(27,31,36,0.15); --color-btn-outline-hover-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-outline-hover-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-outline-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-outline-selected-text: #ffffff; --color-btn-outline-selected-bg: hsla(212,92%,42%,1); --color-btn-outline-selected-border: rgba(27,31,36,0.15); --color-btn-outline-selected-shadow: inset 0 1px 0 rgba(0,33,85,0.2); --color-btn-outline-disabled-text: rgba(9,105,218,0.5); --color-btn-outline-disabled-bg: #f6f8fa; --color-btn-outline-disabled-counter-bg: rgba(9,105,218,0.05); --color-btn-outline-focus-border: rgba(27,31,36,0.15); --color-btn-outline-focus-shadow: 0 0 0 3px rgba(5,80,174,0.4); --color-btn-outline-counter-bg: rgba(9,105,218,0.1); --color-btn-danger-text: #cf222e; --color-btn-danger-hover-text: #ffffff; --color-btn-danger-hover-bg: #a40e26; --color-btn-danger-hover-border: rgba(27,31,36,0.15); --color-btn-danger-hover-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-danger-hover-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-danger-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-danger-selected-text: #ffffff; --color-btn-danger-selected-bg: hsla(356,72%,44%,1); --color-btn-danger-selected-border: rgba(27,31,36,0.15); --color-btn-danger-selected-shadow: inset 0 1px 0 rgba(76,0,20,0.2); --color-btn-danger-disabled-text: rgba(207,34,46,0.5); --color-btn-danger-disabled-bg: #f6f8fa; --color-btn-danger-disabled-counter-bg: rgba(207,34,46,0.05); --color-btn-danger-focus-border: rgba(27,31,36,0.15); --color-btn-danger-focus-shadow: 0 0 0 3px rgba(164,14,38,0.4); --color-btn-danger-counter-bg: rgba(207,34,46,0.1); --color-btn-danger-icon: #cf222e; --color-btn-danger-hover-icon: #ffffff; --color-underlinenav-icon: #6e7781; --color-underlinenav-border-hover: rgba(175,184,193,0.2); --color-action-list-item-inline-divider: rgba(208,215,222,0.48); --color-action-list-item-default-hover-bg: rgba(208,215,222,0.32); --color-action-list-item-default-active-bg: rgba(208,215,222,0.48); --color-action-list-item-default-selected-bg: rgba(208,215,222,0.24); --color-action-list-item-danger-hover-bg: rgba(255,235,233,0.64); --color-action-list-item-danger-active-bg: #FFEBE9; --color-action-list-item-danger-hover-text: #cf222e; --color-fg-default: #24292f; --color-fg-muted: #57606a; --color-fg-subtle: #6e7781; --color-fg-on-emphasis: #ffffff; --color-canvas-default: #ffffff; --color-canvas-overlay: #ffffff; --color-canvas-inset: #f6f8fa; --color-canvas-subtle: #f6f8fa; --color-border-default: #d0d7de; --color-border-muted: hsla(210,18%,87%,1); --color-border-subtle: rgba(27,31,36,0.15); --color-shadow-small: 0 1px 0 rgba(27,31,36,0.04); --color-shadow-medium: 0 3px 6px rgba(140,149,159,0.15); --color-shadow-large: 0 8px 24px rgba(140,149,159,0.2); --color-shadow-extra-large: 0 12px 28px rgba(140,149,159,0.3); --color-neutral-emphasis-plus: #24292f; --color-neutral-emphasis: #6e7781; --color-neutral-muted: rgba(175,184,193,0.2); --color-neutral-subtle: rgba(234,238,242,0.5); --color-accent-fg: #0969da; --color-accent-emphasis: #0969da; --color-accent-muted: rgba(84,174,255,0.4); --color-accent-subtle: #ddf4ff; --color-success-fg: #1a7f37; --color-success-emphasis: #2da44e; --color-success-muted: rgba(74,194,107,0.4); --color-success-subtle: #dafbe1; --color-attention-fg: #9a6700; --color-attention-emphasis: #bf8700; --color-attention-muted: rgba(212,167,44,0.4); --color-attention-subtle: #fff8c5; --color-severe-fg: #bc4c00; --color-severe-emphasis: #bc4c00; --color-severe-muted: rgba(251,143,68,0.4); --color-severe-subtle: #fff1e5; --color-danger-fg: #cf222e; --color-danger-emphasis: #cf222e; --color-danger-muted: rgba(255,129,130,0.4); --color-danger-subtle: #FFEBE9; --color-done-fg: #8250df; --color-done-emphasis: #8250df; --color-done-muted: rgba(194,151,255,0.4); --color-done-subtle: #fbefff; --color-sponsors-fg: #bf3989; --color-sponsors-emphasis: #bf3989; --color-sponsors-muted: rgba(255,128,200,0.4); --color-sponsors-subtle: #ffeff7; --color-primer-fg-disabled: #8c959f; --color-primer-canvas-backdrop: rgba(27,31,36,0.5); --color-primer-canvas-sticky: rgba(255,255,255,0.95); --color-primer-border-active: #FD8C73; --color-primer-border-contrast: rgba(27,31,36,0.1); --color-primer-shadow-highlight: inset 0 1px 0 rgba(255,255,255,0.25); --color-primer-shadow-inset: inset 0 1px 0 rgba(208,215,222,0.2); --color-primer-shadow-focus: 0 0 0 3px rgba(9,105,218,0.3); --color-scale-black: #1b1f24; --color-scale-white: #ffffff; --color-scale-gray-0: #f6f8fa; --color-scale-gray-1: #eaeef2; --color-scale-gray-2: #d0d7de; --color-scale-gray-3: #afb8c1; --color-scale-gray-4: #8c959f; --color-scale-gray-5: #6e7781; --color-scale-gray-6: #57606a; --color-scale-gray-7: #424a53; --color-scale-gray-8: #32383f; --color-scale-gray-9: #24292f; --color-scale-blue-0: #ddf4ff; --color-scale-blue-1: #b6e3ff; --color-scale-blue-2: #80ccff; --color-scale-blue-3: #54aeff; --color-scale-blue-4: #218bff; --color-scale-blue-5: #0969da; --color-scale-blue-6: #0550ae; --color-scale-blue-7: #033d8b; --color-scale-blue-8: #0a3069; --color-scale-blue-9: #002155; --color-scale-green-0: #dafbe1; --color-scale-green-1: #aceebb; --color-scale-green-2: #6fdd8b; --color-scale-green-3: #4ac26b; --color-scale-green-4: #2da44e; --color-scale-green-5: #1a7f37; --color-scale-green-6: #116329; --color-scale-green-7: #044f1e; --color-scale-green-8: #003d16; --color-scale-green-9: #002d11; --color-scale-yellow-0: #fff8c5; --color-scale-yellow-1: #fae17d; --color-scale-yellow-2: #eac54f; --color-scale-yellow-3: #d4a72c; --color-scale-yellow-4: #bf8700; --color-scale-yellow-5: #9a6700; --color-scale-yellow-6: #7d4e00; --color-scale-yellow-7: #633c01; --color-scale-yellow-8: #4d2d00; --color-scale-yellow-9: #3b2300; --color-scale-orange-0: #fff1e5; --color-scale-orange-1: #ffd8b5; --color-scale-orange-2: #ffb77c; --color-scale-orange-3: #fb8f44; --color-scale-orange-4: #e16f24; --color-scale-orange-5: #bc4c00; --color-scale-orange-6: #953800; --color-scale-orange-7: #762c00; --color-scale-orange-8: #5c2200; --color-scale-orange-9: #471700; --color-scale-red-0: #FFEBE9; --color-scale-red-1: #ffcecb; --color-scale-red-2: #ffaba8; --color-scale-red-3: #ff8182; --color-scale-red-4: #fa4549; --color-scale-red-5: #cf222e; --color-scale-red-6: #a40e26; --color-scale-red-7: #82071e; --color-scale-red-8: #660018; --color-scale-red-9: #4c0014; --color-scale-purple-0: #fbefff; --color-scale-purple-1: #ecd8ff; --color-scale-purple-2: #d8b9ff; --color-scale-purple-3: #c297ff; --color-scale-purple-4: #a475f9; --color-scale-purple-5: #8250df; --color-scale-purple-6: #6639ba; --color-scale-purple-7: #512a97; --color-scale-purple-8: #3e1f79; --color-scale-purple-9: #2e1461; --color-scale-pink-0: #ffeff7; --color-scale-pink-1: #ffd3eb; --color-scale-pink-2: #ffadda; --color-scale-pink-3: #ff80c8; --color-scale-pink-4: #e85aad; --color-scale-pink-5: #bf3989; --color-scale-pink-6: #99286e; --color-scale-pink-7: #772057; --color-scale-pink-8: #611347; --color-scale-pink-9: #4d0336; --color-scale-coral-0: #FFF0EB; --color-scale-coral-1: #FFD6CC; --color-scale-coral-2: #FFB4A1; --color-scale-coral-3: #FD8C73; --color-scale-coral-4: #EC6547; --color-scale-coral-5: #C4432B; --color-scale-coral-6: #9E2F1C; --color-scale-coral-7: #801F0F; --color-scale-coral-8: #691105; --color-scale-coral-9: #510901; }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme="light"] { --color-canvas-default-transparent: rgba(255,255,255,0); --color-marketing-icon-primary: #218bff; --color-marketing-icon-secondary: #54aeff; --color-diff-blob-addition-num-text: #24292f; --color-diff-blob-addition-fg: #24292f; --color-diff-blob-addition-num-bg: #CCFFD8; --color-diff-blob-addition-line-bg: #E6FFEC; --color-diff-blob-addition-word-bg: #ABF2BC; --color-diff-blob-deletion-num-text: #24292f; --color-diff-blob-deletion-fg: #24292f; --color-diff-blob-deletion-num-bg: #FFD7D5; --color-diff-blob-deletion-line-bg: #FFEBE9; --color-diff-blob-deletion-word-bg: rgba(255,129,130,0.4); --color-diff-blob-hunk-num-bg: rgba(84,174,255,0.4); --color-diff-blob-expander-icon: #57606a; --color-diff-blob-selected-line-highlight-mix-blend-mode: multiply; --color-diffstat-deletion-border: rgba(27,31,36,0.15); --color-diffstat-addition-border: rgba(27,31,36,0.15); --color-diffstat-addition-bg: #2da44e; --color-search-keyword-hl: #fff8c5; --color-prettylights-syntax-comment: #6e7781; --color-prettylights-syntax-constant: #0550ae; --color-prettylights-syntax-entity: #8250df; --color-prettylights-syntax-storage-modifier-import: #24292f; --color-prettylights-syntax-entity-tag: #116329; --color-prettylights-syntax-keyword: #cf222e; --color-prettylights-syntax-string: #0a3069; --color-prettylights-syntax-variable: #953800; --color-prettylights-syntax-brackethighlighter-unmatched: #82071e; --color-prettylights-syntax-invalid-illegal-text: #f6f8fa; --color-prettylights-syntax-invalid-illegal-bg: #82071e; --color-prettylights-syntax-carriage-return-text: #f6f8fa; --color-prettylights-syntax-carriage-return-bg: #cf222e; --color-prettylights-syntax-string-regexp: #116329; --color-prettylights-syntax-markup-list: #3b2300; --color-prettylights-syntax-markup-heading: #0550ae; --color-prettylights-syntax-markup-italic: #24292f; --color-prettylights-syntax-markup-bold: #24292f; --color-prettylights-syntax-markup-deleted-text: #82071e; --color-prettylights-syntax-markup-deleted-bg: #FFEBE9; --color-prettylights-syntax-markup-inserted-text: #116329; --color-prettylights-syntax-markup-inserted-bg: #dafbe1; --color-prettylights-syntax-markup-changed-text: #953800; --color-prettylights-syntax-markup-changed-bg: #ffd8b5; --color-prettylights-syntax-markup-ignored-text: #eaeef2; --color-prettylights-syntax-markup-ignored-bg: #0550ae; --color-prettylights-syntax-meta-diff-range: #8250df; --color-prettylights-syntax-brackethighlighter-angle: #57606a; --color-prettylights-syntax-sublimelinter-gutter-mark: #8c959f; --color-prettylights-syntax-constant-other-reference-link: #0a3069; --color-codemirror-text: #24292f; --color-codemirror-bg: #ffffff; --color-codemirror-gutters-bg: #ffffff; --color-codemirror-guttermarker-text: #ffffff; --color-codemirror-guttermarker-subtle-text: #6e7781; --color-codemirror-linenumber-text: #57606a; --color-codemirror-cursor: #24292f; --color-codemirror-selection-bg: rgba(84,174,255,0.4); --color-codemirror-activeline-bg: rgba(234,238,242,0.5); --color-codemirror-matchingbracket-text: #24292f; --color-codemirror-lines-bg: #ffffff; --color-codemirror-syntax-comment: #24292f; --color-codemirror-syntax-constant: #0550ae; --color-codemirror-syntax-entity: #8250df; --color-codemirror-syntax-keyword: #cf222e; --color-codemirror-syntax-storage: #cf222e; --color-codemirror-syntax-string: #0a3069; --color-codemirror-syntax-support: #0550ae; --color-codemirror-syntax-variable: #953800; --color-checks-bg: #24292f; --color-checks-run-border-width: 0px; --color-checks-container-border-width: 0px; --color-checks-text-primary: #f6f8fa; --color-checks-text-secondary: #8c959f; --color-checks-text-link: #54aeff; --color-checks-btn-icon: #afb8c1; --color-checks-btn-hover-icon: #f6f8fa; --color-checks-btn-hover-bg: rgba(255,255,255,0.125); --color-checks-input-text: #eaeef2; --color-checks-input-placeholder-text: #8c959f; --color-checks-input-focus-text: #8c959f; --color-checks-input-bg: #32383f; --color-checks-input-shadow: none; --color-checks-donut-error: #fa4549; --color-checks-donut-pending: #bf8700; --color-checks-donut-success: #2da44e; --color-checks-donut-neutral: #afb8c1; --color-checks-dropdown-text: #afb8c1; --color-checks-dropdown-bg: #32383f; --color-checks-dropdown-border: #424a53; --color-checks-dropdown-shadow: rgba(27,31,36,0.3); --color-checks-dropdown-hover-text: #f6f8fa; --color-checks-dropdown-hover-bg: #424a53; --color-checks-dropdown-btn-hover-text: #f6f8fa; --color-checks-dropdown-btn-hover-bg: #32383f; --color-checks-scrollbar-thumb-bg: #57606a; --color-checks-header-label-text: #d0d7de; --color-checks-header-label-open-text: #f6f8fa; --color-checks-header-border: #32383f; --color-checks-header-icon: #8c959f; --color-checks-line-text: #d0d7de; --color-checks-line-num-text: rgba(140,149,159,0.75); --color-checks-line-timestamp-text: #8c959f; --color-checks-line-hover-bg: #32383f; --color-checks-line-selected-bg: rgba(33,139,255,0.15); --color-checks-line-selected-num-text: #54aeff; --color-checks-line-dt-fm-text: #24292f; --color-checks-line-dt-fm-bg: #9a6700; --color-checks-gate-bg: rgba(125,78,0,0.15); --color-checks-gate-text: #d0d7de; --color-checks-gate-waiting-text: #afb8c1; --color-checks-step-header-open-bg: #32383f; --color-checks-step-error-text: #ff8182; --color-checks-step-warning-text: #d4a72c; --color-checks-logline-text: #8c959f; --color-checks-logline-num-text: rgba(140,149,159,0.75); --color-checks-logline-debug-text: #c297ff; --color-checks-logline-error-text: #d0d7de; --color-checks-logline-error-num-text: #ff8182; --color-checks-logline-error-bg: rgba(164,14,38,0.15); --color-checks-logline-warning-text: #d0d7de; --color-checks-logline-warning-num-text: #d4a72c; --color-checks-logline-warning-bg: rgba(125,78,0,0.15); --color-checks-logline-command-text: #54aeff; --color-checks-logline-section-text: #4ac26b; --color-checks-ansi-black: #24292f; --color-checks-ansi-black-bright: #32383f; --color-checks-ansi-white: #d0d7de; --color-checks-ansi-white-bright: #d0d7de; --color-checks-ansi-gray: #8c959f; --color-checks-ansi-red: #ff8182; --color-checks-ansi-red-bright: #ffaba8; --color-checks-ansi-green: #4ac26b; --color-checks-ansi-green-bright: #6fdd8b; --color-checks-ansi-yellow: #d4a72c; --color-checks-ansi-yellow-bright: #eac54f; --color-checks-ansi-blue: #54aeff; --color-checks-ansi-blue-bright: #80ccff; --color-checks-ansi-magenta: #c297ff; --color-checks-ansi-magenta-bright: #d8b9ff; --color-checks-ansi-cyan: #76e3ea; --color-checks-ansi-cyan-bright: #b3f0ff; --color-project-header-bg: #24292f; --color-project-sidebar-bg: #ffffff; --color-project-gradient-in: #ffffff; --color-project-gradient-out: rgba(255,255,255,0); --color-mktg-btn-bg: #1b1f23; --color-mktg-btn-shadow-outline: rgb(0 0 0 / 15%) 0 0 0 1px inset; --color-mktg-btn-shadow-focus: rgb(0 0 0 / 15%) 0 0 0 4px; --color-mktg-btn-shadow-hover: 0 3px 2px rgba(0, 0, 0, 0.07), 0 7px 5px rgba(0, 0, 0, 0.04), 0 12px 10px rgba(0, 0, 0, 0.03), 0 22px 18px rgba(0, 0, 0, 0.03), 0 42px 33px rgba(0, 0, 0, 0.02), 0 100px 80px rgba(0, 0, 0, 0.02); --color-mktg-btn-shadow-hover-muted: rgb(0 0 0 / 70%) 0 0 0 2px inset; --color-avatar-bg: #ffffff; --color-avatar-border: rgba(27,31,36,0.15); --color-avatar-stack-fade: #afb8c1; --color-avatar-stack-fade-more: #d0d7de; --color-avatar-child-shadow: -2px -2px 0 rgba(255,255,255,0.8); --color-topic-tag-border: rgba(0,0,0,0); --color-counter-border: rgba(0,0,0,0); --color-select-menu-backdrop-border: rgba(0,0,0,0); --color-select-menu-tap-highlight: rgba(175,184,193,0.5); --color-select-menu-tap-focus-bg: #b6e3ff; --color-overlay-shadow: 0 1px 3px rgba(27,31,36,0.12), 0 8px 24px rgba(66,74,83,0.12); --color-header-text: rgba(255,255,255,0.7); --color-header-bg: #24292f; --color-header-divider: #57606a; --color-header-logo: #ffffff; --color-header-search-bg: #24292f; --color-header-search-border: #57606a; --color-sidenav-selected-bg: #ffffff; --color-menu-bg-active: rgba(0,0,0,0); --color-input-disabled-bg: rgba(175,184,193,0.2); --color-timeline-badge-bg: #eaeef2; --color-ansi-black: #24292f; --color-ansi-black-bright: #57606a; --color-ansi-white: #6e7781; --color-ansi-white-bright: #8c959f; --color-ansi-gray: #6e7781; --color-ansi-red: #cf222e; --color-ansi-red-bright: #a40e26; --color-ansi-green: #116329; --color-ansi-green-bright: #1a7f37; --color-ansi-yellow: #4d2d00; --color-ansi-yellow-bright: #633c01; --color-ansi-blue: #0969da; --color-ansi-blue-bright: #218bff; --color-ansi-magenta: #8250df; --color-ansi-magenta-bright: #a475f9; --color-ansi-cyan: #1b7c83; --color-ansi-cyan-bright: #3192aa; --color-btn-text: #24292f; --color-btn-bg: #f6f8fa; --color-btn-border: rgba(27,31,36,0.15); --color-btn-shadow: 0 1px 0 rgba(27,31,36,0.04); --color-btn-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.25); --color-btn-hover-bg: #f3f4f6; --color-btn-hover-border: rgba(27,31,36,0.15); --color-btn-active-bg: hsla(220,14%,93%,1); --color-btn-active-border: rgba(27,31,36,0.15); --color-btn-selected-bg: hsla(220,14%,94%,1); --color-btn-focus-bg: #f6f8fa; --color-btn-focus-border: rgba(27,31,36,0.15); --color-btn-focus-shadow: 0 0 0 3px rgba(9,105,218,0.3); --color-btn-shadow-active: inset 0 0.15em 0.3em rgba(27,31,36,0.15); --color-btn-shadow-input-focus: 0 0 0 0.2em rgba(9,105,218,0.3); --color-btn-counter-bg: rgba(27,31,36,0.08); --color-btn-primary-text: #ffffff; --color-btn-primary-bg: #2da44e; --color-btn-primary-border: rgba(27,31,36,0.15); --color-btn-primary-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-primary-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-primary-hover-bg: #2c974b; --color-btn-primary-hover-border: rgba(27,31,36,0.15); --color-btn-primary-selected-bg: hsla(137,55%,36%,1); --color-btn-primary-selected-shadow: inset 0 1px 0 rgba(0,45,17,0.2); --color-btn-primary-disabled-text: rgba(255,255,255,0.8); --color-btn-primary-disabled-bg: #94d3a2; --color-btn-primary-disabled-border: rgba(27,31,36,0.15); --color-btn-primary-focus-bg: #2da44e; --color-btn-primary-focus-border: rgba(27,31,36,0.15); --color-btn-primary-focus-shadow: 0 0 0 3px rgba(45,164,78,0.4); --color-btn-primary-icon: rgba(255,255,255,0.8); --color-btn-primary-counter-bg: rgba(255,255,255,0.2); --color-btn-outline-text: #0969da; --color-btn-outline-hover-text: #ffffff; --color-btn-outline-hover-bg: #0969da; --color-btn-outline-hover-border: rgba(27,31,36,0.15); --color-btn-outline-hover-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-outline-hover-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-outline-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-outline-selected-text: #ffffff; --color-btn-outline-selected-bg: hsla(212,92%,42%,1); --color-btn-outline-selected-border: rgba(27,31,36,0.15); --color-btn-outline-selected-shadow: inset 0 1px 0 rgba(0,33,85,0.2); --color-btn-outline-disabled-text: rgba(9,105,218,0.5); --color-btn-outline-disabled-bg: #f6f8fa; --color-btn-outline-disabled-counter-bg: rgba(9,105,218,0.05); --color-btn-outline-focus-border: rgba(27,31,36,0.15); --color-btn-outline-focus-shadow: 0 0 0 3px rgba(5,80,174,0.4); --color-btn-outline-counter-bg: rgba(9,105,218,0.1); --color-btn-danger-text: #cf222e; --color-btn-danger-hover-text: #ffffff; --color-btn-danger-hover-bg: #a40e26; --color-btn-danger-hover-border: rgba(27,31,36,0.15); --color-btn-danger-hover-shadow: 0 1px 0 rgba(27,31,36,0.1); --color-btn-danger-hover-inset-shadow: inset 0 1px 0 rgba(255,255,255,0.03); --color-btn-danger-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-danger-selected-text: #ffffff; --color-btn-danger-selected-bg: hsla(356,72%,44%,1); --color-btn-danger-selected-border: rgba(27,31,36,0.15); --color-btn-danger-selected-shadow: inset 0 1px 0 rgba(76,0,20,0.2); --color-btn-danger-disabled-text: rgba(207,34,46,0.5); --color-btn-danger-disabled-bg: #f6f8fa; --color-btn-danger-disabled-counter-bg: rgba(207,34,46,0.05); --color-btn-danger-focus-border: rgba(27,31,36,0.15); --color-btn-danger-focus-shadow: 0 0 0 3px rgba(164,14,38,0.4); --color-btn-danger-counter-bg: rgba(207,34,46,0.1); --color-btn-danger-icon: #cf222e; --color-btn-danger-hover-icon: #ffffff; --color-underlinenav-icon: #6e7781; --color-underlinenav-border-hover: rgba(175,184,193,0.2); --color-action-list-item-inline-divider: rgba(208,215,222,0.48); --color-action-list-item-default-hover-bg: rgba(208,215,222,0.32); --color-action-list-item-default-active-bg: rgba(208,215,222,0.48); --color-action-list-item-default-selected-bg: rgba(208,215,222,0.24); --color-action-list-item-danger-hover-bg: rgba(255,235,233,0.64); --color-action-list-item-danger-active-bg: #FFEBE9; --color-action-list-item-danger-hover-text: #cf222e; --color-fg-default: #24292f; --color-fg-muted: #57606a; --color-fg-subtle: #6e7781; --color-fg-on-emphasis: #ffffff; --color-canvas-default: #ffffff; --color-canvas-overlay: #ffffff; --color-canvas-inset: #f6f8fa; --color-canvas-subtle: #f6f8fa; --color-border-default: #d0d7de; --color-border-muted: hsla(210,18%,87%,1); --color-border-subtle: rgba(27,31,36,0.15); --color-shadow-small: 0 1px 0 rgba(27,31,36,0.04); --color-shadow-medium: 0 3px 6px rgba(140,149,159,0.15); --color-shadow-large: 0 8px 24px rgba(140,149,159,0.2); --color-shadow-extra-large: 0 12px 28px rgba(140,149,159,0.3); --color-neutral-emphasis-plus: #24292f; --color-neutral-emphasis: #6e7781; --color-neutral-muted: rgba(175,184,193,0.2); --color-neutral-subtle: rgba(234,238,242,0.5); --color-accent-fg: #0969da; --color-accent-emphasis: #0969da; --color-accent-muted: rgba(84,174,255,0.4); --color-accent-subtle: #ddf4ff; --color-success-fg: #1a7f37; --color-success-emphasis: #2da44e; --color-success-muted: rgba(74,194,107,0.4); --color-success-subtle: #dafbe1; --color-attention-fg: #9a6700; --color-attention-emphasis: #bf8700; --color-attention-muted: rgba(212,167,44,0.4); --color-attention-subtle: #fff8c5; --color-severe-fg: #bc4c00; --color-severe-emphasis: #bc4c00; --color-severe-muted: rgba(251,143,68,0.4); --color-severe-subtle: #fff1e5; --color-danger-fg: #cf222e; --color-danger-emphasis: #cf222e; --color-danger-muted: rgba(255,129,130,0.4); --color-danger-subtle: #FFEBE9; --color-done-fg: #8250df; --color-done-emphasis: #8250df; --color-done-muted: rgba(194,151,255,0.4); --color-done-subtle: #fbefff; --color-sponsors-fg: #bf3989; --color-sponsors-emphasis: #bf3989; --color-sponsors-muted: rgba(255,128,200,0.4); --color-sponsors-subtle: #ffeff7; --color-primer-fg-disabled: #8c959f; --color-primer-canvas-backdrop: rgba(27,31,36,0.5); --color-primer-canvas-sticky: rgba(255,255,255,0.95); --color-primer-border-active: #FD8C73; --color-primer-border-contrast: rgba(27,31,36,0.1); --color-primer-shadow-highlight: inset 0 1px 0 rgba(255,255,255,0.25); --color-primer-shadow-inset: inset 0 1px 0 rgba(208,215,222,0.2); --color-primer-shadow-focus: 0 0 0 3px rgba(9,105,218,0.3); --color-scale-black: #1b1f24; --color-scale-white: #ffffff; --color-scale-gray-0: #f6f8fa; --color-scale-gray-1: #eaeef2; --color-scale-gray-2: #d0d7de; --color-scale-gray-3: #afb8c1; --color-scale-gray-4: #8c959f; --color-scale-gray-5: #6e7781; --color-scale-gray-6: #57606a; --color-scale-gray-7: #424a53; --color-scale-gray-8: #32383f; --color-scale-gray-9: #24292f; --color-scale-blue-0: #ddf4ff; --color-scale-blue-1: #b6e3ff; --color-scale-blue-2: #80ccff; --color-scale-blue-3: #54aeff; --color-scale-blue-4: #218bff; --color-scale-blue-5: #0969da; --color-scale-blue-6: #0550ae; --color-scale-blue-7: #033d8b; --color-scale-blue-8: #0a3069; --color-scale-blue-9: #002155; --color-scale-green-0: #dafbe1; --color-scale-green-1: #aceebb; --color-scale-green-2: #6fdd8b; --color-scale-green-3: #4ac26b; --color-scale-green-4: #2da44e; --color-scale-green-5: #1a7f37; --color-scale-green-6: #116329; --color-scale-green-7: #044f1e; --color-scale-green-8: #003d16; --color-scale-green-9: #002d11; --color-scale-yellow-0: #fff8c5; --color-scale-yellow-1: #fae17d; --color-scale-yellow-2: #eac54f; --color-scale-yellow-3: #d4a72c; --color-scale-yellow-4: #bf8700; --color-scale-yellow-5: #9a6700; --color-scale-yellow-6: #7d4e00; --color-scale-yellow-7: #633c01; --color-scale-yellow-8: #4d2d00; --color-scale-yellow-9: #3b2300; --color-scale-orange-0: #fff1e5; --color-scale-orange-1: #ffd8b5; --color-scale-orange-2: #ffb77c; --color-scale-orange-3: #fb8f44; --color-scale-orange-4: #e16f24; --color-scale-orange-5: #bc4c00; --color-scale-orange-6: #953800; --color-scale-orange-7: #762c00; --color-scale-orange-8: #5c2200; --color-scale-orange-9: #471700; --color-scale-red-0: #FFEBE9; --color-scale-red-1: #ffcecb; --color-scale-red-2: #ffaba8; --color-scale-red-3: #ff8182; --color-scale-red-4: #fa4549; --color-scale-red-5: #cf222e; --color-scale-red-6: #a40e26; --color-scale-red-7: #82071e; --color-scale-red-8: #660018; --color-scale-red-9: #4c0014; --color-scale-purple-0: #fbefff; --color-scale-purple-1: #ecd8ff; --color-scale-purple-2: #d8b9ff; --color-scale-purple-3: #c297ff; --color-scale-purple-4: #a475f9; --color-scale-purple-5: #8250df; --color-scale-purple-6: #6639ba; --color-scale-purple-7: #512a97; --color-scale-purple-8: #3e1f79; --color-scale-purple-9: #2e1461; --color-scale-pink-0: #ffeff7; --color-scale-pink-1: #ffd3eb; --color-scale-pink-2: #ffadda; --color-scale-pink-3: #ff80c8; --color-scale-pink-4: #e85aad; --color-scale-pink-5: #bf3989; --color-scale-pink-6: #99286e; --color-scale-pink-7: #772057; --color-scale-pink-8: #611347; --color-scale-pink-9: #4d0336; --color-scale-coral-0: #FFF0EB; --color-scale-coral-1: #FFD6CC; --color-scale-coral-2: #FFB4A1; --color-scale-coral-3: #FD8C73; --color-scale-coral-4: #EC6547; --color-scale-coral-5: #C4432B; --color-scale-coral-6: #9E2F1C; --color-scale-coral-7: #801F0F; --color-scale-coral-8: #691105; --color-scale-coral-9: #510901; }
}
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://github.githubassets.com/assets/dark-a0349787ff32dba0ea6d0ecef2c75de8.css

@charset "utf-8";

[data-color-mode="light"][data-light-theme="dark"], [data-color-mode="dark"][data-dark-theme="dark"] { --color-canvas-default-transparent: rgba(13,17,23,0); --color-marketing-icon-primary: #79c0ff; --color-marketing-icon-secondary: #1f6feb; --color-diff-blob-addition-num-text: #c9d1d9; --color-diff-blob-addition-fg: #c9d1d9; --color-diff-blob-addition-num-bg: rgba(63,185,80,0.3); --color-diff-blob-addition-line-bg: rgba(46,160,67,0.15); --color-diff-blob-addition-word-bg: rgba(46,160,67,0.4); --color-diff-blob-deletion-num-text: #c9d1d9; --color-diff-blob-deletion-fg: #c9d1d9; --color-diff-blob-deletion-num-bg: rgba(248,81,73,0.3); --color-diff-blob-deletion-line-bg: rgba(248,81,73,0.15); --color-diff-blob-deletion-word-bg: rgba(248,81,73,0.4); --color-diff-blob-hunk-num-bg: rgba(56,139,253,0.4); --color-diff-blob-expander-icon: #8b949e; --color-diff-blob-selected-line-highlight-mix-blend-mode: screen; --color-diffstat-deletion-border: rgba(240,246,252,0.1); --color-diffstat-addition-border: rgba(240,246,252,0.1); --color-diffstat-addition-bg: #3fb950; --color-search-keyword-hl: rgba(210,153,34,0.4); --color-prettylights-syntax-comment: #8b949e; --color-prettylights-syntax-constant: #79c0ff; --color-prettylights-syntax-entity: #d2a8ff; --color-prettylights-syntax-storage-modifier-import: #c9d1d9; --color-prettylights-syntax-entity-tag: #7ee787; --color-prettylights-syntax-keyword: #ff7b72; --color-prettylights-syntax-string: #a5d6ff; --color-prettylights-syntax-variable: #ffa657; --color-prettylights-syntax-brackethighlighter-unmatched: #f85149; --color-prettylights-syntax-invalid-illegal-text: #f0f6fc; --color-prettylights-syntax-invalid-illegal-bg: #8e1519; --color-prettylights-syntax-carriage-return-text: #f0f6fc; --color-prettylights-syntax-carriage-return-bg: #b62324; --color-prettylights-syntax-string-regexp: #7ee787; --color-prettylights-syntax-markup-list: #f2cc60; --color-prettylights-syntax-markup-heading: #1f6feb; --color-prettylights-syntax-markup-italic: #c9d1d9; --color-prettylights-syntax-markup-bold: #c9d1d9; --color-prettylights-syntax-markup-deleted-text: #ffdcd7; --color-prettylights-syntax-markup-deleted-bg: #67060c; --color-prettylights-syntax-markup-inserted-text: #aff5b4; --color-prettylights-syntax-markup-inserted-bg: #033a16; --color-prettylights-syntax-markup-changed-text: #ffdfb6; --color-prettylights-syntax-markup-changed-bg: #5a1e02; --color-prettylights-syntax-markup-ignored-text: #c9d1d9; --color-prettylights-syntax-markup-ignored-bg: #1158c7; --color-prettylights-syntax-meta-diff-range: #d2a8ff; --color-prettylights-syntax-brackethighlighter-angle: #8b949e; --color-prettylights-syntax-sublimelinter-gutter-mark: #484f58; --color-prettylights-syntax-constant-other-reference-link: #a5d6ff; --color-codemirror-text: #c9d1d9; --color-codemirror-bg: #0d1117; --color-codemirror-gutters-bg: #0d1117; --color-codemirror-guttermarker-text: #0d1117; --color-codemirror-guttermarker-subtle-text: #484f58; --color-codemirror-linenumber-text: #8b949e; --color-codemirror-cursor: #c9d1d9; --color-codemirror-selection-bg: rgba(56,139,253,0.4); --color-codemirror-activeline-bg: rgba(110,118,129,0.1); --color-codemirror-matchingbracket-text: #c9d1d9; --color-codemirror-lines-bg: #0d1117; --color-codemirror-syntax-comment: #8b949e; --color-codemirror-syntax-constant: #79c0ff; --color-codemirror-syntax-entity: #d2a8ff; --color-codemirror-syntax-keyword: #ff7b72; --color-codemirror-syntax-storage: #ff7b72; --color-codemirror-syntax-string: #a5d6ff; --color-codemirror-syntax-support: #79c0ff; --color-codemirror-syntax-variable: #ffa657; --color-checks-bg: #010409; --color-checks-run-border-width: 1px; --color-checks-container-border-width: 1px; --color-checks-text-primary: #c9d1d9; --color-checks-text-secondary: #8b949e; --color-checks-text-link: #58a6ff; --color-checks-btn-icon: #8b949e; --color-checks-btn-hover-icon: #c9d1d9; --color-checks-btn-hover-bg: rgba(110,118,129,0.1); --color-checks-input-text: #8b949e; --color-checks-input-placeholder-text: #484f58; --color-checks-input-focus-text: #c9d1d9; --color-checks-input-bg: #161b22; --color-checks-input-shadow: 0 0 0 1px (obj) => get_1.default(obj, path); --color-checks-donut-error: #f85149; --color-checks-donut-pending: #d29922; --color-checks-donut-success: #2ea043; --color-checks-donut-neutral: #8b949e; --color-checks-dropdown-text: #c9d1d9; --color-checks-dropdown-bg: #161b22; --color-checks-dropdown-border: #30363d; --color-checks-dropdown-shadow: rgba(1,4,9,0.3); --color-checks-dropdown-hover-text: #c9d1d9; --color-checks-dropdown-hover-bg: rgba(110,118,129,0.1); --color-checks-dropdown-btn-hover-text: #c9d1d9; --color-checks-dropdown-btn-hover-bg: rgba(110,118,129,0.1); --color-checks-scrollbar-thumb-bg: rgba(110,118,129,0.4); --color-checks-header-label-text: #8b949e; --color-checks-header-label-open-text: #c9d1d9; --color-checks-header-border: #21262d; --color-checks-header-icon: #8b949e; --color-checks-line-text: #8b949e; --color-checks-line-num-text: #484f58; --color-checks-line-timestamp-text: #484f58; --color-checks-line-hover-bg: rgba(110,118,129,0.1); --color-checks-line-selected-bg: rgba(56,139,253,0.15); --color-checks-line-selected-num-text: #58a6ff; --color-checks-line-dt-fm-text: #f0f6fc; --color-checks-line-dt-fm-bg: #9e6a03; --color-checks-gate-bg: rgba(187,128,9,0.15); --color-checks-gate-text: #8b949e; --color-checks-gate-waiting-text: #d29922; --color-checks-step-header-open-bg: #161b22; --color-checks-step-error-text: #f85149; --color-checks-step-warning-text: #d29922; --color-checks-logline-text: #8b949e; --color-checks-logline-num-text: #484f58; --color-checks-logline-debug-text: #a371f7; --color-checks-logline-error-text: #8b949e; --color-checks-logline-error-num-text: #484f58; --color-checks-logline-error-bg: rgba(248,81,73,0.15); --color-checks-logline-warning-text: #8b949e; --color-checks-logline-warning-num-text: #d29922; --color-checks-logline-warning-bg: rgba(187,128,9,0.15); --color-checks-logline-command-text: #58a6ff; --color-checks-logline-section-text: #3fb950; --color-checks-ansi-black: #0d1117; --color-checks-ansi-black-bright: #161b22; --color-checks-ansi-white: #b1bac4; --color-checks-ansi-white-bright: #b1bac4; --color-checks-ansi-gray: #6e7681; --color-checks-ansi-red: #ff7b72; --color-checks-ansi-red-bright: #ffa198; --color-checks-ansi-green: #3fb950; --color-checks-ansi-green-bright: #56d364; --color-checks-ansi-yellow: #d29922; --color-checks-ansi-yellow-bright: #e3b341; --color-checks-ansi-blue: #58a6ff; --color-checks-ansi-blue-bright: #79c0ff; --color-checks-ansi-magenta: #bc8cff; --color-checks-ansi-magenta-bright: #d2a8ff; --color-checks-ansi-cyan: #76e3ea; --color-checks-ansi-cyan-bright: #b3f0ff; --color-project-header-bg: #0d1117; --color-project-sidebar-bg: #161b22; --color-project-gradient-in: #161b22; --color-project-gradient-out: rgba(22,27,34,0); --color-mktg-btn-bg: #f6f8fa; --color-mktg-btn-shadow-outline: rgb(255 255 255 / 25%) 0 0 0 1px inset; --color-mktg-btn-shadow-focus: rgb(255 255 255 / 25%) 0 0 0 4px; --color-mktg-btn-shadow-hover: 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07); --color-mktg-btn-shadow-hover-muted: rgb(255 255 255) 0 0 0 2px inset; --color-avatar-bg: rgba(240,246,252,0.1); --color-avatar-border: rgba(240,246,252,0.1); --color-avatar-stack-fade: #30363d; --color-avatar-stack-fade-more: #21262d; --color-avatar-child-shadow: -2px -2px 0 #0d1117; --color-topic-tag-border: rgba(0,0,0,0); --color-counter-border: rgba(0,0,0,0); --color-select-menu-backdrop-border: #484f58; --color-select-menu-tap-highlight: rgba(48,54,61,0.5); --color-select-menu-tap-focus-bg: #0c2d6b; --color-overlay-shadow: 0 0 0 1px #30363d, 0 16px 32px rgba(1,4,9,0.85); --color-header-text: rgba(240,246,252,0.7); --color-header-bg: #161b22; --color-header-divider: #8b949e; --color-header-logo: #f0f6fc; --color-header-search-bg: #0d1117; --color-header-search-border: #30363d; --color-sidenav-selected-bg: #21262d; --color-menu-bg-active: #161b22; --color-input-disabled-bg: rgba(110,118,129,0); --color-timeline-badge-bg: #21262d; --color-ansi-black: #484f58; --color-ansi-black-bright: #6e7681; --color-ansi-white: #b1bac4; --color-ansi-white-bright: #f0f6fc; --color-ansi-gray: #6e7681; --color-ansi-red: #ff7b72; --color-ansi-red-bright: #ffa198; --color-ansi-green: #3fb950; --color-ansi-green-bright: #56d364; --color-ansi-yellow: #d29922; --color-ansi-yellow-bright: #e3b341; --color-ansi-blue: #58a6ff; --color-ansi-blue-bright: #79c0ff; --color-ansi-magenta: #bc8cff; --color-ansi-magenta-bright: #d2a8ff; --color-ansi-cyan: #39c5cf; --color-ansi-cyan-bright: #56d4dd; --color-btn-text: #c9d1d9; --color-btn-bg: #21262d; --color-btn-border: rgba(240,246,252,0.1); --color-btn-shadow: 0 0 transparent; --color-btn-inset-shadow: 0 0 transparent; --color-btn-hover-bg: #30363d; --color-btn-hover-border: #8b949e; --color-btn-active-bg: hsla(212,12%,18%,1); --color-btn-active-border: #6e7681; --color-btn-selected-bg: #161b22; --color-btn-focus-bg: #21262d; --color-btn-focus-border: #8b949e; --color-btn-focus-shadow: 0 0 0 3px rgba(139,148,158,0.3); --color-btn-shadow-active: inset 0 0.15em 0.3em rgba(1,4,9,0.15); --color-btn-shadow-input-focus: 0 0 0 0.2em rgba(31,111,235,0.3); --color-btn-counter-bg: #30363d; --color-btn-primary-text: #ffffff; --color-btn-primary-bg: #238636; --color-btn-primary-border: rgba(240,246,252,0.1); --color-btn-primary-shadow: 0 0 transparent; --color-btn-primary-inset-shadow: 0 0 transparent; --color-btn-primary-hover-bg: #2ea043; --color-btn-primary-hover-border: rgba(240,246,252,0.1); --color-btn-primary-selected-bg: #238636; --color-btn-primary-selected-shadow: 0 0 transparent; --color-btn-primary-disabled-text: rgba(240,246,252,0.5); --color-btn-primary-disabled-bg: rgba(35,134,54,0.6); --color-btn-primary-disabled-border: rgba(240,246,252,0.1); --color-btn-primary-focus-bg: #238636; --color-btn-primary-focus-border: rgba(240,246,252,0.1); --color-btn-primary-focus-shadow: 0 0 0 3px rgba(46,164,79,0.4); --color-btn-primary-icon: #f0f6fc; --color-btn-primary-counter-bg: rgba(240,246,252,0.2); --color-btn-outline-text: #58a6ff; --color-btn-outline-hover-text: #58a6ff; --color-btn-outline-hover-bg: #30363d; --color-btn-outline-hover-border: rgba(240,246,252,0.1); --color-btn-outline-hover-shadow: 0 1px 0 rgba(1,4,9,0.1); --color-btn-outline-hover-inset-shadow: inset 0 1px 0 rgba(240,246,252,0.03); --color-btn-outline-hover-counter-bg: rgba(240,246,252,0.2); --color-btn-outline-selected-text: #f0f6fc; --color-btn-outline-selected-bg: #0d419d; --color-btn-outline-selected-border: rgba(240,246,252,0.1); --color-btn-outline-selected-shadow: 0 0 transparent; --color-btn-outline-disabled-text: rgba(88,166,255,0.5); --color-btn-outline-disabled-bg: #0d1117; --color-btn-outline-disabled-counter-bg: rgba(31,111,235,0.05); --color-btn-outline-focus-border: rgba(240,246,252,0.1); --color-btn-outline-focus-shadow: 0 0 0 3px rgba(17,88,199,0.4); --color-btn-outline-counter-bg: rgba(31,111,235,0.1); --color-btn-danger-text: #f85149; --color-btn-danger-hover-text: #f0f6fc; --color-btn-danger-hover-bg: #da3633; --color-btn-danger-hover-border: #f85149; --color-btn-danger-hover-shadow: 0 0 transparent; --color-btn-danger-hover-inset-shadow: 0 0 transparent; --color-btn-danger-hover-icon: #f0f6fc; --color-btn-danger-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-danger-selected-text: #ffffff; --color-btn-danger-selected-bg: #b62324; --color-btn-danger-selected-border: #ff7b72; --color-btn-danger-selected-shadow: 0 0 transparent; --color-btn-danger-disabled-text: rgba(248,81,73,0.5); --color-btn-danger-disabled-bg: #0d1117; --color-btn-danger-disabled-counter-bg: rgba(218,54,51,0.05); --color-btn-danger-focus-border: #f85149; --color-btn-danger-focus-shadow: 0 0 0 3px rgba(248,81,73,0.4); --color-btn-danger-counter-bg: rgba(218,54,51,0.1); --color-btn-danger-icon: #f85149; --color-underlinenav-icon: #484f58; --color-underlinenav-border-hover: rgba(110,118,129,0.4); --color-action-list-item-inline-divider: rgba(48,54,61,0.48); --color-action-list-item-default-hover-bg: rgba(177,186,196,0.12); --color-action-list-item-default-active-bg: rgba(177,186,196,0.2); --color-action-list-item-default-selected-bg: rgba(177,186,196,0.08); --color-action-list-item-danger-hover-bg: rgba(248,81,73,0.16); --color-action-list-item-danger-active-bg: rgba(248,81,73,0.24); --color-action-list-item-danger-hover-text: #ff7b72; --color-fg-default: #c9d1d9; --color-fg-muted: #8b949e; --color-fg-subtle: #484f58; --color-fg-on-emphasis: #f0f6fc; --color-canvas-default: #0d1117; --color-canvas-overlay: #161b22; --color-canvas-inset: #010409; --color-canvas-subtle: #161b22; --color-border-default: #30363d; --color-border-muted: #21262d; --color-border-subtle: rgba(240,246,252,0.1); --color-shadow-small: 0 0 transparent; --color-shadow-medium: 0 3px 6px #010409; --color-shadow-large: 0 8px 24px #010409; --color-shadow-extra-large: 0 12px 48px #010409; --color-neutral-emphasis-plus: #6e7681; --color-neutral-emphasis: #6e7681; --color-neutral-muted: rgba(110,118,129,0.4); --color-neutral-subtle: rgba(110,118,129,0.1); --color-accent-fg: #58a6ff; --color-accent-emphasis: #1f6feb; --color-accent-muted: rgba(56,139,253,0.4); --color-accent-subtle: rgba(56,139,253,0.15); --color-success-fg: #3fb950; --color-success-emphasis: #238636; --color-success-muted: rgba(46,160,67,0.4); --color-success-subtle: rgba(46,160,67,0.15); --color-attention-fg: #d29922; --color-attention-emphasis: #9e6a03; --color-attention-muted: rgba(187,128,9,0.4); --color-attention-subtle: rgba(187,128,9,0.15); --color-severe-fg: #db6d28; --color-severe-emphasis: #bd561d; --color-severe-muted: rgba(219,109,40,0.4); --color-severe-subtle: rgba(219,109,40,0.15); --color-danger-fg: #f85149; --color-danger-emphasis: #da3633; --color-danger-muted: rgba(248,81,73,0.4); --color-danger-subtle: rgba(248,81,73,0.15); --color-done-fg: #a371f7; --color-done-emphasis: #8957e5; --color-done-muted: rgba(163,113,247,0.4); --color-done-subtle: rgba(163,113,247,0.15); --color-sponsors-fg: #db61a2; --color-sponsors-emphasis: #bf4b8a; --color-sponsors-muted: rgba(219,97,162,0.4); --color-sponsors-subtle: rgba(219,97,162,0.15); --color-primer-fg-disabled: #484f58; --color-primer-canvas-backdrop: rgba(1,4,9,0.8); --color-primer-canvas-sticky: rgba(13,17,23,0.95); --color-primer-border-active: #F78166; --color-primer-border-contrast: rgba(240,246,252,0.2); --color-primer-shadow-highlight: 0 0 transparent; --color-primer-shadow-inset: 0 0 transparent; --color-primer-shadow-focus: 0 0 0 3px #0c2d6b; --color-scale-black: #010409; --color-scale-white: #f0f6fc; --color-scale-gray-0: #f0f6fc; --color-scale-gray-1: #c9d1d9; --color-scale-gray-2: #b1bac4; --color-scale-gray-3: #8b949e; --color-scale-gray-4: #6e7681; --color-scale-gray-5: #484f58; --color-scale-gray-6: #30363d; --color-scale-gray-7: #21262d; --color-scale-gray-8: #161b22; --color-scale-gray-9: #0d1117; --color-scale-blue-0: #cae8ff; --color-scale-blue-1: #a5d6ff; --color-scale-blue-2: #79c0ff; --color-scale-blue-3: #58a6ff; --color-scale-blue-4: #388bfd; --color-scale-blue-5: #1f6feb; --color-scale-blue-6: #1158c7; --color-scale-blue-7: #0d419d; --color-scale-blue-8: #0c2d6b; --color-scale-blue-9: #051d4d; --color-scale-green-0: #aff5b4; --color-scale-green-1: #7ee787; --color-scale-green-2: #56d364; --color-scale-green-3: #3fb950; --color-scale-green-4: #2ea043; --color-scale-green-5: #238636; --color-scale-green-6: #196c2e; --color-scale-green-7: #0f5323; --color-scale-green-8: #033a16; --color-scale-green-9: #04260f; --color-scale-yellow-0: #f8e3a1; --color-scale-yellow-1: #f2cc60; --color-scale-yellow-2: #e3b341; --color-scale-yellow-3: #d29922; --color-scale-yellow-4: #bb8009; --color-scale-yellow-5: #9e6a03; --color-scale-yellow-6: #845306; --color-scale-yellow-7: #693e00; --color-scale-yellow-8: #4b2900; --color-scale-yellow-9: #341a00; --color-scale-orange-0: #ffdfb6; --color-scale-orange-1: #ffc680; --color-scale-orange-2: #ffa657; --color-scale-orange-3: #f0883e; --color-scale-orange-4: #db6d28; --color-scale-orange-5: #bd561d; --color-scale-orange-6: #9b4215; --color-scale-orange-7: #762d0a; --color-scale-orange-8: #5a1e02; --color-scale-orange-9: #3d1300; --color-scale-red-0: #ffdcd7; --color-scale-red-1: #ffc1ba; --color-scale-red-2: #ffa198; --color-scale-red-3: #ff7b72; --color-scale-red-4: #f85149; --color-scale-red-5: #da3633; --color-scale-red-6: #b62324; --color-scale-red-7: #8e1519; --color-scale-red-8: #67060c; --color-scale-red-9: #490202; --color-scale-purple-0: #eddeff; --color-scale-purple-1: #e2c5ff; --color-scale-purple-2: #d2a8ff; --color-scale-purple-3: #bc8cff; --color-scale-purple-4: #a371f7; --color-scale-purple-5: #8957e5; --color-scale-purple-6: #6e40c9; --color-scale-purple-7: #553098; --color-scale-purple-8: #3c1e70; --color-scale-purple-9: #271052; --color-scale-pink-0: #ffdaec; --color-scale-pink-1: #ffbedd; --color-scale-pink-2: #ff9bce; --color-scale-pink-3: #f778ba; --color-scale-pink-4: #db61a2; --color-scale-pink-5: #bf4b8a; --color-scale-pink-6: #9e3670; --color-scale-pink-7: #7d2457; --color-scale-pink-8: #5e103e; --color-scale-pink-9: #42062a; --color-scale-coral-0: #FFDDD2; --color-scale-coral-1: #FFC2B2; --color-scale-coral-2: #FFA28B; --color-scale-coral-3: #F78166; --color-scale-coral-4: #EA6045; --color-scale-coral-5: #CF462D; --color-scale-coral-6: #AC3220; --color-scale-coral-7: #872012; --color-scale-coral-8: #640D04; --color-scale-coral-9: #460701; }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme="dark"] { --color-canvas-default-transparent: rgba(13,17,23,0); --color-marketing-icon-primary: #79c0ff; --color-marketing-icon-secondary: #1f6feb; --color-diff-blob-addition-num-text: #c9d1d9; --color-diff-blob-addition-fg: #c9d1d9; --color-diff-blob-addition-num-bg: rgba(63,185,80,0.3); --color-diff-blob-addition-line-bg: rgba(46,160,67,0.15); --color-diff-blob-addition-word-bg: rgba(46,160,67,0.4); --color-diff-blob-deletion-num-text: #c9d1d9; --color-diff-blob-deletion-fg: #c9d1d9; --color-diff-blob-deletion-num-bg: rgba(248,81,73,0.3); --color-diff-blob-deletion-line-bg: rgba(248,81,73,0.15); --color-diff-blob-deletion-word-bg: rgba(248,81,73,0.4); --color-diff-blob-hunk-num-bg: rgba(56,139,253,0.4); --color-diff-blob-expander-icon: #8b949e; --color-diff-blob-selected-line-highlight-mix-blend-mode: screen; --color-diffstat-deletion-border: rgba(240,246,252,0.1); --color-diffstat-addition-border: rgba(240,246,252,0.1); --color-diffstat-addition-bg: #3fb950; --color-search-keyword-hl: rgba(210,153,34,0.4); --color-prettylights-syntax-comment: #8b949e; --color-prettylights-syntax-constant: #79c0ff; --color-prettylights-syntax-entity: #d2a8ff; --color-prettylights-syntax-storage-modifier-import: #c9d1d9; --color-prettylights-syntax-entity-tag: #7ee787; --color-prettylights-syntax-keyword: #ff7b72; --color-prettylights-syntax-string: #a5d6ff; --color-prettylights-syntax-variable: #ffa657; --color-prettylights-syntax-brackethighlighter-unmatched: #f85149; --color-prettylights-syntax-invalid-illegal-text: #f0f6fc; --color-prettylights-syntax-invalid-illegal-bg: #8e1519; --color-prettylights-syntax-carriage-return-text: #f0f6fc; --color-prettylights-syntax-carriage-return-bg: #b62324; --color-prettylights-syntax-string-regexp: #7ee787; --color-prettylights-syntax-markup-list: #f2cc60; --color-prettylights-syntax-markup-heading: #1f6feb; --color-prettylights-syntax-markup-italic: #c9d1d9; --color-prettylights-syntax-markup-bold: #c9d1d9; --color-prettylights-syntax-markup-deleted-text: #ffdcd7; --color-prettylights-syntax-markup-deleted-bg: #67060c; --color-prettylights-syntax-markup-inserted-text: #aff5b4; --color-prettylights-syntax-markup-inserted-bg: #033a16; --color-prettylights-syntax-markup-changed-text: #ffdfb6; --color-prettylights-syntax-markup-changed-bg: #5a1e02; --color-prettylights-syntax-markup-ignored-text: #c9d1d9; --color-prettylights-syntax-markup-ignored-bg: #1158c7; --color-prettylights-syntax-meta-diff-range: #d2a8ff; --color-prettylights-syntax-brackethighlighter-angle: #8b949e; --color-prettylights-syntax-sublimelinter-gutter-mark: #484f58; --color-prettylights-syntax-constant-other-reference-link: #a5d6ff; --color-codemirror-text: #c9d1d9; --color-codemirror-bg: #0d1117; --color-codemirror-gutters-bg: #0d1117; --color-codemirror-guttermarker-text: #0d1117; --color-codemirror-guttermarker-subtle-text: #484f58; --color-codemirror-linenumber-text: #8b949e; --color-codemirror-cursor: #c9d1d9; --color-codemirror-selection-bg: rgba(56,139,253,0.4); --color-codemirror-activeline-bg: rgba(110,118,129,0.1); --color-codemirror-matchingbracket-text: #c9d1d9; --color-codemirror-lines-bg: #0d1117; --color-codemirror-syntax-comment: #8b949e; --color-codemirror-syntax-constant: #79c0ff; --color-codemirror-syntax-entity: #d2a8ff; --color-codemirror-syntax-keyword: #ff7b72; --color-codemirror-syntax-storage: #ff7b72; --color-codemirror-syntax-string: #a5d6ff; --color-codemirror-syntax-support: #79c0ff; --color-codemirror-syntax-variable: #ffa657; --color-checks-bg: #010409; --color-checks-run-border-width: 1px; --color-checks-container-border-width: 1px; --color-checks-text-primary: #c9d1d9; --color-checks-text-secondary: #8b949e; --color-checks-text-link: #58a6ff; --color-checks-btn-icon: #8b949e; --color-checks-btn-hover-icon: #c9d1d9; --color-checks-btn-hover-bg: rgba(110,118,129,0.1); --color-checks-input-text: #8b949e; --color-checks-input-placeholder-text: #484f58; --color-checks-input-focus-text: #c9d1d9; --color-checks-input-bg: #161b22; --color-checks-input-shadow: 0 0 0 1px (obj) => get_1.default(obj, path); --color-checks-donut-error: #f85149; --color-checks-donut-pending: #d29922; --color-checks-donut-success: #2ea043; --color-checks-donut-neutral: #8b949e; --color-checks-dropdown-text: #c9d1d9; --color-checks-dropdown-bg: #161b22; --color-checks-dropdown-border: #30363d; --color-checks-dropdown-shadow: rgba(1,4,9,0.3); --color-checks-dropdown-hover-text: #c9d1d9; --color-checks-dropdown-hover-bg: rgba(110,118,129,0.1); --color-checks-dropdown-btn-hover-text: #c9d1d9; --color-checks-dropdown-btn-hover-bg: rgba(110,118,129,0.1); --color-checks-scrollbar-thumb-bg: rgba(110,118,129,0.4); --color-checks-header-label-text: #8b949e; --color-checks-header-label-open-text: #c9d1d9; --color-checks-header-border: #21262d; --color-checks-header-icon: #8b949e; --color-checks-line-text: #8b949e; --color-checks-line-num-text: #484f58; --color-checks-line-timestamp-text: #484f58; --color-checks-line-hover-bg: rgba(110,118,129,0.1); --color-checks-line-selected-bg: rgba(56,139,253,0.15); --color-checks-line-selected-num-text: #58a6ff; --color-checks-line-dt-fm-text: #f0f6fc; --color-checks-line-dt-fm-bg: #9e6a03; --color-checks-gate-bg: rgba(187,128,9,0.15); --color-checks-gate-text: #8b949e; --color-checks-gate-waiting-text: #d29922; --color-checks-step-header-open-bg: #161b22; --color-checks-step-error-text: #f85149; --color-checks-step-warning-text: #d29922; --color-checks-logline-text: #8b949e; --color-checks-logline-num-text: #484f58; --color-checks-logline-debug-text: #a371f7; --color-checks-logline-error-text: #8b949e; --color-checks-logline-error-num-text: #484f58; --color-checks-logline-error-bg: rgba(248,81,73,0.15); --color-checks-logline-warning-text: #8b949e; --color-checks-logline-warning-num-text: #d29922; --color-checks-logline-warning-bg: rgba(187,128,9,0.15); --color-checks-logline-command-text: #58a6ff; --color-checks-logline-section-text: #3fb950; --color-checks-ansi-black: #0d1117; --color-checks-ansi-black-bright: #161b22; --color-checks-ansi-white: #b1bac4; --color-checks-ansi-white-bright: #b1bac4; --color-checks-ansi-gray: #6e7681; --color-checks-ansi-red: #ff7b72; --color-checks-ansi-red-bright: #ffa198; --color-checks-ansi-green: #3fb950; --color-checks-ansi-green-bright: #56d364; --color-checks-ansi-yellow: #d29922; --color-checks-ansi-yellow-bright: #e3b341; --color-checks-ansi-blue: #58a6ff; --color-checks-ansi-blue-bright: #79c0ff; --color-checks-ansi-magenta: #bc8cff; --color-checks-ansi-magenta-bright: #d2a8ff; --color-checks-ansi-cyan: #76e3ea; --color-checks-ansi-cyan-bright: #b3f0ff; --color-project-header-bg: #0d1117; --color-project-sidebar-bg: #161b22; --color-project-gradient-in: #161b22; --color-project-gradient-out: rgba(22,27,34,0); --color-mktg-btn-bg: #f6f8fa; --color-mktg-btn-shadow-outline: rgb(255 255 255 / 25%) 0 0 0 1px inset; --color-mktg-btn-shadow-focus: rgb(255 255 255 / 25%) 0 0 0 4px; --color-mktg-btn-shadow-hover: 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07); --color-mktg-btn-shadow-hover-muted: rgb(255 255 255) 0 0 0 2px inset; --color-avatar-bg: rgba(240,246,252,0.1); --color-avatar-border: rgba(240,246,252,0.1); --color-avatar-stack-fade: #30363d; --color-avatar-stack-fade-more: #21262d; --color-avatar-child-shadow: -2px -2px 0 #0d1117; --color-topic-tag-border: rgba(0,0,0,0); --color-counter-border: rgba(0,0,0,0); --color-select-menu-backdrop-border: #484f58; --color-select-menu-tap-highlight: rgba(48,54,61,0.5); --color-select-menu-tap-focus-bg: #0c2d6b; --color-overlay-shadow: 0 0 0 1px #30363d, 0 16px 32px rgba(1,4,9,0.85); --color-header-text: rgba(240,246,252,0.7); --color-header-bg: #161b22; --color-header-divider: #8b949e; --color-header-logo: #f0f6fc; --color-header-search-bg: #0d1117; --color-header-search-border: #30363d; --color-sidenav-selected-bg: #21262d; --color-menu-bg-active: #161b22; --color-input-disabled-bg: rgba(110,118,129,0); --color-timeline-badge-bg: #21262d; --color-ansi-black: #484f58; --color-ansi-black-bright: #6e7681; --color-ansi-white: #b1bac4; --color-ansi-white-bright: #f0f6fc; --color-ansi-gray: #6e7681; --color-ansi-red: #ff7b72; --color-ansi-red-bright: #ffa198; --color-ansi-green: #3fb950; --color-ansi-green-bright: #56d364; --color-ansi-yellow: #d29922; --color-ansi-yellow-bright: #e3b341; --color-ansi-blue: #58a6ff; --color-ansi-blue-bright: #79c0ff; --color-ansi-magenta: #bc8cff; --color-ansi-magenta-bright: #d2a8ff; --color-ansi-cyan: #39c5cf; --color-ansi-cyan-bright: #56d4dd; --color-btn-text: #c9d1d9; --color-btn-bg: #21262d; --color-btn-border: rgba(240,246,252,0.1); --color-btn-shadow: 0 0 transparent; --color-btn-inset-shadow: 0 0 transparent; --color-btn-hover-bg: #30363d; --color-btn-hover-border: #8b949e; --color-btn-active-bg: hsla(212,12%,18%,1); --color-btn-active-border: #6e7681; --color-btn-selected-bg: #161b22; --color-btn-focus-bg: #21262d; --color-btn-focus-border: #8b949e; --color-btn-focus-shadow: 0 0 0 3px rgba(139,148,158,0.3); --color-btn-shadow-active: inset 0 0.15em 0.3em rgba(1,4,9,0.15); --color-btn-shadow-input-focus: 0 0 0 0.2em rgba(31,111,235,0.3); --color-btn-counter-bg: #30363d; --color-btn-primary-text: #ffffff; --color-btn-primary-bg: #238636; --color-btn-primary-border: rgba(240,246,252,0.1); --color-btn-primary-shadow: 0 0 transparent; --color-btn-primary-inset-shadow: 0 0 transparent; --color-btn-primary-hover-bg: #2ea043; --color-btn-primary-hover-border: rgba(240,246,252,0.1); --color-btn-primary-selected-bg: #238636; --color-btn-primary-selected-shadow: 0 0 transparent; --color-btn-primary-disabled-text: rgba(240,246,252,0.5); --color-btn-primary-disabled-bg: rgba(35,134,54,0.6); --color-btn-primary-disabled-border: rgba(240,246,252,0.1); --color-btn-primary-focus-bg: #238636; --color-btn-primary-focus-border: rgba(240,246,252,0.1); --color-btn-primary-focus-shadow: 0 0 0 3px rgba(46,164,79,0.4); --color-btn-primary-icon: #f0f6fc; --color-btn-primary-counter-bg: rgba(240,246,252,0.2); --color-btn-outline-text: #58a6ff; --color-btn-outline-hover-text: #58a6ff; --color-btn-outline-hover-bg: #30363d; --color-btn-outline-hover-border: rgba(240,246,252,0.1); --color-btn-outline-hover-shadow: 0 1px 0 rgba(1,4,9,0.1); --color-btn-outline-hover-inset-shadow: inset 0 1px 0 rgba(240,246,252,0.03); --color-btn-outline-hover-counter-bg: rgba(240,246,252,0.2); --color-btn-outline-selected-text: #f0f6fc; --color-btn-outline-selected-bg: #0d419d; --color-btn-outline-selected-border: rgba(240,246,252,0.1); --color-btn-outline-selected-shadow: 0 0 transparent; --color-btn-outline-disabled-text: rgba(88,166,255,0.5); --color-btn-outline-disabled-bg: #0d1117; --color-btn-outline-disabled-counter-bg: rgba(31,111,235,0.05); --color-btn-outline-focus-border: rgba(240,246,252,0.1); --color-btn-outline-focus-shadow: 0 0 0 3px rgba(17,88,199,0.4); --color-btn-outline-counter-bg: rgba(31,111,235,0.1); --color-btn-danger-text: #f85149; --color-btn-danger-hover-text: #f0f6fc; --color-btn-danger-hover-bg: #da3633; --color-btn-danger-hover-border: #f85149; --color-btn-danger-hover-shadow: 0 0 transparent; --color-btn-danger-hover-inset-shadow: 0 0 transparent; --color-btn-danger-hover-icon: #f0f6fc; --color-btn-danger-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-danger-selected-text: #ffffff; --color-btn-danger-selected-bg: #b62324; --color-btn-danger-selected-border: #ff7b72; --color-btn-danger-selected-shadow: 0 0 transparent; --color-btn-danger-disabled-text: rgba(248,81,73,0.5); --color-btn-danger-disabled-bg: #0d1117; --color-btn-danger-disabled-counter-bg: rgba(218,54,51,0.05); --color-btn-danger-focus-border: #f85149; --color-btn-danger-focus-shadow: 0 0 0 3px rgba(248,81,73,0.4); --color-btn-danger-counter-bg: rgba(218,54,51,0.1); --color-btn-danger-icon: #f85149; --color-underlinenav-icon: #484f58; --color-underlinenav-border-hover: rgba(110,118,129,0.4); --color-action-list-item-inline-divider: rgba(48,54,61,0.48); --color-action-list-item-default-hover-bg: rgba(177,186,196,0.12); --color-action-list-item-default-active-bg: rgba(177,186,196,0.2); --color-action-list-item-default-selected-bg: rgba(177,186,196,0.08); --color-action-list-item-danger-hover-bg: rgba(248,81,73,0.16); --color-action-list-item-danger-active-bg: rgba(248,81,73,0.24); --color-action-list-item-danger-hover-text: #ff7b72; --color-fg-default: #c9d1d9; --color-fg-muted: #8b949e; --color-fg-subtle: #484f58; --color-fg-on-emphasis: #f0f6fc; --color-canvas-default: #0d1117; --color-canvas-overlay: #161b22; --color-canvas-inset: #010409; --color-canvas-subtle: #161b22; --color-border-default: #30363d; --color-border-muted: #21262d; --color-border-subtle: rgba(240,246,252,0.1); --color-shadow-small: 0 0 transparent; --color-shadow-medium: 0 3px 6px #010409; --color-shadow-large: 0 8px 24px #010409; --color-shadow-extra-large: 0 12px 48px #010409; --color-neutral-emphasis-plus: #6e7681; --color-neutral-emphasis: #6e7681; --color-neutral-muted: rgba(110,118,129,0.4); --color-neutral-subtle: rgba(110,118,129,0.1); --color-accent-fg: #58a6ff; --color-accent-emphasis: #1f6feb; --color-accent-muted: rgba(56,139,253,0.4); --color-accent-subtle: rgba(56,139,253,0.15); --color-success-fg: #3fb950; --color-success-emphasis: #238636; --color-success-muted: rgba(46,160,67,0.4); --color-success-subtle: rgba(46,160,67,0.15); --color-attention-fg: #d29922; --color-attention-emphasis: #9e6a03; --color-attention-muted: rgba(187,128,9,0.4); --color-attention-subtle: rgba(187,128,9,0.15); --color-severe-fg: #db6d28; --color-severe-emphasis: #bd561d; --color-severe-muted: rgba(219,109,40,0.4); --color-severe-subtle: rgba(219,109,40,0.15); --color-danger-fg: #f85149; --color-danger-emphasis: #da3633; --color-danger-muted: rgba(248,81,73,0.4); --color-danger-subtle: rgba(248,81,73,0.15); --color-done-fg: #a371f7; --color-done-emphasis: #8957e5; --color-done-muted: rgba(163,113,247,0.4); --color-done-subtle: rgba(163,113,247,0.15); --color-sponsors-fg: #db61a2; --color-sponsors-emphasis: #bf4b8a; --color-sponsors-muted: rgba(219,97,162,0.4); --color-sponsors-subtle: rgba(219,97,162,0.15); --color-primer-fg-disabled: #484f58; --color-primer-canvas-backdrop: rgba(1,4,9,0.8); --color-primer-canvas-sticky: rgba(13,17,23,0.95); --color-primer-border-active: #F78166; --color-primer-border-contrast: rgba(240,246,252,0.2); --color-primer-shadow-highlight: 0 0 transparent; --color-primer-shadow-inset: 0 0 transparent; --color-primer-shadow-focus: 0 0 0 3px #0c2d6b; --color-scale-black: #010409; --color-scale-white: #f0f6fc; --color-scale-gray-0: #f0f6fc; --color-scale-gray-1: #c9d1d9; --color-scale-gray-2: #b1bac4; --color-scale-gray-3: #8b949e; --color-scale-gray-4: #6e7681; --color-scale-gray-5: #484f58; --color-scale-gray-6: #30363d; --color-scale-gray-7: #21262d; --color-scale-gray-8: #161b22; --color-scale-gray-9: #0d1117; --color-scale-blue-0: #cae8ff; --color-scale-blue-1: #a5d6ff; --color-scale-blue-2: #79c0ff; --color-scale-blue-3: #58a6ff; --color-scale-blue-4: #388bfd; --color-scale-blue-5: #1f6feb; --color-scale-blue-6: #1158c7; --color-scale-blue-7: #0d419d; --color-scale-blue-8: #0c2d6b; --color-scale-blue-9: #051d4d; --color-scale-green-0: #aff5b4; --color-scale-green-1: #7ee787; --color-scale-green-2: #56d364; --color-scale-green-3: #3fb950; --color-scale-green-4: #2ea043; --color-scale-green-5: #238636; --color-scale-green-6: #196c2e; --color-scale-green-7: #0f5323; --color-scale-green-8: #033a16; --color-scale-green-9: #04260f; --color-scale-yellow-0: #f8e3a1; --color-scale-yellow-1: #f2cc60; --color-scale-yellow-2: #e3b341; --color-scale-yellow-3: #d29922; --color-scale-yellow-4: #bb8009; --color-scale-yellow-5: #9e6a03; --color-scale-yellow-6: #845306; --color-scale-yellow-7: #693e00; --color-scale-yellow-8: #4b2900; --color-scale-yellow-9: #341a00; --color-scale-orange-0: #ffdfb6; --color-scale-orange-1: #ffc680; --color-scale-orange-2: #ffa657; --color-scale-orange-3: #f0883e; --color-scale-orange-4: #db6d28; --color-scale-orange-5: #bd561d; --color-scale-orange-6: #9b4215; --color-scale-orange-7: #762d0a; --color-scale-orange-8: #5a1e02; --color-scale-orange-9: #3d1300; --color-scale-red-0: #ffdcd7; --color-scale-red-1: #ffc1ba; --color-scale-red-2: #ffa198; --color-scale-red-3: #ff7b72; --color-scale-red-4: #f85149; --color-scale-red-5: #da3633; --color-scale-red-6: #b62324; --color-scale-red-7: #8e1519; --color-scale-red-8: #67060c; --color-scale-red-9: #490202; --color-scale-purple-0: #eddeff; --color-scale-purple-1: #e2c5ff; --color-scale-purple-2: #d2a8ff; --color-scale-purple-3: #bc8cff; --color-scale-purple-4: #a371f7; --color-scale-purple-5: #8957e5; --color-scale-purple-6: #6e40c9; --color-scale-purple-7: #553098; --color-scale-purple-8: #3c1e70; --color-scale-purple-9: #271052; --color-scale-pink-0: #ffdaec; --color-scale-pink-1: #ffbedd; --color-scale-pink-2: #ff9bce; --color-scale-pink-3: #f778ba; --color-scale-pink-4: #db61a2; --color-scale-pink-5: #bf4b8a; --color-scale-pink-6: #9e3670; --color-scale-pink-7: #7d2457; --color-scale-pink-8: #5e103e; --color-scale-pink-9: #42062a; --color-scale-coral-0: #FFDDD2; --color-scale-coral-1: #FFC2B2; --color-scale-coral-2: #FFA28B; --color-scale-coral-3: #F78166; --color-scale-coral-4: #EA6045; --color-scale-coral-5: #CF462D; --color-scale-coral-6: #AC3220; --color-scale-coral-7: #872012; --color-scale-coral-8: #640D04; --color-scale-coral-9: #460701; }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme="dark"] { --color-canvas-default-transparent: rgba(13,17,23,0); --color-marketing-icon-primary: #79c0ff; --color-marketing-icon-secondary: #1f6feb; --color-diff-blob-addition-num-text: #c9d1d9; --color-diff-blob-addition-fg: #c9d1d9; --color-diff-blob-addition-num-bg: rgba(63,185,80,0.3); --color-diff-blob-addition-line-bg: rgba(46,160,67,0.15); --color-diff-blob-addition-word-bg: rgba(46,160,67,0.4); --color-diff-blob-deletion-num-text: #c9d1d9; --color-diff-blob-deletion-fg: #c9d1d9; --color-diff-blob-deletion-num-bg: rgba(248,81,73,0.3); --color-diff-blob-deletion-line-bg: rgba(248,81,73,0.15); --color-diff-blob-deletion-word-bg: rgba(248,81,73,0.4); --color-diff-blob-hunk-num-bg: rgba(56,139,253,0.4); --color-diff-blob-expander-icon: #8b949e; --color-diff-blob-selected-line-highlight-mix-blend-mode: screen; --color-diffstat-deletion-border: rgba(240,246,252,0.1); --color-diffstat-addition-border: rgba(240,246,252,0.1); --color-diffstat-addition-bg: #3fb950; --color-search-keyword-hl: rgba(210,153,34,0.4); --color-prettylights-syntax-comment: #8b949e; --color-prettylights-syntax-constant: #79c0ff; --color-prettylights-syntax-entity: #d2a8ff; --color-prettylights-syntax-storage-modifier-import: #c9d1d9; --color-prettylights-syntax-entity-tag: #7ee787; --color-prettylights-syntax-keyword: #ff7b72; --color-prettylights-syntax-string: #a5d6ff; --color-prettylights-syntax-variable: #ffa657; --color-prettylights-syntax-brackethighlighter-unmatched: #f85149; --color-prettylights-syntax-invalid-illegal-text: #f0f6fc; --color-prettylights-syntax-invalid-illegal-bg: #8e1519; --color-prettylights-syntax-carriage-return-text: #f0f6fc; --color-prettylights-syntax-carriage-return-bg: #b62324; --color-prettylights-syntax-string-regexp: #7ee787; --color-prettylights-syntax-markup-list: #f2cc60; --color-prettylights-syntax-markup-heading: #1f6feb; --color-prettylights-syntax-markup-italic: #c9d1d9; --color-prettylights-syntax-markup-bold: #c9d1d9; --color-prettylights-syntax-markup-deleted-text: #ffdcd7; --color-prettylights-syntax-markup-deleted-bg: #67060c; --color-prettylights-syntax-markup-inserted-text: #aff5b4; --color-prettylights-syntax-markup-inserted-bg: #033a16; --color-prettylights-syntax-markup-changed-text: #ffdfb6; --color-prettylights-syntax-markup-changed-bg: #5a1e02; --color-prettylights-syntax-markup-ignored-text: #c9d1d9; --color-prettylights-syntax-markup-ignored-bg: #1158c7; --color-prettylights-syntax-meta-diff-range: #d2a8ff; --color-prettylights-syntax-brackethighlighter-angle: #8b949e; --color-prettylights-syntax-sublimelinter-gutter-mark: #484f58; --color-prettylights-syntax-constant-other-reference-link: #a5d6ff; --color-codemirror-text: #c9d1d9; --color-codemirror-bg: #0d1117; --color-codemirror-gutters-bg: #0d1117; --color-codemirror-guttermarker-text: #0d1117; --color-codemirror-guttermarker-subtle-text: #484f58; --color-codemirror-linenumber-text: #8b949e; --color-codemirror-cursor: #c9d1d9; --color-codemirror-selection-bg: rgba(56,139,253,0.4); --color-codemirror-activeline-bg: rgba(110,118,129,0.1); --color-codemirror-matchingbracket-text: #c9d1d9; --color-codemirror-lines-bg: #0d1117; --color-codemirror-syntax-comment: #8b949e; --color-codemirror-syntax-constant: #79c0ff; --color-codemirror-syntax-entity: #d2a8ff; --color-codemirror-syntax-keyword: #ff7b72; --color-codemirror-syntax-storage: #ff7b72; --color-codemirror-syntax-string: #a5d6ff; --color-codemirror-syntax-support: #79c0ff; --color-codemirror-syntax-variable: #ffa657; --color-checks-bg: #010409; --color-checks-run-border-width: 1px; --color-checks-container-border-width: 1px; --color-checks-text-primary: #c9d1d9; --color-checks-text-secondary: #8b949e; --color-checks-text-link: #58a6ff; --color-checks-btn-icon: #8b949e; --color-checks-btn-hover-icon: #c9d1d9; --color-checks-btn-hover-bg: rgba(110,118,129,0.1); --color-checks-input-text: #8b949e; --color-checks-input-placeholder-text: #484f58; --color-checks-input-focus-text: #c9d1d9; --color-checks-input-bg: #161b22; --color-checks-input-shadow: 0 0 0 1px (obj) => get_1.default(obj, path); --color-checks-donut-error: #f85149; --color-checks-donut-pending: #d29922; --color-checks-donut-success: #2ea043; --color-checks-donut-neutral: #8b949e; --color-checks-dropdown-text: #c9d1d9; --color-checks-dropdown-bg: #161b22; --color-checks-dropdown-border: #30363d; --color-checks-dropdown-shadow: rgba(1,4,9,0.3); --color-checks-dropdown-hover-text: #c9d1d9; --color-checks-dropdown-hover-bg: rgba(110,118,129,0.1); --color-checks-dropdown-btn-hover-text: #c9d1d9; --color-checks-dropdown-btn-hover-bg: rgba(110,118,129,0.1); --color-checks-scrollbar-thumb-bg: rgba(110,118,129,0.4); --color-checks-header-label-text: #8b949e; --color-checks-header-label-open-text: #c9d1d9; --color-checks-header-border: #21262d; --color-checks-header-icon: #8b949e; --color-checks-line-text: #8b949e; --color-checks-line-num-text: #484f58; --color-checks-line-timestamp-text: #484f58; --color-checks-line-hover-bg: rgba(110,118,129,0.1); --color-checks-line-selected-bg: rgba(56,139,253,0.15); --color-checks-line-selected-num-text: #58a6ff; --color-checks-line-dt-fm-text: #f0f6fc; --color-checks-line-dt-fm-bg: #9e6a03; --color-checks-gate-bg: rgba(187,128,9,0.15); --color-checks-gate-text: #8b949e; --color-checks-gate-waiting-text: #d29922; --color-checks-step-header-open-bg: #161b22; --color-checks-step-error-text: #f85149; --color-checks-step-warning-text: #d29922; --color-checks-logline-text: #8b949e; --color-checks-logline-num-text: #484f58; --color-checks-logline-debug-text: #a371f7; --color-checks-logline-error-text: #8b949e; --color-checks-logline-error-num-text: #484f58; --color-checks-logline-error-bg: rgba(248,81,73,0.15); --color-checks-logline-warning-text: #8b949e; --color-checks-logline-warning-num-text: #d29922; --color-checks-logline-warning-bg: rgba(187,128,9,0.15); --color-checks-logline-command-text: #58a6ff; --color-checks-logline-section-text: #3fb950; --color-checks-ansi-black: #0d1117; --color-checks-ansi-black-bright: #161b22; --color-checks-ansi-white: #b1bac4; --color-checks-ansi-white-bright: #b1bac4; --color-checks-ansi-gray: #6e7681; --color-checks-ansi-red: #ff7b72; --color-checks-ansi-red-bright: #ffa198; --color-checks-ansi-green: #3fb950; --color-checks-ansi-green-bright: #56d364; --color-checks-ansi-yellow: #d29922; --color-checks-ansi-yellow-bright: #e3b341; --color-checks-ansi-blue: #58a6ff; --color-checks-ansi-blue-bright: #79c0ff; --color-checks-ansi-magenta: #bc8cff; --color-checks-ansi-magenta-bright: #d2a8ff; --color-checks-ansi-cyan: #76e3ea; --color-checks-ansi-cyan-bright: #b3f0ff; --color-project-header-bg: #0d1117; --color-project-sidebar-bg: #161b22; --color-project-gradient-in: #161b22; --color-project-gradient-out: rgba(22,27,34,0); --color-mktg-btn-bg: #f6f8fa; --color-mktg-btn-shadow-outline: rgb(255 255 255 / 25%) 0 0 0 1px inset; --color-mktg-btn-shadow-focus: rgb(255 255 255 / 25%) 0 0 0 4px; --color-mktg-btn-shadow-hover: 0 4px 7px rgba(0, 0, 0, 0.15), 0 100px 80px rgba(255, 255, 255, 0.02), 0 42px 33px rgba(255, 255, 255, 0.024), 0 22px 18px rgba(255, 255, 255, 0.028), 0 12px 10px rgba(255, 255, 255, 0.034), 0 7px 5px rgba(255, 255, 255, 0.04), 0 3px 2px rgba(255, 255, 255, 0.07); --color-mktg-btn-shadow-hover-muted: rgb(255 255 255) 0 0 0 2px inset; --color-avatar-bg: rgba(240,246,252,0.1); --color-avatar-border: rgba(240,246,252,0.1); --color-avatar-stack-fade: #30363d; --color-avatar-stack-fade-more: #21262d; --color-avatar-child-shadow: -2px -2px 0 #0d1117; --color-topic-tag-border: rgba(0,0,0,0); --color-counter-border: rgba(0,0,0,0); --color-select-menu-backdrop-border: #484f58; --color-select-menu-tap-highlight: rgba(48,54,61,0.5); --color-select-menu-tap-focus-bg: #0c2d6b; --color-overlay-shadow: 0 0 0 1px #30363d, 0 16px 32px rgba(1,4,9,0.85); --color-header-text: rgba(240,246,252,0.7); --color-header-bg: #161b22; --color-header-divider: #8b949e; --color-header-logo: #f0f6fc; --color-header-search-bg: #0d1117; --color-header-search-border: #30363d; --color-sidenav-selected-bg: #21262d; --color-menu-bg-active: #161b22; --color-input-disabled-bg: rgba(110,118,129,0); --color-timeline-badge-bg: #21262d; --color-ansi-black: #484f58; --color-ansi-black-bright: #6e7681; --color-ansi-white: #b1bac4; --color-ansi-white-bright: #f0f6fc; --color-ansi-gray: #6e7681; --color-ansi-red: #ff7b72; --color-ansi-red-bright: #ffa198; --color-ansi-green: #3fb950; --color-ansi-green-bright: #56d364; --color-ansi-yellow: #d29922; --color-ansi-yellow-bright: #e3b341; --color-ansi-blue: #58a6ff; --color-ansi-blue-bright: #79c0ff; --color-ansi-magenta: #bc8cff; --color-ansi-magenta-bright: #d2a8ff; --color-ansi-cyan: #39c5cf; --color-ansi-cyan-bright: #56d4dd; --color-btn-text: #c9d1d9; --color-btn-bg: #21262d; --color-btn-border: rgba(240,246,252,0.1); --color-btn-shadow: 0 0 transparent; --color-btn-inset-shadow: 0 0 transparent; --color-btn-hover-bg: #30363d; --color-btn-hover-border: #8b949e; --color-btn-active-bg: hsla(212,12%,18%,1); --color-btn-active-border: #6e7681; --color-btn-selected-bg: #161b22; --color-btn-focus-bg: #21262d; --color-btn-focus-border: #8b949e; --color-btn-focus-shadow: 0 0 0 3px rgba(139,148,158,0.3); --color-btn-shadow-active: inset 0 0.15em 0.3em rgba(1,4,9,0.15); --color-btn-shadow-input-focus: 0 0 0 0.2em rgba(31,111,235,0.3); --color-btn-counter-bg: #30363d; --color-btn-primary-text: #ffffff; --color-btn-primary-bg: #238636; --color-btn-primary-border: rgba(240,246,252,0.1); --color-btn-primary-shadow: 0 0 transparent; --color-btn-primary-inset-shadow: 0 0 transparent; --color-btn-primary-hover-bg: #2ea043; --color-btn-primary-hover-border: rgba(240,246,252,0.1); --color-btn-primary-selected-bg: #238636; --color-btn-primary-selected-shadow: 0 0 transparent; --color-btn-primary-disabled-text: rgba(240,246,252,0.5); --color-btn-primary-disabled-bg: rgba(35,134,54,0.6); --color-btn-primary-disabled-border: rgba(240,246,252,0.1); --color-btn-primary-focus-bg: #238636; --color-btn-primary-focus-border: rgba(240,246,252,0.1); --color-btn-primary-focus-shadow: 0 0 0 3px rgba(46,164,79,0.4); --color-btn-primary-icon: #f0f6fc; --color-btn-primary-counter-bg: rgba(240,246,252,0.2); --color-btn-outline-text: #58a6ff; --color-btn-outline-hover-text: #58a6ff; --color-btn-outline-hover-bg: #30363d; --color-btn-outline-hover-border: rgba(240,246,252,0.1); --color-btn-outline-hover-shadow: 0 1px 0 rgba(1,4,9,0.1); --color-btn-outline-hover-inset-shadow: inset 0 1px 0 rgba(240,246,252,0.03); --color-btn-outline-hover-counter-bg: rgba(240,246,252,0.2); --color-btn-outline-selected-text: #f0f6fc; --color-btn-outline-selected-bg: #0d419d; --color-btn-outline-selected-border: rgba(240,246,252,0.1); --color-btn-outline-selected-shadow: 0 0 transparent; --color-btn-outline-disabled-text: rgba(88,166,255,0.5); --color-btn-outline-disabled-bg: #0d1117; --color-btn-outline-disabled-counter-bg: rgba(31,111,235,0.05); --color-btn-outline-focus-border: rgba(240,246,252,0.1); --color-btn-outline-focus-shadow: 0 0 0 3px rgba(17,88,199,0.4); --color-btn-outline-counter-bg: rgba(31,111,235,0.1); --color-btn-danger-text: #f85149; --color-btn-danger-hover-text: #f0f6fc; --color-btn-danger-hover-bg: #da3633; --color-btn-danger-hover-border: #f85149; --color-btn-danger-hover-shadow: 0 0 transparent; --color-btn-danger-hover-inset-shadow: 0 0 transparent; --color-btn-danger-hover-icon: #f0f6fc; --color-btn-danger-hover-counter-bg: rgba(255,255,255,0.2); --color-btn-danger-selected-text: #ffffff; --color-btn-danger-selected-bg: #b62324; --color-btn-danger-selected-border: #ff7b72; --color-btn-danger-selected-shadow: 0 0 transparent; --color-btn-danger-disabled-text: rgba(248,81,73,0.5); --color-btn-danger-disabled-bg: #0d1117; --color-btn-danger-disabled-counter-bg: rgba(218,54,51,0.05); --color-btn-danger-focus-border: #f85149; --color-btn-danger-focus-shadow: 0 0 0 3px rgba(248,81,73,0.4); --color-btn-danger-counter-bg: rgba(218,54,51,0.1); --color-btn-danger-icon: #f85149; --color-underlinenav-icon: #484f58; --color-underlinenav-border-hover: rgba(110,118,129,0.4); --color-action-list-item-inline-divider: rgba(48,54,61,0.48); --color-action-list-item-default-hover-bg: rgba(177,186,196,0.12); --color-action-list-item-default-active-bg: rgba(177,186,196,0.2); --color-action-list-item-default-selected-bg: rgba(177,186,196,0.08); --color-action-list-item-danger-hover-bg: rgba(248,81,73,0.16); --color-action-list-item-danger-active-bg: rgba(248,81,73,0.24); --color-action-list-item-danger-hover-text: #ff7b72; --color-fg-default: #c9d1d9; --color-fg-muted: #8b949e; --color-fg-subtle: #484f58; --color-fg-on-emphasis: #f0f6fc; --color-canvas-default: #0d1117; --color-canvas-overlay: #161b22; --color-canvas-inset: #010409; --color-canvas-subtle: #161b22; --color-border-default: #30363d; --color-border-muted: #21262d; --color-border-subtle: rgba(240,246,252,0.1); --color-shadow-small: 0 0 transparent; --color-shadow-medium: 0 3px 6px #010409; --color-shadow-large: 0 8px 24px #010409; --color-shadow-extra-large: 0 12px 48px #010409; --color-neutral-emphasis-plus: #6e7681; --color-neutral-emphasis: #6e7681; --color-neutral-muted: rgba(110,118,129,0.4); --color-neutral-subtle: rgba(110,118,129,0.1); --color-accent-fg: #58a6ff; --color-accent-emphasis: #1f6feb; --color-accent-muted: rgba(56,139,253,0.4); --color-accent-subtle: rgba(56,139,253,0.15); --color-success-fg: #3fb950; --color-success-emphasis: #238636; --color-success-muted: rgba(46,160,67,0.4); --color-success-subtle: rgba(46,160,67,0.15); --color-attention-fg: #d29922; --color-attention-emphasis: #9e6a03; --color-attention-muted: rgba(187,128,9,0.4); --color-attention-subtle: rgba(187,128,9,0.15); --color-severe-fg: #db6d28; --color-severe-emphasis: #bd561d; --color-severe-muted: rgba(219,109,40,0.4); --color-severe-subtle: rgba(219,109,40,0.15); --color-danger-fg: #f85149; --color-danger-emphasis: #da3633; --color-danger-muted: rgba(248,81,73,0.4); --color-danger-subtle: rgba(248,81,73,0.15); --color-done-fg: #a371f7; --color-done-emphasis: #8957e5; --color-done-muted: rgba(163,113,247,0.4); --color-done-subtle: rgba(163,113,247,0.15); --color-sponsors-fg: #db61a2; --color-sponsors-emphasis: #bf4b8a; --color-sponsors-muted: rgba(219,97,162,0.4); --color-sponsors-subtle: rgba(219,97,162,0.15); --color-primer-fg-disabled: #484f58; --color-primer-canvas-backdrop: rgba(1,4,9,0.8); --color-primer-canvas-sticky: rgba(13,17,23,0.95); --color-primer-border-active: #F78166; --color-primer-border-contrast: rgba(240,246,252,0.2); --color-primer-shadow-highlight: 0 0 transparent; --color-primer-shadow-inset: 0 0 transparent; --color-primer-shadow-focus: 0 0 0 3px #0c2d6b; --color-scale-black: #010409; --color-scale-white: #f0f6fc; --color-scale-gray-0: #f0f6fc; --color-scale-gray-1: #c9d1d9; --color-scale-gray-2: #b1bac4; --color-scale-gray-3: #8b949e; --color-scale-gray-4: #6e7681; --color-scale-gray-5: #484f58; --color-scale-gray-6: #30363d; --color-scale-gray-7: #21262d; --color-scale-gray-8: #161b22; --color-scale-gray-9: #0d1117; --color-scale-blue-0: #cae8ff; --color-scale-blue-1: #a5d6ff; --color-scale-blue-2: #79c0ff; --color-scale-blue-3: #58a6ff; --color-scale-blue-4: #388bfd; --color-scale-blue-5: #1f6feb; --color-scale-blue-6: #1158c7; --color-scale-blue-7: #0d419d; --color-scale-blue-8: #0c2d6b; --color-scale-blue-9: #051d4d; --color-scale-green-0: #aff5b4; --color-scale-green-1: #7ee787; --color-scale-green-2: #56d364; --color-scale-green-3: #3fb950; --color-scale-green-4: #2ea043; --color-scale-green-5: #238636; --color-scale-green-6: #196c2e; --color-scale-green-7: #0f5323; --color-scale-green-8: #033a16; --color-scale-green-9: #04260f; --color-scale-yellow-0: #f8e3a1; --color-scale-yellow-1: #f2cc60; --color-scale-yellow-2: #e3b341; --color-scale-yellow-3: #d29922; --color-scale-yellow-4: #bb8009; --color-scale-yellow-5: #9e6a03; --color-scale-yellow-6: #845306; --color-scale-yellow-7: #693e00; --color-scale-yellow-8: #4b2900; --color-scale-yellow-9: #341a00; --color-scale-orange-0: #ffdfb6; --color-scale-orange-1: #ffc680; --color-scale-orange-2: #ffa657; --color-scale-orange-3: #f0883e; --color-scale-orange-4: #db6d28; --color-scale-orange-5: #bd561d; --color-scale-orange-6: #9b4215; --color-scale-orange-7: #762d0a; --color-scale-orange-8: #5a1e02; --color-scale-orange-9: #3d1300; --color-scale-red-0: #ffdcd7; --color-scale-red-1: #ffc1ba; --color-scale-red-2: #ffa198; --color-scale-red-3: #ff7b72; --color-scale-red-4: #f85149; --color-scale-red-5: #da3633; --color-scale-red-6: #b62324; --color-scale-red-7: #8e1519; --color-scale-red-8: #67060c; --color-scale-red-9: #490202; --color-scale-purple-0: #eddeff; --color-scale-purple-1: #e2c5ff; --color-scale-purple-2: #d2a8ff; --color-scale-purple-3: #bc8cff; --color-scale-purple-4: #a371f7; --color-scale-purple-5: #8957e5; --color-scale-purple-6: #6e40c9; --color-scale-purple-7: #553098; --color-scale-purple-8: #3c1e70; --color-scale-purple-9: #271052; --color-scale-pink-0: #ffdaec; --color-scale-pink-1: #ffbedd; --color-scale-pink-2: #ff9bce; --color-scale-pink-3: #f778ba; --color-scale-pink-4: #db61a2; --color-scale-pink-5: #bf4b8a; --color-scale-pink-6: #9e3670; --color-scale-pink-7: #7d2457; --color-scale-pink-8: #5e103e; --color-scale-pink-9: #42062a; --color-scale-coral-0: #FFDDD2; --color-scale-coral-1: #FFC2B2; --color-scale-coral-2: #FFA28B; --color-scale-coral-3: #F78166; --color-scale-coral-4: #EA6045; --color-scale-coral-5: #CF462D; --color-scale-coral-6: #AC3220; --color-scale-coral-7: #872012; --color-scale-coral-8: #640D04; --color-scale-coral-9: #460701; }
}
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://github.githubassets.com/assets/frameworks-f73ad64a961ad5f0948ddeeca7af56e1.css

@charset "utf-8";

:root { --border-width: 1px; --border-style: solid; --font-size-small: 12px; --font-weight-semibold: 500; --size-2: 20px; }

:root, [data-color-mode="light"][data-light-theme*="light"], [data-color-mode="dark"][data-dark-theme*="light"] { color-scheme: light; }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="light"] { color-scheme: light; }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="light"] { color-scheme: light; }
}

[data-color-mode="light"][data-light-theme*="dark"], [data-color-mode="dark"][data-dark-theme*="dark"] { color-scheme: dark; }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] { color-scheme: dark; }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] { color-scheme: dark; }
}

[data-color-mode] { color: var(--color-fg-default); background-color: var(--color-canvas-default); }

.ActionList { padding: 8px; }

.ActionList--full { padding: 0px; }

.ActionList--divided .ActionList-item-label::before { position: absolute; top: -6px; display: block; width: 100%; height: 1px; content: ""; background: var(--color-action-list-item-inline-divider); }

.ActionList--divided .ActionList-item--navActive .ActionList-item-label::before, .ActionList--divided .ActionList-item--navActive + .ActionList-item .ActionList-item-label::before { visibility: hidden; }

.ActionList-item:first-of-type .ActionList-item-label::before, .ActionList-sectionDivider + .ActionList-item .ActionList-item-label::before { visibility: hidden; }

.ActionList--tree { --ActionList-tree-depth: 1; }

.ActionList--tree .ActionList-item--subItem > .ActionList-content { font-size: 14px; }

.ActionList--tree .ActionList-item[aria-expanded] .ActionList--subGroup { position: relative; }

.ActionList--tree .ActionList-item[aria-expanded] .ActionList--subGroup .ActionList-content { padding-left: calc(8px * var(--ActionList-tree-depth)); }

.ActionList--tree .ActionList-item[aria-expanded="true"] .ActionList-item-collapseIcon { transition: transform 120ms linear 0s; transform: rotate(0deg); }

.ActionList--tree .ActionList-item[aria-expanded="false"] .ActionList-item-collapseIcon { transition: transform 120ms linear 0s; transform: rotate(-90deg); }

.ActionList--tree .ActionList-item--hasSubItem .ActionList-item--subItem:not(.ActionList-item--hasSubItem) .ActionList-content > span:first-child { padding-left: 24px; }

.ActionList--tree > [aria-level="1"].ActionList-item--hasSubItem > .ActionList--subGroup::before { position: absolute; left: 16px; width: 1px; height: 100%; content: ""; background: var(--color-action-list-item-inline-divider); }

.ActionList--tree .ActionList-item--hasSubItem:not([aria-level="1"]) > .ActionList--subGroup::before { position: absolute; left: calc(8px * (var(--ActionList-tree-depth)) + 7px); width: 1px; height: 100%; content: ""; background: var(--color-action-list-item-inline-divider); }

.ActionList-item { position: relative; list-style: none; background-color: transparent; border-radius: 6px; }

.ActionList-item:hover, .ActionList-item:active { cursor: pointer; }

.ActionList-item:hover .ActionList-content, .ActionList-item:active .ActionList-content { text-decoration: none; }

.ActionList-item:not(.ActionList-item--hasSubItem):hover { cursor: pointer; background-color: var(--color-action-list-item-default-hover-bg); }

.ActionList-item:not(.ActionList-item--hasSubItem):active { background: var(--color-action-list-item-default-active-bg); }

@media screen and (prefers-reduced-motion: no-preference) {
  .ActionList-item:not(.ActionList-item--hasSubItem):active { animation: 4s cubic-bezier(0.33, 1, 0.68, 1) 0s 1 normal forwards running ActionList-item-active-bg; }
}

@keyframes ActionList-item-active-bg { 
  50% { box-shadow: rgba(0, 0, 0, 0.04) 0px 0px 0px inset; transform: scale(1); }
  100% { box-shadow: rgba(0, 0, 0, 0.04) 0px 3px 9px inset; transform: scale(0.97); }
}

.ActionList-item:not(.ActionList-item--hasSubItem):hover .ActionList-item-label::before, .ActionList-item:not(.ActionList-item--hasSubItem):hover + .ActionList-item .ActionList-item-label::before, .ActionList-item:not(.ActionList-item--hasSubItem):active .ActionList-item-label::before, .ActionList-item:not(.ActionList-item--hasSubItem):active + .ActionList-item .ActionList-item-label::before { visibility: hidden; }

.ActionList-item.ActionList-item--hasSubItem > .ActionList-content:hover { background-color: var(--color-action-list-item-default-hover-bg); }

.ActionList-item.ActionList-item--navActive:not(.ActionList-item--subItem) .ActionList-item-label { font-weight: 600; }

.ActionList-item.ActionList-item--navActive:not(.ActionList-item--danger) { background: var(--color-action-list-item-default-selected-bg); }

.ActionList-item.ActionList-item--navActive:not(.ActionList-item--danger)::before, .ActionList-item.ActionList-item--navActive:not(.ActionList-item--danger) + .ActionList-item::before { visibility: hidden; }

.ActionList-item.ActionList-item--navActive:not(.ActionList-item--danger)::after { position: absolute; top: calc(50% - 12px); left: -8px; width: 4px; height: 24px; content: ""; background: var(--color-accent-fg); border-radius: 6px; }

.ActionList-item[aria-expanded] .ActionList--subGroup .ActionList-content { padding-left: 24px; }

.ActionList-item[aria-expanded] .ActionList-content--visual16 + .ActionList--subGroup .ActionList-content { padding-left: 32px; }

.ActionList-item[aria-expanded] .ActionList-content--visual20 + .ActionList--subGroup .ActionList-content { padding-left: 36px; }

.ActionList-item[aria-expanded] .ActionList-content--visual24 + .ActionList--subGroup .ActionList-content { padding-left: 40px; }

.ActionList-item[aria-expanded="true"] .ActionList-item-collapseIcon { transition: transform 120ms linear 0s; transform: scaleY(-1); }

.ActionList-item[aria-expanded="true"] .ActionList--subGroup { display: block; }

.ActionList-item[aria-expanded="true"].ActionList-item--hasActiveSubItem > .ActionList-content > .ActionList-item-label { font-weight: 600; }

.ActionList-item[aria-expanded="false"] .ActionList-item-collapseIcon { transition: transform 120ms linear 0s; transform: scaleY(1); }

.ActionList-item[aria-expanded="false"] .ActionList--subGroup { display: none; }

.ActionList-item[aria-expanded="false"].ActionList-item--hasActiveSubItem { background: var(--color-action-list-item-default-selected-bg); }

.ActionList-item[aria-expanded="false"].ActionList-item--hasActiveSubItem .ActionList-item-label { font-weight: 600; }

.ActionList-item[aria-expanded="false"].ActionList-item--hasActiveSubItem::before, .ActionList-item[aria-expanded="false"].ActionList-item--hasActiveSubItem + .ActionList-item::before { visibility: hidden; }

.ActionList-item[aria-expanded="false"].ActionList-item--hasActiveSubItem::after { position: absolute; top: calc(50% - 12px); left: -8px; width: 4px; height: 24px; content: ""; background: var(--color-accent-fg); border-radius: 6px; }

.ActionList-item[aria-checked="true"] .ActionList-item-multiSelectCheckmark, .ActionList-item[aria-selected="true"] .ActionList-item-multiSelectCheckmark { visibility: visible; opacity: 1; }

.ActionList-item[aria-checked="true"] .ActionList-item-singleSelectCheckmark, .ActionList-item[aria-selected="true"] .ActionList-item-singleSelectCheckmark { visibility: visible; }

@media screen and (prefers-reduced-motion: no-preference) {
  .ActionList-item[aria-checked="true"] .ActionList-item-singleSelectCheckmark, .ActionList-item[aria-selected="true"] .ActionList-item-singleSelectCheckmark { animation: 200ms cubic-bezier(0.11, 0, 0.5, 0) 0s 1 normal forwards running checkmarkIn; }
}

.ActionList-item[aria-checked="true"] .ActionList-item-multiSelectIcon .ActionList-item-multiSelectIconRect, .ActionList-item[aria-selected="true"] .ActionList-item-multiSelectIcon .ActionList-item-multiSelectIconRect { fill: var(--color-accent-fg); stroke: var(--color-accent-fg); stroke-width: 1px; }

.ActionList-item[aria-checked="true"] .ActionList-item-multiSelectIcon .ActionList-item-multiSelectCheckmark, .ActionList-item[aria-selected="true"] .ActionList-item-multiSelectIcon .ActionList-item-multiSelectCheckmark { fill: var(--color-fg-on-emphasis); }

.ActionList-item[aria-checked="false"] .ActionList-item-multiSelectCheckmark, .ActionList-item[aria-selected="false"] .ActionList-item-multiSelectCheckmark { visibility: hidden; opacity: 0; }

.ActionList-item[aria-checked="false"] .ActionList-item-singleSelectCheckmark, .ActionList-item[aria-selected="false"] .ActionList-item-singleSelectCheckmark { visibility: hidden; transition: visibility 0s linear 200ms; clip-path: inset(16px 0px 0px); }

@media screen and (prefers-reduced-motion: no-preference) {
  .ActionList-item[aria-checked="false"] .ActionList-item-singleSelectCheckmark, .ActionList-item[aria-selected="false"] .ActionList-item-singleSelectCheckmark { animation: 200ms cubic-bezier(0.11, 0, 0.5, 0) 0s 1 normal forwards running checkmarkOut; }
}

.ActionList-item[aria-checked="false"] .ActionList-item-multiSelectIcon .ActionList-item-multiSelectIconRect, .ActionList-item[aria-selected="false"] .ActionList-item-multiSelectIcon .ActionList-item-multiSelectIconRect { fill: var(--color-canvas-default); stroke: var(--color-border-default); stroke-width: 1px; }

.ActionList-item[aria-checked="false"] .ActionList-item-multiSelectIconRect, .ActionList-item[aria-selected="false"] .ActionList-item-multiSelectIconRect { fill: var(--color-canvas-default); border: 1px solid var(--color-border-default); }

@keyframes checkmarkIn { 
  0% { clip-path: inset(16px 0px 0px); }
  100% { clip-path: inset(0px); }
}

@keyframes checkmarkOut { 
  0% { clip-path: inset(0px); }
  100% { clip-path: inset(16px 0px 0px); }
}

.ActionList-item.ActionList-item--danger .ActionList-item-label { color: var(--color-danger-fg); }

.ActionList-item.ActionList-item--danger .ActionList-item-visual { color: var(--color-danger-fg); }

@media (hover: hover) and (pointer: fine) {
  .ActionList-item.ActionList-item--danger:hover { background: var(--color-action-list-item-danger-hover-bg); }
  .ActionList-item.ActionList-item--danger:hover .ActionList-item-label { color: var(--color-action-list-item-danger-hover-text); }
}

.ActionList-item.ActionList-item--danger:active { background: var(--color-action-list-item-danger-active-bg); }

.ActionList-item[aria-disabled="true"] .ActionList-item-label, .ActionList-item[aria-disabled="true"] .ActionList-item-description { color: var(--color-primer-fg-disabled); }

.ActionList-item[aria-disabled="true"] .ActionList-item-visual { fill: var(--color-primer-fg-disabled); }

@media (hover: hover) and (pointer: fine) {
  .ActionList-item[aria-disabled="true"]:hover { cursor: not-allowed; background-color: transparent; }
}

.ActionList-item .ActionList { padding: unset; }

.ActionList-content { position: relative; display: grid; padding: 6px 8px; font-size: 14px; font-weight: 400; color: var(--color-fg-default); user-select: none; border-radius: 6px; transition: background 33.333ms linear 0s; grid-template-rows: min-content; grid-template-areas: "leadingAction leadingVisual label trailingVisual trailingAction"; grid-template-columns: min-content min-content minmax(0px, auto) min-content min-content; align-items: start; }

.ActionList-content > :not(:last-child) { margin-right: 8px; }

.ActionList-content:focus-visible { position: relative; z-index: 1; outline: none; box-shadow: 0 0 0 2px var(--color-accent-fg); }

.ActionList-content.ActionList-content--sizeMedium { padding: 10px 8px; }

.ActionList-content.ActionList-content--sizeLarge { padding: 14px 8px; }

.ActionList-content.ActionList-content--fontSmall { font-size: 12px; }

@media (pointer: coarse) {
  .ActionList-content { padding: 14px 8px; }
}

.ActionList-content.ActionList-content--blockDescription .ActionList-item-visual { place-self: start; }

.ActionList-item-action--leading { grid-area: leadingAction / leadingAction / leadingAction / leadingAction; }

.ActionList-item-visual--leading { grid-area: leadingVisual / leadingVisual / leadingVisual / leadingVisual; }

.ActionList-item-label { grid-area: label / label / label / label; }

.ActionList-item-visual--trailing { grid-area: trailingVisual / trailingVisual / trailingVisual / trailingVisual; }

.ActionList-item-action--trailing { grid-area: trailingAction / trailingAction / trailingAction / trailingAction; }

.ActionList-item-descriptionWrap { grid-area: label / label / label / label; display: flex; flex-direction: column; }

.ActionList-item-descriptionWrap .ActionList-item-description { margin-top: 4px; }

.ActionList-item-descriptionWrap .ActionList-item-label { font-weight: 600; }

.ActionList-item-descriptionWrap--inline { flex-direction: row; align-items: baseline; }

.ActionList-item-descriptionWrap--inline .ActionList-item-description { margin-left: 8px; }

.ActionList-item-description { font-size: 12px; font-weight: 400; line-height: 1.5; color: var(--color-fg-muted); }

.ActionList-item-visual, .ActionList-item-action { display: flex; min-height: 20px; color: var(--color-fg-muted); fill: var(--color-fg-muted); align-items: center; }

.ActionList-item-label { position: relative; font-weight: 400; line-height: 20px; color: var(--color-fg-default); }

.ActionList-item-label--truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.ActionList-item--subItem > .ActionList-content { font-size: 12px; }

.ActionList-sectionDivider:not(:empty) { display: flex; padding: 6px 8px; font-size: 12px; font-weight: 600; color: var(--color-fg-muted); flex-direction: column; }

.ActionList-sectionDivider:empty { height: 1px; padding: 0px; margin: 7px -8px 8px; list-style: none; background: var(--color-action-list-item-inline-divider); border: 0px; }

.ActionList-sectionDivider--filled { margin: 8px -8px; background: var(--color-canvas-subtle); border-top: 1px solid var(--color-action-list-item-inline-divider); border-bottom: 1px solid var(--color-action-list-item-inline-divider); }

.ActionList-sectionDivider--filled:empty { height: 8px; box-sizing: border-box; }

.ActionList-sectionDivider--filled:first-child { margin-top: 0px; }

html { font-family: sans-serif; text-size-adjust: 100%; }

body { margin: 0px; }

article, aside, details, figcaption, figure, footer, header, main, menu, nav, section { display: block; }

summary { display: list-item; }

audio, canvas, progress, video { display: inline-block; }

audio:not([controls]) { display: none; height: 0px; }

progress { vertical-align: baseline; }

template, [hidden] { display: none !important; }

a { background-color: transparent; }

a:active, a:hover { outline-width: 0px; }

abbr[title] { border-bottom: none; text-decoration: underline dotted; }

b, strong { font-weight: inherit; }

b, strong { font-weight: bolder; }

dfn { font-style: italic; }

h1 { font-size: 2em; margin: 0.67em 0px; }

mark { background-color: var(--color-attention-subtle); color: var(--color-text-primary); }

small { font-size: 80%; }

sub, sup { font-size: 75%; line-height: 0; position: relative; vertical-align: baseline; }

sub { bottom: -0.25em; }

sup { top: -0.5em; }

img { border-style: none; }

svg:not(:root) { overflow: hidden; }

code, kbd, pre, samp { font-family: monospace, monospace; font-size: 1em; }

figure { margin: 1em 40px; }

hr { box-sizing: content-box; height: 0px; overflow: visible; }

button, input, select, textarea { font: inherit; margin: 0px; }

optgroup { font-weight: 600; }

button, input { overflow: visible; }

button, select { text-transform: none; }

button, html [type="button"], [type="reset"], [type="submit"] { appearance: button; }

fieldset { border: 1px solid silver; margin: 0px 2px; padding: 0.35em 0.625em 0.75em; }

legend { box-sizing: border-box; color: inherit; display: table; max-width: 100%; padding: 0px; white-space: normal; }

textarea { overflow: auto; }

[type="checkbox"], [type="radio"] { box-sizing: border-box; padding: 0px; }

[type="number"]::-webkit-inner-spin-button, [type="number"]::-webkit-outer-spin-button { height: auto; }

[type="search"] { appearance: textfield; outline-offset: -2px; }

[type="search"]::-webkit-search-cancel-button, [type="search"]::-webkit-search-decoration { appearance: none; }

::-webkit-input-placeholder { color: inherit; opacity: 0.54; }

::-webkit-file-upload-button { appearance: button; font: inherit; }

* { box-sizing: border-box; }

input, select, textarea, button { font-family: inherit; font-size: inherit; line-height: inherit; }

body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"; font-size: 14px; line-height: 1.5; color: var(--color-fg-default); background-color: var(--color-canvas-default); }

a { color: var(--color-accent-fg); text-decoration: none; }

a:hover { text-decoration: underline; }

b, strong { font-weight: 600; }

hr, .rule { height: 0px; margin: 15px 0px; overflow: hidden; background: transparent; border-top: 0px; border-right: 0px; border-left: 0px; border-image: initial; border-bottom: 1px solid var(--color-border-muted); }

hr::before, .rule::before { display: table; content: ""; }

hr::after, .rule::after { display: table; clear: both; content: ""; }

table { border-spacing: 0px; border-collapse: collapse; }

td, th { padding: 0px; }

button { cursor: pointer; border-radius: 0px; }

[hidden][hidden] { display: none !important; }

details summary { cursor: pointer; }

details:not([open]) > :not(summary) { display: none !important; }

kbd { display: inline-block; padding: 3px 5px; font: 11px / 10px ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; color: var(--color-fg-default); vertical-align: middle; background-color: var(--color-canvas-subtle); border-top-color: ; border-top-style: ; border-top-width: ; border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-style: ; border-bottom-width: ; border-left-color: ; border-left-style: ; border-left-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-bottom-color: var(--color-neutral-muted); border-radius: 6px; box-shadow: inset 0 -1px 0 var(--color-neutral-muted); }

h1, h2, h3, h4, h5, h6 { margin-top: 0px; margin-bottom: 0px; }

h1 { font-size: 32px; font-weight: 600; }

h2 { font-size: 24px; font-weight: 600; }

h3 { font-size: 20px; font-weight: 600; }

h4 { font-size: 16px; font-weight: 600; }

h5 { font-size: 14px; font-weight: 600; }

h6 { font-size: 12px; font-weight: 600; }

p { margin-top: 0px; margin-bottom: 10px; }

small { font-size: 90%; }

blockquote { margin: 0px; }

ul, ol { padding-left: 0px; margin-top: 0px; margin-bottom: 0px; }

ol ol, ul ol { list-style-type: lower-roman; }

ul ul ol, ul ol ol, ol ul ol, ol ol ol { list-style-type: lower-alpha; }

dd { margin-left: 0px; }

tt, code { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; }

pre { margin-top: 0px; margin-bottom: 0px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; }

.octicon { vertical-align: text-bottom; }

.octicon { display: inline-block; vertical-align: text-bottom; fill: currentcolor; overflow: visible !important; }

.Box { background-color: var(--color-canvas-default); border-color: var(--color-border-default); border-style: solid; border-width: 1px; border-radius: 6px; }

.Box--condensed { line-height: 1.25; }

.Box--condensed .Box-header { padding: 8px 16px; }

.Box--condensed .Box-body { padding: 8px 16px; }

.Box--condensed .Box-footer { padding: 8px 16px; }

.Box--condensed .Box-btn-octicon.btn-octicon { padding: 8px 16px; margin: -8px -16px; line-height: 1.25; }

.Box--condensed .Box-row { padding: 8px 16px; }

.Box--spacious .Box-header { padding: 24px; line-height: 1.25; }

.Box--spacious .Box-title { font-size: 20px; }

.Box--spacious .Box-body { padding: 24px; }

.Box--spacious .Box-footer { padding: 24px; }

.Box--spacious .Box-btn-octicon.btn-octicon { padding: 24px; margin: -24px; }

.Box--spacious .Box-row { padding: 24px; }

.Box-header { padding: 16px; margin: -1px -1px 0px; background-color: var(--color-canvas-subtle); border-color: var(--color-border-default); border-style: solid; border-width: 1px; border-top-left-radius: 6px; border-top-right-radius: 6px; }

.Box-title { font-size: 14px; font-weight: 600; }

.Box-body { padding: 16px; border-bottom: 1px solid var(--color-border-default); }

.Box-body:last-of-type { margin-bottom: -1px; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.Box-row { padding: 16px; margin-top: -1px; list-style-type: none; border-top-color: var(--color-border-muted); border-top-style: solid; border-top-width: 1px; }

.Box-row:first-of-type { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.Box-row:last-of-type { border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.Box-row.Box-row--unread, .Box-row.unread { box-shadow: inset 2px 0 0 var(--color-accent-emphasis); }

.Box-row.navigation-focus .Box-row--drag-button { color: var(--color-accent-fg); cursor: grab; opacity: 100; }

.Box-row.navigation-focus.is-dragging .Box-row--drag-button { cursor: grabbing; }

.Box-row.navigation-focus.sortable-chosen { background-color: var(--color-canvas-subtle); }

.Box-row.navigation-focus.sortable-ghost { background-color: var(--color-canvas-subtle); }

.Box-row.navigation-focus.sortable-ghost .Box-row--drag-hide { opacity: 0; }

.Box-row--focus-gray.navigation-focus { background-color: var(--color-canvas-subtle); }

.Box-row--focus-blue.navigation-focus { background-color: var(--color-accent-subtle); }

.Box-row--hover-gray:hover { background-color: var(--color-canvas-subtle); }

.Box-row--hover-blue:hover { background-color: var(--color-accent-subtle); }

@media (min-width: 768px) {
  .Box-row-link { color: var(--color-fg-default); text-decoration: none; }
  .Box-row-link:hover { color: var(--color-accent-fg); text-decoration: none; }
}

.Box-row--drag-button { opacity: 0; }

.Box-footer { padding: 16px; margin-top: -1px; border-top-color: var(--color-border-default); border-top-style: solid; border-top-width: 1px; border-radius: 0px 0px 6px 6px; }

.Box--scrollable { max-height: 324px; overflow: scroll; }

.Box--blue { border-color: var(--color-accent-muted); }

.Box--blue .Box-header { background-color: var(--color-accent-subtle); border-color: var(--color-accent-muted); }

.Box--blue .Box-body { border-color: var(--color-accent-muted); }

.Box--blue .Box-row { border-color: var(--color-accent-muted); }

.Box--blue .Box-footer { border-color: var(--color-accent-muted); }

.Box--danger { border-color: var(--color-danger-emphasis); }

.Box--danger .Box-row:first-of-type { border-color: var(--color-danger-emphasis); }

.Box--danger .Box-body:last-of-type { border-color: var(--color-danger-emphasis); }

.Box-header--blue { background-color: var(--color-accent-subtle); border-color: var(--color-accent-muted); }

.Box-row--yellow { background-color: var(--color-attention-subtle); }

.Box-row--blue { background-color: var(--color-accent-subtle); }

.Box-row--gray { background-color: var(--color-canvas-subtle); }

.Box-btn-octicon.btn-octicon { padding: 16px; margin: -16px; line-height: 1.5; }

.Box--overlay { width: 448px; margin-right: auto; margin-left: auto; background-color: var(--color-canvas-default); background-clip: padding-box; border-color: var(--color-border-default); box-shadow: rgba(0, 0, 0, 0.4) 0px 0px 18px; }

.Box--overlay .Box-header { margin: 0px; border-width: 0px 0px 1px; border-top-left-radius: 6px; border-top-right-radius: 6px; }

.Box-overlay--narrow { width: 320px; }

.Box-overlay--wide { width: 640px; }

.Box-body.scrollable-overlay { max-height: 400px; overflow-y: scroll; }

.Box-body .help { padding-top: 8px; margin: 0px; color: var(--color-fg-muted); text-align: center; }

.breadcrumb-item { display: inline-block; margin-left: -0.35em; white-space: nowrap; list-style: none; }

.breadcrumb-item::after { display: inline-block; height: 0.8em; margin: 0px 0.5em; content: ""; border-right: 0.1em solid var(--color-fg-muted); transform: rotate(15deg); }

.breadcrumb-item:first-child { margin-left: 0px; }

.breadcrumb-item-selected::after, .breadcrumb-item[aria-current]:not([aria-current="false"])::after { content: none; }

.breadcrumb-item-selected a { color: var(--color-fg-default); }

.btn { position: relative; display: inline-block; padding: 5px 16px; font-size: 14px; font-weight: 500; line-height: 20px; white-space: nowrap; vertical-align: middle; cursor: pointer; user-select: none; border: 1px solid; border-radius: 6px; appearance: none; }

.btn:hover { text-decoration: none; }

.btn:disabled, .btn.disabled, .btn[aria-disabled="true"] { cursor: default; }

.btn i { font-style: normal; font-weight: 500; opacity: 0.75; }

.btn .octicon { margin-right: 4px; color: var(--color-fg-muted); vertical-align: text-bottom; }

.btn .octicon:only-child { margin-right: 0px; }

.btn .Counter { margin-left: 2px; color: inherit; text-shadow: none; vertical-align: top; background-color: var(--color-btn-counter-bg); }

.btn .dropdown-caret { margin-left: 4px; opacity: 0.8; }

.btn { color: var(--color-btn-text); background-color: var(--color-btn-bg); border-color: var(--color-btn-border); box-shadow: var(--color-btn-shadow),var(--color-btn-inset-shadow); transition: color 0.2s cubic-bezier(0.3, 0, 0.5, 1) 0s, background-color, border-color; }

.btn:hover, .btn.hover, [open] > .btn { background-color: var(--color-btn-hover-bg); border-color: var(--color-btn-hover-border); transition-duration: 0.1s; }

.btn:active { background-color: var(--color-btn-active-bg); border-color: var(--color-btn-active-border); transition: none 0s ease 0s; }

.btn.selected, .btn[aria-selected="true"] { background-color: var(--color-btn-selected-bg); box-shadow: var(--color-primer-shadow-inset); }

.btn:disabled, .btn.disabled, .btn[aria-disabled="true"] { color: var(--color-primer-fg-disabled); background-color: var(--color-btn-bg); border-color: var(--color-btn-border); }

.btn:disabled .octicon, .btn.disabled .octicon, .btn[aria-disabled="true"] .octicon { color: var(--color-primer-fg-disabled); }

.btn:focus, .btn.focus { border-color: var(--color-btn-focus-border); outline: none; box-shadow: var(--color-btn-focus-shadow); }

.btn-primary { color: var(--color-btn-primary-text); background-color: var(--color-btn-primary-bg); border-color: var(--color-btn-primary-border); box-shadow: var(--color-btn-primary-shadow),var(--color-btn-primary-inset-shadow); }

.btn-primary:hover, .btn-primary.hover, [open] > .btn-primary { background-color: var(--color-btn-primary-hover-bg); border-color: var(--color-btn-primary-hover-border); }

.btn-primary:active, .btn-primary.selected, .btn-primary[aria-selected="true"] { background-color: var(--color-btn-primary-selected-bg); box-shadow: var(--color-btn-primary-selected-shadow); }

.btn-primary:disabled, .btn-primary.disabled, .btn-primary[aria-disabled="true"] { color: var(--color-btn-primary-disabled-text); background-color: var(--color-btn-primary-disabled-bg); border-color: var(--color-btn-primary-disabled-border); }

.btn-primary:disabled .octicon, .btn-primary.disabled .octicon, .btn-primary[aria-disabled="true"] .octicon { color: var(--color-btn-primary-disabled-text); }

.btn-primary:focus, .btn-primary.focus { background-color: var(--color-btn-primary-focus-bg); border-color: var(--color-btn-primary-focus-border); box-shadow: var(--color-btn-primary-focus-shadow); }

.btn-primary .Counter { color: inherit; background-color: var(--color-btn-primary-counter-bg); }

.btn-primary .octicon { color: var(--color-btn-primary-icon); }

.btn-outline { color: var(--color-btn-outline-text); }

.btn-outline:hover, [open] > .btn-outline { color: var(--color-btn-outline-hover-text); background-color: var(--color-btn-outline-hover-bg); border-color: var(--color-btn-outline-hover-border); box-shadow: var(--color-btn-outline-hover-shadow),var(--color-btn-outline-hover-inset-shadow); }

.btn-outline:hover .Counter, [open] > .btn-outline .Counter { background-color: var(--color-btn-outline-hover-counter-bg); }

.btn-outline:hover .octicon, [open] > .btn-outline .octicon { color: inherit; }

.btn-outline:active, .btn-outline.selected, .btn-outline[aria-selected="true"] { color: var(--color-btn-outline-selected-text); background-color: var(--color-btn-outline-selected-bg); border-color: var(--color-btn-outline-selected-border); box-shadow: var(--color-btn-outline-selected-shadow); }

.btn-outline:disabled, .btn-outline.disabled, .btn-outline[aria-disabled="true"] { color: var(--color-btn-outline-disabled-text); background-color: var(--color-btn-outline-disabled-bg); border-color: var(--color-btn-border); box-shadow: none; }

.btn-outline:disabled .Counter, .btn-outline.disabled .Counter, .btn-outline[aria-disabled="true"] .Counter { background-color: var(--color-btn-outline-disabled-counter-bg); }

.btn-outline:focus { border-color: var(--color-btn-outline-focus-border); box-shadow: var(--color-btn-outline-focus-shadow); }

.btn-outline .Counter { color: inherit; background-color: var(--color-btn-outline-counter-bg); }

.btn-danger { color: var(--color-btn-danger-text); }

.btn-danger .octicon { color: var(--color-btn-danger-icon); }

.btn-danger:hover, [open] > .btn-danger { color: var(--color-btn-danger-hover-text); background-color: var(--color-btn-danger-hover-bg); border-color: var(--color-btn-danger-hover-border); box-shadow: var(--color-btn-danger-hover-shadow),var(--color-btn-danger-hover-inset-shadow); }

.btn-danger:hover .Counter, [open] > .btn-danger .Counter { background-color: var(--color-btn-danger-hover-counter-bg); }

.btn-danger:hover .octicon, [open] > .btn-danger .octicon { color: var(--color-btn-danger-hover-icon); }

.btn-danger:active, .btn-danger.selected, .btn-danger[aria-selected="true"] { color: var(--color-btn-danger-selected-text); background-color: var(--color-btn-danger-selected-bg); border-color: var(--color-btn-danger-selected-border); box-shadow: var(--color-btn-danger-selected-shadow); }

.btn-danger:disabled, .btn-danger.disabled, .btn-danger[aria-disabled="true"] { color: var(--color-btn-danger-disabled-text); background-color: var(--color-btn-danger-disabled-bg); border-color: var(--color-btn-border); box-shadow: none; }

.btn-danger:disabled .Counter, .btn-danger.disabled .Counter, .btn-danger[aria-disabled="true"] .Counter { background-color: var(--color-btn-danger-disabled-counter-bg); }

.btn-danger:disabled .octicon, .btn-danger.disabled .octicon, .btn-danger[aria-disabled="true"] .octicon { color: var(--color-btn-danger-disabled-text); }

.btn-danger:focus { border-color: var(--color-btn-danger-focus-border); box-shadow: var(--color-btn-danger-focus-shadow); }

.btn-danger .Counter { color: inherit; background-color: var(--color-btn-danger-counter-bg); }

.btn-sm { padding: 3px 12px; font-size: 12px; line-height: 20px; }

.btn-sm .octicon { vertical-align: text-top; }

.btn-large { padding: 0.75em 1.5em; font-size: inherit; line-height: 1.5; border-radius: 0.5em; }

.btn-block { display: block; width: 100%; text-align: center; }

.BtnGroup { display: inline-block; vertical-align: middle; }

.BtnGroup::before { display: table; content: ""; }

.BtnGroup::after { display: table; clear: both; content: ""; }

.BtnGroup + .BtnGroup, .BtnGroup + .btn { margin-left: 4px; }

.BtnGroup-item { position: relative; float: left; border-right-width: 0px; border-radius: 0px; }

.BtnGroup-item:first-child { border-top-left-radius: 6px; border-bottom-left-radius: 6px; }

.BtnGroup-item:last-child { border-right-width: 1px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.BtnGroup-item.selected, .BtnGroup-item[aria-selected="true"], .BtnGroup-item:focus, .BtnGroup-item:active, .BtnGroup-item:hover { border-right-width: 1px; }

.BtnGroup-item.selected + .BtnGroup-item, .BtnGroup-item.selected + .BtnGroup-parent .BtnGroup-item, .BtnGroup-item[aria-selected="true"] + .BtnGroup-item, .BtnGroup-item[aria-selected="true"] + .BtnGroup-parent .BtnGroup-item, .BtnGroup-item:focus + .BtnGroup-item, .BtnGroup-item:focus + .BtnGroup-parent .BtnGroup-item, .BtnGroup-item:active + .BtnGroup-item, .BtnGroup-item:active + .BtnGroup-parent .BtnGroup-item, .BtnGroup-item:hover + .BtnGroup-item, .BtnGroup-item:hover + .BtnGroup-parent .BtnGroup-item { border-left-width: 0px; }

.BtnGroup-parent { float: left; }

.BtnGroup-parent:first-child .BtnGroup-item { border-top-left-radius: 6px; border-bottom-left-radius: 6px; }

.BtnGroup-parent:last-child .BtnGroup-item { border-right-width: 1px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.BtnGroup-parent .BtnGroup-item { border-right-width: 0px; border-radius: 0px; }

.BtnGroup-parent.selected .BtnGroup-item, .BtnGroup-parent[aria-selected="true"] .BtnGroup-item, .BtnGroup-parent:focus .BtnGroup-item, .BtnGroup-parent:active .BtnGroup-item, .BtnGroup-parent:hover .BtnGroup-item { border-right-width: 1px; }

.BtnGroup-parent.selected + .BtnGroup-item, .BtnGroup-parent.selected + .BtnGroup-parent .BtnGroup-item, .BtnGroup-parent[aria-selected="true"] + .BtnGroup-item, .BtnGroup-parent[aria-selected="true"] + .BtnGroup-parent .BtnGroup-item, .BtnGroup-parent:focus + .BtnGroup-item, .BtnGroup-parent:focus + .BtnGroup-parent .BtnGroup-item, .BtnGroup-parent:active + .BtnGroup-item, .BtnGroup-parent:active + .BtnGroup-parent .BtnGroup-item, .BtnGroup-parent:hover + .BtnGroup-item, .BtnGroup-parent:hover + .BtnGroup-parent .BtnGroup-item { border-left-width: 0px; }

.BtnGroup-item:focus, .BtnGroup-item:active, .BtnGroup-parent:focus, .BtnGroup-parent:active { z-index: 1; }

.btn-link { display: inline-block; padding: 0px; font-size: inherit; color: var(--color-accent-fg); text-decoration: none; white-space: nowrap; cursor: pointer; user-select: none; background-color: transparent; border: 0px; appearance: none; }

.btn-link:hover { text-decoration: underline; }

.btn-link:disabled, .btn-link:disabled:hover, .btn-link[aria-disabled="true"], .btn-link[aria-disabled="true"]:hover { color: var(--color-primer-fg-disabled); cursor: default; }

.btn-invisible { color: var(--color-accent-fg); background-color: transparent; border: 0px; box-shadow: none; }

.btn-invisible:hover, .btn-invisible.zeroclipboard-is-hover { color: var(--color-accent-fg); background-color: var(--color-btn-hover-bg); outline: none; box-shadow: none; }

.btn-invisible:active, .btn-invisible:focus, .btn-invisible.selected, .btn-invisible[aria-selected="true"], .btn-invisible.zeroclipboard-is-active { color: var(--color-accent-fg); border-color: var(--color-btn-active-border); outline: none; box-shadow: var(--color-btn-focus-shadow); }

.btn-invisible:active .btn-invisible.zeroclipboard-is-active { background-color: var(--color-btn-selected-bg); }

.btn-invisible:disabled, .btn-invisible.disabled, .btn-invisible[aria-disabled="true"] { color: var(--color-primer-fg-disabled); background-color: transparent; }

.btn-octicon { display: inline-block; padding: 5px; margin-left: 5px; line-height: 1; color: var(--color-fg-muted); vertical-align: middle; background: transparent; border: 0px; box-shadow: none; }

.btn-octicon:hover { color: var(--color-accent-fg); }

.btn-octicon.disabled, .btn-octicon[aria-disabled="true"] { color: var(--color-primer-fg-disabled); cursor: default; }

.btn-octicon.disabled:hover, .btn-octicon[aria-disabled="true"]:hover { color: var(--color-primer-fg-disabled); }

.btn-octicon-danger:hover { color: var(--color-danger-fg); }

.close-button { padding: 0px; color: var(--color-fg-muted); background: transparent; border: 0px; outline: none; }

.close-button:hover { color: var(--color-fg-default); }

.close-button:active, .close-button:focus { color: var(--color-fg-muted); border-color: var(--color-btn-active-border); outline: none; box-shadow: var(--color-btn-focus-shadow); }

.hidden-text-expander { display: block; }

.hidden-text-expander.inline { position: relative; top: -1px; display: inline-block; margin-left: 5px; line-height: 0; }

.hidden-text-expander a, .ellipsis-expander { display: inline-block; height: 12px; padding: 0px 5px 5px; font-size: 12px; font-weight: 600; line-height: 6px; color: var(--color-fg-default); text-decoration: none; vertical-align: middle; background: var(--color-neutral-muted); border: 0px; border-radius: 1px; }

.hidden-text-expander a:hover, .ellipsis-expander:hover { text-decoration: none; background-color: var(--color-accent-muted); }

.hidden-text-expander a:active, .ellipsis-expander:active { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.btn-with-count { float: left; border-top-right-radius: 0px; border-bottom-right-radius: 0px; }

.btn-with-count:focus { z-index: 1; }

.social-count { position: relative; float: left; padding: 3px 12px; font-size: 12px; font-weight: 600; line-height: 20px; color: var(--color-fg-default); vertical-align: middle; background-color: var(--color-canvas-default); border-top-color: ; border-top-style: ; border-top-width: ; border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: ; border-bottom-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-left: 0px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; box-shadow: var(--color-shadow-small),var(--color-primer-shadow-highlight); }

.social-count:hover, .social-count:active { text-decoration: none; }

.social-count:hover { color: var(--color-accent-fg); cursor: pointer; }

.social-count:focus { z-index: 1; outline: 0px; box-shadow: var(--color-primer-shadow-focus); }

.TableObject { display: table; }

.TableObject-item { display: table-cell; width: 1%; white-space: nowrap; vertical-align: middle; }

.TableObject-item--primary { width: 99%; }

fieldset { padding: 0px; margin: 0px; border: 0px; }

label { font-weight: 600; }

.form-control, .form-select { padding: 5px 12px; font-size: 14px; line-height: 20px; color: var(--color-fg-default); vertical-align: middle; background-color: var(--color-canvas-default); background-repeat: no-repeat; background-position: right 8px center; border: 1px solid var(--color-border-default); border-radius: 6px; outline: none; box-shadow: var(--color-primer-shadow-inset); }

.form-control.focus, .form-control:focus, .form-select.focus, .form-select:focus { border-color: var(--color-accent-emphasis); outline: none; box-shadow: var(--color-primer-shadow-focus); }

.form-control[disabled], .form-select[disabled] { color: var(--color-primer-fg-disabled); background-color: var(--color-input-disabled-bg); border-color: var(--color-border-default); -webkit-text-fill-color: var(--color-primer-fg-disabled); opacity: 1; }

.form-control[disabled]::placeholder, .form-select[disabled]::placeholder { color: var(--color-primer-fg-disabled); }

@supports (-webkit-touch-callout: none) {
  .form-control, .form-select { font-size: 16px; }
  @media (min-width: 768px) {
  .form-control, .form-select { font-size: 14px; }
}
}

textarea.form-control { padding-top: 8px; padding-bottom: 8px; line-height: 1.5; }

.input-contrast { background-color: var(--color-canvas-inset); }

.input-contrast:focus { background-color: var(--color-canvas-default); }

::placeholder { color: var(--color-fg-subtle); opacity: 1; }

.input-sm { min-height: 28px; padding-top: 3px; padding-bottom: 3px; font-size: 12px; line-height: 20px; }

.input-lg { font-size: 16px; }

.input-block { display: block; width: 100%; }

.input-monospace { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; }

.input-hide-webkit-autofill::-webkit-contacts-auto-fill-button { position: absolute; right: 0px; pointer-events: none; visibility: hidden; display: none !important; }

.form-checkbox { padding-left: 20px; margin: 15px 0px; vertical-align: middle; }

.form-checkbox label em.highlight { position: relative; left: -4px; padding: 2px 4px; font-style: normal; background: var(--color-attention-subtle); border-radius: 6px; }

.form-checkbox input[type="checkbox"], .form-checkbox input[type="radio"] { float: left; margin: 5px 0px 0px -20px; vertical-align: middle; }

.form-checkbox .note { display: block; margin: 0px; font-size: 12px; font-weight: 400; color: var(--color-fg-muted); }

.form-checkbox-details { display: none; }

.form-checkbox-details-trigger:checked ~ * .form-checkbox-details, .form-checkbox-details-trigger:checked ~ .form-checkbox-details { display: block; }

.hfields { margin: 15px 0px; }

.hfields::before { display: table; content: ""; }

.hfields::after { display: table; clear: both; content: ""; }

.hfields .form-group { float: left; margin: 0px 30px 0px 0px; }

.hfields .form-group dt label, .hfields .form-group .form-group-header label { display: inline-block; margin: 5px 0px 0px; color: var(--color-fg-muted); }

.hfields .form-group dt img, .hfields .form-group .form-group-header img { position: relative; top: -2px; }

.hfields .btn { float: left; margin: 28px 25px 0px -20px; }

.hfields .form-select { margin-top: 5px; }

input::-webkit-outer-spin-button, input::-webkit-inner-spin-button { margin: 0px; appearance: none; }

.form-actions::before { display: table; content: ""; }

.form-actions::after { display: table; clear: both; content: ""; }

.form-actions .btn { float: right; }

.form-actions .btn + .btn { margin-right: 5px; }

.form-warning { padding: 8px 10px; margin: 10px 0px; font-size: 14px; color: var(--color-attention-fg); background: var(--color-attention-subtle); border: 1px solid var(--color-attention-emphasis); border-radius: 6px; }

.form-warning p { margin: 0px; line-height: 1.5; }

.form-warning a { font-weight: 600; }

.form-select { display: inline-block; max-width: 100%; height: 32px; padding-right: 24px; background-color: var(--color-canvas-default); background-image: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0iIzU4NjA2OSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNC40MjcgOS40MjdsMy4zOTYgMy4zOTZhLjI1MS4yNTEgMCAwMC4zNTQgMGwzLjM5Ni0zLjM5NkEuMjUuMjUgMCAwMDExLjM5NiA5SDQuNjA0YS4yNS4yNSAwIDAwLS4xNzcuNDI3ek00LjQyMyA2LjQ3TDcuODIgMy4wNzJhLjI1LjI1IDAgMDEuMzU0IDBMMTEuNTcgNi40N2EuMjUuMjUgMCAwMS0uMTc3LjQyN0g0LjZhLjI1LjI1IDAgMDEtLjE3Ny0uNDI3eiIgLz48L3N2Zz4="); background-repeat: no-repeat; background-position: right 4px center; background-size: 16px; appearance: none; }

.form-select[multiple] { height: auto; }

[data-color-mode="light"][data-light-theme*="dark"] .form-select, [data-color-mode="dark"][data-dark-theme*="dark"] .form-select { background-image: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0iIzZlNzY4MSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNC40MjcgOS40MjdsMy4zOTYgMy4zOTZhLjI1MS4yNTEgMCAwMC4zNTQgMGwzLjM5Ni0zLjM5NkEuMjUuMjUgMCAwMDExLjM5NiA5SDQuNjA0YS4yNS4yNSAwIDAwLS4xNzcuNDI3ek00LjQyMyA2LjQ3TDcuODIgMy4wNzJhLjI1LjI1IDAgMDEuMzU0IDBMMTEuNTcgNi40N2EuMjUuMjUgMCAwMS0uMTc3LjQyN0g0LjZhLjI1LjI1IDAgMDEtLjE3Ny0uNDI3eiIgLz48L3N2Zz4="); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] .form-select { background-image: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0iIzZlNzY4MSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNC40MjcgOS40MjdsMy4zOTYgMy4zOTZhLjI1MS4yNTEgMCAwMC4zNTQgMGwzLjM5Ni0zLjM5NkEuMjUuMjUgMCAwMDExLjM5NiA5SDQuNjA0YS4yNS4yNSAwIDAwLS4xNzcuNDI3ek00LjQyMyA2LjQ3TDcuODIgMy4wNzJhLjI1LjI1IDAgMDEuMzU0IDBMMTEuNTcgNi40N2EuMjUuMjUgMCAwMS0uMTc3LjQyN0g0LjZhLjI1LjI1IDAgMDEtLjE3Ny0uNDI3eiIgLz48L3N2Zz4="); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] .form-select { background-image: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0iIzZlNzY4MSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNC40MjcgOS40MjdsMy4zOTYgMy4zOTZhLjI1MS4yNTEgMCAwMC4zNTQgMGwzLjM5Ni0zLjM5NkEuMjUuMjUgMCAwMDExLjM5NiA5SDQuNjA0YS4yNS4yNSAwIDAwLS4xNzcuNDI3ek00LjQyMyA2LjQ3TDcuODIgMy4wNzJhLjI1LjI1IDAgMDEuMzU0IDBMMTEuNTcgNi40N2EuMjUuMjUgMCAwMS0uMTc3LjQyN0g0LjZhLjI1LjI1IDAgMDEtLjE3Ny0uNDI3eiIgLz48L3N2Zz4="); }
}

.select-sm { height: 28px; padding-top: 3px; padding-bottom: 3px; font-size: 12px; }

.select-sm[multiple] { height: auto; min-height: 0px; }

.form-group { margin: 15px 0px; }

.form-group .form-control { width: 440px; max-width: 100%; margin-right: 5px; background-color: var(--color-canvas-inset); }

.form-group .form-control:focus { background-color: var(--color-canvas-default); }

.form-group .form-control.shorter { width: 130px; }

.form-group .form-control.short { width: 250px; }

.form-group .form-control.long { width: 100%; }

.form-group textarea.form-control { width: 100%; height: 200px; min-height: 200px; }

.form-group textarea.form-control.short { height: 50px; min-height: 50px; }

.form-group dt, .form-group .form-group-header { margin: 0px 0px 6px; }

.form-group label { position: relative; }

.form-group.flattened dt, .form-group.flattened .form-group-header { float: left; margin: 0px; line-height: 32px; }

.form-group.flattened dd, .form-group.flattened .form-group-body { line-height: 32px; }

.form-group dd h4, .form-group .form-group-body h4 { margin: 4px 0px 0px; }

.form-group dd h4.is-error, .form-group .form-group-body h4.is-error { color: var(--color-danger-fg); }

.form-group dd h4.is-success, .form-group .form-group-body h4.is-success { color: var(--color-success-fg); }

.form-group dd h4 + .note, .form-group .form-group-body h4 + .note { margin-top: 0px; }

.form-group.required dt label::after, .form-group.required .form-group-header label::after { padding-left: 5px; color: var(--color-danger-fg); content: "*"; }

.form-group .success, .form-group .error, .form-group .indicator { display: none; font-size: 12px; font-weight: 600; }

.form-group.loading { opacity: 0.5; }

.form-group.loading .indicator { display: inline; }

.form-group.loading .spinner { display: inline-block; vertical-align: middle; }

.form-group.successful .success { display: inline; color: var(--color-success-fg); }

.form-group.successed .success, .form-group.successed .warning, .form-group.successed .error, .form-group.warn .success, .form-group.warn .warning, .form-group.warn .error, .form-group.errored .success, .form-group.errored .warning, .form-group.errored .error { position: absolute; z-index: 10; display: block; max-width: 450px; padding: 4px 8px; margin: 8px 0px 0px; font-size: 12px; font-weight: 400; border-style: solid; border-width: 1px; border-radius: 6px; }

.form-group.successed .success::after, .form-group.successed .success::before, .form-group.successed .warning::after, .form-group.successed .warning::before, .form-group.successed .error::after, .form-group.successed .error::before, .form-group.warn .success::after, .form-group.warn .success::before, .form-group.warn .warning::after, .form-group.warn .warning::before, .form-group.warn .error::after, .form-group.warn .error::before, .form-group.errored .success::after, .form-group.errored .success::before, .form-group.errored .warning::after, .form-group.errored .warning::before, .form-group.errored .error::after, .form-group.errored .error::before { position: absolute; bottom: 100%; left: 10px; z-index: 15; width: 0px; height: 0px; pointer-events: none; content: " "; border: solid transparent; }

.form-group.successed .success::after, .form-group.successed .warning::after, .form-group.successed .error::after, .form-group.warn .success::after, .form-group.warn .warning::after, .form-group.warn .error::after, .form-group.errored .success::after, .form-group.errored .warning::after, .form-group.errored .error::after { border-width: 5px; }

.form-group.successed .success::before, .form-group.successed .warning::before, .form-group.successed .error::before, .form-group.warn .success::before, .form-group.warn .warning::before, .form-group.warn .error::before, .form-group.errored .success::before, .form-group.errored .warning::before, .form-group.errored .error::before { margin-left: -1px; border-width: 6px; }

.form-group.successed .success { color: var(--color-fg-default); background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-success-subtle), var(--color-success-subtle)); border-color: var(--color-success-muted); }

.form-group.successed .success::after { border-bottom-color: var(--color-success-subtle); }

.form-group.successed .success::before { border-bottom-color: var(--color-success-muted); }

.form-group.warn .form-control { border-color: var(--color-attention-emphasis); }

.form-group.warn .warning { color: var(--color-fg-default); background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-attention-subtle), var(--color-attention-subtle)); border-color: var(--color-attention-muted); }

.form-group.warn .warning::after { border-bottom-color: var(--color-attention-subtle); }

.form-group.warn .warning::before { border-bottom-color: var(--color-attention-muted); }

.form-group.errored .form-control { border-color: var(--color-danger-emphasis); }

.form-group.errored label { color: var(--color-danger-fg); }

.form-group.errored .error { color: var(--color-fg-default); background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-danger-subtle), var(--color-danger-subtle)); border-color: var(--color-danger-muted); }

.form-group.errored .error::after { border-bottom-color: var(--color-danger-subtle); }

.form-group.errored .error::before { border-bottom-color: var(--color-danger-muted); }

.note { min-height: 17px; margin: 4px 0px 2px; font-size: 12px; color: var(--color-fg-muted); }

.note .spinner { margin-right: 3px; vertical-align: middle; }

dl.form-group > dd .form-control.is-autocheck-loading, dl.form-group > dd .form-control.is-autocheck-successful, dl.form-group > dd .form-control.is-autocheck-errored, .form-group > .form-group-body .form-control.is-autocheck-loading, .form-group > .form-group-body .form-control.is-autocheck-successful, .form-group > .form-group-body .form-control.is-autocheck-errored { padding-right: 30px; }

dl.form-group > dd .form-control.is-autocheck-loading, .form-group > .form-group-body .form-control.is-autocheck-loading { background-image: url("/images/spinners/octocat-spinner-16px.gif"); }

dl.form-group > dd .form-control.is-autocheck-successful, .form-group > .form-group-body .form-control.is-autocheck-successful { background-image: url("/images/modules/ajax/success.png"); }

dl.form-group > dd .form-control.is-autocheck-errored, .form-group > .form-group-body .form-control.is-autocheck-errored { background-image: url("/images/modules/ajax/error.png"); }

@media only screen and (-webkit-min-device-pixel-ratio: 2), not all, not all, not all, only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
  dl.form-group > dd .form-control.is-autocheck-loading, dl.form-group > dd .form-control.is-autocheck-successful, dl.form-group > dd .form-control.is-autocheck-errored, .form-group > .form-group-body .form-control.is-autocheck-loading, .form-group > .form-group-body .form-control.is-autocheck-successful, .form-group > .form-group-body .form-control.is-autocheck-errored { background-size: 16px 16px; }
  dl.form-group > dd .form-control.is-autocheck-loading, .form-group > .form-group-body .form-control.is-autocheck-loading { background-image: url("/images/spinners/octocat-spinner-32.gif"); }
  dl.form-group > dd .form-control.is-autocheck-successful, .form-group > .form-group-body .form-control.is-autocheck-successful { background-image: url("/images/modules/ajax/success@2x.png"); }
  dl.form-group > dd .form-control.is-autocheck-errored, .form-group > .form-group-body .form-control.is-autocheck-errored { background-image: url("/images/modules/ajax/error@2x.png"); }
}

.status-indicator { display: inline-block; width: 16px; height: 16px; margin-left: 5px; }

.status-indicator .octicon { display: none; }

.status-indicator-success::before { content: ""; }

.status-indicator-success .octicon-check { display: inline-block; color: var(--color-success-fg); fill: var(--color-success-fg); }

.status-indicator-success .octicon-x { display: none; }

.status-indicator-failed::before { content: ""; }

.status-indicator-failed .octicon-check { display: none; }

.status-indicator-failed .octicon-x { display: inline-block; color: var(--color-danger-fg); fill: var(--color-danger-fg); }

.status-indicator-loading { width: 16px; background-image: url("/images/spinners/octocat-spinner-32-EAF2F5.gif"); background-repeat: no-repeat; background-position: 0px 0px; background-size: 16px; }

.inline-form { display: inline-block; }

.inline-form .btn-plain { background-color: transparent; border: 0px; }

.drag-and-drop { padding: 7px 10px; margin: 0px; font-size: 13px; line-height: 16px; color: var(--color-fg-muted); background-color: var(--color-canvas-subtle); border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: ; border-bottom-width: ; border-left-color: ; border-left-style: ; border-left-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-top: 0px; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.drag-and-drop .default, .drag-and-drop .loading, .drag-and-drop .error { display: none; }

.drag-and-drop .error { color: var(--color-danger-fg); }

.drag-and-drop img { vertical-align: top; }

.is-default .drag-and-drop .default { display: inline-block; }

.is-uploading .drag-and-drop .loading { display: inline-block; }

.is-bad-file .drag-and-drop .bad-file { display: inline-block; }

.is-duplicate-filename .drag-and-drop .duplicate-filename { display: inline-block; }

.is-too-big .drag-and-drop .too-big { display: inline-block; }

.is-hidden-file .drag-and-drop .hidden-file { display: inline-block; }

.is-empty .drag-and-drop .empty { display: inline-block; }

.is-bad-permissions .drag-and-drop .bad-permissions { display: inline-block; }

.is-repository-required .drag-and-drop .repository-required { display: inline-block; }

.drag-and-drop-error-info { font-weight: 400; color: var(--color-fg-muted); }

.drag-and-drop-error-info a { color: var(--color-accent-fg); }

.is-failed .drag-and-drop .failed-request { display: inline-block; }

.manual-file-chooser { position: absolute; width: 240px; padding: 5px; margin-left: -80px; cursor: pointer; opacity: 0.0001; }

.manual-file-chooser:hover + .manual-file-chooser-text { text-decoration: underline; }

.btn .manual-file-chooser { top: 0px; padding: 0px; line-height: 34px; }

.upload-enabled textarea { display: block; border-bottom: 1px dashed var(--color-border-default); border-bottom-right-radius: 0px; border-bottom-left-radius: 0px; }

.upload-enabled.focused { border-radius: 6px; box-shadow: var(--color-primer-shadow-inset),var(--color-primer-shadow-focus); }

.upload-enabled.focused .form-control { box-shadow: none; }

.upload-enabled.focused .drag-and-drop { border-color: var(--color-accent-emphasis); }

.dragover textarea, .dragover .drag-and-drop { box-shadow: rgb(201, 255, 0) 0px 0px 3px; }

.write-content { position: relative; }

.previewable-comment-form { position: relative; }

.previewable-comment-form .tabnav { position: relative; padding: 8px 8px 0px; }

.previewable-comment-form .comment { border: 1px solid var(--color-border-default); }

.previewable-comment-form .comment-form-error { margin-bottom: 8px; }

.previewable-comment-form .write-content, .previewable-comment-form .preview-content { display: none; margin: 0px 8px 8px; }

.previewable-comment-form.write-selected .write-content, .previewable-comment-form.preview-selected .preview-content { display: block; }

.previewable-comment-form textarea { display: block; width: 100%; min-height: 100px; max-height: 500px; padding: 8px; resize: vertical; }

.form-action-spacious { margin-top: 10px; }

div.composer { margin-top: 0px; border: 0px; }

.composer .comment-form-textarea { height: 200px; min-height: 200px; }

.composer .tabnav { margin: 0px 0px 10px; }

h2.account { margin: 15px 0px 0px; font-size: 18px; font-weight: 400; color: var(--color-fg-muted); }

p.explain { position: relative; font-size: 12px; color: var(--color-fg-muted); }

p.explain strong { color: var(--color-fg-default); }

p.explain .octicon { margin-right: 5px; color: var(--color-fg-muted); }

p.explain .minibutton { top: -4px; float: right; }

.form-group label { position: static; }

.input-group { display: table; }

.input-group .form-control { position: relative; width: 100%; }

.input-group .form-control:focus { z-index: 2; }

.input-group .form-control + .btn { margin-left: 0px; }

.input-group.inline { display: inline-table; }

.input-group .form-control, .input-group-button { display: table-cell; }

.input-group-button { width: 1%; vertical-align: middle; }

.input-group .form-control:first-child, .input-group-button:first-child .btn { border-top-right-radius: 0px; border-bottom-right-radius: 0px; }

.input-group-button:first-child .btn { margin-right: -1px; }

.input-group .form-control:last-child, .input-group-button:last-child .btn { border-top-left-radius: 0px; border-bottom-left-radius: 0px; }

.input-group-button:last-child .btn { margin-left: -1px; }

.radio-group::before { display: table; content: ""; }

.radio-group::after { display: table; clear: both; content: ""; }

.radio-label { float: left; padding: 6px 16px 6px 36px; margin-left: -1px; font-size: 14px; line-height: 20px; color: var(--color-fg-default); cursor: pointer; border: 1px solid var(--color-border-default); }

:checked + .radio-label { position: relative; z-index: 1; border-color: var(--color-accent-emphasis); }

.radio-label:first-of-type { margin-left: 0px; border-top-left-radius: 6px; border-bottom-left-radius: 6px; }

.radio-label:last-of-type { border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.radio-label .octicon { margin-left: 4px; color: var(--color-fg-subtle); }

.radio-input { z-index: 3; float: left; margin: 10px -32px 0px 16px; }

.radio-input:disabled { position: relative; }

.radio-input:disabled + .radio-label { color: var(--color-primer-fg-disabled); cursor: default; background-color: var(--color-neutral-subtle); }

.radio-input:disabled + .radio-label .octicon { color: inherit; }

.container-sm { max-width: 544px; margin-right: auto; margin-left: auto; }

.container-md { max-width: 768px; margin-right: auto; margin-left: auto; }

.container-lg { max-width: 1012px; margin-right: auto; margin-left: auto; }

.container-xl { max-width: 1280px; margin-right: auto; margin-left: auto; }

.col-1 { width: 8.33333%; }

.col-2 { width: 16.6667%; }

.col-3 { width: 25%; }

.col-4 { width: 33.3333%; }

.col-5 { width: 41.6667%; }

.col-6 { width: 50%; }

.col-7 { width: 58.3333%; }

.col-8 { width: 66.6667%; }

.col-9 { width: 75%; }

.col-10 { width: 83.3333%; }

.col-11 { width: 91.6667%; }

.col-12 { width: 100%; }

@media (min-width: 544px) {
  .col-sm-1 { width: 8.33333%; }
  .col-sm-2 { width: 16.6667%; }
  .col-sm-3 { width: 25%; }
  .col-sm-4 { width: 33.3333%; }
  .col-sm-5 { width: 41.6667%; }
  .col-sm-6 { width: 50%; }
  .col-sm-7 { width: 58.3333%; }
  .col-sm-8 { width: 66.6667%; }
  .col-sm-9 { width: 75%; }
  .col-sm-10 { width: 83.3333%; }
  .col-sm-11 { width: 91.6667%; }
  .col-sm-12 { width: 100%; }
}

@media (min-width: 768px) {
  .col-md-1 { width: 8.33333%; }
  .col-md-2 { width: 16.6667%; }
  .col-md-3 { width: 25%; }
  .col-md-4 { width: 33.3333%; }
  .col-md-5 { width: 41.6667%; }
  .col-md-6 { width: 50%; }
  .col-md-7 { width: 58.3333%; }
  .col-md-8 { width: 66.6667%; }
  .col-md-9 { width: 75%; }
  .col-md-10 { width: 83.3333%; }
  .col-md-11 { width: 91.6667%; }
  .col-md-12 { width: 100%; }
}

@media (min-width: 1012px) {
  .col-lg-1 { width: 8.33333%; }
  .col-lg-2 { width: 16.6667%; }
  .col-lg-3 { width: 25%; }
  .col-lg-4 { width: 33.3333%; }
  .col-lg-5 { width: 41.6667%; }
  .col-lg-6 { width: 50%; }
  .col-lg-7 { width: 58.3333%; }
  .col-lg-8 { width: 66.6667%; }
  .col-lg-9 { width: 75%; }
  .col-lg-10 { width: 83.3333%; }
  .col-lg-11 { width: 91.6667%; }
  .col-lg-12 { width: 100%; }
}

@media (min-width: 1280px) {
  .col-xl-1 { width: 8.33333%; }
  .col-xl-2 { width: 16.6667%; }
  .col-xl-3 { width: 25%; }
  .col-xl-4 { width: 33.3333%; }
  .col-xl-5 { width: 41.6667%; }
  .col-xl-6 { width: 50%; }
  .col-xl-7 { width: 58.3333%; }
  .col-xl-8 { width: 66.6667%; }
  .col-xl-9 { width: 75%; }
  .col-xl-10 { width: 83.3333%; }
  .col-xl-11 { width: 91.6667%; }
  .col-xl-12 { width: 100%; }
}

.gutter { margin-right: -16px; margin-left: -16px; }

.gutter > [class*="col-"] { padding-right: 16px !important; padding-left: 16px !important; }

.gutter-condensed { margin-right: -8px; margin-left: -8px; }

.gutter-condensed > [class*="col-"] { padding-right: 8px !important; padding-left: 8px !important; }

.gutter-spacious { margin-right: -24px; margin-left: -24px; }

.gutter-spacious > [class*="col-"] { padding-right: 24px !important; padding-left: 24px !important; }

@media (min-width: 544px) {
  .gutter-sm { margin-right: -16px; margin-left: -16px; }
  .gutter-sm > [class*="col-"] { padding-right: 16px !important; padding-left: 16px !important; }
  .gutter-sm-condensed { margin-right: -8px; margin-left: -8px; }
  .gutter-sm-condensed > [class*="col-"] { padding-right: 8px !important; padding-left: 8px !important; }
  .gutter-sm-spacious { margin-right: -24px; margin-left: -24px; }
  .gutter-sm-spacious > [class*="col-"] { padding-right: 24px !important; padding-left: 24px !important; }
}

@media (min-width: 768px) {
  .gutter-md { margin-right: -16px; margin-left: -16px; }
  .gutter-md > [class*="col-"] { padding-right: 16px !important; padding-left: 16px !important; }
  .gutter-md-condensed { margin-right: -8px; margin-left: -8px; }
  .gutter-md-condensed > [class*="col-"] { padding-right: 8px !important; padding-left: 8px !important; }
  .gutter-md-spacious { margin-right: -24px; margin-left: -24px; }
  .gutter-md-spacious > [class*="col-"] { padding-right: 24px !important; padding-left: 24px !important; }
}

@media (min-width: 1012px) {
  .gutter-lg { margin-right: -16px; margin-left: -16px; }
  .gutter-lg > [class*="col-"] { padding-right: 16px !important; padding-left: 16px !important; }
  .gutter-lg-condensed { margin-right: -8px; margin-left: -8px; }
  .gutter-lg-condensed > [class*="col-"] { padding-right: 8px !important; padding-left: 8px !important; }
  .gutter-lg-spacious { margin-right: -24px; margin-left: -24px; }
  .gutter-lg-spacious > [class*="col-"] { padding-right: 24px !important; padding-left: 24px !important; }
}

@media (min-width: 1280px) {
  .gutter-xl { margin-right: -16px; margin-left: -16px; }
  .gutter-xl > [class*="col-"] { padding-right: 16px !important; padding-left: 16px !important; }
  .gutter-xl-condensed { margin-right: -8px; margin-left: -8px; }
  .gutter-xl-condensed > [class*="col-"] { padding-right: 8px !important; padding-left: 8px !important; }
  .gutter-xl-spacious { margin-right: -24px; margin-left: -24px; }
  .gutter-xl-spacious > [class*="col-"] { padding-right: 24px !important; padding-left: 24px !important; }
}

.offset-1 { margin-left: 8.33333% !important; }

.offset-2 { margin-left: 16.6667% !important; }

.offset-3 { margin-left: 25% !important; }

.offset-4 { margin-left: 33.3333% !important; }

.offset-5 { margin-left: 41.6667% !important; }

.offset-6 { margin-left: 50% !important; }

.offset-7 { margin-left: 58.3333% !important; }

.offset-8 { margin-left: 66.6667% !important; }

.offset-9 { margin-left: 75% !important; }

.offset-10 { margin-left: 83.3333% !important; }

.offset-11 { margin-left: 91.6667% !important; }

@media (min-width: 544px) {
  .offset-sm-1 { margin-left: 8.33333% !important; }
  .offset-sm-2 { margin-left: 16.6667% !important; }
  .offset-sm-3 { margin-left: 25% !important; }
  .offset-sm-4 { margin-left: 33.3333% !important; }
  .offset-sm-5 { margin-left: 41.6667% !important; }
  .offset-sm-6 { margin-left: 50% !important; }
  .offset-sm-7 { margin-left: 58.3333% !important; }
  .offset-sm-8 { margin-left: 66.6667% !important; }
  .offset-sm-9 { margin-left: 75% !important; }
  .offset-sm-10 { margin-left: 83.3333% !important; }
  .offset-sm-11 { margin-left: 91.6667% !important; }
}

@media (min-width: 768px) {
  .offset-md-1 { margin-left: 8.33333% !important; }
  .offset-md-2 { margin-left: 16.6667% !important; }
  .offset-md-3 { margin-left: 25% !important; }
  .offset-md-4 { margin-left: 33.3333% !important; }
  .offset-md-5 { margin-left: 41.6667% !important; }
  .offset-md-6 { margin-left: 50% !important; }
  .offset-md-7 { margin-left: 58.3333% !important; }
  .offset-md-8 { margin-left: 66.6667% !important; }
  .offset-md-9 { margin-left: 75% !important; }
  .offset-md-10 { margin-left: 83.3333% !important; }
  .offset-md-11 { margin-left: 91.6667% !important; }
}

@media (min-width: 1012px) {
  .offset-lg-1 { margin-left: 8.33333% !important; }
  .offset-lg-2 { margin-left: 16.6667% !important; }
  .offset-lg-3 { margin-left: 25% !important; }
  .offset-lg-4 { margin-left: 33.3333% !important; }
  .offset-lg-5 { margin-left: 41.6667% !important; }
  .offset-lg-6 { margin-left: 50% !important; }
  .offset-lg-7 { margin-left: 58.3333% !important; }
  .offset-lg-8 { margin-left: 66.6667% !important; }
  .offset-lg-9 { margin-left: 75% !important; }
  .offset-lg-10 { margin-left: 83.3333% !important; }
  .offset-lg-11 { margin-left: 91.6667% !important; }
}

@media (min-width: 1280px) {
  .offset-xl-1 { margin-left: 8.33333% !important; }
  .offset-xl-2 { margin-left: 16.6667% !important; }
  .offset-xl-3 { margin-left: 25% !important; }
  .offset-xl-4 { margin-left: 33.3333% !important; }
  .offset-xl-5 { margin-left: 41.6667% !important; }
  .offset-xl-6 { margin-left: 50% !important; }
  .offset-xl-7 { margin-left: 58.3333% !important; }
  .offset-xl-8 { margin-left: 66.6667% !important; }
  .offset-xl-9 { margin-left: 75% !important; }
  .offset-xl-10 { margin-left: 83.3333% !important; }
  .offset-xl-11 { margin-left: 91.6667% !important; }
}

.Layout { display: grid; --Layout-sidebar-width: 220px; --Layout-gutter: 16px; grid-auto-flow: column; grid-template-columns: auto 0 minmax(0, calc(100% - var(--Layout-sidebar-width) - var(--Layout-gutter))); grid-gap: var(--Layout-gutter); }

@media (max-width: 543.98px) {
  .Layout { grid-auto-flow: row; grid-template-columns: 1fr !important; }
  .Layout .Layout-sidebar, .Layout .Layout-divider, .Layout .Layout-main { width: 100% !important; grid-column: 1 / auto !important; }
  .Layout.Layout--sidebarPosition-flowRow-start .Layout-sidebar { grid-row: 1 / auto; }
  .Layout.Layout--sidebarPosition-flowRow-start .Layout-main { grid-row: 2 / span 2; }
  .Layout.Layout--sidebarPosition-flowRow-end .Layout-sidebar { grid-row: 2 / span 2; }
  .Layout.Layout--sidebarPosition-flowRow-end .Layout-main { grid-row: 1 / auto; }
  .Layout.Layout--sidebarPosition-flowRow-none .Layout-sidebar { display: none; }
  .Layout.Layout--divided { --Layout-gutter: 0; }
  .Layout.Layout--divided .Layout-divider { height: 1px; grid-row: 2 / auto; }
  .Layout.Layout--divided .Layout-divider.Layout-divider--flowRow-hidden { display: none; }
  .Layout.Layout--divided .Layout-divider.Layout-divider--flowRow-shallow { height: 8px; margin-right: 0px; background: var(--color-canvas-inset); border-color: var(--color-border-default); border-style: solid; border-width: 1px 0px; }
  .Layout.Layout--divided .Layout-main { grid-row: 3 / span 1; }
  .Layout.Layout--divided.Layout--sidebarPosition-flowRow-end .Layout-sidebar { grid-row: 3 / span 1; }
  .Layout.Layout--divided.Layout--sidebarPosition-flowRow-end .Layout-main { grid-row: 1 / auto; }
}

@media (max-width: 767.98px) {
  .Layout.Layout--flowRow-until-md { grid-auto-flow: row; grid-template-columns: 1fr !important; }
  .Layout.Layout--flowRow-until-md .Layout-sidebar, .Layout.Layout--flowRow-until-md .Layout-divider, .Layout.Layout--flowRow-until-md .Layout-main { width: 100% !important; grid-column: 1 / auto !important; }
  .Layout.Layout--flowRow-until-md.Layout--sidebarPosition-flowRow-start .Layout-sidebar { grid-row: 1 / auto; }
  .Layout.Layout--flowRow-until-md.Layout--sidebarPosition-flowRow-start .Layout-main { grid-row: 2 / span 2; }
  .Layout.Layout--flowRow-until-md.Layout--sidebarPosition-flowRow-end .Layout-sidebar { grid-row: 2 / span 2; }
  .Layout.Layout--flowRow-until-md.Layout--sidebarPosition-flowRow-end .Layout-main { grid-row: 1 / auto; }
  .Layout.Layout--flowRow-until-md.Layout--sidebarPosition-flowRow-none .Layout-sidebar { display: none; }
  .Layout.Layout--flowRow-until-md.Layout--divided { --Layout-gutter: 0; }
  .Layout.Layout--flowRow-until-md.Layout--divided .Layout-divider { height: 1px; grid-row: 2 / auto; }
  .Layout.Layout--flowRow-until-md.Layout--divided .Layout-divider.Layout-divider--flowRow-hidden { display: none; }
  .Layout.Layout--flowRow-until-md.Layout--divided .Layout-divider.Layout-divider--flowRow-shallow { height: 8px; margin-right: 0px; background: var(--color-canvas-inset); border-color: var(--color-border-default); border-style: solid; border-width: 1px 0px; }
  .Layout.Layout--flowRow-until-md.Layout--divided .Layout-main { grid-row: 3 / span 1; }
  .Layout.Layout--flowRow-until-md.Layout--divided.Layout--sidebarPosition-flowRow-end .Layout-sidebar { grid-row: 3 / span 1; }
  .Layout.Layout--flowRow-until-md.Layout--divided.Layout--sidebarPosition-flowRow-end .Layout-main { grid-row: 1 / auto; }
}

@media (max-width: 1011.98px) {
  .Layout.Layout--flowRow-until-lg { grid-auto-flow: row; grid-template-columns: 1fr !important; }
  .Layout.Layout--flowRow-until-lg .Layout-sidebar, .Layout.Layout--flowRow-until-lg .Layout-divider, .Layout.Layout--flowRow-until-lg .Layout-main { width: 100% !important; grid-column: 1 / auto !important; }
  .Layout.Layout--flowRow-until-lg.Layout--sidebarPosition-flowRow-start .Layout-sidebar { grid-row: 1 / auto; }
  .Layout.Layout--flowRow-until-lg.Layout--sidebarPosition-flowRow-start .Layout-main { grid-row: 2 / span 2; }
  .Layout.Layout--flowRow-until-lg.Layout--sidebarPosition-flowRow-end .Layout-sidebar { grid-row: 2 / span 2; }
  .Layout.Layout--flowRow-until-lg.Layout--sidebarPosition-flowRow-end .Layout-main { grid-row: 1 / auto; }
  .Layout.Layout--flowRow-until-lg.Layout--sidebarPosition-flowRow-none .Layout-sidebar { display: none; }
  .Layout.Layout--flowRow-until-lg.Layout--divided { --Layout-gutter: 0; }
  .Layout.Layout--flowRow-until-lg.Layout--divided .Layout-divider { height: 1px; grid-row: 2 / auto; }
  .Layout.Layout--flowRow-until-lg.Layout--divided .Layout-divider.Layout-divider--flowRow-hidden { display: none; }
  .Layout.Layout--flowRow-until-lg.Layout--divided .Layout-divider.Layout-divider--flowRow-shallow { height: 8px; margin-right: 0px; background: var(--color-canvas-inset); border-color: var(--color-border-default); border-style: solid; border-width: 1px 0px; }
  .Layout.Layout--flowRow-until-lg.Layout--divided .Layout-main { grid-row: 3 / span 1; }
  .Layout.Layout--flowRow-until-lg.Layout--divided.Layout--sidebarPosition-flowRow-end .Layout-sidebar { grid-row: 3 / span 1; }
  .Layout.Layout--flowRow-until-lg.Layout--divided.Layout--sidebarPosition-flowRow-end .Layout-main { grid-row: 1 / auto; }
}

.Layout .Layout-sidebar { grid-column: 1 / auto; }

.Layout .Layout-divider { display: none; }

.Layout .Layout-main { grid-column: 2 / span 2; }

@media (min-width: 1012px) {
  .Layout { --Layout-gutter: 24px; }
}

.Layout.Layout--gutter-none { --Layout-gutter: 0; }

.Layout.Layout--gutter-condensed { --Layout-gutter: 16px; }

@media (min-width: 1012px) {
  .Layout.Layout--gutter-spacious { --Layout-gutter: 32px; }
}

@media (min-width: 1280px) {
  .Layout.Layout--gutter-spacious { --Layout-gutter: 40px; }
}

@media (min-width: 544px) {
  .Layout { --Layout-sidebar-width: 220px; }
}

@media (min-width: 768px) {
  .Layout { --Layout-sidebar-width: 256px; }
}

@media (min-width: 1012px) {
  .Layout { --Layout-sidebar-width: 296px; }
}

@media (min-width: 768px) {
  .Layout.Layout--sidebar-narrow { --Layout-sidebar-width: 240px; }
}

@media (min-width: 1012px) {
  .Layout.Layout--sidebar-narrow { --Layout-sidebar-width: 256px; }
}

@media (min-width: 768px) {
  .Layout.Layout--sidebar-wide { --Layout-sidebar-width: 296px; }
}

@media (min-width: 1012px) {
  .Layout.Layout--sidebar-wide { --Layout-sidebar-width: 320px; }
}

@media (min-width: 1280px) {
  .Layout.Layout--sidebar-wide { --Layout-sidebar-width: 344px; }
}

.Layout.Layout--sidebarPosition-start .Layout-sidebar { grid-column: 1 / auto; }

.Layout.Layout--sidebarPosition-start .Layout-main { grid-column: 2 / span 2; }

.Layout.Layout--sidebarPosition-end { grid-template-columns: minmax(0, calc(100% - var(--Layout-sidebar-width) - var(--Layout-gutter))) 0 auto; }

.Layout.Layout--sidebarPosition-end .Layout-main { grid-column: 1 / auto; }

.Layout.Layout--sidebarPosition-end .Layout-sidebar { grid-column: 2 / span 2; }

.Layout.Layout--divided .Layout-divider { display: block; grid-column: 2 / auto; width: 1px; margin-right: -1px; background: var(--color-border-default); }

.Layout.Layout--divided .Layout-main { grid-column: 3 / span 1; }

.Layout.Layout--divided.Layout--sidebarPosition-end .Layout-sidebar { grid-column: 3 / span 1; }

.Layout.Layout--divided.Layout--sidebarPosition-end .Layout-main { grid-column: 1 / auto; }

.Layout-divider { display: none; width: 1px; }

.Layout-sidebar { width: var(--Layout-sidebar-width); }

.Layout-main { min-width: 0px; }

.Layout-main .Layout-main-centered-md, .Layout-main .Layout-main-centered-lg, .Layout-main .Layout-main-centered-xl { margin-right: auto; margin-left: auto; }

.Layout-main .Layout-main-centered-md > .container-md, .Layout-main .Layout-main-centered-md > .container-lg, .Layout-main .Layout-main-centered-md > .container-xl, .Layout-main .Layout-main-centered-lg > .container-md, .Layout-main .Layout-main-centered-lg > .container-lg, .Layout-main .Layout-main-centered-lg > .container-xl, .Layout-main .Layout-main-centered-xl > .container-md, .Layout-main .Layout-main-centered-xl > .container-lg, .Layout-main .Layout-main-centered-xl > .container-xl { margin-left: 0px; }

.Layout-main .Layout-main-centered-md { max-width: calc(768px + var(--Layout-sidebar-width) + var(--Layout-gutter)); }

.Layout-main .Layout-main-centered-lg { max-width: calc(1012px + var(--Layout-sidebar-width) + var(--Layout-gutter)); }

.Layout-main .Layout-main-centered-xl { max-width: calc(1280px + var(--Layout-sidebar-width) + var(--Layout-gutter)); }

.Link { color: var(--color-accent-fg); }

.Link:hover { text-decoration: underline; cursor: pointer; }

.Link--primary { color: var(--color-fg-default)  !important; }

.Link--primary:hover { color: var(--color-accent-fg)  !important; }

.Link--secondary { color: var(--color-fg-muted)  !important; }

.Link--secondary:hover { color: var(--color-accent-fg)  !important; }

.Link--muted { color: var(--color-fg-muted)  !important; }

.Link--muted:hover { text-decoration: none; color: var(--color-accent-fg)  !important; }

.Link--onHover:hover { text-decoration: underline; cursor: pointer; color: var(--color-accent-fg)  !important; }

.Link--secondary:hover [class*="color-text"], .Link--primary:hover [class*="color-text"], .Link--muted:hover [class*="color-text"] { color: inherit !important; }

.menu { margin-bottom: 16px; list-style: none; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.menu-item { position: relative; display: block; padding: 8px 16px; color: var(--color-fg-default); border-bottom: 1px solid var(--color-border-muted); }

.menu-item:first-child { border-top: 0px; border-top-left-radius: 6px; border-top-right-radius: 6px; }

.menu-item:first-child::before { border-top-left-radius: 6px; }

.menu-item:last-child { border-bottom: 0px; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.menu-item:last-child::before { border-bottom-left-radius: 6px; }

.menu-item:focus { z-index: 1; outline: none; box-shadow: var(--color-primer-shadow-focus); }

.menu-item:hover { text-decoration: none; background-color: var(--color-neutral-subtle); }

.menu-item:active { background-color: var(--color-canvas-subtle); }

.menu-item.selected, .menu-item[aria-selected="true"], .menu-item[aria-current]:not([aria-current="false"]) { cursor: default; background-color: var(--color-menu-bg-active); }

.menu-item.selected::before, .menu-item[aria-selected="true"]::before, .menu-item[aria-current]:not([aria-current="false"])::before { position: absolute; top: 0px; bottom: 0px; left: 0px; width: 2px; content: ""; background-color: var(--color-primer-border-active); }

.menu-item .octicon { width: 16px; margin-right: 8px; color: var(--color-fg-muted); text-align: center; }

.menu-item .Counter { float: right; margin-left: 4px; }

.menu-item .menu-warning { float: right; color: var(--color-attention-fg); }

.menu-item .avatar { float: left; margin-right: 4px; }

.menu-item.alert .Counter { color: var(--color-danger-fg); }

.menu-heading { display: block; padding: 8px 16px; margin-top: 0px; margin-bottom: 0px; font-size: inherit; font-weight: 600; color: var(--color-fg-default); border-bottom: 1px solid var(--color-border-muted); }

.menu-heading:hover { text-decoration: none; }

.menu-heading:first-child { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.menu-heading:last-child { border-bottom: 0px; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.tabnav { margin-top: 0px; margin-bottom: 16px; border-bottom: 1px solid var(--color-border-default); }

.tabnav-tabs { display: flex; margin-bottom: -1px; overflow: auto; }

.tabnav-tab { display: inline-block; flex-shrink: 0; padding: 8px 16px; font-size: 14px; line-height: 23px; color: var(--color-fg-muted); text-decoration: none; background-color: transparent; border-width: 1px 1px 0px; border-top-style: solid; border-right-style: solid; border-left-style: solid; border-top-color: transparent; border-right-color: transparent; border-left-color: transparent; border-image: initial; border-bottom-style: initial; border-bottom-color: initial; transition: color 0.2s cubic-bezier(0.3, 0, 0.5, 1) 0s; }

.tabnav-tab.selected, .tabnav-tab[aria-selected="true"], .tabnav-tab[aria-current]:not([aria-current="false"]) { color: var(--color-fg-default); background-color: var(--color-canvas-default); border-color: var(--color-border-default); border-radius: 6px 6px 0px 0px; }

.tabnav-tab.selected .octicon, .tabnav-tab[aria-selected="true"] .octicon, .tabnav-tab[aria-current]:not([aria-current="false"]) .octicon { color: inherit; }

.tabnav-tab:hover, .tabnav-tab:focus { color: var(--color-fg-default); text-decoration: none; transition-duration: 0.1s; }

.tabnav-tab:active { color: var(--color-fg-muted); }

.tabnav-tab .octicon { margin-right: 4px; color: var(--color-fg-muted); }

.tabnav-tab .Counter { margin-left: 4px; color: inherit; }

.tabnav-extra { display: inline-block; padding-top: 10px; margin-left: 10px; font-size: 12px; color: var(--color-fg-muted); }

.tabnav-extra > .octicon { margin-right: 2px; }

a.tabnav-extra:hover { color: var(--color-accent-fg); text-decoration: none; }

.tabnav-btn { margin-left: 8px; }

.filter-list { list-style-type: none; }

.filter-list.small .filter-item { padding: 6px 12px; font-size: 12px; }

.filter-list.pjax-active .filter-item { color: var(--color-fg-muted); background-color: transparent; }

.filter-list.pjax-active .filter-item.pjax-active { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.filter-item { position: relative; display: block; padding: 8px 16px; margin-bottom: 4px; overflow: hidden; font-size: 14px; color: var(--color-fg-muted); text-decoration: none; text-overflow: ellipsis; white-space: nowrap; cursor: pointer; border-radius: 6px; }

.filter-item:hover { text-decoration: none; background-color: var(--color-canvas-subtle); }

.filter-item.selected, .filter-item[aria-selected="true"], .filter-item[aria-current]:not([aria-current="false"]) { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.filter-item .count { float: right; font-weight: 600; }

.filter-item .bar { position: absolute; top: 2px; right: 0px; bottom: 2px; z-index: -1; display: inline-block; background-color: var(--color-neutral-subtle); }

.SideNav { background-color: var(--color-canvas-subtle); }

.SideNav-item { position: relative; display: block; width: 100%; padding: 12px 16px; color: var(--color-fg-default); text-align: left; background-color: transparent; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top: 1px solid var(--color-border-muted); }

.SideNav-item:first-child { border-top: 0px; }

.SideNav-item:last-child { box-shadow: 0 1px 0 var(--color-border-default); }

.SideNav-item::before { position: absolute; top: 0px; bottom: 0px; left: 0px; z-index: 1; width: 2px; pointer-events: none; content: ""; }

.SideNav-item:focus { z-index: 1; outline: none; box-shadow: var(--color-primer-shadow-focus); }

.SideNav-item:hover { text-decoration: none; background-color: var(--color-neutral-subtle); outline: none; }

.SideNav-item:active { background-color: var(--color-canvas-subtle); }

.SideNav-item[aria-current]:not([aria-current="false"]), .SideNav-item[aria-selected="true"] { background-color: var(--color-sidenav-selected-bg); }

.SideNav-item[aria-current]:not([aria-current="false"])::before, .SideNav-item[aria-selected="true"]::before { background-color: var(--color-primer-border-active); }

.SideNav-icon { width: 16px; margin-right: 8px; color: var(--color-fg-muted); }

.SideNav-subItem { position: relative; display: block; width: 100%; padding: 4px 0px; color: var(--color-accent-fg); text-align: left; background-color: transparent; border: 0px; }

.SideNav-subItem:hover, .SideNav-subItem:focus { color: var(--color-fg-default); text-decoration: none; outline: none; }

.SideNav-subItem[aria-current]:not([aria-current="false"]), .SideNav-subItem[aria-selected="true"] { font-weight: 500; color: var(--color-fg-default); }

.subnav { margin-bottom: 20px; }

.subnav::before { display: table; content: ""; }

.subnav::after { display: table; clear: both; content: ""; }

.subnav-bordered { padding-bottom: 20px; border-bottom: 1px solid var(--color-border-muted); }

.subnav-flush { margin-bottom: 0px; }

.subnav-item { position: relative; float: left; padding: 5px 16px; font-weight: 500; line-height: 20px; color: var(--color-fg-default); border: 1px solid var(--color-border-default); }

.subnav-item + .subnav-item { margin-left: -1px; }

.subnav-item:hover, .subnav-item:focus { text-decoration: none; background-color: var(--color-canvas-subtle); }

.subnav-item.selected, .subnav-item[aria-selected="true"], .subnav-item[aria-current]:not([aria-current="false"]) { z-index: 2; color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); border-color: var(--color-accent-emphasis); }

.subnav-item:first-child { border-top-left-radius: 6px; border-bottom-left-radius: 6px; }

.subnav-item:last-child { border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.subnav-search { position: relative; margin-left: 12px; }

.subnav-search-input { width: 320px; padding-left: 32px; color: var(--color-fg-muted); }

.subnav-search-input-wide { width: 500px; }

.subnav-search-icon { position: absolute; top: 9px; left: 8px; display: block; color: var(--color-fg-muted); text-align: center; pointer-events: none; }

.subnav-search-context .btn { border-top-right-radius: 0px; border-bottom-right-radius: 0px; }

.subnav-search-context .btn:hover, .subnav-search-context .btn:focus, .subnav-search-context .btn:active, .subnav-search-context .btn.selected { z-index: 2; }

.subnav-search-context + .subnav-search { margin-left: -1px; }

.subnav-search-context + .subnav-search .subnav-search-input { border-top-left-radius: 0px; border-bottom-left-radius: 0px; }

.subnav-search-context .select-menu-modal-holder { z-index: 30; }

.subnav-search-context .select-menu-modal { width: 220px; }

.subnav-search-context .select-menu-item-icon { color: inherit; }

.subnav-spacer-right { padding-right: 12px; }

.UnderlineNav { display: flex; overflow: auto hidden; box-shadow: inset 0 -1px 0 var(--color-border-muted); justify-content: space-between; }

.UnderlineNav-body { display: flex; }

.UnderlineNav-item { padding: 8px 16px; font-size: 14px; line-height: 30px; color: var(--color-fg-default); text-align: center; white-space: nowrap; background-color: transparent; border-width: 0px 0px 2px; border-top-style: initial; border-right-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-left-color: initial; border-image: initial; border-bottom-style: solid; border-bottom-color: transparent; }

.UnderlineNav-item:hover, .UnderlineNav-item:focus { color: var(--color-fg-default); text-decoration: none; border-bottom-color: var(--color-neutral-muted); outline: transparent dotted 1px; outline-offset: -1px; transition: border-bottom-color 0.12s ease-out 0s; }

.UnderlineNav-item.selected, .UnderlineNav-item[role="tab"][aria-selected="true"], .UnderlineNav-item[aria-current]:not([aria-current="false"]) { font-weight: 600; color: var(--color-fg-default); border-bottom-color: var(--color-primer-border-active); outline: transparent dotted 1px; outline-offset: -1px; }

.UnderlineNav-item.selected .UnderlineNav-octicon, .UnderlineNav-item[role="tab"][aria-selected="true"] .UnderlineNav-octicon, .UnderlineNav-item[aria-current]:not([aria-current="false"]) .UnderlineNav-octicon { color: var(--color-fg-muted); }

.UnderlineNav--right { justify-content: flex-end; }

.UnderlineNav--right .UnderlineNav-actions { flex: 1 1 auto; }

.UnderlineNav-actions { align-self: center; }

.UnderlineNav--full { display: block; }

.UnderlineNav-octicon { margin-right: 4px; color: var(--color-fg-subtle); }

.UnderlineNav .Counter { margin-left: 4px; color: var(--color-fg-default); background-color: var(--color-neutral-muted); }

.UnderlineNav .Counter--primary { color: var(--color-fg-on-emphasis); background-color: var(--color-neutral-emphasis); }

.UnderlineNav-container { display: flex; justify-content: space-between; }

.pagination a, .pagination span, .pagination em { display: inline-block; min-width: 32px; padding: 5px 10px; font-style: normal; line-height: 20px; color: var(--color-fg-default); text-align: center; white-space: nowrap; vertical-align: middle; cursor: pointer; user-select: none; border: 1px solid transparent; border-radius: 6px; transition: border-color 0.2s cubic-bezier(0.3, 0, 0.5, 1) 0s; }

.pagination a:hover, .pagination a:focus, .pagination span:hover, .pagination span:focus, .pagination em:hover, .pagination em:focus { text-decoration: none; border-color: var(--color-border-default); outline: 0px; transition-duration: 0.1s; }

.pagination a:active, .pagination span:active, .pagination em:active { border-color: var(--color-border-muted); transition: none 0s ease 0s; }

.pagination .previous_page, .pagination .next_page { color: var(--color-accent-fg); }

.pagination .current, .pagination .current:hover, .pagination [aria-current]:not([aria-current="false"]) { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); border-color: transparent; }

.pagination .gap, .pagination .disabled, .pagination [aria-disabled="true"], .pagination .gap:hover, .pagination .disabled:hover, .pagination [aria-disabled="true"]:hover { color: var(--color-primer-fg-disabled); cursor: default; border-color: transparent; }

@supports ((-webkit-clip-path: polygon(50% 0, 100% 50%, 50% 100%)) or (clip-path: polygon(50% 0, 100% 50%, 50% 100%))) {
  .pagination .previous_page::before, .pagination .next_page::after { display: inline-block; width: 16px; height: 16px; vertical-align: text-bottom; content: ""; background-color: currentcolor; }
  .pagination .previous_page::before { margin-right: 4px; clip-path: polygon(9.8px 12.8px, 8.7px 12.8px, 4.5px 8.5px, 4.5px 7.5px, 8.7px 3.2px, 9.8px 4.3px, 6.1px 8px, 9.8px 11.7px, 9.8px 12.8px); }
  .pagination .next_page::after { margin-left: 4px; clip-path: polygon(6.2px 3.2px, 7.3px 3.2px, 11.5px 7.5px, 11.5px 8.5px, 7.3px 12.8px, 6.2px 11.7px, 9.9px 8px, 6.2px 4.3px, 6.2px 3.2px); }
}

.paginate-container { margin-top: 16px; margin-bottom: 16px; text-align: center; }

.paginate-container .pagination { display: inline-block; }

.tooltipped { position: relative; }

.tooltipped::after { position: absolute; z-index: 1000000; display: none; padding: 0.5em 0.75em; font: 11px / 1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"; -webkit-font-smoothing: subpixel-antialiased; color: var(--color-fg-on-emphasis); text-align: center; text-decoration: none; text-shadow: none; text-transform: none; letter-spacing: normal; overflow-wrap: break-word; white-space: pre; pointer-events: none; content: attr(aria-label); background: var(--color-neutral-emphasis-plus); border-radius: 6px; opacity: 0; }

.tooltipped::before { position: absolute; z-index: 1000001; display: none; width: 0px; height: 0px; color: var(--color-neutral-emphasis-plus); pointer-events: none; content: ""; border: 6px solid transparent; opacity: 0; }

@keyframes tooltip-appear { 
  0% { opacity: 0; }
  100% { opacity: 1; }
}

.tooltipped:hover::before, .tooltipped:hover::after, .tooltipped:active::before, .tooltipped:active::after, .tooltipped:focus::before, .tooltipped:focus::after { display: inline-block; text-decoration: none; animation-name: tooltip-appear; animation-duration: 0.1s; animation-fill-mode: forwards; animation-timing-function: ease-in; animation-delay: 0.4s; }

.tooltipped-no-delay:hover::before, .tooltipped-no-delay:hover::after, .tooltipped-no-delay:active::before, .tooltipped-no-delay:active::after, .tooltipped-no-delay:focus::before, .tooltipped-no-delay:focus::after { animation-delay: 0s; }

.tooltipped-multiline:hover::after, .tooltipped-multiline:active::after, .tooltipped-multiline:focus::after { display: table-cell; }

.tooltipped-s::after, .tooltipped-se::after, .tooltipped-sw::after { top: 100%; right: 50%; margin-top: 6px; }

.tooltipped-s::before, .tooltipped-se::before, .tooltipped-sw::before { top: auto; right: 50%; bottom: -7px; margin-right: -6px; border-bottom-color: var(--color-neutral-emphasis-plus); }

.tooltipped-se::after { right: auto; left: 50%; margin-left: -16px; }

.tooltipped-sw::after { margin-right: -16px; }

.tooltipped-n::after, .tooltipped-ne::after, .tooltipped-nw::after { right: 50%; bottom: 100%; margin-bottom: 6px; }

.tooltipped-n::before, .tooltipped-ne::before, .tooltipped-nw::before { top: -7px; right: 50%; bottom: auto; margin-right: -6px; border-top-color: var(--color-neutral-emphasis-plus); }

.tooltipped-ne::after { right: auto; left: 50%; margin-left: -16px; }

.tooltipped-nw::after { margin-right: -16px; }

.tooltipped-s::after, .tooltipped-n::after { transform: translateX(50%); }

.tooltipped-w::after { right: 100%; bottom: 50%; margin-right: 6px; transform: translateY(50%); }

.tooltipped-w::before { top: 50%; bottom: 50%; left: -7px; margin-top: -6px; border-left-color: var(--color-neutral-emphasis-plus); }

.tooltipped-e::after { bottom: 50%; left: 100%; margin-left: 6px; transform: translateY(50%); }

.tooltipped-e::before { top: 50%; right: -7px; bottom: 50%; margin-top: -6px; border-right-color: var(--color-neutral-emphasis-plus); }

.tooltipped-align-right-1::after, .tooltipped-align-right-2::after { right: 0px; margin-right: 0px; }

.tooltipped-align-right-1::before { right: 10px; }

.tooltipped-align-right-2::before { right: 15px; }

.tooltipped-align-left-1::after, .tooltipped-align-left-2::after { left: 0px; margin-left: 0px; }

.tooltipped-align-left-1::before { left: 5px; }

.tooltipped-align-left-2::before { left: 10px; }

.tooltipped-multiline::after { width: max-content; max-width: 250px; overflow-wrap: break-word; white-space: pre-line; border-collapse: separate; }

.tooltipped-multiline.tooltipped-s::after, .tooltipped-multiline.tooltipped-n::after { right: auto; left: 50%; transform: translateX(-50%); }

.tooltipped-multiline.tooltipped-w::after, .tooltipped-multiline.tooltipped-e::after { right: 100%; }

@media not all {
  .tooltipped-multiline::after { width: 250px; }
}

.tooltipped-sticky::before, .tooltipped-sticky::after { display: inline-block; }

.tooltipped-sticky.tooltipped-multiline::after { display: table-cell; }

.css-truncate.css-truncate-overflow, .css-truncate .css-truncate-overflow, .css-truncate.css-truncate-target, .css-truncate .css-truncate-target { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.css-truncate.css-truncate-target, .css-truncate .css-truncate-target { display: inline-block; max-width: 125px; vertical-align: top; }

.css-truncate.expandable.zeroclipboard-is-hover .css-truncate-target, .css-truncate.expandable.zeroclipboard-is-hover.css-truncate-target, .css-truncate.expandable:hover .css-truncate-target, .css-truncate.expandable:hover.css-truncate-target { max-width: 10000px !important; }

.Truncate { display: inline-flex; min-width: 0px; max-width: 100%; }

.Truncate > .Truncate-text { min-width: 1ch; max-width: fit-content; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.Truncate > .Truncate-text + .Truncate-text { margin-left: 4px; }

.Truncate > .Truncate-text.Truncate-text--primary { flex-basis: 200%; }

.Truncate > .Truncate-text.Truncate-text--expandable:hover, .Truncate > .Truncate-text.Truncate-text--expandable:focus, .Truncate > .Truncate-text.Truncate-text--expandable:active { flex-shrink: 0; cursor: pointer; max-width: 100% !important; }

.anim-fade-in { animation-name: fade-in; animation-duration: 1s; animation-timing-function: ease-in-out; }

.anim-fade-in.fast { animation-duration: 300ms; }

@keyframes fade-in { 
  0% { opacity: 0; }
  100% { opacity: 1; }
}

.anim-fade-out { animation-name: fade-out; animation-duration: 1s; animation-fill-mode: forwards; animation-timing-function: ease-out; }

.anim-fade-out.fast { animation-duration: 0.3s; }

@keyframes fade-out { 
  0% { opacity: 1; }
  100% { opacity: 0; }
}

.anim-fade-up { opacity: 0; animation-name: fade-up; animation-duration: 0.3s; animation-fill-mode: forwards; animation-timing-function: ease-out; animation-delay: 1s; }

@keyframes fade-up { 
  0% { opacity: 0.8; transform: translateY(100%); }
  100% { opacity: 1; transform: translateY(0px); }
}

.anim-fade-down { animation-name: fade-down; animation-duration: 0.3s; animation-fill-mode: forwards; animation-timing-function: ease-in; }

@keyframes fade-down { 
  0% { opacity: 1; transform: translateY(0px); }
  100% { opacity: 0.5; transform: translateY(100%); }
}

.anim-grow-x { width: 0%; animation-name: grow-x; animation-duration: 0.3s; animation-fill-mode: forwards; animation-timing-function: ease; animation-delay: 0.5s; }

@keyframes grow-x { 
  100% { width: 100%; }
}

.anim-shrink-x { animation-name: shrink-x; animation-duration: 0.3s; animation-fill-mode: forwards; animation-timing-function: ease-in-out; animation-delay: 0.5s; }

@keyframes shrink-x { 
  100% { width: 0%; }
}

.anim-scale-in { animation-name: scale-in; animation-duration: 0.15s; animation-timing-function: cubic-bezier(0.2, 0, 0.13, 1.5); }

@keyframes scale-in { 
  0% { opacity: 0; transform: scale(0.5); }
  100% { opacity: 1; transform: scale(1); }
}

.anim-pulse { animation-name: pulse; animation-duration: 2s; animation-timing-function: linear; animation-iteration-count: infinite; }

@keyframes pulse { 
  0% { opacity: 0.3; }
  10% { opacity: 1; }
  100% { opacity: 0.3; }
}

.anim-pulse-in { animation-name: pulse-in; animation-duration: 0.5s; }

@keyframes pulse-in { 
  0% { transform: scale3d(1, 1, 1); }
  50% { transform: scale3d(1.1, 1.1, 1.1); }
  100% { transform: scale3d(1, 1, 1); }
}

.hover-grow, .anim-hover-grow { transition: transform 0.3s ease 0s; backface-visibility: hidden; }

.hover-grow:hover, .anim-hover-grow:hover { transform: scale(1.025); }

.anim-rotate { animation: 1s linear 0s infinite normal none running rotate-keyframes; }

@keyframes rotate-keyframes { 
  100% { transform: rotate(360deg); }
}

.border-x { border-right: 1px solid var(--color-border-default)  !important; border-left: 1px solid var(--color-border-default)  !important; }

.border-y { border-top: 1px solid var(--color-border-default)  !important; border-bottom: 1px solid var(--color-border-default)  !important; }

.border { border: 1px solid var(--color-border-default)  !important; }

.border-0 { border: 0px !important; }

.border-top { border-top: 1px solid var(--color-border-default)  !important; }

.border-right { border-right: 1px solid var(--color-border-default)  !important; }

.border-bottom { border-bottom: 1px solid var(--color-border-default)  !important; }

.border-left { border-left: 1px solid var(--color-border-default)  !important; }

.border-top-0 { border-top: 0px !important; }

.border-right-0 { border-right: 0px !important; }

.border-bottom-0 { border-bottom: 0px !important; }

.border-left-0 { border-left: 0px !important; }

.rounded { border-radius: 6px !important; }

.rounded-0 { border-radius: 0px !important; }

.rounded-1 { border-radius: 4px !important; }

.rounded-2 { border-radius: 6px !important; }

.rounded-3 { border-radius: 8px !important; }

.rounded-top-0 { border-top-left-radius: 0px !important; border-top-right-radius: 0px !important; }

.rounded-top-1 { border-top-left-radius: 4px !important; border-top-right-radius: 4px !important; }

.rounded-top-2 { border-top-left-radius: 6px !important; border-top-right-radius: 6px !important; }

.rounded-top-3 { border-top-left-radius: 8px !important; border-top-right-radius: 8px !important; }

.rounded-right-0 { border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; }

.rounded-right-1 { border-top-right-radius: 4px !important; border-bottom-right-radius: 4px !important; }

.rounded-right-2 { border-top-right-radius: 6px !important; border-bottom-right-radius: 6px !important; }

.rounded-right-3 { border-top-right-radius: 8px !important; border-bottom-right-radius: 8px !important; }

.rounded-bottom-0 { border-bottom-right-radius: 0px !important; border-bottom-left-radius: 0px !important; }

.rounded-bottom-1 { border-bottom-right-radius: 4px !important; border-bottom-left-radius: 4px !important; }

.rounded-bottom-2 { border-bottom-right-radius: 6px !important; border-bottom-left-radius: 6px !important; }

.rounded-bottom-3 { border-bottom-right-radius: 8px !important; border-bottom-left-radius: 8px !important; }

.rounded-left-0 { border-bottom-left-radius: 0px !important; border-top-left-radius: 0px !important; }

.rounded-left-1 { border-bottom-left-radius: 4px !important; border-top-left-radius: 4px !important; }

.rounded-left-2 { border-bottom-left-radius: 6px !important; border-top-left-radius: 6px !important; }

.rounded-left-3 { border-bottom-left-radius: 8px !important; border-top-left-radius: 8px !important; }

@media (min-width: 544px) {
  .border-sm { border: 1px solid var(--color-border-default)  !important; }
  .border-sm-0 { border: 0px !important; }
  .border-sm-top { border-top: 1px solid var(--color-border-default)  !important; }
  .border-sm-right { border-right: 1px solid var(--color-border-default)  !important; }
  .border-sm-bottom { border-bottom: 1px solid var(--color-border-default)  !important; }
  .border-sm-left { border-left: 1px solid var(--color-border-default)  !important; }
  .border-sm-top-0 { border-top: 0px !important; }
  .border-sm-right-0 { border-right: 0px !important; }
  .border-sm-bottom-0 { border-bottom: 0px !important; }
  .border-sm-left-0 { border-left: 0px !important; }
  .rounded-sm { border-radius: 6px !important; }
  .rounded-sm-0 { border-radius: 0px !important; }
  .rounded-sm-1 { border-radius: 4px !important; }
  .rounded-sm-2 { border-radius: 6px !important; }
  .rounded-sm-3 { border-radius: 8px !important; }
  .rounded-sm-top-0 { border-top-left-radius: 0px !important; border-top-right-radius: 0px !important; }
  .rounded-sm-top-1 { border-top-left-radius: 4px !important; border-top-right-radius: 4px !important; }
  .rounded-sm-top-2 { border-top-left-radius: 6px !important; border-top-right-radius: 6px !important; }
  .rounded-sm-top-3 { border-top-left-radius: 8px !important; border-top-right-radius: 8px !important; }
  .rounded-sm-right-0 { border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; }
  .rounded-sm-right-1 { border-top-right-radius: 4px !important; border-bottom-right-radius: 4px !important; }
  .rounded-sm-right-2 { border-top-right-radius: 6px !important; border-bottom-right-radius: 6px !important; }
  .rounded-sm-right-3 { border-top-right-radius: 8px !important; border-bottom-right-radius: 8px !important; }
  .rounded-sm-bottom-0 { border-bottom-right-radius: 0px !important; border-bottom-left-radius: 0px !important; }
  .rounded-sm-bottom-1 { border-bottom-right-radius: 4px !important; border-bottom-left-radius: 4px !important; }
  .rounded-sm-bottom-2 { border-bottom-right-radius: 6px !important; border-bottom-left-radius: 6px !important; }
  .rounded-sm-bottom-3 { border-bottom-right-radius: 8px !important; border-bottom-left-radius: 8px !important; }
  .rounded-sm-left-0 { border-bottom-left-radius: 0px !important; border-top-left-radius: 0px !important; }
  .rounded-sm-left-1 { border-bottom-left-radius: 4px !important; border-top-left-radius: 4px !important; }
  .rounded-sm-left-2 { border-bottom-left-radius: 6px !important; border-top-left-radius: 6px !important; }
  .rounded-sm-left-3 { border-bottom-left-radius: 8px !important; border-top-left-radius: 8px !important; }
}

@media (min-width: 768px) {
  .border-md { border: 1px solid var(--color-border-default)  !important; }
  .border-md-0 { border: 0px !important; }
  .border-md-top { border-top: 1px solid var(--color-border-default)  !important; }
  .border-md-right { border-right: 1px solid var(--color-border-default)  !important; }
  .border-md-bottom { border-bottom: 1px solid var(--color-border-default)  !important; }
  .border-md-left { border-left: 1px solid var(--color-border-default)  !important; }
  .border-md-top-0 { border-top: 0px !important; }
  .border-md-right-0 { border-right: 0px !important; }
  .border-md-bottom-0 { border-bottom: 0px !important; }
  .border-md-left-0 { border-left: 0px !important; }
  .rounded-md { border-radius: 6px !important; }
  .rounded-md-0 { border-radius: 0px !important; }
  .rounded-md-1 { border-radius: 4px !important; }
  .rounded-md-2 { border-radius: 6px !important; }
  .rounded-md-3 { border-radius: 8px !important; }
  .rounded-md-top-0 { border-top-left-radius: 0px !important; border-top-right-radius: 0px !important; }
  .rounded-md-top-1 { border-top-left-radius: 4px !important; border-top-right-radius: 4px !important; }
  .rounded-md-top-2 { border-top-left-radius: 6px !important; border-top-right-radius: 6px !important; }
  .rounded-md-top-3 { border-top-left-radius: 8px !important; border-top-right-radius: 8px !important; }
  .rounded-md-right-0 { border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; }
  .rounded-md-right-1 { border-top-right-radius: 4px !important; border-bottom-right-radius: 4px !important; }
  .rounded-md-right-2 { border-top-right-radius: 6px !important; border-bottom-right-radius: 6px !important; }
  .rounded-md-right-3 { border-top-right-radius: 8px !important; border-bottom-right-radius: 8px !important; }
  .rounded-md-bottom-0 { border-bottom-right-radius: 0px !important; border-bottom-left-radius: 0px !important; }
  .rounded-md-bottom-1 { border-bottom-right-radius: 4px !important; border-bottom-left-radius: 4px !important; }
  .rounded-md-bottom-2 { border-bottom-right-radius: 6px !important; border-bottom-left-radius: 6px !important; }
  .rounded-md-bottom-3 { border-bottom-right-radius: 8px !important; border-bottom-left-radius: 8px !important; }
  .rounded-md-left-0 { border-bottom-left-radius: 0px !important; border-top-left-radius: 0px !important; }
  .rounded-md-left-1 { border-bottom-left-radius: 4px !important; border-top-left-radius: 4px !important; }
  .rounded-md-left-2 { border-bottom-left-radius: 6px !important; border-top-left-radius: 6px !important; }
  .rounded-md-left-3 { border-bottom-left-radius: 8px !important; border-top-left-radius: 8px !important; }
}

@media (min-width: 1012px) {
  .border-lg { border: 1px solid var(--color-border-default)  !important; }
  .border-lg-0 { border: 0px !important; }
  .border-lg-top { border-top: 1px solid var(--color-border-default)  !important; }
  .border-lg-right { border-right: 1px solid var(--color-border-default)  !important; }
  .border-lg-bottom { border-bottom: 1px solid var(--color-border-default)  !important; }
  .border-lg-left { border-left: 1px solid var(--color-border-default)  !important; }
  .border-lg-top-0 { border-top: 0px !important; }
  .border-lg-right-0 { border-right: 0px !important; }
  .border-lg-bottom-0 { border-bottom: 0px !important; }
  .border-lg-left-0 { border-left: 0px !important; }
  .rounded-lg { border-radius: 6px !important; }
  .rounded-lg-0 { border-radius: 0px !important; }
  .rounded-lg-1 { border-radius: 4px !important; }
  .rounded-lg-2 { border-radius: 6px !important; }
  .rounded-lg-3 { border-radius: 8px !important; }
  .rounded-lg-top-0 { border-top-left-radius: 0px !important; border-top-right-radius: 0px !important; }
  .rounded-lg-top-1 { border-top-left-radius: 4px !important; border-top-right-radius: 4px !important; }
  .rounded-lg-top-2 { border-top-left-radius: 6px !important; border-top-right-radius: 6px !important; }
  .rounded-lg-top-3 { border-top-left-radius: 8px !important; border-top-right-radius: 8px !important; }
  .rounded-lg-right-0 { border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; }
  .rounded-lg-right-1 { border-top-right-radius: 4px !important; border-bottom-right-radius: 4px !important; }
  .rounded-lg-right-2 { border-top-right-radius: 6px !important; border-bottom-right-radius: 6px !important; }
  .rounded-lg-right-3 { border-top-right-radius: 8px !important; border-bottom-right-radius: 8px !important; }
  .rounded-lg-bottom-0 { border-bottom-right-radius: 0px !important; border-bottom-left-radius: 0px !important; }
  .rounded-lg-bottom-1 { border-bottom-right-radius: 4px !important; border-bottom-left-radius: 4px !important; }
  .rounded-lg-bottom-2 { border-bottom-right-radius: 6px !important; border-bottom-left-radius: 6px !important; }
  .rounded-lg-bottom-3 { border-bottom-right-radius: 8px !important; border-bottom-left-radius: 8px !important; }
  .rounded-lg-left-0 { border-bottom-left-radius: 0px !important; border-top-left-radius: 0px !important; }
  .rounded-lg-left-1 { border-bottom-left-radius: 4px !important; border-top-left-radius: 4px !important; }
  .rounded-lg-left-2 { border-bottom-left-radius: 6px !important; border-top-left-radius: 6px !important; }
  .rounded-lg-left-3 { border-bottom-left-radius: 8px !important; border-top-left-radius: 8px !important; }
}

@media (min-width: 1280px) {
  .border-xl { border: 1px solid var(--color-border-default)  !important; }
  .border-xl-0 { border: 0px !important; }
  .border-xl-top { border-top: 1px solid var(--color-border-default)  !important; }
  .border-xl-right { border-right: 1px solid var(--color-border-default)  !important; }
  .border-xl-bottom { border-bottom: 1px solid var(--color-border-default)  !important; }
  .border-xl-left { border-left: 1px solid var(--color-border-default)  !important; }
  .border-xl-top-0 { border-top: 0px !important; }
  .border-xl-right-0 { border-right: 0px !important; }
  .border-xl-bottom-0 { border-bottom: 0px !important; }
  .border-xl-left-0 { border-left: 0px !important; }
  .rounded-xl { border-radius: 6px !important; }
  .rounded-xl-0 { border-radius: 0px !important; }
  .rounded-xl-1 { border-radius: 4px !important; }
  .rounded-xl-2 { border-radius: 6px !important; }
  .rounded-xl-3 { border-radius: 8px !important; }
  .rounded-xl-top-0 { border-top-left-radius: 0px !important; border-top-right-radius: 0px !important; }
  .rounded-xl-top-1 { border-top-left-radius: 4px !important; border-top-right-radius: 4px !important; }
  .rounded-xl-top-2 { border-top-left-radius: 6px !important; border-top-right-radius: 6px !important; }
  .rounded-xl-top-3 { border-top-left-radius: 8px !important; border-top-right-radius: 8px !important; }
  .rounded-xl-right-0 { border-top-right-radius: 0px !important; border-bottom-right-radius: 0px !important; }
  .rounded-xl-right-1 { border-top-right-radius: 4px !important; border-bottom-right-radius: 4px !important; }
  .rounded-xl-right-2 { border-top-right-radius: 6px !important; border-bottom-right-radius: 6px !important; }
  .rounded-xl-right-3 { border-top-right-radius: 8px !important; border-bottom-right-radius: 8px !important; }
  .rounded-xl-bottom-0 { border-bottom-right-radius: 0px !important; border-bottom-left-radius: 0px !important; }
  .rounded-xl-bottom-1 { border-bottom-right-radius: 4px !important; border-bottom-left-radius: 4px !important; }
  .rounded-xl-bottom-2 { border-bottom-right-radius: 6px !important; border-bottom-left-radius: 6px !important; }
  .rounded-xl-bottom-3 { border-bottom-right-radius: 8px !important; border-bottom-left-radius: 8px !important; }
  .rounded-xl-left-0 { border-bottom-left-radius: 0px !important; border-top-left-radius: 0px !important; }
  .rounded-xl-left-1 { border-bottom-left-radius: 4px !important; border-top-left-radius: 4px !important; }
  .rounded-xl-left-2 { border-bottom-left-radius: 6px !important; border-top-left-radius: 6px !important; }
  .rounded-xl-left-3 { border-bottom-left-radius: 8px !important; border-top-left-radius: 8px !important; }
}

.circle { border-radius: 50% !important; }

.border-dashed { border-style: dashed !important; }

.color-shadow-small { box-shadow: var(--color-shadow-small)  !important; }

.color-shadow-medium { box-shadow: var(--color-shadow-medium)  !important; }

.color-shadow-large { box-shadow: var(--color-shadow-large)  !important; }

.color-shadow-extra-large { box-shadow: var(--color-shadow-extra-large)  !important; }

.box-shadow-none { box-shadow: none !important; }

.color-fg-default { color: var(--color-fg-default)  !important; }

.color-fg-muted { color: var(--color-fg-muted)  !important; }

.color-fg-subtle { color: var(--color-fg-subtle)  !important; }

.color-fg-accent { color: var(--color-accent-fg)  !important; }

.color-fg-success { color: var(--color-success-fg)  !important; }

.color-fg-attention { color: var(--color-attention-fg)  !important; }

.color-fg-severe { color: var(--color-severe-fg)  !important; }

.color-fg-danger { color: var(--color-danger-fg)  !important; }

.color-fg-done { color: var(--color-done-fg)  !important; }

.color-fg-sponsors { color: var(--color-sponsors-fg)  !important; }

.color-fg-on-emphasis { color: var(--color-fg-on-emphasis)  !important; }

.color-bg-default { background-color: var(--color-canvas-default)  !important; }

.color-bg-overlay { background-color: var(--color-canvas-overlay)  !important; }

.color-bg-inset { background-color: var(--color-canvas-inset)  !important; }

.color-bg-subtle { background-color: var(--color-canvas-subtle)  !important; }

.color-bg-emphasis { background-color: var(--color-neutral-emphasis-plus)  !important; }

.color-bg-accent { background-color: var(--color-accent-subtle)  !important; }

.color-bg-accent-emphasis { background-color: var(--color-accent-emphasis)  !important; }

.color-bg-success { background-color: var(--color-success-subtle)  !important; }

.color-bg-success-emphasis { background-color: var(--color-success-emphasis)  !important; }

.color-bg-attention { background-color: var(--color-attention-subtle)  !important; }

.color-bg-attention-emphasis { background-color: var(--color-attention-emphasis)  !important; }

.color-bg-severe { background-color: var(--color-severe-subtle)  !important; }

.color-bg-severe-emphasis { background-color: var(--color-severe-emphasis)  !important; }

.color-bg-danger { background-color: var(--color-danger-subtle)  !important; }

.color-bg-danger-emphasis { background-color: var(--color-danger-emphasis)  !important; }

.color-bg-done { background-color: var(--color-done-subtle)  !important; }

.color-bg-done-emphasis { background-color: var(--color-done-emphasis)  !important; }

.color-bg-sponsors { background-color: var(--color-sponsors-subtle)  !important; }

.color-bg-sponsors-emphasis { background-color: var(--color-sponsors-emphasis)  !important; }

.color-border-default { border-color: var(--color-border-default)  !important; }

.color-border-muted { border-color: var(--color-border-muted)  !important; }

.color-border-subtle { border-color: var(--color-border-subtle)  !important; }

.color-border-accent { border-color: var(--color-accent-muted)  !important; }

.color-border-accent-emphasis { border-color: var(--color-accent-emphasis)  !important; }

.color-border-success { border-color: var(--color-success-muted)  !important; }

.color-border-success-emphasis { border-color: var(--color-success-emphasis)  !important; }

.color-border-attention { border-color: var(--color-attention-muted)  !important; }

.color-border-attention-emphasis { border-color: var(--color-attention-emphasis)  !important; }

.color-border-severe { border-color: var(--color-severe-muted)  !important; }

.color-border-severe-emphasis { border-color: var(--color-severe-emphasis)  !important; }

.color-border-danger { border-color: var(--color-danger-muted)  !important; }

.color-border-danger-emphasis { border-color: var(--color-danger-emphasis)  !important; }

.color-border-done { border-color: var(--color-done-muted)  !important; }

.color-border-done-emphasis { border-color: var(--color-done-emphasis)  !important; }

.color-border-sponsors { border-color: var(--color-sponsors-muted)  !important; }

.color-border-sponsors-emphasis { border-color: var(--color-sponsors-emphasis)  !important; }

.color-fg-inherit { color: inherit !important; }

.details-overlay[open] > summary::before { position: fixed; inset: 0px; z-index: 80; display: block; cursor: default; content: " "; background: transparent; }

.details-overlay-dark[open] > summary::before { z-index: 111; background: var(--color-primer-canvas-backdrop); }

.details-reset > summary { list-style: none; }

.details-reset > summary::before { display: none; }

.details-reset > summary::-webkit-details-marker { display: none; }

.flex-row { flex-direction: row !important; }

.flex-row-reverse { flex-direction: row-reverse !important; }

.flex-column { flex-direction: column !important; }

.flex-column-reverse { flex-direction: column-reverse !important; }

.flex-wrap { flex-wrap: wrap !important; }

.flex-nowrap { flex-wrap: nowrap !important; }

.flex-wrap-reverse { flex-wrap: wrap-reverse !important; }

.flex-justify-start { justify-content: flex-start !important; }

.flex-justify-end { justify-content: flex-end !important; }

.flex-justify-center { justify-content: center !important; }

.flex-justify-between { justify-content: space-between !important; }

.flex-justify-around { justify-content: space-around !important; }

.flex-items-start { align-items: flex-start !important; }

.flex-items-end { align-items: flex-end !important; }

.flex-items-center { align-items: center !important; }

.flex-items-baseline { align-items: baseline !important; }

.flex-items-stretch { align-items: stretch !important; }

.flex-content-start { align-content: flex-start !important; }

.flex-content-end { align-content: flex-end !important; }

.flex-content-center { align-content: center !important; }

.flex-content-between { align-content: space-between !important; }

.flex-content-around { align-content: space-around !important; }

.flex-content-stretch { align-content: stretch !important; }

.flex-1 { flex: 1 1 0% !important; }

.flex-auto { flex: 1 1 auto !important; }

.flex-grow-0 { flex-grow: 0 !important; }

.flex-shrink-0 { flex-shrink: 0 !important; }

.flex-self-auto { align-self: auto !important; }

.flex-self-start { align-self: flex-start !important; }

.flex-self-end { align-self: flex-end !important; }

.flex-self-center { align-self: center !important; }

.flex-self-baseline { align-self: baseline !important; }

.flex-self-stretch { align-self: stretch !important; }

.flex-order-1 { order: 1 !important; }

.flex-order-2 { order: 2 !important; }

.flex-order-none { order: inherit !important; }

@media (min-width: 544px) {
  .flex-sm-row { flex-direction: row !important; }
  .flex-sm-row-reverse { flex-direction: row-reverse !important; }
  .flex-sm-column { flex-direction: column !important; }
  .flex-sm-column-reverse { flex-direction: column-reverse !important; }
  .flex-sm-wrap { flex-wrap: wrap !important; }
  .flex-sm-nowrap { flex-wrap: nowrap !important; }
  .flex-sm-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .flex-sm-justify-start { justify-content: flex-start !important; }
  .flex-sm-justify-end { justify-content: flex-end !important; }
  .flex-sm-justify-center { justify-content: center !important; }
  .flex-sm-justify-between { justify-content: space-between !important; }
  .flex-sm-justify-around { justify-content: space-around !important; }
  .flex-sm-items-start { align-items: flex-start !important; }
  .flex-sm-items-end { align-items: flex-end !important; }
  .flex-sm-items-center { align-items: center !important; }
  .flex-sm-items-baseline { align-items: baseline !important; }
  .flex-sm-items-stretch { align-items: stretch !important; }
  .flex-sm-content-start { align-content: flex-start !important; }
  .flex-sm-content-end { align-content: flex-end !important; }
  .flex-sm-content-center { align-content: center !important; }
  .flex-sm-content-between { align-content: space-between !important; }
  .flex-sm-content-around { align-content: space-around !important; }
  .flex-sm-content-stretch { align-content: stretch !important; }
  .flex-sm-1 { flex: 1 1 0% !important; }
  .flex-sm-auto { flex: 1 1 auto !important; }
  .flex-sm-grow-0 { flex-grow: 0 !important; }
  .flex-sm-shrink-0 { flex-shrink: 0 !important; }
  .flex-sm-self-auto { align-self: auto !important; }
  .flex-sm-self-start { align-self: flex-start !important; }
  .flex-sm-self-end { align-self: flex-end !important; }
  .flex-sm-self-center { align-self: center !important; }
  .flex-sm-self-baseline { align-self: baseline !important; }
  .flex-sm-self-stretch { align-self: stretch !important; }
  .flex-sm-order-1 { order: 1 !important; }
  .flex-sm-order-2 { order: 2 !important; }
  .flex-sm-order-none { order: inherit !important; }
}

@media (min-width: 768px) {
  .flex-md-row { flex-direction: row !important; }
  .flex-md-row-reverse { flex-direction: row-reverse !important; }
  .flex-md-column { flex-direction: column !important; }
  .flex-md-column-reverse { flex-direction: column-reverse !important; }
  .flex-md-wrap { flex-wrap: wrap !important; }
  .flex-md-nowrap { flex-wrap: nowrap !important; }
  .flex-md-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .flex-md-justify-start { justify-content: flex-start !important; }
  .flex-md-justify-end { justify-content: flex-end !important; }
  .flex-md-justify-center { justify-content: center !important; }
  .flex-md-justify-between { justify-content: space-between !important; }
  .flex-md-justify-around { justify-content: space-around !important; }
  .flex-md-items-start { align-items: flex-start !important; }
  .flex-md-items-end { align-items: flex-end !important; }
  .flex-md-items-center { align-items: center !important; }
  .flex-md-items-baseline { align-items: baseline !important; }
  .flex-md-items-stretch { align-items: stretch !important; }
  .flex-md-content-start { align-content: flex-start !important; }
  .flex-md-content-end { align-content: flex-end !important; }
  .flex-md-content-center { align-content: center !important; }
  .flex-md-content-between { align-content: space-between !important; }
  .flex-md-content-around { align-content: space-around !important; }
  .flex-md-content-stretch { align-content: stretch !important; }
  .flex-md-1 { flex: 1 1 0% !important; }
  .flex-md-auto { flex: 1 1 auto !important; }
  .flex-md-grow-0 { flex-grow: 0 !important; }
  .flex-md-shrink-0 { flex-shrink: 0 !important; }
  .flex-md-self-auto { align-self: auto !important; }
  .flex-md-self-start { align-self: flex-start !important; }
  .flex-md-self-end { align-self: flex-end !important; }
  .flex-md-self-center { align-self: center !important; }
  .flex-md-self-baseline { align-self: baseline !important; }
  .flex-md-self-stretch { align-self: stretch !important; }
  .flex-md-order-1 { order: 1 !important; }
  .flex-md-order-2 { order: 2 !important; }
  .flex-md-order-none { order: inherit !important; }
}

@media (min-width: 1012px) {
  .flex-lg-row { flex-direction: row !important; }
  .flex-lg-row-reverse { flex-direction: row-reverse !important; }
  .flex-lg-column { flex-direction: column !important; }
  .flex-lg-column-reverse { flex-direction: column-reverse !important; }
  .flex-lg-wrap { flex-wrap: wrap !important; }
  .flex-lg-nowrap { flex-wrap: nowrap !important; }
  .flex-lg-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .flex-lg-justify-start { justify-content: flex-start !important; }
  .flex-lg-justify-end { justify-content: flex-end !important; }
  .flex-lg-justify-center { justify-content: center !important; }
  .flex-lg-justify-between { justify-content: space-between !important; }
  .flex-lg-justify-around { justify-content: space-around !important; }
  .flex-lg-items-start { align-items: flex-start !important; }
  .flex-lg-items-end { align-items: flex-end !important; }
  .flex-lg-items-center { align-items: center !important; }
  .flex-lg-items-baseline { align-items: baseline !important; }
  .flex-lg-items-stretch { align-items: stretch !important; }
  .flex-lg-content-start { align-content: flex-start !important; }
  .flex-lg-content-end { align-content: flex-end !important; }
  .flex-lg-content-center { align-content: center !important; }
  .flex-lg-content-between { align-content: space-between !important; }
  .flex-lg-content-around { align-content: space-around !important; }
  .flex-lg-content-stretch { align-content: stretch !important; }
  .flex-lg-1 { flex: 1 1 0% !important; }
  .flex-lg-auto { flex: 1 1 auto !important; }
  .flex-lg-grow-0 { flex-grow: 0 !important; }
  .flex-lg-shrink-0 { flex-shrink: 0 !important; }
  .flex-lg-self-auto { align-self: auto !important; }
  .flex-lg-self-start { align-self: flex-start !important; }
  .flex-lg-self-end { align-self: flex-end !important; }
  .flex-lg-self-center { align-self: center !important; }
  .flex-lg-self-baseline { align-self: baseline !important; }
  .flex-lg-self-stretch { align-self: stretch !important; }
  .flex-lg-order-1 { order: 1 !important; }
  .flex-lg-order-2 { order: 2 !important; }
  .flex-lg-order-none { order: inherit !important; }
}

@media (min-width: 1280px) {
  .flex-xl-row { flex-direction: row !important; }
  .flex-xl-row-reverse { flex-direction: row-reverse !important; }
  .flex-xl-column { flex-direction: column !important; }
  .flex-xl-column-reverse { flex-direction: column-reverse !important; }
  .flex-xl-wrap { flex-wrap: wrap !important; }
  .flex-xl-nowrap { flex-wrap: nowrap !important; }
  .flex-xl-wrap-reverse { flex-wrap: wrap-reverse !important; }
  .flex-xl-justify-start { justify-content: flex-start !important; }
  .flex-xl-justify-end { justify-content: flex-end !important; }
  .flex-xl-justify-center { justify-content: center !important; }
  .flex-xl-justify-between { justify-content: space-between !important; }
  .flex-xl-justify-around { justify-content: space-around !important; }
  .flex-xl-items-start { align-items: flex-start !important; }
  .flex-xl-items-end { align-items: flex-end !important; }
  .flex-xl-items-center { align-items: center !important; }
  .flex-xl-items-baseline { align-items: baseline !important; }
  .flex-xl-items-stretch { align-items: stretch !important; }
  .flex-xl-content-start { align-content: flex-start !important; }
  .flex-xl-content-end { align-content: flex-end !important; }
  .flex-xl-content-center { align-content: center !important; }
  .flex-xl-content-between { align-content: space-between !important; }
  .flex-xl-content-around { align-content: space-around !important; }
  .flex-xl-content-stretch { align-content: stretch !important; }
  .flex-xl-1 { flex: 1 1 0% !important; }
  .flex-xl-auto { flex: 1 1 auto !important; }
  .flex-xl-grow-0 { flex-grow: 0 !important; }
  .flex-xl-shrink-0 { flex-shrink: 0 !important; }
  .flex-xl-self-auto { align-self: auto !important; }
  .flex-xl-self-start { align-self: flex-start !important; }
  .flex-xl-self-end { align-self: flex-end !important; }
  .flex-xl-self-center { align-self: center !important; }
  .flex-xl-self-baseline { align-self: baseline !important; }
  .flex-xl-self-stretch { align-self: stretch !important; }
  .flex-xl-order-1 { order: 1 !important; }
  .flex-xl-order-2 { order: 2 !important; }
  .flex-xl-order-none { order: inherit !important; }
}

.position-static { position: static !important; }

.position-relative { position: relative !important; }

.position-absolute { position: absolute !important; }

.position-fixed { position: fixed !important; }

.position-sticky { position: sticky !important; }

@media (min-width: 544px) {
  .position-sm-static { position: static !important; }
  .position-sm-relative { position: relative !important; }
  .position-sm-absolute { position: absolute !important; }
  .position-sm-fixed { position: fixed !important; }
  .position-sm-sticky { position: sticky !important; }
}

@media (min-width: 768px) {
  .position-md-static { position: static !important; }
  .position-md-relative { position: relative !important; }
  .position-md-absolute { position: absolute !important; }
  .position-md-fixed { position: fixed !important; }
  .position-md-sticky { position: sticky !important; }
}

@media (min-width: 1012px) {
  .position-lg-static { position: static !important; }
  .position-lg-relative { position: relative !important; }
  .position-lg-absolute { position: absolute !important; }
  .position-lg-fixed { position: fixed !important; }
  .position-lg-sticky { position: sticky !important; }
}

@media (min-width: 1280px) {
  .position-xl-static { position: static !important; }
  .position-xl-relative { position: relative !important; }
  .position-xl-absolute { position: absolute !important; }
  .position-xl-fixed { position: fixed !important; }
  .position-xl-sticky { position: sticky !important; }
}

.top-0 { top: 0px !important; }

.right-0 { right: 0px !important; }

.bottom-0 { bottom: 0px !important; }

.left-0 { left: 0px !important; }

.top-auto { top: auto !important; }

.right-auto { right: auto !important; }

.bottom-auto { bottom: auto !important; }

.left-auto { left: auto !important; }

@media (min-width: 544px) {
  .top-sm-0 { top: 0px !important; }
  .right-sm-0 { right: 0px !important; }
  .bottom-sm-0 { bottom: 0px !important; }
  .left-sm-0 { left: 0px !important; }
  .top-sm-auto { top: auto !important; }
  .right-sm-auto { right: auto !important; }
  .bottom-sm-auto { bottom: auto !important; }
  .left-sm-auto { left: auto !important; }
}

@media (min-width: 768px) {
  .top-md-0 { top: 0px !important; }
  .right-md-0 { right: 0px !important; }
  .bottom-md-0 { bottom: 0px !important; }
  .left-md-0 { left: 0px !important; }
  .top-md-auto { top: auto !important; }
  .right-md-auto { right: auto !important; }
  .bottom-md-auto { bottom: auto !important; }
  .left-md-auto { left: auto !important; }
}

@media (min-width: 1012px) {
  .top-lg-0 { top: 0px !important; }
  .right-lg-0 { right: 0px !important; }
  .bottom-lg-0 { bottom: 0px !important; }
  .left-lg-0 { left: 0px !important; }
  .top-lg-auto { top: auto !important; }
  .right-lg-auto { right: auto !important; }
  .bottom-lg-auto { bottom: auto !important; }
  .left-lg-auto { left: auto !important; }
}

@media (min-width: 1280px) {
  .top-xl-0 { top: 0px !important; }
  .right-xl-0 { right: 0px !important; }
  .bottom-xl-0 { bottom: 0px !important; }
  .left-xl-0 { left: 0px !important; }
  .top-xl-auto { top: auto !important; }
  .right-xl-auto { right: auto !important; }
  .bottom-xl-auto { bottom: auto !important; }
  .left-xl-auto { left: auto !important; }
}

.v-align-middle { vertical-align: middle !important; }

.v-align-top { vertical-align: top !important; }

.v-align-bottom { vertical-align: bottom !important; }

.v-align-text-top { vertical-align: text-top !important; }

.v-align-text-bottom { vertical-align: text-bottom !important; }

.v-align-baseline { vertical-align: baseline !important; }

.overflow-visible { overflow: visible !important; }

.overflow-x-visible { overflow-x: visible !important; }

.overflow-y-visible { overflow-y: visible !important; }

.overflow-hidden { overflow: hidden !important; }

.overflow-x-hidden { overflow-x: hidden !important; }

.overflow-y-hidden { overflow-y: hidden !important; }

.overflow-auto { overflow: auto !important; }

.overflow-x-auto { overflow-x: auto !important; }

.overflow-y-auto { overflow-y: auto !important; }

.overflow-scroll { overflow: scroll !important; }

.overflow-x-scroll { overflow-x: scroll !important; }

.overflow-y-scroll { overflow-y: scroll !important; }

@media (min-width: 544px) {
  .overflow-sm-visible { overflow: visible !important; }
  .overflow-sm-x-visible { overflow-x: visible !important; }
  .overflow-sm-y-visible { overflow-y: visible !important; }
  .overflow-sm-hidden { overflow: hidden !important; }
  .overflow-sm-x-hidden { overflow-x: hidden !important; }
  .overflow-sm-y-hidden { overflow-y: hidden !important; }
  .overflow-sm-auto { overflow: auto !important; }
  .overflow-sm-x-auto { overflow-x: auto !important; }
  .overflow-sm-y-auto { overflow-y: auto !important; }
  .overflow-sm-scroll { overflow: scroll !important; }
  .overflow-sm-x-scroll { overflow-x: scroll !important; }
  .overflow-sm-y-scroll { overflow-y: scroll !important; }
}

@media (min-width: 768px) {
  .overflow-md-visible { overflow: visible !important; }
  .overflow-md-x-visible { overflow-x: visible !important; }
  .overflow-md-y-visible { overflow-y: visible !important; }
  .overflow-md-hidden { overflow: hidden !important; }
  .overflow-md-x-hidden { overflow-x: hidden !important; }
  .overflow-md-y-hidden { overflow-y: hidden !important; }
  .overflow-md-auto { overflow: auto !important; }
  .overflow-md-x-auto { overflow-x: auto !important; }
  .overflow-md-y-auto { overflow-y: auto !important; }
  .overflow-md-scroll { overflow: scroll !important; }
  .overflow-md-x-scroll { overflow-x: scroll !important; }
  .overflow-md-y-scroll { overflow-y: scroll !important; }
}

@media (min-width: 1012px) {
  .overflow-lg-visible { overflow: visible !important; }
  .overflow-lg-x-visible { overflow-x: visible !important; }
  .overflow-lg-y-visible { overflow-y: visible !important; }
  .overflow-lg-hidden { overflow: hidden !important; }
  .overflow-lg-x-hidden { overflow-x: hidden !important; }
  .overflow-lg-y-hidden { overflow-y: hidden !important; }
  .overflow-lg-auto { overflow: auto !important; }
  .overflow-lg-x-auto { overflow-x: auto !important; }
  .overflow-lg-y-auto { overflow-y: auto !important; }
  .overflow-lg-scroll { overflow: scroll !important; }
  .overflow-lg-x-scroll { overflow-x: scroll !important; }
  .overflow-lg-y-scroll { overflow-y: scroll !important; }
}

@media (min-width: 1280px) {
  .overflow-xl-visible { overflow: visible !important; }
  .overflow-xl-x-visible { overflow-x: visible !important; }
  .overflow-xl-y-visible { overflow-y: visible !important; }
  .overflow-xl-hidden { overflow: hidden !important; }
  .overflow-xl-x-hidden { overflow-x: hidden !important; }
  .overflow-xl-y-hidden { overflow-y: hidden !important; }
  .overflow-xl-auto { overflow: auto !important; }
  .overflow-xl-x-auto { overflow-x: auto !important; }
  .overflow-xl-y-auto { overflow-y: auto !important; }
  .overflow-xl-scroll { overflow: scroll !important; }
  .overflow-xl-x-scroll { overflow-x: scroll !important; }
  .overflow-xl-y-scroll { overflow-y: scroll !important; }
}

.clearfix::before { display: table; content: ""; }

.clearfix::after { display: table; clear: both; content: ""; }

.float-left { float: left !important; }

.float-right { float: right !important; }

.float-none { float: none !important; }

@media (min-width: 544px) {
  .float-sm-left { float: left !important; }
  .float-sm-right { float: right !important; }
  .float-sm-none { float: none !important; }
}

@media (min-width: 768px) {
  .float-md-left { float: left !important; }
  .float-md-right { float: right !important; }
  .float-md-none { float: none !important; }
}

@media (min-width: 1012px) {
  .float-lg-left { float: left !important; }
  .float-lg-right { float: right !important; }
  .float-lg-none { float: none !important; }
}

@media (min-width: 1280px) {
  .float-xl-left { float: left !important; }
  .float-xl-right { float: right !important; }
  .float-xl-none { float: none !important; }
}

.width-fit { max-width: 100% !important; }

.width-full { width: 100% !important; }

.height-fit { max-height: 100% !important; }

.height-full { height: 100% !important; }

.min-width-0 { min-width: 0px !important; }

.width-auto { width: auto !important; }

.direction-rtl { direction: rtl !important; }

.direction-ltr { direction: ltr !important; }

@media (min-width: 544px) {
  .width-sm-auto { width: auto !important; }
  .direction-sm-rtl { direction: rtl !important; }
  .direction-sm-ltr { direction: ltr !important; }
}

@media (min-width: 768px) {
  .width-md-auto { width: auto !important; }
  .direction-md-rtl { direction: rtl !important; }
  .direction-md-ltr { direction: ltr !important; }
}

@media (min-width: 1012px) {
  .width-lg-auto { width: auto !important; }
  .direction-lg-rtl { direction: rtl !important; }
  .direction-lg-ltr { direction: ltr !important; }
}

@media (min-width: 1280px) {
  .width-xl-auto { width: auto !important; }
  .direction-xl-rtl { direction: rtl !important; }
  .direction-xl-ltr { direction: ltr !important; }
}

.m-0 { margin: 0px !important; }

.mt-0 { margin-top: 0px !important; }

.mb-0 { margin-bottom: 0px !important; }

.mr-0 { margin-right: 0px !important; }

.ml-0 { margin-left: 0px !important; }

.mx-0 { margin-right: 0px !important; margin-left: 0px !important; }

.my-0 { margin-top: 0px !important; margin-bottom: 0px !important; }

.m-1 { margin: 4px !important; }

.mt-1 { margin-top: 4px !important; }

.mb-1 { margin-bottom: 4px !important; }

.mr-1 { margin-right: 4px !important; }

.ml-1 { margin-left: 4px !important; }

.mt-n1 { margin-top: -4px !important; }

.mb-n1 { margin-bottom: -4px !important; }

.mr-n1 { margin-right: -4px !important; }

.ml-n1 { margin-left: -4px !important; }

.mx-1 { margin-right: 4px !important; margin-left: 4px !important; }

.my-1 { margin-top: 4px !important; margin-bottom: 4px !important; }

.m-2 { margin: 8px !important; }

.mt-2 { margin-top: 8px !important; }

.mb-2 { margin-bottom: 8px !important; }

.mr-2 { margin-right: 8px !important; }

.ml-2 { margin-left: 8px !important; }

.mt-n2 { margin-top: -8px !important; }

.mb-n2 { margin-bottom: -8px !important; }

.mr-n2 { margin-right: -8px !important; }

.ml-n2 { margin-left: -8px !important; }

.mx-2 { margin-right: 8px !important; margin-left: 8px !important; }

.my-2 { margin-top: 8px !important; margin-bottom: 8px !important; }

.m-3 { margin: 16px !important; }

.mt-3 { margin-top: 16px !important; }

.mb-3 { margin-bottom: 16px !important; }

.mr-3 { margin-right: 16px !important; }

.ml-3 { margin-left: 16px !important; }

.mt-n3 { margin-top: -16px !important; }

.mb-n3 { margin-bottom: -16px !important; }

.mr-n3 { margin-right: -16px !important; }

.ml-n3 { margin-left: -16px !important; }

.mx-3 { margin-right: 16px !important; margin-left: 16px !important; }

.my-3 { margin-top: 16px !important; margin-bottom: 16px !important; }

.m-4 { margin: 24px !important; }

.mt-4 { margin-top: 24px !important; }

.mb-4 { margin-bottom: 24px !important; }

.mr-4 { margin-right: 24px !important; }

.ml-4 { margin-left: 24px !important; }

.mt-n4 { margin-top: -24px !important; }

.mb-n4 { margin-bottom: -24px !important; }

.mr-n4 { margin-right: -24px !important; }

.ml-n4 { margin-left: -24px !important; }

.mx-4 { margin-right: 24px !important; margin-left: 24px !important; }

.my-4 { margin-top: 24px !important; margin-bottom: 24px !important; }

.m-5 { margin: 32px !important; }

.mt-5 { margin-top: 32px !important; }

.mb-5 { margin-bottom: 32px !important; }

.mr-5 { margin-right: 32px !important; }

.ml-5 { margin-left: 32px !important; }

.mt-n5 { margin-top: -32px !important; }

.mb-n5 { margin-bottom: -32px !important; }

.mr-n5 { margin-right: -32px !important; }

.ml-n5 { margin-left: -32px !important; }

.mx-5 { margin-right: 32px !important; margin-left: 32px !important; }

.my-5 { margin-top: 32px !important; margin-bottom: 32px !important; }

.m-6 { margin: 40px !important; }

.mt-6 { margin-top: 40px !important; }

.mb-6 { margin-bottom: 40px !important; }

.mr-6 { margin-right: 40px !important; }

.ml-6 { margin-left: 40px !important; }

.mt-n6 { margin-top: -40px !important; }

.mb-n6 { margin-bottom: -40px !important; }

.mr-n6 { margin-right: -40px !important; }

.ml-n6 { margin-left: -40px !important; }

.mx-6 { margin-right: 40px !important; margin-left: 40px !important; }

.my-6 { margin-top: 40px !important; margin-bottom: 40px !important; }

.mt-7 { margin-top: 48px !important; }

.mb-7 { margin-bottom: 48px !important; }

.mt-n7 { margin-top: -48px !important; }

.mb-n7 { margin-bottom: -48px !important; }

.my-7 { margin-top: 48px !important; margin-bottom: 48px !important; }

.mt-8 { margin-top: 64px !important; }

.mb-8 { margin-bottom: 64px !important; }

.mt-n8 { margin-top: -64px !important; }

.mb-n8 { margin-bottom: -64px !important; }

.my-8 { margin-top: 64px !important; margin-bottom: 64px !important; }

.mt-9 { margin-top: 80px !important; }

.mb-9 { margin-bottom: 80px !important; }

.mt-n9 { margin-top: -80px !important; }

.mb-n9 { margin-bottom: -80px !important; }

.my-9 { margin-top: 80px !important; margin-bottom: 80px !important; }

.mt-10 { margin-top: 96px !important; }

.mb-10 { margin-bottom: 96px !important; }

.mt-n10 { margin-top: -96px !important; }

.mb-n10 { margin-bottom: -96px !important; }

.my-10 { margin-top: 96px !important; margin-bottom: 96px !important; }

.mt-11 { margin-top: 112px !important; }

.mb-11 { margin-bottom: 112px !important; }

.mt-n11 { margin-top: -112px !important; }

.mb-n11 { margin-bottom: -112px !important; }

.my-11 { margin-top: 112px !important; margin-bottom: 112px !important; }

.mt-12 { margin-top: 128px !important; }

.mb-12 { margin-bottom: 128px !important; }

.mt-n12 { margin-top: -128px !important; }

.mb-n12 { margin-bottom: -128px !important; }

.my-12 { margin-top: 128px !important; margin-bottom: 128px !important; }

.mx-auto { margin-right: auto !important; margin-left: auto !important; }

@media (min-width: 544px) {
  .m-sm-0 { margin: 0px !important; }
  .mt-sm-0 { margin-top: 0px !important; }
  .mb-sm-0 { margin-bottom: 0px !important; }
  .mr-sm-0 { margin-right: 0px !important; }
  .ml-sm-0 { margin-left: 0px !important; }
  .mx-sm-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .my-sm-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .m-sm-1 { margin: 4px !important; }
  .mt-sm-1 { margin-top: 4px !important; }
  .mb-sm-1 { margin-bottom: 4px !important; }
  .mr-sm-1 { margin-right: 4px !important; }
  .ml-sm-1 { margin-left: 4px !important; }
  .mt-sm-n1 { margin-top: -4px !important; }
  .mb-sm-n1 { margin-bottom: -4px !important; }
  .mr-sm-n1 { margin-right: -4px !important; }
  .ml-sm-n1 { margin-left: -4px !important; }
  .mx-sm-1 { margin-right: 4px !important; margin-left: 4px !important; }
  .my-sm-1 { margin-top: 4px !important; margin-bottom: 4px !important; }
  .m-sm-2 { margin: 8px !important; }
  .mt-sm-2 { margin-top: 8px !important; }
  .mb-sm-2 { margin-bottom: 8px !important; }
  .mr-sm-2 { margin-right: 8px !important; }
  .ml-sm-2 { margin-left: 8px !important; }
  .mt-sm-n2 { margin-top: -8px !important; }
  .mb-sm-n2 { margin-bottom: -8px !important; }
  .mr-sm-n2 { margin-right: -8px !important; }
  .ml-sm-n2 { margin-left: -8px !important; }
  .mx-sm-2 { margin-right: 8px !important; margin-left: 8px !important; }
  .my-sm-2 { margin-top: 8px !important; margin-bottom: 8px !important; }
  .m-sm-3 { margin: 16px !important; }
  .mt-sm-3 { margin-top: 16px !important; }
  .mb-sm-3 { margin-bottom: 16px !important; }
  .mr-sm-3 { margin-right: 16px !important; }
  .ml-sm-3 { margin-left: 16px !important; }
  .mt-sm-n3 { margin-top: -16px !important; }
  .mb-sm-n3 { margin-bottom: -16px !important; }
  .mr-sm-n3 { margin-right: -16px !important; }
  .ml-sm-n3 { margin-left: -16px !important; }
  .mx-sm-3 { margin-right: 16px !important; margin-left: 16px !important; }
  .my-sm-3 { margin-top: 16px !important; margin-bottom: 16px !important; }
  .m-sm-4 { margin: 24px !important; }
  .mt-sm-4 { margin-top: 24px !important; }
  .mb-sm-4 { margin-bottom: 24px !important; }
  .mr-sm-4 { margin-right: 24px !important; }
  .ml-sm-4 { margin-left: 24px !important; }
  .mt-sm-n4 { margin-top: -24px !important; }
  .mb-sm-n4 { margin-bottom: -24px !important; }
  .mr-sm-n4 { margin-right: -24px !important; }
  .ml-sm-n4 { margin-left: -24px !important; }
  .mx-sm-4 { margin-right: 24px !important; margin-left: 24px !important; }
  .my-sm-4 { margin-top: 24px !important; margin-bottom: 24px !important; }
  .m-sm-5 { margin: 32px !important; }
  .mt-sm-5 { margin-top: 32px !important; }
  .mb-sm-5 { margin-bottom: 32px !important; }
  .mr-sm-5 { margin-right: 32px !important; }
  .ml-sm-5 { margin-left: 32px !important; }
  .mt-sm-n5 { margin-top: -32px !important; }
  .mb-sm-n5 { margin-bottom: -32px !important; }
  .mr-sm-n5 { margin-right: -32px !important; }
  .ml-sm-n5 { margin-left: -32px !important; }
  .mx-sm-5 { margin-right: 32px !important; margin-left: 32px !important; }
  .my-sm-5 { margin-top: 32px !important; margin-bottom: 32px !important; }
  .m-sm-6 { margin: 40px !important; }
  .mt-sm-6 { margin-top: 40px !important; }
  .mb-sm-6 { margin-bottom: 40px !important; }
  .mr-sm-6 { margin-right: 40px !important; }
  .ml-sm-6 { margin-left: 40px !important; }
  .mt-sm-n6 { margin-top: -40px !important; }
  .mb-sm-n6 { margin-bottom: -40px !important; }
  .mr-sm-n6 { margin-right: -40px !important; }
  .ml-sm-n6 { margin-left: -40px !important; }
  .mx-sm-6 { margin-right: 40px !important; margin-left: 40px !important; }
  .my-sm-6 { margin-top: 40px !important; margin-bottom: 40px !important; }
  .mt-sm-7 { margin-top: 48px !important; }
  .mb-sm-7 { margin-bottom: 48px !important; }
  .mt-sm-n7 { margin-top: -48px !important; }
  .mb-sm-n7 { margin-bottom: -48px !important; }
  .my-sm-7 { margin-top: 48px !important; margin-bottom: 48px !important; }
  .mt-sm-8 { margin-top: 64px !important; }
  .mb-sm-8 { margin-bottom: 64px !important; }
  .mt-sm-n8 { margin-top: -64px !important; }
  .mb-sm-n8 { margin-bottom: -64px !important; }
  .my-sm-8 { margin-top: 64px !important; margin-bottom: 64px !important; }
  .mt-sm-9 { margin-top: 80px !important; }
  .mb-sm-9 { margin-bottom: 80px !important; }
  .mt-sm-n9 { margin-top: -80px !important; }
  .mb-sm-n9 { margin-bottom: -80px !important; }
  .my-sm-9 { margin-top: 80px !important; margin-bottom: 80px !important; }
  .mt-sm-10 { margin-top: 96px !important; }
  .mb-sm-10 { margin-bottom: 96px !important; }
  .mt-sm-n10 { margin-top: -96px !important; }
  .mb-sm-n10 { margin-bottom: -96px !important; }
  .my-sm-10 { margin-top: 96px !important; margin-bottom: 96px !important; }
  .mt-sm-11 { margin-top: 112px !important; }
  .mb-sm-11 { margin-bottom: 112px !important; }
  .mt-sm-n11 { margin-top: -112px !important; }
  .mb-sm-n11 { margin-bottom: -112px !important; }
  .my-sm-11 { margin-top: 112px !important; margin-bottom: 112px !important; }
  .mt-sm-12 { margin-top: 128px !important; }
  .mb-sm-12 { margin-bottom: 128px !important; }
  .mt-sm-n12 { margin-top: -128px !important; }
  .mb-sm-n12 { margin-bottom: -128px !important; }
  .my-sm-12 { margin-top: 128px !important; margin-bottom: 128px !important; }
  .mx-sm-auto { margin-right: auto !important; margin-left: auto !important; }
}

@media (min-width: 768px) {
  .m-md-0 { margin: 0px !important; }
  .mt-md-0 { margin-top: 0px !important; }
  .mb-md-0 { margin-bottom: 0px !important; }
  .mr-md-0 { margin-right: 0px !important; }
  .ml-md-0 { margin-left: 0px !important; }
  .mx-md-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .my-md-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .m-md-1 { margin: 4px !important; }
  .mt-md-1 { margin-top: 4px !important; }
  .mb-md-1 { margin-bottom: 4px !important; }
  .mr-md-1 { margin-right: 4px !important; }
  .ml-md-1 { margin-left: 4px !important; }
  .mt-md-n1 { margin-top: -4px !important; }
  .mb-md-n1 { margin-bottom: -4px !important; }
  .mr-md-n1 { margin-right: -4px !important; }
  .ml-md-n1 { margin-left: -4px !important; }
  .mx-md-1 { margin-right: 4px !important; margin-left: 4px !important; }
  .my-md-1 { margin-top: 4px !important; margin-bottom: 4px !important; }
  .m-md-2 { margin: 8px !important; }
  .mt-md-2 { margin-top: 8px !important; }
  .mb-md-2 { margin-bottom: 8px !important; }
  .mr-md-2 { margin-right: 8px !important; }
  .ml-md-2 { margin-left: 8px !important; }
  .mt-md-n2 { margin-top: -8px !important; }
  .mb-md-n2 { margin-bottom: -8px !important; }
  .mr-md-n2 { margin-right: -8px !important; }
  .ml-md-n2 { margin-left: -8px !important; }
  .mx-md-2 { margin-right: 8px !important; margin-left: 8px !important; }
  .my-md-2 { margin-top: 8px !important; margin-bottom: 8px !important; }
  .m-md-3 { margin: 16px !important; }
  .mt-md-3 { margin-top: 16px !important; }
  .mb-md-3 { margin-bottom: 16px !important; }
  .mr-md-3 { margin-right: 16px !important; }
  .ml-md-3 { margin-left: 16px !important; }
  .mt-md-n3 { margin-top: -16px !important; }
  .mb-md-n3 { margin-bottom: -16px !important; }
  .mr-md-n3 { margin-right: -16px !important; }
  .ml-md-n3 { margin-left: -16px !important; }
  .mx-md-3 { margin-right: 16px !important; margin-left: 16px !important; }
  .my-md-3 { margin-top: 16px !important; margin-bottom: 16px !important; }
  .m-md-4 { margin: 24px !important; }
  .mt-md-4 { margin-top: 24px !important; }
  .mb-md-4 { margin-bottom: 24px !important; }
  .mr-md-4 { margin-right: 24px !important; }
  .ml-md-4 { margin-left: 24px !important; }
  .mt-md-n4 { margin-top: -24px !important; }
  .mb-md-n4 { margin-bottom: -24px !important; }
  .mr-md-n4 { margin-right: -24px !important; }
  .ml-md-n4 { margin-left: -24px !important; }
  .mx-md-4 { margin-right: 24px !important; margin-left: 24px !important; }
  .my-md-4 { margin-top: 24px !important; margin-bottom: 24px !important; }
  .m-md-5 { margin: 32px !important; }
  .mt-md-5 { margin-top: 32px !important; }
  .mb-md-5 { margin-bottom: 32px !important; }
  .mr-md-5 { margin-right: 32px !important; }
  .ml-md-5 { margin-left: 32px !important; }
  .mt-md-n5 { margin-top: -32px !important; }
  .mb-md-n5 { margin-bottom: -32px !important; }
  .mr-md-n5 { margin-right: -32px !important; }
  .ml-md-n5 { margin-left: -32px !important; }
  .mx-md-5 { margin-right: 32px !important; margin-left: 32px !important; }
  .my-md-5 { margin-top: 32px !important; margin-bottom: 32px !important; }
  .m-md-6 { margin: 40px !important; }
  .mt-md-6 { margin-top: 40px !important; }
  .mb-md-6 { margin-bottom: 40px !important; }
  .mr-md-6 { margin-right: 40px !important; }
  .ml-md-6 { margin-left: 40px !important; }
  .mt-md-n6 { margin-top: -40px !important; }
  .mb-md-n6 { margin-bottom: -40px !important; }
  .mr-md-n6 { margin-right: -40px !important; }
  .ml-md-n6 { margin-left: -40px !important; }
  .mx-md-6 { margin-right: 40px !important; margin-left: 40px !important; }
  .my-md-6 { margin-top: 40px !important; margin-bottom: 40px !important; }
  .mt-md-7 { margin-top: 48px !important; }
  .mb-md-7 { margin-bottom: 48px !important; }
  .mt-md-n7 { margin-top: -48px !important; }
  .mb-md-n7 { margin-bottom: -48px !important; }
  .my-md-7 { margin-top: 48px !important; margin-bottom: 48px !important; }
  .mt-md-8 { margin-top: 64px !important; }
  .mb-md-8 { margin-bottom: 64px !important; }
  .mt-md-n8 { margin-top: -64px !important; }
  .mb-md-n8 { margin-bottom: -64px !important; }
  .my-md-8 { margin-top: 64px !important; margin-bottom: 64px !important; }
  .mt-md-9 { margin-top: 80px !important; }
  .mb-md-9 { margin-bottom: 80px !important; }
  .mt-md-n9 { margin-top: -80px !important; }
  .mb-md-n9 { margin-bottom: -80px !important; }
  .my-md-9 { margin-top: 80px !important; margin-bottom: 80px !important; }
  .mt-md-10 { margin-top: 96px !important; }
  .mb-md-10 { margin-bottom: 96px !important; }
  .mt-md-n10 { margin-top: -96px !important; }
  .mb-md-n10 { margin-bottom: -96px !important; }
  .my-md-10 { margin-top: 96px !important; margin-bottom: 96px !important; }
  .mt-md-11 { margin-top: 112px !important; }
  .mb-md-11 { margin-bottom: 112px !important; }
  .mt-md-n11 { margin-top: -112px !important; }
  .mb-md-n11 { margin-bottom: -112px !important; }
  .my-md-11 { margin-top: 112px !important; margin-bottom: 112px !important; }
  .mt-md-12 { margin-top: 128px !important; }
  .mb-md-12 { margin-bottom: 128px !important; }
  .mt-md-n12 { margin-top: -128px !important; }
  .mb-md-n12 { margin-bottom: -128px !important; }
  .my-md-12 { margin-top: 128px !important; margin-bottom: 128px !important; }
  .mx-md-auto { margin-right: auto !important; margin-left: auto !important; }
}

@media (min-width: 1012px) {
  .m-lg-0 { margin: 0px !important; }
  .mt-lg-0 { margin-top: 0px !important; }
  .mb-lg-0 { margin-bottom: 0px !important; }
  .mr-lg-0 { margin-right: 0px !important; }
  .ml-lg-0 { margin-left: 0px !important; }
  .mx-lg-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .my-lg-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .m-lg-1 { margin: 4px !important; }
  .mt-lg-1 { margin-top: 4px !important; }
  .mb-lg-1 { margin-bottom: 4px !important; }
  .mr-lg-1 { margin-right: 4px !important; }
  .ml-lg-1 { margin-left: 4px !important; }
  .mt-lg-n1 { margin-top: -4px !important; }
  .mb-lg-n1 { margin-bottom: -4px !important; }
  .mr-lg-n1 { margin-right: -4px !important; }
  .ml-lg-n1 { margin-left: -4px !important; }
  .mx-lg-1 { margin-right: 4px !important; margin-left: 4px !important; }
  .my-lg-1 { margin-top: 4px !important; margin-bottom: 4px !important; }
  .m-lg-2 { margin: 8px !important; }
  .mt-lg-2 { margin-top: 8px !important; }
  .mb-lg-2 { margin-bottom: 8px !important; }
  .mr-lg-2 { margin-right: 8px !important; }
  .ml-lg-2 { margin-left: 8px !important; }
  .mt-lg-n2 { margin-top: -8px !important; }
  .mb-lg-n2 { margin-bottom: -8px !important; }
  .mr-lg-n2 { margin-right: -8px !important; }
  .ml-lg-n2 { margin-left: -8px !important; }
  .mx-lg-2 { margin-right: 8px !important; margin-left: 8px !important; }
  .my-lg-2 { margin-top: 8px !important; margin-bottom: 8px !important; }
  .m-lg-3 { margin: 16px !important; }
  .mt-lg-3 { margin-top: 16px !important; }
  .mb-lg-3 { margin-bottom: 16px !important; }
  .mr-lg-3 { margin-right: 16px !important; }
  .ml-lg-3 { margin-left: 16px !important; }
  .mt-lg-n3 { margin-top: -16px !important; }
  .mb-lg-n3 { margin-bottom: -16px !important; }
  .mr-lg-n3 { margin-right: -16px !important; }
  .ml-lg-n3 { margin-left: -16px !important; }
  .mx-lg-3 { margin-right: 16px !important; margin-left: 16px !important; }
  .my-lg-3 { margin-top: 16px !important; margin-bottom: 16px !important; }
  .m-lg-4 { margin: 24px !important; }
  .mt-lg-4 { margin-top: 24px !important; }
  .mb-lg-4 { margin-bottom: 24px !important; }
  .mr-lg-4 { margin-right: 24px !important; }
  .ml-lg-4 { margin-left: 24px !important; }
  .mt-lg-n4 { margin-top: -24px !important; }
  .mb-lg-n4 { margin-bottom: -24px !important; }
  .mr-lg-n4 { margin-right: -24px !important; }
  .ml-lg-n4 { margin-left: -24px !important; }
  .mx-lg-4 { margin-right: 24px !important; margin-left: 24px !important; }
  .my-lg-4 { margin-top: 24px !important; margin-bottom: 24px !important; }
  .m-lg-5 { margin: 32px !important; }
  .mt-lg-5 { margin-top: 32px !important; }
  .mb-lg-5 { margin-bottom: 32px !important; }
  .mr-lg-5 { margin-right: 32px !important; }
  .ml-lg-5 { margin-left: 32px !important; }
  .mt-lg-n5 { margin-top: -32px !important; }
  .mb-lg-n5 { margin-bottom: -32px !important; }
  .mr-lg-n5 { margin-right: -32px !important; }
  .ml-lg-n5 { margin-left: -32px !important; }
  .mx-lg-5 { margin-right: 32px !important; margin-left: 32px !important; }
  .my-lg-5 { margin-top: 32px !important; margin-bottom: 32px !important; }
  .m-lg-6 { margin: 40px !important; }
  .mt-lg-6 { margin-top: 40px !important; }
  .mb-lg-6 { margin-bottom: 40px !important; }
  .mr-lg-6 { margin-right: 40px !important; }
  .ml-lg-6 { margin-left: 40px !important; }
  .mt-lg-n6 { margin-top: -40px !important; }
  .mb-lg-n6 { margin-bottom: -40px !important; }
  .mr-lg-n6 { margin-right: -40px !important; }
  .ml-lg-n6 { margin-left: -40px !important; }
  .mx-lg-6 { margin-right: 40px !important; margin-left: 40px !important; }
  .my-lg-6 { margin-top: 40px !important; margin-bottom: 40px !important; }
  .mt-lg-7 { margin-top: 48px !important; }
  .mb-lg-7 { margin-bottom: 48px !important; }
  .mt-lg-n7 { margin-top: -48px !important; }
  .mb-lg-n7 { margin-bottom: -48px !important; }
  .my-lg-7 { margin-top: 48px !important; margin-bottom: 48px !important; }
  .mt-lg-8 { margin-top: 64px !important; }
  .mb-lg-8 { margin-bottom: 64px !important; }
  .mt-lg-n8 { margin-top: -64px !important; }
  .mb-lg-n8 { margin-bottom: -64px !important; }
  .my-lg-8 { margin-top: 64px !important; margin-bottom: 64px !important; }
  .mt-lg-9 { margin-top: 80px !important; }
  .mb-lg-9 { margin-bottom: 80px !important; }
  .mt-lg-n9 { margin-top: -80px !important; }
  .mb-lg-n9 { margin-bottom: -80px !important; }
  .my-lg-9 { margin-top: 80px !important; margin-bottom: 80px !important; }
  .mt-lg-10 { margin-top: 96px !important; }
  .mb-lg-10 { margin-bottom: 96px !important; }
  .mt-lg-n10 { margin-top: -96px !important; }
  .mb-lg-n10 { margin-bottom: -96px !important; }
  .my-lg-10 { margin-top: 96px !important; margin-bottom: 96px !important; }
  .mt-lg-11 { margin-top: 112px !important; }
  .mb-lg-11 { margin-bottom: 112px !important; }
  .mt-lg-n11 { margin-top: -112px !important; }
  .mb-lg-n11 { margin-bottom: -112px !important; }
  .my-lg-11 { margin-top: 112px !important; margin-bottom: 112px !important; }
  .mt-lg-12 { margin-top: 128px !important; }
  .mb-lg-12 { margin-bottom: 128px !important; }
  .mt-lg-n12 { margin-top: -128px !important; }
  .mb-lg-n12 { margin-bottom: -128px !important; }
  .my-lg-12 { margin-top: 128px !important; margin-bottom: 128px !important; }
  .mx-lg-auto { margin-right: auto !important; margin-left: auto !important; }
}

@media (min-width: 1280px) {
  .m-xl-0 { margin: 0px !important; }
  .mt-xl-0 { margin-top: 0px !important; }
  .mb-xl-0 { margin-bottom: 0px !important; }
  .mr-xl-0 { margin-right: 0px !important; }
  .ml-xl-0 { margin-left: 0px !important; }
  .mx-xl-0 { margin-right: 0px !important; margin-left: 0px !important; }
  .my-xl-0 { margin-top: 0px !important; margin-bottom: 0px !important; }
  .m-xl-1 { margin: 4px !important; }
  .mt-xl-1 { margin-top: 4px !important; }
  .mb-xl-1 { margin-bottom: 4px !important; }
  .mr-xl-1 { margin-right: 4px !important; }
  .ml-xl-1 { margin-left: 4px !important; }
  .mt-xl-n1 { margin-top: -4px !important; }
  .mb-xl-n1 { margin-bottom: -4px !important; }
  .mr-xl-n1 { margin-right: -4px !important; }
  .ml-xl-n1 { margin-left: -4px !important; }
  .mx-xl-1 { margin-right: 4px !important; margin-left: 4px !important; }
  .my-xl-1 { margin-top: 4px !important; margin-bottom: 4px !important; }
  .m-xl-2 { margin: 8px !important; }
  .mt-xl-2 { margin-top: 8px !important; }
  .mb-xl-2 { margin-bottom: 8px !important; }
  .mr-xl-2 { margin-right: 8px !important; }
  .ml-xl-2 { margin-left: 8px !important; }
  .mt-xl-n2 { margin-top: -8px !important; }
  .mb-xl-n2 { margin-bottom: -8px !important; }
  .mr-xl-n2 { margin-right: -8px !important; }
  .ml-xl-n2 { margin-left: -8px !important; }
  .mx-xl-2 { margin-right: 8px !important; margin-left: 8px !important; }
  .my-xl-2 { margin-top: 8px !important; margin-bottom: 8px !important; }
  .m-xl-3 { margin: 16px !important; }
  .mt-xl-3 { margin-top: 16px !important; }
  .mb-xl-3 { margin-bottom: 16px !important; }
  .mr-xl-3 { margin-right: 16px !important; }
  .ml-xl-3 { margin-left: 16px !important; }
  .mt-xl-n3 { margin-top: -16px !important; }
  .mb-xl-n3 { margin-bottom: -16px !important; }
  .mr-xl-n3 { margin-right: -16px !important; }
  .ml-xl-n3 { margin-left: -16px !important; }
  .mx-xl-3 { margin-right: 16px !important; margin-left: 16px !important; }
  .my-xl-3 { margin-top: 16px !important; margin-bottom: 16px !important; }
  .m-xl-4 { margin: 24px !important; }
  .mt-xl-4 { margin-top: 24px !important; }
  .mb-xl-4 { margin-bottom: 24px !important; }
  .mr-xl-4 { margin-right: 24px !important; }
  .ml-xl-4 { margin-left: 24px !important; }
  .mt-xl-n4 { margin-top: -24px !important; }
  .mb-xl-n4 { margin-bottom: -24px !important; }
  .mr-xl-n4 { margin-right: -24px !important; }
  .ml-xl-n4 { margin-left: -24px !important; }
  .mx-xl-4 { margin-right: 24px !important; margin-left: 24px !important; }
  .my-xl-4 { margin-top: 24px !important; margin-bottom: 24px !important; }
  .m-xl-5 { margin: 32px !important; }
  .mt-xl-5 { margin-top: 32px !important; }
  .mb-xl-5 { margin-bottom: 32px !important; }
  .mr-xl-5 { margin-right: 32px !important; }
  .ml-xl-5 { margin-left: 32px !important; }
  .mt-xl-n5 { margin-top: -32px !important; }
  .mb-xl-n5 { margin-bottom: -32px !important; }
  .mr-xl-n5 { margin-right: -32px !important; }
  .ml-xl-n5 { margin-left: -32px !important; }
  .mx-xl-5 { margin-right: 32px !important; margin-left: 32px !important; }
  .my-xl-5 { margin-top: 32px !important; margin-bottom: 32px !important; }
  .m-xl-6 { margin: 40px !important; }
  .mt-xl-6 { margin-top: 40px !important; }
  .mb-xl-6 { margin-bottom: 40px !important; }
  .mr-xl-6 { margin-right: 40px !important; }
  .ml-xl-6 { margin-left: 40px !important; }
  .mt-xl-n6 { margin-top: -40px !important; }
  .mb-xl-n6 { margin-bottom: -40px !important; }
  .mr-xl-n6 { margin-right: -40px !important; }
  .ml-xl-n6 { margin-left: -40px !important; }
  .mx-xl-6 { margin-right: 40px !important; margin-left: 40px !important; }
  .my-xl-6 { margin-top: 40px !important; margin-bottom: 40px !important; }
  .mt-xl-7 { margin-top: 48px !important; }
  .mb-xl-7 { margin-bottom: 48px !important; }
  .mt-xl-n7 { margin-top: -48px !important; }
  .mb-xl-n7 { margin-bottom: -48px !important; }
  .my-xl-7 { margin-top: 48px !important; margin-bottom: 48px !important; }
  .mt-xl-8 { margin-top: 64px !important; }
  .mb-xl-8 { margin-bottom: 64px !important; }
  .mt-xl-n8 { margin-top: -64px !important; }
  .mb-xl-n8 { margin-bottom: -64px !important; }
  .my-xl-8 { margin-top: 64px !important; margin-bottom: 64px !important; }
  .mt-xl-9 { margin-top: 80px !important; }
  .mb-xl-9 { margin-bottom: 80px !important; }
  .mt-xl-n9 { margin-top: -80px !important; }
  .mb-xl-n9 { margin-bottom: -80px !important; }
  .my-xl-9 { margin-top: 80px !important; margin-bottom: 80px !important; }
  .mt-xl-10 { margin-top: 96px !important; }
  .mb-xl-10 { margin-bottom: 96px !important; }
  .mt-xl-n10 { margin-top: -96px !important; }
  .mb-xl-n10 { margin-bottom: -96px !important; }
  .my-xl-10 { margin-top: 96px !important; margin-bottom: 96px !important; }
  .mt-xl-11 { margin-top: 112px !important; }
  .mb-xl-11 { margin-bottom: 112px !important; }
  .mt-xl-n11 { margin-top: -112px !important; }
  .mb-xl-n11 { margin-bottom: -112px !important; }
  .my-xl-11 { margin-top: 112px !important; margin-bottom: 112px !important; }
  .mt-xl-12 { margin-top: 128px !important; }
  .mb-xl-12 { margin-bottom: 128px !important; }
  .mt-xl-n12 { margin-top: -128px !important; }
  .mb-xl-n12 { margin-bottom: -128px !important; }
  .my-xl-12 { margin-top: 128px !important; margin-bottom: 128px !important; }
  .mx-xl-auto { margin-right: auto !important; margin-left: auto !important; }
}

.m-auto { margin: auto !important; }

.mt-auto { margin-top: auto !important; }

.mr-auto { margin-right: auto !important; }

.mb-auto { margin-bottom: auto !important; }

.ml-auto { margin-left: auto !important; }

.p-0 { padding: 0px !important; }

.pt-0 { padding-top: 0px !important; }

.pr-0 { padding-right: 0px !important; }

.pb-0 { padding-bottom: 0px !important; }

.pl-0 { padding-left: 0px !important; }

.px-0 { padding-right: 0px !important; padding-left: 0px !important; }

.py-0 { padding-top: 0px !important; padding-bottom: 0px !important; }

.p-1 { padding: 4px !important; }

.pt-1 { padding-top: 4px !important; }

.pr-1 { padding-right: 4px !important; }

.pb-1 { padding-bottom: 4px !important; }

.pl-1 { padding-left: 4px !important; }

.px-1 { padding-right: 4px !important; padding-left: 4px !important; }

.py-1 { padding-top: 4px !important; padding-bottom: 4px !important; }

.p-2 { padding: 8px !important; }

.pt-2 { padding-top: 8px !important; }

.pr-2 { padding-right: 8px !important; }

.pb-2 { padding-bottom: 8px !important; }

.pl-2 { padding-left: 8px !important; }

.px-2 { padding-right: 8px !important; padding-left: 8px !important; }

.py-2 { padding-top: 8px !important; padding-bottom: 8px !important; }

.p-3 { padding: 16px !important; }

.pt-3 { padding-top: 16px !important; }

.pr-3 { padding-right: 16px !important; }

.pb-3 { padding-bottom: 16px !important; }

.pl-3 { padding-left: 16px !important; }

.px-3 { padding-right: 16px !important; padding-left: 16px !important; }

.py-3 { padding-top: 16px !important; padding-bottom: 16px !important; }

.p-4 { padding: 24px !important; }

.pt-4 { padding-top: 24px !important; }

.pr-4 { padding-right: 24px !important; }

.pb-4 { padding-bottom: 24px !important; }

.pl-4 { padding-left: 24px !important; }

.px-4 { padding-right: 24px !important; padding-left: 24px !important; }

.py-4 { padding-top: 24px !important; padding-bottom: 24px !important; }

.p-5 { padding: 32px !important; }

.pt-5 { padding-top: 32px !important; }

.pr-5 { padding-right: 32px !important; }

.pb-5 { padding-bottom: 32px !important; }

.pl-5 { padding-left: 32px !important; }

.px-5 { padding-right: 32px !important; padding-left: 32px !important; }

.py-5 { padding-top: 32px !important; padding-bottom: 32px !important; }

.p-6 { padding: 40px !important; }

.pt-6 { padding-top: 40px !important; }

.pr-6 { padding-right: 40px !important; }

.pb-6 { padding-bottom: 40px !important; }

.pl-6 { padding-left: 40px !important; }

.px-6 { padding-right: 40px !important; padding-left: 40px !important; }

.py-6 { padding-top: 40px !important; padding-bottom: 40px !important; }

.pt-7 { padding-top: 48px !important; }

.pr-7 { padding-right: 48px !important; }

.pb-7 { padding-bottom: 48px !important; }

.pl-7 { padding-left: 48px !important; }

.py-7 { padding-top: 48px !important; padding-bottom: 48px !important; }

.pt-8 { padding-top: 64px !important; }

.pr-8 { padding-right: 64px !important; }

.pb-8 { padding-bottom: 64px !important; }

.pl-8 { padding-left: 64px !important; }

.py-8 { padding-top: 64px !important; padding-bottom: 64px !important; }

.pt-9 { padding-top: 80px !important; }

.pr-9 { padding-right: 80px !important; }

.pb-9 { padding-bottom: 80px !important; }

.pl-9 { padding-left: 80px !important; }

.py-9 { padding-top: 80px !important; padding-bottom: 80px !important; }

.pt-10 { padding-top: 96px !important; }

.pr-10 { padding-right: 96px !important; }

.pb-10 { padding-bottom: 96px !important; }

.pl-10 { padding-left: 96px !important; }

.py-10 { padding-top: 96px !important; padding-bottom: 96px !important; }

.pt-11 { padding-top: 112px !important; }

.pr-11 { padding-right: 112px !important; }

.pb-11 { padding-bottom: 112px !important; }

.pl-11 { padding-left: 112px !important; }

.py-11 { padding-top: 112px !important; padding-bottom: 112px !important; }

.pt-12 { padding-top: 128px !important; }

.pr-12 { padding-right: 128px !important; }

.pb-12 { padding-bottom: 128px !important; }

.pl-12 { padding-left: 128px !important; }

.py-12 { padding-top: 128px !important; padding-bottom: 128px !important; }

@media (min-width: 544px) {
  .p-sm-0 { padding: 0px !important; }
  .pt-sm-0 { padding-top: 0px !important; }
  .pr-sm-0 { padding-right: 0px !important; }
  .pb-sm-0 { padding-bottom: 0px !important; }
  .pl-sm-0 { padding-left: 0px !important; }
  .px-sm-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .py-sm-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .p-sm-1 { padding: 4px !important; }
  .pt-sm-1 { padding-top: 4px !important; }
  .pr-sm-1 { padding-right: 4px !important; }
  .pb-sm-1 { padding-bottom: 4px !important; }
  .pl-sm-1 { padding-left: 4px !important; }
  .px-sm-1 { padding-right: 4px !important; padding-left: 4px !important; }
  .py-sm-1 { padding-top: 4px !important; padding-bottom: 4px !important; }
  .p-sm-2 { padding: 8px !important; }
  .pt-sm-2 { padding-top: 8px !important; }
  .pr-sm-2 { padding-right: 8px !important; }
  .pb-sm-2 { padding-bottom: 8px !important; }
  .pl-sm-2 { padding-left: 8px !important; }
  .px-sm-2 { padding-right: 8px !important; padding-left: 8px !important; }
  .py-sm-2 { padding-top: 8px !important; padding-bottom: 8px !important; }
  .p-sm-3 { padding: 16px !important; }
  .pt-sm-3 { padding-top: 16px !important; }
  .pr-sm-3 { padding-right: 16px !important; }
  .pb-sm-3 { padding-bottom: 16px !important; }
  .pl-sm-3 { padding-left: 16px !important; }
  .px-sm-3 { padding-right: 16px !important; padding-left: 16px !important; }
  .py-sm-3 { padding-top: 16px !important; padding-bottom: 16px !important; }
  .p-sm-4 { padding: 24px !important; }
  .pt-sm-4 { padding-top: 24px !important; }
  .pr-sm-4 { padding-right: 24px !important; }
  .pb-sm-4 { padding-bottom: 24px !important; }
  .pl-sm-4 { padding-left: 24px !important; }
  .px-sm-4 { padding-right: 24px !important; padding-left: 24px !important; }
  .py-sm-4 { padding-top: 24px !important; padding-bottom: 24px !important; }
  .p-sm-5 { padding: 32px !important; }
  .pt-sm-5 { padding-top: 32px !important; }
  .pr-sm-5 { padding-right: 32px !important; }
  .pb-sm-5 { padding-bottom: 32px !important; }
  .pl-sm-5 { padding-left: 32px !important; }
  .px-sm-5 { padding-right: 32px !important; padding-left: 32px !important; }
  .py-sm-5 { padding-top: 32px !important; padding-bottom: 32px !important; }
  .p-sm-6 { padding: 40px !important; }
  .pt-sm-6 { padding-top: 40px !important; }
  .pr-sm-6 { padding-right: 40px !important; }
  .pb-sm-6 { padding-bottom: 40px !important; }
  .pl-sm-6 { padding-left: 40px !important; }
  .px-sm-6 { padding-right: 40px !important; padding-left: 40px !important; }
  .py-sm-6 { padding-top: 40px !important; padding-bottom: 40px !important; }
  .pt-sm-7 { padding-top: 48px !important; }
  .pr-sm-7 { padding-right: 48px !important; }
  .pb-sm-7 { padding-bottom: 48px !important; }
  .pl-sm-7 { padding-left: 48px !important; }
  .py-sm-7 { padding-top: 48px !important; padding-bottom: 48px !important; }
  .pt-sm-8 { padding-top: 64px !important; }
  .pr-sm-8 { padding-right: 64px !important; }
  .pb-sm-8 { padding-bottom: 64px !important; }
  .pl-sm-8 { padding-left: 64px !important; }
  .py-sm-8 { padding-top: 64px !important; padding-bottom: 64px !important; }
  .pt-sm-9 { padding-top: 80px !important; }
  .pr-sm-9 { padding-right: 80px !important; }
  .pb-sm-9 { padding-bottom: 80px !important; }
  .pl-sm-9 { padding-left: 80px !important; }
  .py-sm-9 { padding-top: 80px !important; padding-bottom: 80px !important; }
  .pt-sm-10 { padding-top: 96px !important; }
  .pr-sm-10 { padding-right: 96px !important; }
  .pb-sm-10 { padding-bottom: 96px !important; }
  .pl-sm-10 { padding-left: 96px !important; }
  .py-sm-10 { padding-top: 96px !important; padding-bottom: 96px !important; }
  .pt-sm-11 { padding-top: 112px !important; }
  .pr-sm-11 { padding-right: 112px !important; }
  .pb-sm-11 { padding-bottom: 112px !important; }
  .pl-sm-11 { padding-left: 112px !important; }
  .py-sm-11 { padding-top: 112px !important; padding-bottom: 112px !important; }
  .pt-sm-12 { padding-top: 128px !important; }
  .pr-sm-12 { padding-right: 128px !important; }
  .pb-sm-12 { padding-bottom: 128px !important; }
  .pl-sm-12 { padding-left: 128px !important; }
  .py-sm-12 { padding-top: 128px !important; padding-bottom: 128px !important; }
}

@media (min-width: 768px) {
  .p-md-0 { padding: 0px !important; }
  .pt-md-0 { padding-top: 0px !important; }
  .pr-md-0 { padding-right: 0px !important; }
  .pb-md-0 { padding-bottom: 0px !important; }
  .pl-md-0 { padding-left: 0px !important; }
  .px-md-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .py-md-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .p-md-1 { padding: 4px !important; }
  .pt-md-1 { padding-top: 4px !important; }
  .pr-md-1 { padding-right: 4px !important; }
  .pb-md-1 { padding-bottom: 4px !important; }
  .pl-md-1 { padding-left: 4px !important; }
  .px-md-1 { padding-right: 4px !important; padding-left: 4px !important; }
  .py-md-1 { padding-top: 4px !important; padding-bottom: 4px !important; }
  .p-md-2 { padding: 8px !important; }
  .pt-md-2 { padding-top: 8px !important; }
  .pr-md-2 { padding-right: 8px !important; }
  .pb-md-2 { padding-bottom: 8px !important; }
  .pl-md-2 { padding-left: 8px !important; }
  .px-md-2 { padding-right: 8px !important; padding-left: 8px !important; }
  .py-md-2 { padding-top: 8px !important; padding-bottom: 8px !important; }
  .p-md-3 { padding: 16px !important; }
  .pt-md-3 { padding-top: 16px !important; }
  .pr-md-3 { padding-right: 16px !important; }
  .pb-md-3 { padding-bottom: 16px !important; }
  .pl-md-3 { padding-left: 16px !important; }
  .px-md-3 { padding-right: 16px !important; padding-left: 16px !important; }
  .py-md-3 { padding-top: 16px !important; padding-bottom: 16px !important; }
  .p-md-4 { padding: 24px !important; }
  .pt-md-4 { padding-top: 24px !important; }
  .pr-md-4 { padding-right: 24px !important; }
  .pb-md-4 { padding-bottom: 24px !important; }
  .pl-md-4 { padding-left: 24px !important; }
  .px-md-4 { padding-right: 24px !important; padding-left: 24px !important; }
  .py-md-4 { padding-top: 24px !important; padding-bottom: 24px !important; }
  .p-md-5 { padding: 32px !important; }
  .pt-md-5 { padding-top: 32px !important; }
  .pr-md-5 { padding-right: 32px !important; }
  .pb-md-5 { padding-bottom: 32px !important; }
  .pl-md-5 { padding-left: 32px !important; }
  .px-md-5 { padding-right: 32px !important; padding-left: 32px !important; }
  .py-md-5 { padding-top: 32px !important; padding-bottom: 32px !important; }
  .p-md-6 { padding: 40px !important; }
  .pt-md-6 { padding-top: 40px !important; }
  .pr-md-6 { padding-right: 40px !important; }
  .pb-md-6 { padding-bottom: 40px !important; }
  .pl-md-6 { padding-left: 40px !important; }
  .px-md-6 { padding-right: 40px !important; padding-left: 40px !important; }
  .py-md-6 { padding-top: 40px !important; padding-bottom: 40px !important; }
  .pt-md-7 { padding-top: 48px !important; }
  .pr-md-7 { padding-right: 48px !important; }
  .pb-md-7 { padding-bottom: 48px !important; }
  .pl-md-7 { padding-left: 48px !important; }
  .py-md-7 { padding-top: 48px !important; padding-bottom: 48px !important; }
  .pt-md-8 { padding-top: 64px !important; }
  .pr-md-8 { padding-right: 64px !important; }
  .pb-md-8 { padding-bottom: 64px !important; }
  .pl-md-8 { padding-left: 64px !important; }
  .py-md-8 { padding-top: 64px !important; padding-bottom: 64px !important; }
  .pt-md-9 { padding-top: 80px !important; }
  .pr-md-9 { padding-right: 80px !important; }
  .pb-md-9 { padding-bottom: 80px !important; }
  .pl-md-9 { padding-left: 80px !important; }
  .py-md-9 { padding-top: 80px !important; padding-bottom: 80px !important; }
  .pt-md-10 { padding-top: 96px !important; }
  .pr-md-10 { padding-right: 96px !important; }
  .pb-md-10 { padding-bottom: 96px !important; }
  .pl-md-10 { padding-left: 96px !important; }
  .py-md-10 { padding-top: 96px !important; padding-bottom: 96px !important; }
  .pt-md-11 { padding-top: 112px !important; }
  .pr-md-11 { padding-right: 112px !important; }
  .pb-md-11 { padding-bottom: 112px !important; }
  .pl-md-11 { padding-left: 112px !important; }
  .py-md-11 { padding-top: 112px !important; padding-bottom: 112px !important; }
  .pt-md-12 { padding-top: 128px !important; }
  .pr-md-12 { padding-right: 128px !important; }
  .pb-md-12 { padding-bottom: 128px !important; }
  .pl-md-12 { padding-left: 128px !important; }
  .py-md-12 { padding-top: 128px !important; padding-bottom: 128px !important; }
}

@media (min-width: 1012px) {
  .p-lg-0 { padding: 0px !important; }
  .pt-lg-0 { padding-top: 0px !important; }
  .pr-lg-0 { padding-right: 0px !important; }
  .pb-lg-0 { padding-bottom: 0px !important; }
  .pl-lg-0 { padding-left: 0px !important; }
  .px-lg-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .py-lg-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .p-lg-1 { padding: 4px !important; }
  .pt-lg-1 { padding-top: 4px !important; }
  .pr-lg-1 { padding-right: 4px !important; }
  .pb-lg-1 { padding-bottom: 4px !important; }
  .pl-lg-1 { padding-left: 4px !important; }
  .px-lg-1 { padding-right: 4px !important; padding-left: 4px !important; }
  .py-lg-1 { padding-top: 4px !important; padding-bottom: 4px !important; }
  .p-lg-2 { padding: 8px !important; }
  .pt-lg-2 { padding-top: 8px !important; }
  .pr-lg-2 { padding-right: 8px !important; }
  .pb-lg-2 { padding-bottom: 8px !important; }
  .pl-lg-2 { padding-left: 8px !important; }
  .px-lg-2 { padding-right: 8px !important; padding-left: 8px !important; }
  .py-lg-2 { padding-top: 8px !important; padding-bottom: 8px !important; }
  .p-lg-3 { padding: 16px !important; }
  .pt-lg-3 { padding-top: 16px !important; }
  .pr-lg-3 { padding-right: 16px !important; }
  .pb-lg-3 { padding-bottom: 16px !important; }
  .pl-lg-3 { padding-left: 16px !important; }
  .px-lg-3 { padding-right: 16px !important; padding-left: 16px !important; }
  .py-lg-3 { padding-top: 16px !important; padding-bottom: 16px !important; }
  .p-lg-4 { padding: 24px !important; }
  .pt-lg-4 { padding-top: 24px !important; }
  .pr-lg-4 { padding-right: 24px !important; }
  .pb-lg-4 { padding-bottom: 24px !important; }
  .pl-lg-4 { padding-left: 24px !important; }
  .px-lg-4 { padding-right: 24px !important; padding-left: 24px !important; }
  .py-lg-4 { padding-top: 24px !important; padding-bottom: 24px !important; }
  .p-lg-5 { padding: 32px !important; }
  .pt-lg-5 { padding-top: 32px !important; }
  .pr-lg-5 { padding-right: 32px !important; }
  .pb-lg-5 { padding-bottom: 32px !important; }
  .pl-lg-5 { padding-left: 32px !important; }
  .px-lg-5 { padding-right: 32px !important; padding-left: 32px !important; }
  .py-lg-5 { padding-top: 32px !important; padding-bottom: 32px !important; }
  .p-lg-6 { padding: 40px !important; }
  .pt-lg-6 { padding-top: 40px !important; }
  .pr-lg-6 { padding-right: 40px !important; }
  .pb-lg-6 { padding-bottom: 40px !important; }
  .pl-lg-6 { padding-left: 40px !important; }
  .px-lg-6 { padding-right: 40px !important; padding-left: 40px !important; }
  .py-lg-6 { padding-top: 40px !important; padding-bottom: 40px !important; }
  .pt-lg-7 { padding-top: 48px !important; }
  .pr-lg-7 { padding-right: 48px !important; }
  .pb-lg-7 { padding-bottom: 48px !important; }
  .pl-lg-7 { padding-left: 48px !important; }
  .py-lg-7 { padding-top: 48px !important; padding-bottom: 48px !important; }
  .pt-lg-8 { padding-top: 64px !important; }
  .pr-lg-8 { padding-right: 64px !important; }
  .pb-lg-8 { padding-bottom: 64px !important; }
  .pl-lg-8 { padding-left: 64px !important; }
  .py-lg-8 { padding-top: 64px !important; padding-bottom: 64px !important; }
  .pt-lg-9 { padding-top: 80px !important; }
  .pr-lg-9 { padding-right: 80px !important; }
  .pb-lg-9 { padding-bottom: 80px !important; }
  .pl-lg-9 { padding-left: 80px !important; }
  .py-lg-9 { padding-top: 80px !important; padding-bottom: 80px !important; }
  .pt-lg-10 { padding-top: 96px !important; }
  .pr-lg-10 { padding-right: 96px !important; }
  .pb-lg-10 { padding-bottom: 96px !important; }
  .pl-lg-10 { padding-left: 96px !important; }
  .py-lg-10 { padding-top: 96px !important; padding-bottom: 96px !important; }
  .pt-lg-11 { padding-top: 112px !important; }
  .pr-lg-11 { padding-right: 112px !important; }
  .pb-lg-11 { padding-bottom: 112px !important; }
  .pl-lg-11 { padding-left: 112px !important; }
  .py-lg-11 { padding-top: 112px !important; padding-bottom: 112px !important; }
  .pt-lg-12 { padding-top: 128px !important; }
  .pr-lg-12 { padding-right: 128px !important; }
  .pb-lg-12 { padding-bottom: 128px !important; }
  .pl-lg-12 { padding-left: 128px !important; }
  .py-lg-12 { padding-top: 128px !important; padding-bottom: 128px !important; }
}

@media (min-width: 1280px) {
  .p-xl-0 { padding: 0px !important; }
  .pt-xl-0 { padding-top: 0px !important; }
  .pr-xl-0 { padding-right: 0px !important; }
  .pb-xl-0 { padding-bottom: 0px !important; }
  .pl-xl-0 { padding-left: 0px !important; }
  .px-xl-0 { padding-right: 0px !important; padding-left: 0px !important; }
  .py-xl-0 { padding-top: 0px !important; padding-bottom: 0px !important; }
  .p-xl-1 { padding: 4px !important; }
  .pt-xl-1 { padding-top: 4px !important; }
  .pr-xl-1 { padding-right: 4px !important; }
  .pb-xl-1 { padding-bottom: 4px !important; }
  .pl-xl-1 { padding-left: 4px !important; }
  .px-xl-1 { padding-right: 4px !important; padding-left: 4px !important; }
  .py-xl-1 { padding-top: 4px !important; padding-bottom: 4px !important; }
  .p-xl-2 { padding: 8px !important; }
  .pt-xl-2 { padding-top: 8px !important; }
  .pr-xl-2 { padding-right: 8px !important; }
  .pb-xl-2 { padding-bottom: 8px !important; }
  .pl-xl-2 { padding-left: 8px !important; }
  .px-xl-2 { padding-right: 8px !important; padding-left: 8px !important; }
  .py-xl-2 { padding-top: 8px !important; padding-bottom: 8px !important; }
  .p-xl-3 { padding: 16px !important; }
  .pt-xl-3 { padding-top: 16px !important; }
  .pr-xl-3 { padding-right: 16px !important; }
  .pb-xl-3 { padding-bottom: 16px !important; }
  .pl-xl-3 { padding-left: 16px !important; }
  .px-xl-3 { padding-right: 16px !important; padding-left: 16px !important; }
  .py-xl-3 { padding-top: 16px !important; padding-bottom: 16px !important; }
  .p-xl-4 { padding: 24px !important; }
  .pt-xl-4 { padding-top: 24px !important; }
  .pr-xl-4 { padding-right: 24px !important; }
  .pb-xl-4 { padding-bottom: 24px !important; }
  .pl-xl-4 { padding-left: 24px !important; }
  .px-xl-4 { padding-right: 24px !important; padding-left: 24px !important; }
  .py-xl-4 { padding-top: 24px !important; padding-bottom: 24px !important; }
  .p-xl-5 { padding: 32px !important; }
  .pt-xl-5 { padding-top: 32px !important; }
  .pr-xl-5 { padding-right: 32px !important; }
  .pb-xl-5 { padding-bottom: 32px !important; }
  .pl-xl-5 { padding-left: 32px !important; }
  .px-xl-5 { padding-right: 32px !important; padding-left: 32px !important; }
  .py-xl-5 { padding-top: 32px !important; padding-bottom: 32px !important; }
  .p-xl-6 { padding: 40px !important; }
  .pt-xl-6 { padding-top: 40px !important; }
  .pr-xl-6 { padding-right: 40px !important; }
  .pb-xl-6 { padding-bottom: 40px !important; }
  .pl-xl-6 { padding-left: 40px !important; }
  .px-xl-6 { padding-right: 40px !important; padding-left: 40px !important; }
  .py-xl-6 { padding-top: 40px !important; padding-bottom: 40px !important; }
  .pt-xl-7 { padding-top: 48px !important; }
  .pr-xl-7 { padding-right: 48px !important; }
  .pb-xl-7 { padding-bottom: 48px !important; }
  .pl-xl-7 { padding-left: 48px !important; }
  .py-xl-7 { padding-top: 48px !important; padding-bottom: 48px !important; }
  .pt-xl-8 { padding-top: 64px !important; }
  .pr-xl-8 { padding-right: 64px !important; }
  .pb-xl-8 { padding-bottom: 64px !important; }
  .pl-xl-8 { padding-left: 64px !important; }
  .py-xl-8 { padding-top: 64px !important; padding-bottom: 64px !important; }
  .pt-xl-9 { padding-top: 80px !important; }
  .pr-xl-9 { padding-right: 80px !important; }
  .pb-xl-9 { padding-bottom: 80px !important; }
  .pl-xl-9 { padding-left: 80px !important; }
  .py-xl-9 { padding-top: 80px !important; padding-bottom: 80px !important; }
  .pt-xl-10 { padding-top: 96px !important; }
  .pr-xl-10 { padding-right: 96px !important; }
  .pb-xl-10 { padding-bottom: 96px !important; }
  .pl-xl-10 { padding-left: 96px !important; }
  .py-xl-10 { padding-top: 96px !important; padding-bottom: 96px !important; }
  .pt-xl-11 { padding-top: 112px !important; }
  .pr-xl-11 { padding-right: 112px !important; }
  .pb-xl-11 { padding-bottom: 112px !important; }
  .pl-xl-11 { padding-left: 112px !important; }
  .py-xl-11 { padding-top: 112px !important; padding-bottom: 112px !important; }
  .pt-xl-12 { padding-top: 128px !important; }
  .pr-xl-12 { padding-right: 128px !important; }
  .pb-xl-12 { padding-bottom: 128px !important; }
  .pl-xl-12 { padding-left: 128px !important; }
  .py-xl-12 { padding-top: 128px !important; padding-bottom: 128px !important; }
}

.p-responsive { padding-right: 16px !important; padding-left: 16px !important; }

@media (min-width: 544px) {
  .p-responsive { padding-right: 40px !important; padding-left: 40px !important; }
}

@media (min-width: 1012px) {
  .p-responsive { padding-right: 16px !important; padding-left: 16px !important; }
}

.h1 { font-size: 26px !important; }

@media (min-width: 768px) {
  .h1 { font-size: 32px !important; }
}

.h2 { font-size: 22px !important; }

@media (min-width: 768px) {
  .h2 { font-size: 24px !important; }
}

.h3 { font-size: 18px !important; }

@media (min-width: 768px) {
  .h3 { font-size: 20px !important; }
}

.h4 { font-size: 16px !important; }

.h5 { font-size: 14px !important; }

.h6 { font-size: 12px !important; }

.h1, .h2, .h3, .h4, .h5, .h6 { font-weight: 600 !important; }

.f1 { font-size: 26px !important; }

@media (min-width: 768px) {
  .f1 { font-size: 32px !important; }
}

.f2 { font-size: 22px !important; }

@media (min-width: 768px) {
  .f2 { font-size: 24px !important; }
}

.f3 { font-size: 18px !important; }

@media (min-width: 768px) {
  .f3 { font-size: 20px !important; }
}

.f4 { font-size: 16px !important; }

@media (min-width: 768px) {
  .f4 { font-size: 16px !important; }
}

.f5 { font-size: 14px !important; }

.f6 { font-size: 12px !important; }

.f00-light { font-size: 40px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f00-light { font-size: 48px !important; }
}

.f0-light { font-size: 32px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f0-light { font-size: 40px !important; }
}

.f1-light { font-size: 26px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f1-light { font-size: 32px !important; }
}

.f2-light { font-size: 22px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f2-light { font-size: 24px !important; }
}

.f3-light { font-size: 18px !important; font-weight: 300 !important; }

@media (min-width: 768px) {
  .f3-light { font-size: 20px !important; }
}

.text-small { font-size: 12px !important; }

.lead { margin-bottom: 30px; font-size: 20px; font-weight: 300; }

.lh-condensed-ultra { line-height: 1 !important; }

.lh-condensed { line-height: 1.25 !important; }

.lh-default { line-height: 1.5 !important; }

.lh-0 { line-height: 0 !important; }

@media (min-width: 544px) {
  .lh-sm-condensed-ultra { line-height: 1 !important; }
  .lh-sm-condensed { line-height: 1.25 !important; }
  .lh-sm-default { line-height: 1.5 !important; }
  .lh-sm-0 { line-height: 0 !important; }
}

@media (min-width: 768px) {
  .lh-md-condensed-ultra { line-height: 1 !important; }
  .lh-md-condensed { line-height: 1.25 !important; }
  .lh-md-default { line-height: 1.5 !important; }
  .lh-md-0 { line-height: 0 !important; }
}

@media (min-width: 1012px) {
  .lh-lg-condensed-ultra { line-height: 1 !important; }
  .lh-lg-condensed { line-height: 1.25 !important; }
  .lh-lg-default { line-height: 1.5 !important; }
  .lh-lg-0 { line-height: 0 !important; }
}

@media (min-width: 1280px) {
  .lh-xl-condensed-ultra { line-height: 1 !important; }
  .lh-xl-condensed { line-height: 1.25 !important; }
  .lh-xl-default { line-height: 1.5 !important; }
  .lh-xl-0 { line-height: 0 !important; }
}

.text-right { text-align: right !important; }

.text-left { text-align: left !important; }

.text-center { text-align: center !important; }

@media (min-width: 544px) {
  .text-sm-right { text-align: right !important; }
  .text-sm-left { text-align: left !important; }
  .text-sm-center { text-align: center !important; }
}

@media (min-width: 768px) {
  .text-md-right { text-align: right !important; }
  .text-md-left { text-align: left !important; }
  .text-md-center { text-align: center !important; }
}

@media (min-width: 1012px) {
  .text-lg-right { text-align: right !important; }
  .text-lg-left { text-align: left !important; }
  .text-lg-center { text-align: center !important; }
}

@media (min-width: 1280px) {
  .text-xl-right { text-align: right !important; }
  .text-xl-left { text-align: left !important; }
  .text-xl-center { text-align: center !important; }
}

.text-normal { font-weight: 400 !important; }

.text-bold { font-weight: 600 !important; }

.text-semibold { font-weight: 500 !important; }

.text-light { font-weight: 300 !important; }

.text-italic { font-style: italic !important; }

.text-uppercase { text-transform: uppercase !important; }

.text-underline { text-decoration: underline !important; }

.no-underline { text-decoration: none !important; }

.no-wrap { white-space: nowrap !important; }

.ws-normal { white-space: normal !important; }

.wb-break-word { word-break: break-word !important; overflow-wrap: break-word !important; }

.wb-break-all { word-break: break-all !important; }

.text-emphasized { font-weight: 600; }

.list-style-none { list-style: none !important; }

.text-mono { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace !important; }

.user-select-none { user-select: none !important; }

.d-block { display: block !important; }

.d-flex { display: flex !important; }

.d-inline { display: inline !important; }

.d-inline-block { display: inline-block !important; }

.d-inline-flex { display: inline-flex !important; }

.d-none { display: none !important; }

.d-table { display: table !important; }

.d-table-cell { display: table-cell !important; }

@media (min-width: 544px) {
  .d-sm-block { display: block !important; }
  .d-sm-flex { display: flex !important; }
  .d-sm-inline { display: inline !important; }
  .d-sm-inline-block { display: inline-block !important; }
  .d-sm-inline-flex { display: inline-flex !important; }
  .d-sm-none { display: none !important; }
  .d-sm-table { display: table !important; }
  .d-sm-table-cell { display: table-cell !important; }
}

@media (min-width: 768px) {
  .d-md-block { display: block !important; }
  .d-md-flex { display: flex !important; }
  .d-md-inline { display: inline !important; }
  .d-md-inline-block { display: inline-block !important; }
  .d-md-inline-flex { display: inline-flex !important; }
  .d-md-none { display: none !important; }
  .d-md-table { display: table !important; }
  .d-md-table-cell { display: table-cell !important; }
}

@media (min-width: 1012px) {
  .d-lg-block { display: block !important; }
  .d-lg-flex { display: flex !important; }
  .d-lg-inline { display: inline !important; }
  .d-lg-inline-block { display: inline-block !important; }
  .d-lg-inline-flex { display: inline-flex !important; }
  .d-lg-none { display: none !important; }
  .d-lg-table { display: table !important; }
  .d-lg-table-cell { display: table-cell !important; }
}

@media (min-width: 1280px) {
  .d-xl-block { display: block !important; }
  .d-xl-flex { display: flex !important; }
  .d-xl-inline { display: inline !important; }
  .d-xl-inline-block { display: inline-block !important; }
  .d-xl-inline-flex { display: inline-flex !important; }
  .d-xl-none { display: none !important; }
  .d-xl-table { display: table !important; }
  .d-xl-table-cell { display: table-cell !important; }
}

.v-hidden { visibility: hidden !important; }

.v-visible { visibility: visible !important; }

@media (max-width: 543.98px) {
  .hide-sm { display: none !important; }
}

@media (min-width: 544px) and (max-width: 767.98px) {
  .hide-md { display: none !important; }
}

@media (min-width: 768px) and (max-width: 1011.98px) {
  .hide-lg { display: none !important; }
}

@media (min-width: 1012px) {
  .hide-xl { display: none !important; }
}

.table-fixed { table-layout: fixed !important; }

.sr-only { position: absolute; width: 1px; height: 1px; padding: 0px; overflow: hidden; clip: rect(0px, 0px, 0px, 0px); overflow-wrap: normal; border: 0px; }

.show-on-focus { position: absolute; width: 1px; height: 1px; margin: 0px; overflow: hidden; clip: rect(1px, 1px, 1px, 1px); }

.show-on-focus:focus { z-index: 20; width: auto; height: auto; clip: auto; }

.color-border-inverse { border-color: var(--color-fg-on-emphasis)  !important; }

.bg-gray-2, .bg-gray-3 { background-color: var(--color-neutral-muted)  !important; }

.color-text-white { color: var(--color-scale-white)  !important; }

.border-white-fade { border-color: rgba(255, 255, 255, 0.15) !important; }

.lead { color: var(--color-fg-muted); }

.text-emphasized { color: var(--color-fg-default); }

.Label.Label--orange { color: var(--color-severe-fg); border-color: var(--color-severe-emphasis); }

.Label.Label--purple { color: var(--color-done-fg); border-color: var(--color-done-emphasis); }

.Label.Label--pink { color: var(--color-sponsors-fg); border-color: var(--color-sponsors-emphasis); }

.pl-c { color: var(--color-prettylights-syntax-comment); }

.pl-c1, .pl-s .pl-v { color: var(--color-prettylights-syntax-constant); }

.pl-e, .pl-en { color: var(--color-prettylights-syntax-entity); }

.pl-smi, .pl-s .pl-s1 { color: var(--color-prettylights-syntax-storage-modifier-import); }

.pl-ent { color: var(--color-prettylights-syntax-entity-tag); }

.pl-k { color: var(--color-prettylights-syntax-keyword); }

.pl-s, .pl-pds, .pl-s .pl-pse .pl-s1, .pl-sr, .pl-sr .pl-cce, .pl-sr .pl-sre, .pl-sr .pl-sra { color: var(--color-prettylights-syntax-string); }

.pl-v, .pl-smw { color: var(--color-prettylights-syntax-variable); }

.pl-bu { color: var(--color-prettylights-syntax-brackethighlighter-unmatched); }

.pl-ii { color: var(--color-prettylights-syntax-invalid-illegal-text); background-color: var(--color-prettylights-syntax-invalid-illegal-bg); }

.pl-c2 { color: var(--color-prettylights-syntax-carriage-return-text); background-color: var(--color-prettylights-syntax-carriage-return-bg); }

.pl-c2::before { content: "^M"; }

.pl-sr .pl-cce { font-weight: bold; color: var(--color-prettylights-syntax-string-regexp); }

.pl-ml { color: var(--color-prettylights-syntax-markup-list); }

.pl-mh, .pl-mh .pl-en, .pl-ms { font-weight: bold; color: var(--color-prettylights-syntax-markup-heading); }

.pl-mi { font-style: italic; color: var(--color-prettylights-syntax-markup-italic); }

.pl-mb { font-weight: bold; color: var(--color-prettylights-syntax-markup-bold); }

.pl-md { color: var(--color-prettylights-syntax-markup-deleted-text); background-color: var(--color-prettylights-syntax-markup-deleted-bg); }

.pl-mi1 { color: var(--color-prettylights-syntax-markup-inserted-text); background-color: var(--color-prettylights-syntax-markup-inserted-bg); }

.pl-mc { color: var(--color-prettylights-syntax-markup-changed-text); background-color: var(--color-prettylights-syntax-markup-changed-bg); }

.pl-mi2 { color: var(--color-prettylights-syntax-markup-ignored-text); background-color: var(--color-prettylights-syntax-markup-ignored-bg); }

.pl-mdr { font-weight: bold; color: var(--color-prettylights-syntax-meta-diff-range); }

.pl-ba { color: var(--color-prettylights-syntax-brackethighlighter-angle); }

.pl-sg { color: var(--color-prettylights-syntax-sublimelinter-gutter-mark); }

.pl-corl { text-decoration: underline; color: var(--color-prettylights-syntax-constant-other-reference-link); }

.CodeMirror { font-family: monospace; height: 300px; color: rgb(0, 0, 0); direction: ltr; }

.CodeMirror-lines { padding: 4px 0px; }

.CodeMirror pre.CodeMirror-line, .CodeMirror pre.CodeMirror-line-like { padding: 0px 4px; }

.CodeMirror-scrollbar-filler, .CodeMirror-gutter-filler { background-color: rgb(255, 255, 255); }

.CodeMirror-gutters { border-right: 1px solid rgb(221, 221, 221); background-color: rgb(247, 247, 247); white-space: nowrap; }

.CodeMirror-linenumber { padding: 0px 3px 0px 5px; min-width: 20px; text-align: right; color: rgb(153, 153, 153); white-space: nowrap; }

.CodeMirror-guttermarker { color: rgb(0, 0, 0); }

.CodeMirror-guttermarker-subtle { color: rgb(153, 153, 153); }

.CodeMirror-cursor { border-left: 1px solid rgb(0, 0, 0); border-right: none; width: 0px; }

.CodeMirror div.CodeMirror-secondarycursor { border-left: 1px solid silver; }

.cm-fat-cursor .CodeMirror-cursor { width: auto; background: rgb(119, 238, 119); border: 0px !important; }

.cm-fat-cursor div.CodeMirror-cursors { z-index: 1; }

.cm-fat-cursor-mark { background-color: rgba(20, 255, 20, 0.5); animation: 1.06s steps(1) 0s infinite normal none running blink; }

.cm-animate-fat-cursor { width: auto; border: 0px; animation: 1.06s steps(1) 0s infinite normal none running blink; background-color: rgb(119, 238, 119); }

@keyframes blink { 
  50% { background-color: transparent; }
}

.cm-tab { display: inline-block; text-decoration: inherit; }

.CodeMirror-rulers { position: absolute; inset: -50px 0px 0px; overflow: hidden; }

.CodeMirror-ruler { border-left: 1px solid rgb(204, 204, 204); top: 0px; bottom: 0px; position: absolute; }

.cm-s-default .cm-header { color: blue; }

.cm-s-default .cm-quote { color: rgb(0, 153, 0); }

.cm-negative { color: rgb(221, 68, 68); }

.cm-positive { color: rgb(34, 153, 34); }

.cm-header, .cm-strong { font-weight: bold; }

.cm-em { font-style: italic; }

.cm-link { text-decoration: underline; }

.cm-strikethrough { text-decoration: line-through; }

.cm-s-default .cm-keyword { color: rgb(119, 0, 136); }

.cm-s-default .cm-atom { color: rgb(34, 17, 153); }

.cm-s-default .cm-number { color: rgb(17, 102, 68); }

.cm-s-default .cm-def { color: blue; }

.cm-s-default .cm-variable-2 { color: rgb(0, 85, 170); }

.cm-s-default .cm-variable-3, .cm-s-default .cm-type { color: rgb(0, 136, 85); }

.cm-s-default .cm-comment { color: rgb(170, 85, 0); }

.cm-s-default .cm-string { color: rgb(170, 17, 17); }

.cm-s-default .cm-string-2 { color: rgb(255, 85, 0); }

.cm-s-default .cm-meta { color: rgb(85, 85, 85); }

.cm-s-default .cm-qualifier { color: rgb(85, 85, 85); }

.cm-s-default .cm-builtin { color: rgb(51, 0, 170); }

.cm-s-default .cm-bracket { color: rgb(153, 153, 119); }

.cm-s-default .cm-tag { color: rgb(17, 119, 0); }

.cm-s-default .cm-attribute { color: rgb(0, 0, 204); }

.cm-s-default .cm-hr { color: rgb(153, 153, 153); }

.cm-s-default .cm-link { color: rgb(0, 0, 204); }

.cm-s-default .cm-error { color: red; }

.cm-invalidchar { color: red; }

.CodeMirror-composing { border-bottom: 2px solid; }

div.CodeMirror span.CodeMirror-matchingbracket { color: rgb(0, 187, 0); }

div.CodeMirror span.CodeMirror-nonmatchingbracket { color: rgb(170, 34, 34); }

.CodeMirror-matchingtag { background: rgba(255, 150, 0, 0.3); }

.CodeMirror-activeline-background { background: rgb(232, 242, 255); }

.CodeMirror { position: relative; overflow: hidden; background: rgb(255, 255, 255); }

.CodeMirror-scroll { margin-bottom: -50px; margin-right: -50px; padding-bottom: 50px; height: 100%; outline: none; position: relative; overflow: scroll !important; }

.CodeMirror-sizer { position: relative; border-right: 50px solid transparent; }

.CodeMirror-vscrollbar, .CodeMirror-hscrollbar, .CodeMirror-scrollbar-filler, .CodeMirror-gutter-filler { position: absolute; z-index: 6; display: none; outline: none; }

.CodeMirror-vscrollbar { right: 0px; top: 0px; overflow: hidden scroll; }

.CodeMirror-hscrollbar { bottom: 0px; left: 0px; overflow: scroll hidden; }

.CodeMirror-scrollbar-filler { right: 0px; bottom: 0px; }

.CodeMirror-gutter-filler { left: 0px; bottom: 0px; }

.CodeMirror-gutters { position: absolute; left: 0px; top: 0px; min-height: 100%; z-index: 3; }

.CodeMirror-gutter { white-space: normal; height: 100%; display: inline-block; vertical-align: top; margin-bottom: -50px; }

.CodeMirror-gutter-wrapper { position: absolute; z-index: 4; background: none !important; border: none !important; }

.CodeMirror-gutter-background { position: absolute; top: 0px; bottom: 0px; z-index: 4; }

.CodeMirror-gutter-elt { position: absolute; cursor: default; z-index: 4; }

.CodeMirror-gutter-wrapper ::selection { background-color: transparent; }

.CodeMirror-lines { cursor: text; min-height: 1px; }

.CodeMirror pre.CodeMirror-line, .CodeMirror pre.CodeMirror-line-like { border-radius: 0px; border-width: 0px; background: transparent; font-family: inherit; font-size: inherit; margin: 0px; white-space: pre; overflow-wrap: normal; line-height: inherit; color: inherit; z-index: 2; position: relative; overflow: visible; -webkit-tap-highlight-color: transparent; font-variant-ligatures: contextual; }

.CodeMirror-wrap pre.CodeMirror-line, .CodeMirror-wrap pre.CodeMirror-line-like { overflow-wrap: break-word; white-space: pre-wrap; word-break: normal; }

.CodeMirror-linebackground { position: absolute; inset: 0px; z-index: 0; }

.CodeMirror-linewidget { position: relative; z-index: 2; padding: 0.1px; }

.CodeMirror-rtl pre { direction: rtl; }

.CodeMirror-code { outline: none; }

.CodeMirror-scroll, .CodeMirror-sizer, .CodeMirror-gutter, .CodeMirror-gutters, .CodeMirror-linenumber { box-sizing: content-box; }

.CodeMirror-measure { position: absolute; width: 100%; height: 0px; overflow: hidden; visibility: hidden; }

.CodeMirror-cursor { position: absolute; pointer-events: none; }

.CodeMirror-measure pre { position: static; }

div.CodeMirror-cursors { visibility: hidden; position: relative; z-index: 3; }

div.CodeMirror-dragcursors { visibility: visible; }

.CodeMirror-focused div.CodeMirror-cursors { visibility: visible; }

.CodeMirror-selected { background: rgb(217, 217, 217); }

.CodeMirror-focused .CodeMirror-selected { background: rgb(215, 212, 240); }

.CodeMirror-crosshair { cursor: crosshair; }

.CodeMirror-line::selection, .CodeMirror-line > span::selection, .CodeMirror-line > span > span::selection { background: rgb(215, 212, 240); }

.cm-searching { background-color: rgba(255, 255, 0, 0.4); }

.cm-force-border { padding-right: 0.1px; }

@media print {
  .CodeMirror div.CodeMirror-cursors { visibility: hidden; }
}

.cm-tab-wrap-hack::after { content: ""; }

span.CodeMirror-selectedtext { background: none; }

.CodeMirror-dialog { position: absolute; left: 0px; right: 0px; background: inherit; z-index: 15; padding: 0.1em 0.8em; overflow: hidden; color: inherit; }

.CodeMirror-dialog-top { border-bottom: 1px solid rgb(238, 238, 238); top: 0px; }

.CodeMirror-dialog-bottom { border-top: 1px solid rgb(238, 238, 238); bottom: 0px; }

.CodeMirror-dialog input { border: none; outline: none; background: transparent; width: 20em; color: inherit; font-family: monospace; }

.CodeMirror-dialog button { font-size: 70%; }

.CodeMirror-merge { position: relative; border: 1px solid rgb(221, 221, 221); white-space: pre; }

.CodeMirror-merge, .CodeMirror-merge .CodeMirror { height: 350px; }

.CodeMirror-merge-2pane .CodeMirror-merge-pane { width: 47%; }

.CodeMirror-merge-2pane .CodeMirror-merge-gap { width: 6%; }

.CodeMirror-merge-3pane .CodeMirror-merge-pane { width: 31%; }

.CodeMirror-merge-3pane .CodeMirror-merge-gap { width: 3.5%; }

.CodeMirror-merge-pane { display: inline-block; white-space: normal; vertical-align: top; }

.CodeMirror-merge-pane-rightmost { position: absolute; right: 0px; z-index: 1; }

.CodeMirror-merge-gap { z-index: 2; display: inline-block; height: 100%; box-sizing: border-box; overflow: hidden; border-left: 1px solid rgb(221, 221, 221); border-right: 1px solid rgb(221, 221, 221); position: relative; background: rgb(248, 248, 248); }

.CodeMirror-merge-scrolllock-wrap { position: absolute; bottom: 0px; left: 50%; }

.CodeMirror-merge-scrolllock { position: relative; left: -50%; cursor: pointer; color: rgb(85, 85, 85); line-height: 1; }

.CodeMirror-merge-scrolllock::after { content: "⇛  ⇚"; }

.CodeMirror-merge-scrolllock.CodeMirror-merge-scrolllock-enabled::after { content: "⇛⇚"; }

.CodeMirror-merge-copybuttons-left, .CodeMirror-merge-copybuttons-right { position: absolute; inset: 0px; line-height: 1; }

.CodeMirror-merge-copy { position: absolute; cursor: pointer; color: rgb(68, 68, 204); z-index: 3; }

.CodeMirror-merge-copy-reverse { position: absolute; cursor: pointer; color: rgb(68, 68, 204); }

.CodeMirror-merge-copybuttons-left .CodeMirror-merge-copy { left: 2px; }

.CodeMirror-merge-copybuttons-right .CodeMirror-merge-copy { right: 2px; }

.CodeMirror-merge-r-inserted, .CodeMirror-merge-l-inserted { background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAACCAYAAACddGYaAAAAGUlEQVQI12MwuCXy3+CWyH8GBgYGJgYkAABZbAQ9ELXurwAAAABJRU5ErkJggg=="); background-position: left bottom; background-repeat: repeat-x; }

.CodeMirror-merge-r-deleted, .CodeMirror-merge-l-deleted { background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAACCAYAAACddGYaAAAAGUlEQVQI12M4Kyb2/6yY2H8GBgYGJgYkAABURgPz6Ks7wQAAAABJRU5ErkJggg=="); background-position: left bottom; background-repeat: repeat-x; }

.CodeMirror-merge-r-chunk { background: rgb(255, 255, 224); }

.CodeMirror-merge-r-chunk-start { border-top: 1px solid rgb(238, 238, 136); }

.CodeMirror-merge-r-chunk-end { border-bottom: 1px solid rgb(238, 238, 136); }

.CodeMirror-merge-r-connect { fill: rgb(255, 255, 224); stroke: rgb(238, 238, 136); stroke-width: 1px; }

.CodeMirror-merge-l-chunk { background: rgb(238, 238, 255); }

.CodeMirror-merge-l-chunk-start { border-top: 1px solid rgb(136, 136, 238); }

.CodeMirror-merge-l-chunk-end { border-bottom: 1px solid rgb(136, 136, 238); }

.CodeMirror-merge-l-connect { fill: rgb(238, 238, 255); stroke: rgb(136, 136, 238); stroke-width: 1px; }

.CodeMirror-merge-l-chunk.CodeMirror-merge-r-chunk { background: rgb(221, 255, 221); }

.CodeMirror-merge-l-chunk-start.CodeMirror-merge-r-chunk-start { border-top: 1px solid rgb(68, 238, 68); }

.CodeMirror-merge-l-chunk-end.CodeMirror-merge-r-chunk-end { border-bottom: 1px solid rgb(68, 238, 68); }

.CodeMirror-merge-collapsed-widget::before { content: "(...)"; }

.CodeMirror-merge-collapsed-widget { cursor: pointer; color: rgb(136, 136, 187); background: rgb(238, 238, 255); border: 1px solid rgb(221, 221, 255); font-size: 90%; padding: 0px 3px; border-radius: 4px; }

.CodeMirror-merge-collapsed-line .CodeMirror-gutter-elt { display: none; }

.cm-s-github-light.CodeMirror { background: var(--color-codemirror-bg); color: var(--color-codemirror-text); }

.cm-s-github-light .CodeMirror-gutters { background: var(--color-codemirror-gutters-bg); border-right-width: 0px; }

.cm-s-github-light .CodeMirror-guttermarker { color: var(--color-codemirror-guttermarker-text); }

.cm-s-github-light .CodeMirror-guttermarker-subtle { color: var(--color-codemirror-guttermarker-subtle-text); }

.cm-s-github-light .CodeMirror-linenumber { color: var(--color-codemirror-linenumber-text); padding: 0px 16px; }

.cm-s-github-light .CodeMirror-cursor { border-left: 1px solid var(--color-codemirror-cursor); }

.cm-s-github-light.CodeMirror-focused .CodeMirror-selected, .cm-s-github-light .CodeMirror-line::selection, .cm-s-github-light .CodeMirror-line > span::selection, .cm-s-github-light .CodeMirror-line > span > span::selection { background: var(--color-codemirror-selection-bg, #d7d4f0); }

.cm-s-github-light .CodeMirror-activeline-background { background: var(--color-codemirror-activeline-bg); }

.cm-s-github-light .CodeMirror-matchingbracket { text-decoration: underline; color: var(--color-codemirror-matchingbracket-text)  !important; }

.cm-s-github-light .CodeMirror-lines { font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, Courier, monospace; font-size: 12px; background: var(--color-codemirror-lines-bg); line-height: 1.5; }

.cm-s-github-light .cm-comment { color: var(--color-codemirror-syntax-comment); }

.cm-s-github-light .cm-constant { color: var(--color-codemirror-syntax-constant); }

.cm-s-github-light .cm-entity { font-weight: normal; font-style: normal; text-decoration: none; color: var(--color-codemirror-syntax-entity); }

.cm-s-github-light .cm-keyword { font-weight: normal; font-style: normal; text-decoration: none; color: var(--color-codemirror-syntax-keyword); }

.cm-s-github-light .cm-storage { color: var(--color-codemirror-syntax-storage); }

.cm-s-github-light .cm-string { font-weight: normal; font-style: normal; text-decoration: none; color: var(--color-codemirror-syntax-string); }

.cm-s-github-light .cm-support { font-weight: normal; font-style: normal; text-decoration: none; color: var(--color-codemirror-syntax-support); }

.cm-s-github-light .cm-variable { font-weight: normal; font-style: normal; text-decoration: none; color: var(--color-codemirror-syntax-variable); }

details-dialog { position: fixed; margin: 10vh auto; top: 0px; left: 50%; transform: translateX(-50%); z-index: 999; max-height: 80vh; max-width: 90vw; width: 448px; }

.user-select-contain { }

.ajax-pagination-form .ajax-pagination-btn { width: 100%; padding: 6px; margin-top: 20px; font-weight: 600; color: var(--color-accent-fg); background: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.ajax-pagination-form .ajax-pagination-btn:hover, .ajax-pagination-form .ajax-pagination-btn:focus { color: var(--color-accent-fg); background-color: var(--color-canvas-subtle); }

.ajax-pagination-form.loading .ajax-pagination-btn { text-indent: -3000px; background-color: var(--color-canvas-subtle); background-image: url("/images/spinners/octocat-spinner-16px-EAF2F5.gif"); background-repeat: no-repeat; background-position: center center; border-color: var(--color-border-default); }

@media only screen and (-webkit-min-device-pixel-ratio: 2), not all, not all, not all, only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
  .ajax-pagination-form.loading .ajax-pagination-btn { background-image: url("/images/spinners/octocat-spinner-32-EAF2F5.gif"); background-size: 16px; }
}

body.intent-mouse [role="button"]:focus, body.intent-mouse [role="tabpanel"][tabindex="0"]:focus, body.intent-mouse button:focus, body.intent-mouse summary:focus, body.intent-mouse a:focus { outline: none; box-shadow: none; }

body.intent-mouse [tabindex="0"]:focus, body.intent-mouse details-dialog:focus { outline: none; }

.CodeMirror { height: calc(100vh - 1px); }

.file-editor-textarea { width: 100%; padding: 5px 4px; font: 12px ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; resize: vertical; border: 0px; border-radius: 0px; outline: none; }

.container-preview .tabnav-tabs { margin: -6px 0px -6px -11px; }

.container-preview .tabnav-tabs .tabnav-tab { padding: 12px 15px; border-radius: 0px; }

.container-preview .tabnav-tabs > .selected:first-child { border-top-left-radius: 6px; }

.container-preview .tabnav-tabs .selected { font-weight: 600; }

.container-preview.template-editor .commit-create, .container-preview.template-editor .file-actions { display: block; }

.container-preview.template-editor .show-code, .container-preview.template-editor .commit-preview, .container-preview.template-editor .loading-preview-msg, .container-preview.template-editor .no-changes-preview-msg, .container-preview.template-editor .error-preview-msg { display: none !important; }

.container-preview.render-editor .commit-create, .container-preview.render-editor .file-actions { display: block; }

.container-preview.render-editor .template-editor, .container-preview.render-editor .show-code, .container-preview.render-editor .commit-preview, .container-preview.render-editor .loading-preview-msg, .container-preview.render-editor .no-changes-preview-msg, .container-preview.render-editor .error-preview-msg { display: none !important; }

.container-preview.show-code .commit-create, .container-preview.show-code .file-actions { display: block; }

.container-preview.show-code .template-editor, .container-preview.show-code .render-editor, .container-preview.show-code .commit-preview, .container-preview.show-code .loading-preview-msg, .container-preview.show-code .no-changes-preview-msg, .container-preview.show-code .error-preview-msg { display: none !important; }

.container-preview:not(.show-code) .commit-create, .container-preview:not(.show-code) .file-actions { display: none !important; }

.container-preview.loading-preview .loading-preview-msg { display: block; }

.container-preview.loading-preview .template-editor, .container-preview.loading-preview .render-editor, .container-preview.loading-preview .no-changes-preview-msg, .container-preview.loading-preview .error-preview-msg, .container-preview.loading-preview .commit-preview { display: none !important; }

.container-preview.show-preview .commit-preview { display: block; }

.container-preview.show-preview .template-editor, .container-preview.show-preview .render-editor, .container-preview.show-preview .loading-preview-msg, .container-preview.show-preview .no-changes-preview-msg, .container-preview.show-preview .error-preview-msg { display: none !important; }

.container-preview.no-changes-preview .no-changes-preview-msg { display: block; }

.container-preview.no-changes-preview .template-editor, .container-preview.no-changes-preview .render-editor, .container-preview.no-changes-preview .loading-preview-msg, .container-preview.no-changes-preview .error-preview-msg, .container-preview.no-changes-preview .commit-preview { display: none !important; }

.container-preview.error-preview .error-preview-msg { display: block; }

.container-preview.error-preview .template-editor, .container-preview.error-preview .render-editor, .container-preview.error-preview .loading-preview-msg, .container-preview.error-preview .no-changes-preview-msg, .container-preview.error-preview .commit-preview { display: none !important; }

.container-preview p.preview-msg { padding: 30px; font-size: 16px; }

.CodeMirror-merge-header { height: 30px; }

.CodeMirror-merge-header .CodeMirror-merge-pane { height: 30px; line-height: 30px; }

.cm-s-github-light .merge-gutter { width: 14px; }

.conflict-background + .CodeMirror-gutter-wrapper .CodeMirror-linenumber { background-color: var(--color-attention-subtle); }

.conflict-gutter-marker { background-color: var(--color-attention-subtle); }

.conflict-gutter-marker::after, .conflict-gutter-marker::before { position: absolute; left: -1px; content: ""; background-color: var(--color-danger-fg); }

.conflict-gutter-marker-start::after, .conflict-gutter-marker-end::after { width: 1px; height: 10px; }

.conflict-gutter-marker-start::before, .conflict-gutter-marker-middle::before, .conflict-gutter-marker-end::before { width: 10px; height: 1px; }

.conflict-gutter-marker-start::after { bottom: 0px; }

.conflict-gutter-marker-end::after { top: 0px; }

.conflict-gutter-marker-start::before { top: 7px; }

.conflict-gutter-marker-end::before { bottom: 7px; }

.conflict-gutter-marker-line::after, .conflict-gutter-marker-middle::after { width: 1px; height: 18px; }

.conflict-gutter-marker-middle::before { top: 9px; }

.form-group .edit-action { opacity: 0.6; }

.form-group .form-field-hover { border: 1px solid var(--color-border-default); }

.form-group:hover .edit-action { cursor: pointer; opacity: 0.7; }

.form-group:hover .form-field-hover { cursor: pointer; border: 1px solid var(--color-border-default); }

.placeholder-box { border: 1px solid var(--color-border-default); }

.template-previews { max-width: 768px; }

.template-previews .Box .expand-group { display: none; height: 0px; }

.template-previews .Box .dismiss-preview-button { display: none; }

.template-previews .Box.expand-preview .expand-group { display: block; height: 100%; transition: height 3s ease 0s; }

.template-previews .Box.expand-preview .preview-button { display: none; }

.template-previews .Box.expand-preview .dismiss-preview-button { display: inline; }

.template-previews .discussion-sidebar-heading { font-size: 14px; color: var(--color-neutral-emphasis); }

.template-previews .discussion-sidebar-heading:hover { color: var(--color-accent-emphasis); }

.edit-labels { display: none; }

.preview-section { display: block; }

.edit-section { display: none; }

.Box .section-focus .preview-section { display: none; }

.Box .section-focus .edit-section { display: block; }

.commit-create .CodeMirror { padding-top: 8px; }

auto-complete, details-dialog, details-menu, file-attachment, filter-input, include-fragment, poll-include-fragment, remote-input, tab-container, text-expander, [data-catalyst] { display: block; }

.Details--on .Details-content--shown { display: none !important; }

.Details:not(.Details--on) .Details-content--hidden { display: none !important; }

.Details:not(.Details--on) .Details-content--hidden-not-important { display: none; }

.Details-element[open] > summary .Details-content--closed { display: none !important; }

.Details-element:not([open]) > summary .Details-content--open { display: none !important; }

g-emoji { font-family: "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"; font-size: 1em; font-weight: 400; line-height: 1; vertical-align: -0.075em; font-style: normal !important; }

g-emoji img { width: 1em; height: 1em; }

.emoji-icon { display: inline-block; width: 20px; height: 20px; vertical-align: middle; background-repeat: no-repeat; background-size: 20px 20px; }

.emoji-result { display: inline-block; height: 20px; font-size: 18px; font-weight: 400; vertical-align: middle; }

.gollum-editor .comment-form-head.tabnav { border: 1px solid var(--color-border-muted); }

.gollum-editor .gollum-editor-body { height: 390px; resize: vertical; }

.active .gollum-editor-function-buttons { display: block !important; }

.auth-form { width: 340px; margin: 0px auto; }

.auth-form .form-group.warn .warning, .auth-form .form-group.warn .error, .auth-form .form-group.errored .warning, .auth-form .form-group.errored .error { max-width: 274px; }

.auth-form-header { padding: 10px 20px; margin: 0px; color: rgb(255, 255, 255); text-shadow: rgba(0, 0, 0, 0.3) 0px -1px 0px; background-color: rgb(130, 154, 168); border: 1px solid rgb(118, 137, 149); border-radius: 6px 6px 0px 0px; }

.auth-form-header h1 { font-size: 16px; }

.auth-form-header h1 a { color: rgb(255, 255, 255); }

.auth-form-header .octicon { position: absolute; top: 10px; right: 20px; color: rgba(0, 0, 0, 0.4); text-shadow: rgba(255, 255, 255, 0.1) 0px 1px 0px; }

.auth-form-message { max-height: 140px; padding: 20px 20px 10px; overflow-y: scroll; border: 1px solid var(--color-border-default); border-radius: 6px; }

.auth-form-message ol, .auth-form-message ul { padding-left: inherit; margin-bottom: inherit; }

.auth-form-body { padding: 20px; font-size: 14px; background-color: var(--color-canvas-subtle); border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: ; border-bottom-width: ; border-left-color: ; border-left-style: ; border-left-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-top: 0px; border-radius: 0px 0px 6px 6px; }

.auth-form-body .input-block { margin-top: 5px; margin-bottom: 15px; }

.auth-form-body p { margin-bottom: 0px; }

.auth-form-body ol, .auth-form-body ul { padding-left: inherit; margin-bottom: inherit; }

.two-factor-help { position: relative; padding: 10px 10px 10px 36px; margin: 60px 0px auto auto; border: 1px solid var(--color-border-muted); border-radius: 6px; }

.two-factor-help h4 { margin-top: 0px; margin-bottom: 5px; }

.two-factor-help .octicon-device-mobile, .two-factor-help .octicon-key, .two-factor-help .octicon-shield-lock, .two-factor-help .octicon-circle-slash { position: absolute; top: 10px; left: 10px; }

.sms-send-code-spinner { position: relative; bottom: 2px; display: none; vertical-align: bottom; }

.loading .sms-send-code-spinner { display: inline; }

.auth-form-body .webauthn-form-body { padding: 0px; }

.webauthn-form-body { padding: 30px 30px 20px; text-align: center; }

.webauthn-form-body button { margin-top: 20px; }

.flash.sms-error, .flash.sms-success { display: none; margin: 0px 0px 10px; }

.is-sent .sms-success { display: block; }

.is-sent .sms-error { display: none; }

.is-not-sent .sms-success { display: none; }

.is-not-sent .sms-error { display: block; }

.session-authentication { background-color: var(--color-canvas-default); }

.session-authentication .header-logged-out { background-color: transparent; border-bottom: 0px; }

.session-authentication .header-logo { color: var(--color-fg-default); }

.session-authentication .flash { padding: 15px 20px; margin: 0px auto 10px; font-size: 13px; border-style: solid; border-width: 1px; border-radius: 6px; }

.session-authentication .flash .container { width: auto; }

.session-authentication .flash .flash-close { height: 40px; }

.session-authentication .flash.flash-banner { width: 100%; border-top: 0px; border-right: 0px; border-left: 0px; border-radius: 0px; }

.session-authentication .auth-form label { display: block; margin-bottom: 7px; font-weight: 400; text-align: left; }

.session-authentication .auth-form .btn { margin-top: 20px; }

.session-authentication .auth-form .webauthn-message { margin-bottom: 0px; }

.session-authentication .label-link { float: right; font-size: 12px; }

.session-authentication .auth-form-header { margin-bottom: 15px; color: var(--color-fg-default); text-align: center; text-shadow: none; background-color: transparent; border: 0px; }

.session-authentication .auth-form-header h1 { font-size: 24px; font-weight: 300; letter-spacing: -0.5px; }

.session-authentication .auth-form-body { border-top: 1px solid var(--color-border-muted); border-radius: 6px; }

.session-authentication .auth-form-body.webauthn-form-body { padding: 20px; }

.session-authentication .login-callout { padding: 15px 20px; text-align: center; border: 1px solid var(--color-border-default); border-radius: 6px; }

.session-authentication .two-factor-help { padding: 0px 0px 0px 20px; margin-top: 20px; border: 0px; }

.session-authentication .two-factor-help .octicon-device-mobile, .session-authentication .two-factor-help .octicon-key, .session-authentication .two-factor-help .octicon-shield-lock, .session-authentication .two-factor-help .octicon-circle-slash { top: 4px; left: 0px; }

.session-authentication.enterprise .header-logged-out { padding: 48px 0px 28px; background-color: transparent; }

.session-authentication.hosted .header-logged-out { padding: 40px 0px 20px; background-color: transparent; }

.Header-old { z-index: 32; padding-top: 12px; padding-bottom: 12px; color: rgb(255, 255, 255); background-color: var(--color-header-bg); }

.server-stats + .Header-old { box-shadow: rgba(255, 255, 255, 0.075) 0px 1px 0px inset; }

.Header-old .dropdown-menu { width: 300px; }

.Header-old .notification-indicator:hover::after { content: none; }

@media (min-width: 1012px) {
  .Header-old .notification-indicator:hover::after { content: attr(aria-label); }
}

.HeaderMenu { display: none; clear: both; }

@media (min-width: 1012px) {
  .HeaderMenu { display: block; clear: none; }
}

.open .HeaderMenu { display: block; }

.HeaderMenu-summary::marker, .HeaderMenu-summary::-webkit-details-marker { display: none; }

@keyframes dropdown-display { 
  0% { opacity: 0; transform: scale(0.98) translateY(-0.6em); }
  100% { opacity: 1; transform: scale(1) translateY(0px); }
}

.HeaderMenu--logged-out { z-index: 100; width: 300px; overflow: auto; background-color: var(--color-canvas-default); box-shadow: rgba(27, 31, 35, 0.15) 0px 10px 50px; }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out { width: auto; overflow: visible; background-color: transparent; box-shadow: none; }
}

.HeaderMenu--logged-out .jump-to-suggestions { top: 100%; }

.HeaderMenu--logged-out .HeaderMenu-details[open] > summary::before { position: absolute; bottom: -8px; display: block; }

.HeaderMenu--logged-out .header-search-key-slash { margin-right: 8px !important; }

.HeaderMenu--logged-out .dropdown-menu { position: static; width: auto; border: 0px solid transparent; box-shadow: none; }

.HeaderMenu--logged-out .dropdown-menu::before, .HeaderMenu--logged-out .dropdown-menu::after { display: none; }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out .dropdown-menu { position: absolute; width: 300px; border: 0px; box-shadow: rgba(27, 31, 35, 0.15) 0px 3px 12px, rgba(27, 31, 35, 0.2) 0px 0px 1px; }
  .HeaderMenu--logged-out .dropdown-menu::before, .HeaderMenu--logged-out .dropdown-menu::after { content: ""; }
}

.HeaderMenu--logged-out .dropdown-menu-s { transform: none; }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out .dropdown-menu-s { transform: translateX(50%); }
}

.HeaderMenu--logged-out .header-search { width: auto; border-top: 0px; }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out .header-search { width: 240px; }
}

.HeaderMenu--logged-out .header-search-wrapper { border-color: var(--color-border-muted); }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out .header-search-wrapper { border-color: var(--color-header-search-border); }
}

@media (max-width: 1012px) {
  .HeaderMenu--logged-out .header-search-wrapper { background-color: var(--color-canvas-default); }
}

.HeaderMenu--logged-out .header-search-input { padding-top: 8px; padding-bottom: 8px; font-size: 14px; appearance: none; color: var(--color-fg-default); }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out .header-search-input { color: inherit; }
}

.HeaderMenu--logged-out .header-search-input::placeholder { color: var(--color-fg-muted)  !important; }

@media (min-width: 1012px) {
  .HeaderMenu--logged-out .header-search-input::placeholder { color: rgba(255, 255, 255, 0.75) !important; }
}

.HeaderMenu-link { color: var(--color-fg-default); white-space: nowrap; background: transparent; transition: opacity 0.4s ease 0s; }

.HeaderMenu-link:hover { color: var(--color-fg-default); opacity: 0.75; }

@media (min-width: 1012px) {
  .HeaderMenu-link { color: rgb(255, 255, 255); transition: opacity 0.4s ease 0s; }
  .HeaderMenu-link:hover { color: rgb(255, 255, 255); opacity: 0.75; }
}

.HeaderMenu-link .icon-chevon-down-mktg { top: 24px; right: 0px; width: 14px; stroke: var(--color-fg-default); transition: stroke 0.4s ease 0s; }

@media (min-width: 1012px) {
  .HeaderMenu-link .icon-chevon-down-mktg { top: -2px; width: 12px; stroke: rgba(255, 255, 255, 0.5); background: transparent; }
}

.HeaderMenu-details[open] > summary::before { display: none; }

@media (min-width: 1012px) {
  .HeaderMenu-details[open] > summary::before { position: absolute; bottom: -8px; display: block; }
}

.HeaderMenu-details[open] .HeaderMenu-link { color: var(--color-fg-default); }

@media (min-width: 1012px) {
  .HeaderMenu-details[open] .HeaderMenu-link { color: rgba(255, 255, 255, 0.75); }
}

.HeaderMenu-details[open] .dropdown-menu { animation: 0s ease 0s 1 normal none running none; }

@media (min-width: 1012px) {
  .HeaderMenu-details[open] .dropdown-menu { animation: 0.4s cubic-bezier(0.73, 0.005, 0.22, 1) 0s 1 normal none running dropdown-display; }
}

.HeaderMenu-details[open] .icon-chevon-down-mktg { stroke: var(--color-fg-default); }

@media (min-width: 1012px) {
  .HeaderMenu-details[open] .icon-chevon-down-mktg { stroke: rgb(255, 255, 255); }
}

.header-logo-invertocat { margin: -1px 15px -1px -2px; color: rgb(255, 255, 255); white-space: nowrap; }

.header-logo-invertocat .octicon-mark-github { float: left; }

.header-logo-invertocat:hover { color: rgb(255, 255, 255); text-decoration: none; }

.notification-indicator .mail-status { position: absolute; top: -6px; left: 6px; z-index: 2; display: none; width: 14px; height: 14px; color: rgb(255, 255, 255); background-image: linear-gradient(rgb(84, 163, 255), rgb(0, 110, 237)); background-clip: padding-box; border: 2px solid var(--color-header-bg); border-radius: 50%; }

.notification-indicator .mail-status.unread { display: inline-block; }

.notification-indicator:hover .mail-status { text-decoration: none; background-color: var(--color-accent-emphasis); }

.header-nav-current-user { padding-bottom: 0px; font-size: inherit; }

.header-nav-current-user .css-truncate-target { max-width: 100%; }

.header-nav-current-user .user-profile-link { color: var(--color-fg-default); }

.feature-preview-indicator { position: absolute; top: 0px; left: 13px; z-index: 2; width: 14px; height: 14px; color: rgb(255, 255, 255); background-image: linear-gradient(rgb(84, 163, 255), rgb(0, 110, 237)); background-clip: padding-box; border: 2px solid var(--color-header-bg); border-radius: 50%; }

.feature-preview-details .feature-preview-indicator { top: 9px; right: 10px; left: inherit; width: 10px; height: 10px; border: 0px; }

.unsupported-browser { color: var(--color-fg-default); background-color: var(--color-attention-subtle); border-bottom: 1px solid var(--color-attention-emphasis); }

.header-search-wrapper { display: table; width: 100%; max-width: 100%; padding: 0px; font-size: inherit; font-weight: 400; color: var(--color-scale-white); vertical-align: middle; background-color: var(--color-header-search-bg); border: 1px solid var(--color-header-search-border); box-shadow: none; }

.header-search-wrapper.header-search-wrapper-jump-to .header-search-scope { width: fit-content; }

.header-search-wrapper .truncate-repo-scope { max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.header-search-wrapper.focus { background-color: rgba(255, 255, 255, 0.176); box-shadow: none; }

.header-search-wrapper.focus .header-search-scope { color: var(--color-scale-white); background-color: rgba(255, 255, 255, 0.075); border-right-color: rgb(40, 46, 52); }

.header-search-input { display: table-cell; width: 100%; padding-top: 0px; padding-bottom: 0px; font-size: inherit; color: inherit; background: none; border: 0px; box-shadow: none; }

.header-search-input::placeholder { color: rgba(255, 255, 255, 0.75); }

.header-search-input:focus { border: 0px; box-shadow: none; }

.header-search-input:focus ~ .header-search-key-slash { display: none !important; }

.header-search-scope { display: none; padding-right: 8px; padding-left: 8px; font-size: inherit; line-height: 28px; color: rgba(255, 255, 255, 0.7); white-space: nowrap; vertical-align: middle; border-right-width: ; border-right-style: ; border-right-color: rgb(40, 46, 52); border-top-left-radius: 6px; border-bottom-left-radius: 6px; }

.header-search-scope:empty + .header-search-input { width: 100%; }

.header-search-scope:hover { color: var(--color-scale-white); background-color: rgba(255, 255, 255, 0.12); }

.scoped-search .header-search-wrapper { display: flex; }

.jump-to-field-active { background-color: var(--color-canvas-subtle); color: var(--color-fg-default)  !important; }

.jump-to-field-active::placeholder { color: var(--color-fg-muted)  !important; }

.jump-to-field-active ~ .header-search-key-slash { display: none; }

.jump-to-field-active.jump-to-dropdown-visible { border-bottom-right-radius: 0px; border-bottom-left-radius: 0px; }

.jump-to-suggestions { top: 100%; left: 0px; z-index: 35; width: 100%; border-radius: 0px 0px 6px 6px; box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 10px; }

.jump-to-suggestions-path { min-width: 0px; min-height: 44px; color: var(--color-fg-default); }

.jump-to-suggestions-path .jump-to-octicon { width: 28px; color: var(--color-fg-muted); }

.jump-to-suggestions-path .jump-to-suggestion-name { max-width: none; }

.jump-to-suggestions-path mark { font-weight: 600; background-color: transparent; }

.jump-to-suggestions-results-container .navigation-item { border-bottom: 1px solid var(--color-border-default); }

.jump-to-suggestions-results-container .navigation-item:last-child { border-bottom: 0px; }

.jump-to-suggestions-results-container .d-on-nav-focus { display: none; }

.jump-to-suggestions-results-container [aria-selected="true"] .jump-to-octicon, .jump-to-suggestions-results-container .navigation-focus .jump-to-octicon { color: var(--color-fg-on-emphasis); }

.jump-to-suggestions-results-container [aria-selected="true"] .jump-to-suggestions-path, .jump-to-suggestions-results-container .navigation-focus .jump-to-suggestions-path { color: var(--color-fg-on-emphasis); background: var(--color-accent-emphasis); }

.jump-to-suggestions-results-container [aria-selected="true"] mark, .jump-to-suggestions-results-container .navigation-focus mark { color: var(--color-fg-on-emphasis); }

.jump-to-suggestions-results-container [aria-selected="true"] .d-on-nav-focus, .jump-to-suggestions-results-container .navigation-focus .d-on-nav-focus { display: block; }

.header-search { max-width: 100%; transition: max-width 0.2s ease-in-out 0s, padding-bottom, padding-top; }

@media (min-width: 768px) {
  .header-search { max-width: 272px; }
}

@media (min-width: 768px) {
  .header-search:focus-within { max-width: 544px; }
}

@media (min-width: 768px) {
  .header-search.fixed-width:focus-within { max-width: 272px; }
}

.HeaderMenu--logged-out .header-search { min-width: auto; }
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://github.githubassets.com/assets/behaviors-70fcbf0f7f153bb886a34c9570d4a6d9.css

@charset "utf-8";

:root { --border-width: 1px; --border-style: solid; --font-size-small: 12px; --font-weight-semibold: 500; --size-2: 20px; }

.flash { position: relative; padding: 20px 16px; border-style: solid; border-width: 1px; border-radius: 6px; }

.flash p:last-child { margin-bottom: 0px; }

.flash .octicon { margin-right: 12px; }

.flash-messages { margin-bottom: 24px; }

.flash-close { float: right; padding: 16px; margin: -16px; text-align: center; cursor: pointer; background: none; border: 0px; appearance: none; }

.flash-close:hover { opacity: 0.7; }

.flash-close:active { opacity: 0.5; }

.flash-close .octicon { margin-right: 0px; }

.flash-action { float: right; margin-top: -3px; margin-left: 24px; background-clip: padding-box; }

.flash-action.btn .octicon { margin-right: 4px; color: var(--color-fg-muted); }

.flash-action.btn-primary .octicon { color: inherit; }

.flash { color: var(--color-fg-default); background-image: linear-gradient(var(--color-accent-subtle), var(--color-accent-subtle)); border-color: var(--color-accent-muted); }

.flash .octicon { color: var(--color-accent-fg); }

.flash-warn { color: var(--color-fg-default); background-image: linear-gradient(var(--color-attention-subtle), var(--color-attention-subtle)); border-color: var(--color-attention-muted); }

.flash-warn .octicon { color: var(--color-attention-fg); }

.flash-error { color: var(--color-fg-default); background-image: linear-gradient(var(--color-danger-subtle), var(--color-danger-subtle)); border-color: var(--color-danger-muted); }

.flash-error .octicon { color: var(--color-danger-fg); }

.flash-success { color: var(--color-fg-default); background-image: linear-gradient(var(--color-success-subtle), var(--color-success-subtle)); border-color: var(--color-success-muted); }

.flash-success .octicon { color: var(--color-success-fg); }

.flash-full { margin-top: -1px; border-width: 1px 0px; border-radius: 0px; }

.flash-banner { position: fixed; top: 0px; z-index: 90; width: 100%; border-top: 0px; border-right: 0px; border-left: 0px; border-radius: 0px; }

.flash-full, .flash-banner { background-color: var(--color-canvas-default); }

.warning { padding: 0.5em; margin-bottom: 0.8em; font-weight: 600; background-color: var(--color-attention-subtle); }

.autocomplete-results { position: absolute; z-index: 99; width: 100%; max-height: 20em; overflow-y: auto; font-size: 13px; list-style: none; background: var(--color-canvas-overlay); border: 1px solid var(--color-border-default); border-radius: 6px; box-shadow: var(--color-shadow-medium); }

.autocomplete-item { display: block; width: 100%; padding: 4px 8px; overflow: hidden; font-weight: 600; color: var(--color-fg-default); text-align: left; text-decoration: none; text-overflow: ellipsis; white-space: nowrap; cursor: pointer; background-color: var(--color-canvas-overlay); border: 0px; }

.autocomplete-item:hover { color: var(--color-fg-on-emphasis); text-decoration: none; background-color: var(--color-accent-emphasis); }

.autocomplete-item:hover * { color: inherit !important; }

.autocomplete-item.selected, .autocomplete-item[aria-selected="true"], .autocomplete-item.navigation-focus { color: var(--color-fg-on-emphasis); text-decoration: none; background-color: var(--color-accent-emphasis); }

.autocomplete-item.selected *, .autocomplete-item[aria-selected="true"] *, .autocomplete-item.navigation-focus * { color: inherit !important; }

.suggester { position: relative; top: 0px; left: 0px; min-width: 180px; padding: 0px; margin: 24px 0px 0px; list-style: none; cursor: pointer; background: var(--color-canvas-overlay); border: 1px solid var(--color-border-default); border-radius: 6px; box-shadow: var(--color-shadow-medium); }

.suggester li { display: block; padding: 4px 8px; font-weight: 500; border-bottom: 1px solid var(--color-border-muted); }

.suggester li small { font-weight: 400; color: var(--color-fg-muted); }

.suggester li:last-child { border-bottom: 0px; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.suggester li:first-child { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.suggester li:hover { color: var(--color-fg-on-emphasis); text-decoration: none; background: var(--color-accent-emphasis); }

.suggester li:hover small { color: var(--color-fg-on-emphasis); }

.suggester li:hover .octicon { color: inherit !important; }

.suggester li[aria-selected="true"], .suggester li.navigation-focus { color: var(--color-fg-on-emphasis); text-decoration: none; background: var(--color-accent-emphasis); }

.suggester li[aria-selected="true"] small, .suggester li.navigation-focus small { color: var(--color-fg-on-emphasis); }

.suggester li[aria-selected="true"] .octicon, .suggester li.navigation-focus .octicon { color: inherit !important; }

.suggester-container { position: absolute; top: 0px; left: 0px; z-index: 30; }

@media (max-width: 544px) {
  .page-responsive .suggester-container { right: 8px !important; left: 8px !important; }
  .page-responsive .suggester li { padding: 8px 16px; }
}

.avatar { display: inline-block; overflow: hidden; line-height: 1; vertical-align: middle; background-color: var(--color-avatar-bg); border-radius: 6px; flex-shrink: 0; box-shadow: 0 0 0 1px var(--color-avatar-border); }

.avatar-link { float: left; line-height: 1; }

.avatar-group-item { display: inline-block; margin-bottom: 3px; }

.avatar-1, .avatar-2, .avatar-small { border-radius: 4px; }

.avatar-1 { width: 16px; height: 16px; }

.avatar-2 { width: 20px; height: 20px; }

.avatar-3 { width: 24px; height: 24px; }

.avatar-4 { width: 28px; height: 28px; }

.avatar-5 { width: 32px; height: 32px; }

.avatar-6 { width: 40px; height: 40px; }

.avatar-7 { width: 48px; height: 48px; }

.avatar-8 { width: 64px; height: 64px; }

.avatar-parent-child { position: relative; }

.avatar-child { position: absolute; right: -15%; bottom: -9%; background-color: var(--color-canvas-default); border-radius: 4px; box-shadow: var(--color-avatar-child-shadow); }

.AvatarStack { position: relative; min-width: 26px; height: 20px; }

.AvatarStack .AvatarStack-body { position: absolute; }

.AvatarStack.AvatarStack--two { min-width: 36px; }

.AvatarStack.AvatarStack--three-plus { min-width: 46px; }

.AvatarStack-body { display: flex; background: var(--color-canvas-default); }

.AvatarStack-body .avatar { position: relative; z-index: 2; display: flex; width: 20px; height: 20px; box-sizing: content-box; margin-right: -11px; background-color: var(--color-canvas-default); border-right: 1px solid var(--color-canvas-default); border-radius: 4px; transition: margin 0.1s ease-in-out 0s; }

.AvatarStack-body .avatar:first-child { z-index: 3; }

.AvatarStack-body .avatar:last-child { z-index: 1; border-right: 0px; }

.AvatarStack-body .avatar img { border-radius: 4px; }

.AvatarStack-body .avatar:nth-child(n+4) { display: none; opacity: 0; }

.AvatarStack-body:hover .avatar { margin-right: 3px; }

.AvatarStack-body:hover .avatar:nth-child(n+4) { display: flex; opacity: 1; }

.AvatarStack-body:hover .avatar-more { display: none !important; }

.avatar.avatar-more { z-index: 1; margin-right: 0px; background: var(--color-canvas-subtle); }

.avatar.avatar-more::before, .avatar.avatar-more::after { position: absolute; display: block; height: 20px; content: ""; border-radius: 2px; outline: 1px solid var(--color-canvas-default); }

.avatar.avatar-more::before { width: 17px; background: var(--color-avatar-stack-fade-more); }

.avatar.avatar-more::after { width: 14px; background: var(--color-avatar-stack-fade); }

.AvatarStack--right .AvatarStack-body { right: 0px; flex-direction: row-reverse; }

.AvatarStack--right .AvatarStack-body:hover .avatar { margin-right: 0px; margin-left: 3px; }

.AvatarStack--right .avatar.avatar-more { background: var(--color-avatar-stack-fade); }

.AvatarStack--right .avatar.avatar-more::before { width: 5px; }

.AvatarStack--right .avatar.avatar-more::after { width: 2px; background: var(--color-canvas-subtle); }

.AvatarStack--right .avatar { margin-right: 0px; margin-left: -11px; border-right: 0px; border-left: 1px solid var(--color-canvas-default); }

.CircleBadge { display: flex; align-items: center; justify-content: center; background-color: var(--color-canvas-default); border-radius: 50%; box-shadow: var(--color-shadow-medium); }

.CircleBadge-icon { max-width: 60% !important; height: auto !important; max-height: 55% !important; }

.CircleBadge--small { width: 56px; height: 56px; }

.CircleBadge--medium { width: 96px; height: 96px; }

.CircleBadge--large { width: 128px; height: 128px; }

.DashedConnection { position: relative; }

.DashedConnection::before { position: absolute; top: 50%; left: 0px; width: 100%; content: ""; border-bottom: 2px dashed var(--color-border-default); }

.DashedConnection .CircleBadge { position: relative; }

.blankslate { position: relative; padding: 32px; text-align: center; }

.blankslate p { color: var(--color-fg-muted); }

.blankslate code { padding: 2px 5px 3px; font-size: 14px; background: var(--color-canvas-default); border: 1px solid var(--color-border-muted); border-radius: 6px; }

.blankslate img { width: 56px; height: 56px; }

.blankslate-icon { margin-right: 4px; margin-bottom: 8px; margin-left: 4px; color: var(--color-fg-muted); }

.blankslate-capped { border-radius: 0px 0px 6px 6px; }

.blankslate-spacious { padding: 80px 40px; }

.blankslate-narrow { max-width: 485px; margin: 0px auto; }

.blankslate-large img { width: 80px; height: 80px; }

.blankslate-large h3 { margin: 16px 0px; font-size: 24px; }

.blankslate-large p { font-size: 16px; }

.blankslate-clean-background { border: 0px; }

.branch-name { display: inline-block; padding: 2px 6px; font: 12px ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; color: var(--color-fg-muted); background-color: var(--color-accent-subtle); border-radius: 6px; }

.branch-name .octicon { margin: 1px -2px 0px 0px; color: var(--color-fg-muted); }

a.branch-name { color: var(--color-accent-fg); background-color: var(--color-accent-subtle); }

a.branch-name .octicon { color: var(--color-accent-fg); }

.dropdown { position: relative; }

.dropdown-caret { display: inline-block; width: 0px; height: 0px; vertical-align: middle; content: ""; border-style: solid; border-width: 4px 4px 0px; border-right-color: transparent; border-bottom-color: transparent; border-left-color: transparent; }

.dropdown-menu { position: absolute; top: 100%; left: 0px; z-index: 100; width: 160px; padding-top: 4px; padding-bottom: 4px; margin-top: 2px; list-style: none; background-color: var(--color-canvas-overlay); background-clip: padding-box; border: 1px solid var(--color-border-default); border-radius: 6px; box-shadow: var(--color-shadow-large); }

.dropdown-menu::before, .dropdown-menu::after { position: absolute; display: inline-block; content: ""; }

.dropdown-menu::before { border-width: 8px; border-style: solid; border-top-color: transparent; border-right-color: transparent; border-left-color: transparent; border-image: initial; border-bottom-color: var(--color-border-default); }

.dropdown-menu::after { border-width: 7px; border-style: solid; border-top-color: transparent; border-right-color: transparent; border-left-color: transparent; border-image: initial; border-bottom-color: var(--color-canvas-overlay); }

.dropdown-menu > ul { list-style: none; }

.dropdown-menu-no-overflow { width: auto; }

.dropdown-menu-no-overflow .dropdown-item { padding: 4px 16px; overflow: visible; text-overflow: inherit; }

.dropdown-item { display: block; padding: 4px 8px 4px 16px; overflow: hidden; color: var(--color-fg-default); text-overflow: ellipsis; white-space: nowrap; }

.dropdown-item:focus, .dropdown-item:hover { color: var(--color-fg-on-emphasis); text-decoration: none; background-color: var(--color-accent-emphasis); outline: none; }

.dropdown-item:focus > .octicon, .dropdown-item:hover > .octicon { color: inherit; opacity: 1; }

.dropdown-item:focus [class*="color-text-"], .dropdown-item:hover [class*="color-text-"] { color: inherit !important; }

.dropdown-item:focus > .Label, .dropdown-item:hover > .Label { border-color: currentcolor; color: inherit !important; }

.dropdown-item.btn-link { width: 100%; text-align: left; }

.dropdown-signout { width: 100%; text-align: left; background: none; border: 0px; }

.dropdown-divider { display: block; height: 0px; margin: 8px 0px; border-top: 1px solid var(--color-border-default); }

.dropdown-header { padding: 4px 16px; font-size: 12px; color: var(--color-fg-muted); }

.dropdown-item[aria-checked="false"] .octicon-check { display: none; }

.dropdown-menu-w { top: 0px; right: 100%; left: auto; width: auto; margin-top: 0px; margin-right: 8px; }

.dropdown-menu-w::before { top: 10px; right: -16px; left: auto; border-top-color: transparent; border-right-color: transparent; border-bottom-color: transparent; border-left-color: var(--color-border-default); }

.dropdown-menu-w::after { top: 11px; right: -14px; left: auto; border-top-color: transparent; border-right-color: transparent; border-bottom-color: transparent; border-left-color: var(--color-canvas-overlay); }

.dropdown-menu-e { top: 0px; left: 100%; width: auto; margin-top: 0px; margin-left: 8px; }

.dropdown-menu-e::before { top: 10px; left: -16px; border-top-color: transparent; border-bottom-color: transparent; border-left-color: transparent; border-right-color: var(--color-border-default); }

.dropdown-menu-e::after { top: 11px; left: -14px; border-top-color: transparent; border-bottom-color: transparent; border-left-color: transparent; border-right-color: var(--color-canvas-overlay); }

.dropdown-menu-ne { top: auto; bottom: 100%; left: 0px; margin-bottom: 3px; }

.dropdown-menu-ne::before, .dropdown-menu-ne::after { top: auto; right: auto; }

.dropdown-menu-ne::before { bottom: -8px; left: 9px; border-top: 8px solid var(--color-border-default); border-right: 8px solid transparent; border-bottom: 0px; border-left: 8px solid transparent; }

.dropdown-menu-ne::after { bottom: -7px; left: 10px; border-top: 7px solid var(--color-canvas-overlay); border-right: 7px solid transparent; border-bottom: 0px; border-left: 7px solid transparent; }

.dropdown-menu-s { right: 50%; left: auto; transform: translateX(50%); }

.dropdown-menu-s::before { top: -16px; right: 50%; transform: translateX(50%); }

.dropdown-menu-s::after { top: -14px; right: 50%; transform: translateX(50%); }

.dropdown-menu-sw { right: 0px; left: auto; }

.dropdown-menu-sw::before { top: -16px; right: 9px; left: auto; }

.dropdown-menu-sw::after { top: -14px; right: 10px; left: auto; }

.dropdown-menu-se::before { top: -16px; left: 9px; }

.dropdown-menu-se::after { top: -14px; left: 10px; }

.Header { z-index: 32; display: flex; padding: 16px; font-size: 14px; line-height: 1.5; color: var(--color-header-text); background-color: var(--color-header-bg); align-items: center; flex-wrap: nowrap; }

.Header-item { display: flex; margin-right: 16px; align-self: stretch; align-items: center; flex-wrap: nowrap; }

.Header-item--full { flex: 1 1 auto; }

.Header-link { font-weight: 600; color: var(--color-header-logo); white-space: nowrap; }

.Header-link:hover, .Header-link:focus { color: var(--color-header-text); text-decoration: none; }

.Header-input { color: var(--color-header-text); background-color: var(--color-header-search-bg); border: 1px solid var(--color-header-search-border); box-shadow: none; }

.Header-input::placeholder { color: rgba(255, 255, 255, 0.75); }

.IssueLabel { display: inline-block; padding: 0px 7px; font-size: 12px; font-weight: 500; line-height: 18px; border: 1px solid transparent; border-radius: 2em; }

.IssueLabel .g-emoji { position: relative; top: -0.05em; display: inline-block; font-size: 1em; line-height: 1; }

.IssueLabel:hover { text-decoration: none; }

.IssueLabel--big { padding-right: 10px; padding-left: 10px; line-height: 22px; }

.labels { position: relative; }

.label, .Label { display: inline-block; padding: 0px 7px; font-size: 12px; font-weight: 500; line-height: 18px; border-width: 1px; border-style: solid; border-image: initial; border-radius: 2em; border-color: var(--color-border-default); }

.label:hover, .Label:hover { text-decoration: none; }

.Label--large { padding-right: 10px; padding-left: 10px; line-height: 22px; }

.Label--inline { display: inline; padding: 0.1667em 0.5em; font-size: 0.9em; }

.Label--primary { color: var(--color-fg-default); border-color: var(--color-neutral-emphasis); }

.Label--secondary { color: var(--color-fg-muted); border-color: var(--color-border-default); }

.Label--info, .Label--accent { color: var(--color-accent-fg); border-color: var(--color-accent-emphasis); }

.Label--success { color: var(--color-success-fg); border-color: var(--color-success-emphasis); }

.Label--warning, .Label--attention { color: var(--color-attention-fg); border-color: var(--color-attention-emphasis); }

.Label--severe { color: var(--color-severe-fg); border-color: var(--color-severe-emphasis); }

.Label--danger { color: var(--color-danger-fg); border-color: var(--color-danger-emphasis); }

.Label--done { color: var(--color-done-fg); border-color: var(--color-done-emphasis); }

.Label--sponsors { color: var(--color-sponsors-fg); border-color: var(--color-sponsors-emphasis); }

.state, .State { display: inline-block; padding: 5px 12px; font-size: 14px; font-weight: 500; line-height: 20px; text-align: center; white-space: nowrap; border-radius: 2em; }

.state, .State, .State--draft { color: var(--color-fg-on-emphasis); background-color: var(--color-neutral-emphasis); border: 1px solid transparent; }

.State--open { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); }

.State--merged { color: var(--color-fg-on-emphasis); background-color: var(--color-done-emphasis); }

.State--closed { color: var(--color-fg-on-emphasis); background-color: var(--color-danger-emphasis); }

.State--small { padding: 0px 10px; font-size: 12px; line-height: 24px; }

.State--small .octicon { width: 1em; }

.Counter { display: inline-block; min-width: 20px; padding: 0px 6px; font-size: 12px; font-weight: 500; line-height: 18px; color: var(--color-fg-default); text-align: center; background-color: var(--color-neutral-muted); border: 1px solid var(--color-counter-border); border-radius: 2em; }

.Counter:empty { display: none; }

.Counter .octicon { vertical-align: text-top; opacity: 0.8; }

.Counter--primary { color: var(--color-fg-on-emphasis); background-color: var(--color-neutral-emphasis); }

.Counter--secondary { color: var(--color-fg-muted); background-color: var(--color-neutral-subtle); }

.diffstat { font-size: 12px; font-weight: 600; color: var(--color-fg-muted); white-space: nowrap; cursor: default; }

.diffstat-block-deleted, .diffstat-block-added, .diffstat-block-neutral { display: inline-block; width: 8px; height: 8px; margin-left: 1px; outline-offset: -1px; }

.diffstat-block-deleted { background-color: var(--color-danger-emphasis); outline: 1px solid var(--color-border-subtle); }

.diffstat-block-added { background-color: var(--color-diffstat-addition-bg); outline: 1px solid var(--color-border-subtle); }

.diffstat-block-neutral { background-color: var(--color-neutral-muted); outline: 1px solid var(--color-border-subtle); }

.AnimatedEllipsis { display: inline-block; overflow: hidden; vertical-align: bottom; }

.AnimatedEllipsis::after { display: inline-block; content: "..."; animation: 1.2s steps(4, jump-none) 0s infinite normal none running AnimatedEllipsis-keyframes; }

@keyframes AnimatedEllipsis-keyframes { 
  0% { transform: translateX(-100%); }
}

.markdown-body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"; font-size: 16px; line-height: 1.5; overflow-wrap: break-word; }

.markdown-body::before { display: table; content: ""; }

.markdown-body::after { display: table; clear: both; content: ""; }

.markdown-body > :first-child { margin-top: 0px !important; }

.markdown-body > :last-child { margin-bottom: 0px !important; }

.markdown-body a:not([href]) { color: inherit; text-decoration: none; }

.markdown-body .absent { color: var(--color-danger-fg); }

.markdown-body .anchor { float: left; padding-right: 4px; margin-left: -20px; line-height: 1; }

.markdown-body .anchor:focus { outline: none; }

.markdown-body p, .markdown-body blockquote, .markdown-body ul, .markdown-body ol, .markdown-body dl, .markdown-body table, .markdown-body pre, .markdown-body details { margin-top: 0px; margin-bottom: 16px; }

.markdown-body hr { height: 0.25em; padding: 0px; margin: 24px 0px; background-color: var(--color-border-default); border: 0px; }

.markdown-body blockquote { padding: 0px 1em; color: var(--color-fg-muted); border-left: 0.25em solid var(--color-border-default); }

.markdown-body blockquote > :first-child { margin-top: 0px; }

.markdown-body blockquote > :last-child { margin-bottom: 0px; }

.markdown-body sup > a::before { content: "["; }

.markdown-body sup > a::after { content: "]"; }

.markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4, .markdown-body h5, .markdown-body h6 { margin-top: 24px; margin-bottom: 16px; font-weight: 600; line-height: 1.25; }

.markdown-body h1 .octicon-link, .markdown-body h2 .octicon-link, .markdown-body h3 .octicon-link, .markdown-body h4 .octicon-link, .markdown-body h5 .octicon-link, .markdown-body h6 .octicon-link { color: var(--color-fg-default); vertical-align: middle; visibility: hidden; }

.markdown-body h1:hover .anchor, .markdown-body h2:hover .anchor, .markdown-body h3:hover .anchor, .markdown-body h4:hover .anchor, .markdown-body h5:hover .anchor, .markdown-body h6:hover .anchor { text-decoration: none; }

.markdown-body h1:hover .anchor .octicon-link, .markdown-body h2:hover .anchor .octicon-link, .markdown-body h3:hover .anchor .octicon-link, .markdown-body h4:hover .anchor .octicon-link, .markdown-body h5:hover .anchor .octicon-link, .markdown-body h6:hover .anchor .octicon-link { visibility: visible; }

.markdown-body h1 tt, .markdown-body h1 code, .markdown-body h2 tt, .markdown-body h2 code, .markdown-body h3 tt, .markdown-body h3 code, .markdown-body h4 tt, .markdown-body h4 code, .markdown-body h5 tt, .markdown-body h5 code, .markdown-body h6 tt, .markdown-body h6 code { padding: 0px 0.2em; font-size: inherit; }

.markdown-body h1 { padding-bottom: 0.3em; font-size: 2em; border-bottom: 1px solid var(--color-border-muted); }

.markdown-body h2 { padding-bottom: 0.3em; font-size: 1.5em; border-bottom: 1px solid var(--color-border-muted); }

.markdown-body h3 { font-size: 1.25em; }

.markdown-body h4 { font-size: 1em; }

.markdown-body h5 { font-size: 0.875em; }

.markdown-body h6 { font-size: 0.85em; color: var(--color-fg-muted); }

.markdown-body ul, .markdown-body ol { padding-left: 2em; }

.markdown-body ul.no-list, .markdown-body ol.no-list { padding: 0px; list-style-type: none; }

.markdown-body ol[type="1"] { list-style-type: decimal; }

.markdown-body ol[type="a"] { list-style-type: lower-alpha; }

.markdown-body ol[type="i"] { list-style-type: lower-roman; }

.markdown-body div > ol:not([type]) { list-style-type: decimal; }

.markdown-body ul ul, .markdown-body ul ol, .markdown-body ol ol, .markdown-body ol ul { margin-top: 0px; margin-bottom: 0px; }

.markdown-body li > p { margin-top: 16px; }

.markdown-body li + li { margin-top: 0.25em; }

.markdown-body dl { padding: 0px; }

.markdown-body dl dt { padding: 0px; margin-top: 16px; font-size: 1em; font-style: italic; font-weight: 600; }

.markdown-body dl dd { padding: 0px 16px; margin-bottom: 16px; }

.markdown-body table { display: block; width: max-content; max-width: 100%; overflow: auto; }

.markdown-body table th { font-weight: 600; }

.markdown-body table th, .markdown-body table td { padding: 6px 13px; border: 1px solid var(--color-border-default); }

.markdown-body table tr { background-color: var(--color-canvas-default); border-top: 1px solid var(--color-border-muted); }

.markdown-body table tr:nth-child(2n) { background-color: var(--color-canvas-subtle); }

.markdown-body table img { background-color: transparent; }

.markdown-body img { max-width: 100%; box-sizing: content-box; background-color: var(--color-canvas-default); }

.markdown-body img[align="right"] { padding-left: 20px; }

.markdown-body img[align="left"] { padding-right: 20px; }

.markdown-body .emoji { max-width: none; vertical-align: text-top; background-color: transparent; }

.markdown-body span.frame { display: block; overflow: hidden; }

.markdown-body span.frame > span { display: block; float: left; width: auto; padding: 7px; margin: 13px 0px 0px; overflow: hidden; border: 1px solid var(--color-border-default); }

.markdown-body span.frame span img { display: block; float: left; }

.markdown-body span.frame span span { display: block; padding: 5px 0px 0px; clear: both; color: var(--color-fg-default); }

.markdown-body span.align-center { display: block; overflow: hidden; clear: both; }

.markdown-body span.align-center > span { display: block; margin: 13px auto 0px; overflow: hidden; text-align: center; }

.markdown-body span.align-center span img { margin: 0px auto; text-align: center; }

.markdown-body span.align-right { display: block; overflow: hidden; clear: both; }

.markdown-body span.align-right > span { display: block; margin: 13px 0px 0px; overflow: hidden; text-align: right; }

.markdown-body span.align-right span img { margin: 0px; text-align: right; }

.markdown-body span.float-left { display: block; float: left; margin-right: 13px; overflow: hidden; }

.markdown-body span.float-left span { margin: 13px 0px 0px; }

.markdown-body span.float-right { display: block; float: right; margin-left: 13px; overflow: hidden; }

.markdown-body span.float-right > span { display: block; margin: 13px auto 0px; overflow: hidden; text-align: right; }

.markdown-body code, .markdown-body tt { padding: 0.2em 0.4em; margin: 0px; font-size: 85%; background-color: var(--color-neutral-muted); border-radius: 6px; }

.markdown-body code br, .markdown-body tt br { display: none; }

.markdown-body del code { text-decoration: inherit; }

.markdown-body pre { overflow-wrap: normal; }

.markdown-body pre code { font-size: 100%; }

.markdown-body pre > code { padding: 0px; margin: 0px; word-break: normal; white-space: pre; background: transparent; border: 0px; }

.markdown-body .highlight { margin-bottom: 16px; }

.markdown-body .highlight pre { margin-bottom: 0px; word-break: normal; }

.markdown-body .highlight pre, .markdown-body pre { padding: 16px; overflow: auto; font-size: 85%; line-height: 1.45; background-color: var(--color-canvas-subtle); border-radius: 6px; }

.markdown-body pre code, .markdown-body pre tt { display: inline; padding: 0px; margin: 0px; overflow: visible; line-height: inherit; overflow-wrap: normal; background-color: transparent; border: 0px; }

.markdown-body .csv-data td, .markdown-body .csv-data th { padding: 5px; overflow: hidden; font-size: 12px; line-height: 1; text-align: left; white-space: nowrap; }

.markdown-body .csv-data .blob-num { padding: 10px 8px 9px; text-align: right; background: var(--color-canvas-default); border: 0px; }

.markdown-body .csv-data tr { border-top: 0px; }

.markdown-body .csv-data th { font-weight: 600; background: var(--color-canvas-subtle); border-top: 0px; }

.markdown-body .footnotes { font-size: 12px; color: var(--color-fg-muted); border-top: 1px solid var(--color-border-default); }

.markdown-body .footnotes ol { padding-left: 16px; }

.markdown-body .footnotes li { position: relative; }

.markdown-body .footnotes li:target::before { position: absolute; inset: -8px -8px -8px -24px; pointer-events: none; content: ""; border: 2px solid var(--color-accent-emphasis); border-radius: 6px; }

.markdown-body .footnotes li:target { color: var(--color-fg-default); }

.markdown-body .footnotes .data-footnote-backref g-emoji { font-family: monospace; }

.Popover { position: absolute; z-index: 100; }

.Popover-message { position: relative; width: 232px; margin-right: auto; margin-left: auto; background-color: var(--color-canvas-overlay); border: 1px solid var(--color-border-default); border-radius: 6px; }

.Popover-message::before, .Popover-message::after { position: absolute; left: 50%; display: inline-block; content: ""; }

.Popover-message::before { top: -16px; margin-left: -9px; border-width: 8px; border-style: solid; border-top-color: transparent; border-right-color: transparent; border-left-color: transparent; border-image: initial; border-bottom-color: var(--color-border-default); }

.Popover-message::after { top: -14px; margin-left: -8px; border-width: 7px; border-style: solid; border-top-color: transparent; border-right-color: transparent; border-left-color: transparent; border-image: initial; border-bottom-color: var(--color-canvas-overlay); }

.Popover-message--no-caret::before, .Popover-message--no-caret::after { display: none; }

.Popover-message--bottom::before, .Popover-message--bottom::after, .Popover-message--bottom-right::before, .Popover-message--bottom-right::after, .Popover-message--bottom-left::before, .Popover-message--bottom-left::after { top: auto; border-bottom-color: transparent; }

.Popover-message--bottom::before, .Popover-message--bottom-right::before, .Popover-message--bottom-left::before { bottom: -16px; border-top-color: var(--color-border-default); }

.Popover-message--bottom::after, .Popover-message--bottom-right::after, .Popover-message--bottom-left::after { bottom: -14px; border-top-color: var(--color-canvas-overlay); }

.Popover-message--top-right, .Popover-message--bottom-right { right: -9px; margin-right: 0px; }

.Popover-message--top-right::before, .Popover-message--top-right::after, .Popover-message--bottom-right::before, .Popover-message--bottom-right::after { left: auto; margin-left: 0px; }

.Popover-message--top-right::before, .Popover-message--bottom-right::before { right: 20px; }

.Popover-message--top-right::after, .Popover-message--bottom-right::after { right: 21px; }

.Popover-message--top-left, .Popover-message--bottom-left { left: -9px; margin-left: 0px; }

.Popover-message--top-left::before, .Popover-message--top-left::after, .Popover-message--bottom-left::before, .Popover-message--bottom-left::after { left: 24px; margin-left: 0px; }

.Popover-message--top-left::after, .Popover-message--bottom-left::after { left: 25px; }

.Popover-message--right::before, .Popover-message--right::after, .Popover-message--right-top::before, .Popover-message--right-top::after, .Popover-message--right-bottom::before, .Popover-message--right-bottom::after, .Popover-message--left::before, .Popover-message--left::after, .Popover-message--left-top::before, .Popover-message--left-top::after, .Popover-message--left-bottom::before, .Popover-message--left-bottom::after { top: 50%; left: auto; margin-left: 0px; border-bottom-color: transparent; }

.Popover-message--right::before, .Popover-message--right-top::before, .Popover-message--right-bottom::before, .Popover-message--left::before, .Popover-message--left-top::before, .Popover-message--left-bottom::before { margin-top: -9px; }

.Popover-message--right::after, .Popover-message--right-top::after, .Popover-message--right-bottom::after, .Popover-message--left::after, .Popover-message--left-top::after, .Popover-message--left-bottom::after { margin-top: -8px; }

.Popover-message--right::before, .Popover-message--right-top::before, .Popover-message--right-bottom::before { right: -16px; border-left-color: var(--color-border-default); }

.Popover-message--right::after, .Popover-message--right-top::after, .Popover-message--right-bottom::after { right: -14px; border-left-color: var(--color-canvas-overlay); }

.Popover-message--left::before, .Popover-message--left-top::before, .Popover-message--left-bottom::before { left: -16px; border-right-color: var(--color-border-default); }

.Popover-message--left::after, .Popover-message--left-top::after, .Popover-message--left-bottom::after { left: -14px; border-right-color: var(--color-canvas-overlay); }

.Popover-message--right-top::before, .Popover-message--right-top::after, .Popover-message--left-top::before, .Popover-message--left-top::after { top: 24px; }

.Popover-message--right-bottom::before, .Popover-message--right-bottom::after, .Popover-message--left-bottom::before, .Popover-message--left-bottom::after { top: auto; }

.Popover-message--right-bottom::before, .Popover-message--left-bottom::before { bottom: 16px; }

.Popover-message--right-bottom::after, .Popover-message--left-bottom::after { bottom: 17px; }

@media (min-width: 544px) {
  .Popover-message--large { min-width: 320px; }
}

@media (max-width: 767.98px) {
  .Popover { position: fixed; inset: auto 0px 0px !important; }
  .Popover-message { inset: auto; margin: 8px; width: auto !important; }
  .Popover-message > .btn-octicon { padding: 12px !important; }
  .Popover-message::after, .Popover-message::before { display: none; }
}

.Progress { display: flex; height: 8px; overflow: hidden; background-color: var(--color-neutral-muted); border-radius: 6px; outline: transparent solid 1px; }

.Progress--large { height: 10px; }

.Progress--small { height: 5px; }

.Progress-item { outline: transparent solid 2px; }

.Progress-item + .Progress-item { margin-left: 2px; }

.SelectMenu { position: fixed; inset: 0px; z-index: 99; display: flex; padding: 16px; pointer-events: none; flex-direction: column; }

@media (min-width: 544px) {
  .SelectMenu { position: absolute; inset: auto; padding: 0px; }
}

.SelectMenu::before { position: absolute; inset: 0px; pointer-events: none; content: ""; background-color: var(--color-primer-canvas-backdrop); }

@media (min-width: 544px) {
  .SelectMenu::before { display: none; }
}

.SelectMenu-modal { position: relative; z-index: 99; display: flex; max-height: 66%; margin: auto 0px; overflow: hidden; pointer-events: auto; flex-direction: column; background-color: var(--color-canvas-overlay); border: 1px solid var(--color-select-menu-backdrop-border); border-radius: 12px; box-shadow: var(--color-shadow-large); animation: 0.12s cubic-bezier(0, 0.1, 0.1, 1) 0s 1 normal backwards running SelectMenu-modal-animation; }

@keyframes SelectMenu-modal-animation { 
  0% { opacity: 0; transform: scale(0.9); }
}

@keyframes SelectMenu-modal-animation--sm { 
  0% { opacity: 0; transform: translateY(-16px); }
}

@media (min-width: 544px) {
  .SelectMenu-modal { width: 300px; height: auto; max-height: 480px; margin: 8px 0px 16px; font-size: 12px; border-color: var(--color-border-default); border-radius: 6px; box-shadow: var(--color-shadow-large); animation-name: SelectMenu-modal-animation--sm; }
}

.SelectMenu-header { display: flex; padding: 16px; flex: 0 0 auto; align-items: center; border-bottom: 1px solid var(--color-border-muted); }

@media (min-width: 544px) {
  .SelectMenu-header { padding: 7px 7px 7px 16px; }
}

.SelectMenu-title { flex: 1 1 0%; font-size: 14px; font-weight: 600; }

@media (min-width: 544px) {
  .SelectMenu-title { font-size: inherit; }
}

.SelectMenu-closeButton { padding: 16px; margin: -16px; line-height: 1; color: var(--color-fg-muted); background-color: transparent; border: 0px; }

@media (min-width: 544px) {
  .SelectMenu-closeButton { padding: 8px; margin: -8px -7px; }
}

.SelectMenu-filter { padding: 16px; margin: 0px; border-bottom: 1px solid var(--color-border-muted); }

@media (min-width: 544px) {
  .SelectMenu-filter { padding: 8px; }
}

.SelectMenu-input { display: block; width: 100%; }

@media (min-width: 544px) {
  .SelectMenu-input { font-size: 14px; }
}

.SelectMenu-list { position: relative; padding: 0px; margin: 0px 0px -1px; flex: 1 1 auto; overflow: hidden auto; background-color: var(--color-canvas-overlay); }

.SelectMenu-item { display: flex; align-items: center; width: 100%; padding: 16px; overflow: hidden; color: var(--color-fg-default); text-align: left; cursor: pointer; background-color: var(--color-canvas-overlay); border-top: 0px; border-right: 0px; border-left: 0px; border-image: initial; border-bottom: 1px solid var(--color-border-muted); }

@media (min-width: 544px) {
  .SelectMenu-item { padding-top: 7px; padding-bottom: 7px; }
}

.SelectMenu-list--borderless .SelectMenu-item { border-bottom: 0px; }

.SelectMenu-icon { width: 16px; margin-right: 8px; flex-shrink: 0; }

.SelectMenu-icon--check { visibility: hidden; transition: transform 0.12s cubic-bezier(0.5, 0.1, 1, 0.5) 0s, visibility 0s linear 0.12s; transform: scale(0); }

.SelectMenu-tabs { display: flex; flex-shrink: 0; overflow: auto hidden; box-shadow: inset 0 -1px 0 var(--color-border-muted); }

.SelectMenu-tabs::-webkit-scrollbar { display: none; }

@media (min-width: 544px) {
  .SelectMenu-tabs { padding: 8px 8px 0px; }
}

.SelectMenu-tab { flex: 1 1 0%; padding: 8px 16px; font-size: 12px; font-weight: 500; color: var(--color-fg-muted); text-align: center; background-color: transparent; border: 0px; box-shadow: inset 0 -1px 0 var(--color-border-muted); }

@media (min-width: 544px) {
  .SelectMenu-tab { flex: 0 0 auto; padding: 4px 16px; border-width: 1px 1px 0px; border-style: solid; border-color: transparent; border-image: initial; border-top-left-radius: 6px; border-top-right-radius: 6px; }
}

.SelectMenu-tab[aria-selected="true"] { z-index: 1; color: var(--color-fg-default); cursor: default; background-color: var(--color-canvas-overlay); box-shadow: 0 0 0 1px var(--color-border-muted); }

@media (min-width: 544px) {
  .SelectMenu-tab[aria-selected="true"] { border-color: var(--color-border-muted); box-shadow: none; }
}

.SelectMenu-message { padding: 7px 16px; text-align: center; background-color: var(--color-canvas-overlay); border-bottom: 1px solid var(--color-border-muted); }

.SelectMenu-blankslate, .SelectMenu-loading { padding: 24px 16px; text-align: center; background-color: var(--color-canvas-overlay); }

.SelectMenu-divider { padding: 4px 16px; margin: 0px; font-size: 12px; font-weight: 500; color: var(--color-fg-muted); background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-muted); }

.SelectMenu-list--borderless .SelectMenu-divider { border-top: 1px solid var(--color-border-muted); }

.SelectMenu-list--borderless .SelectMenu-divider:empty { padding: 0px; border-top: 0px; }

.SelectMenu-footer { z-index: 0; padding: 8px 16px; font-size: 12px; color: var(--color-fg-muted); text-align: center; border-top: 1px solid var(--color-border-muted); }

@media (min-width: 544px) {
  .SelectMenu-footer { padding: 7px 16px; }
}

.SelectMenu--hasFilter .SelectMenu-modal { height: 80%; max-height: none; margin-top: 0px; }

@media (min-width: 544px) {
  .SelectMenu--hasFilter .SelectMenu-modal { height: auto; max-height: 480px; margin-top: 8px; }
}

.SelectMenu-closeButton:focus, .SelectMenu-tab:focus, .SelectMenu-item:focus { outline: 0px; }

.SelectMenu-item:hover { text-decoration: none; }

.SelectMenu-item[aria-checked="true"] { font-weight: 500; color: var(--color-fg-default); }

.SelectMenu-item[aria-checked="true"] .SelectMenu-icon--check { visibility: visible; transition: transform 0.12s cubic-bezier(0, 0, 0.2, 1) 0s, visibility 0s linear 0s; transform: scale(1); }

.SelectMenu-item:disabled, .SelectMenu-item[aria-disabled="true"] { color: var(--color-primer-fg-disabled); pointer-events: none; }

@media (hover: hover) {
  body:not(.intent-mouse) .SelectMenu-closeButton:focus, .SelectMenu-closeButton:hover { color: var(--color-fg-default); }
  .SelectMenu-closeButton:active { color: var(--color-fg-muted); }
  body:not(.intent-mouse) .SelectMenu-item:focus, .SelectMenu-item:hover { background-color: var(--color-neutral-subtle); }
  .SelectMenu-item:active { background-color: var(--color-canvas-subtle); }
  body:not(.intent-mouse) .SelectMenu-tab:focus { background-color: var(--color-select-menu-tap-focus-bg); }
  .SelectMenu-tab:hover { color: var(--color-fg-default); }
  .SelectMenu-tab:not([aria-selected="true"]):active { color: var(--color-fg-default); background-color: var(--color-canvas-subtle); }
}

@media (hover: none) {
  .SelectMenu-item:focus, .SelectMenu-item:active { background-color: var(--color-canvas-subtle); }
  .SelectMenu-item { -webkit-tap-highlight-color: var(--color-select-menu-tap-highlight); }
}

.Subhead { display: flex; padding-bottom: 8px; margin-bottom: 16px; border-bottom: 1px solid var(--color-border-muted); flex-flow: row wrap; justify-content: flex-end; }

.Subhead--spacious { margin-top: 40px; }

.Subhead-heading { font-size: 24px; font-weight: 400; flex: 1 1 auto; }

.Subhead-heading--danger { font-weight: 600; color: var(--color-danger-fg); }

.Subhead-description { font-size: 14px; color: var(--color-fg-muted); flex: 1 1 100%; }

.Subhead-actions { margin: 4px 0px 4px 4px; align-self: center; justify-content: flex-end; }

.Subhead-actions + .Subhead-description { margin-top: 4px; }

.TimelineItem { position: relative; display: flex; padding: 16px 0px; margin-left: 16px; }

.TimelineItem::before { position: absolute; top: 0px; bottom: 0px; left: 0px; display: block; width: 2px; content: ""; background-color: var(--color-border-muted); }

.TimelineItem:target .TimelineItem-badge { border-color: var(--color-accent-emphasis); box-shadow: 0 0 0.2em var(--color-accent-muted); }

.TimelineItem-badge { position: relative; z-index: 1; display: flex; width: 32px; height: 32px; margin-right: 8px; margin-left: -15px; color: var(--color-fg-muted); align-items: center; background-color: var(--color-timeline-badge-bg); border: 2px solid var(--color-canvas-default); border-radius: 50%; justify-content: center; flex-shrink: 0; }

.TimelineItem-badge--success { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); border: 1px solid transparent; }

.TimelineItem-body { min-width: 0px; max-width: 100%; margin-top: 4px; color: var(--color-fg-muted); flex: 1 1 auto; }

.TimelineItem-avatar { position: absolute; left: -72px; z-index: 1; }

.TimelineItem-break { position: relative; z-index: 1; height: 24px; margin: 0px 0px -16px -56px; background-color: var(--color-canvas-default); border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top: 4px solid var(--color-border-default); }

.TimelineItem--condensed { padding-top: 4px; padding-bottom: 0px; }

.TimelineItem--condensed:last-child { padding-bottom: 16px; }

.TimelineItem--condensed .TimelineItem-badge { height: 16px; margin-top: 8px; margin-bottom: 8px; color: var(--color-fg-muted); background-color: var(--color-canvas-default); border: 0px; }

.Toast { display: flex; margin: 8px; color: var(--color-fg-default); background-color: var(--color-canvas-default); border-radius: 6px; box-shadow: inset 0 0 0 1px var(--color-border-default),var(--color-shadow-large); }

@media (min-width: 544px) {
  .Toast { width: max-content; max-width: 450px; margin: 16px; }
}

.Toast-icon { display: flex; align-items: center; justify-content: center; width: 48px; flex-shrink: 0; color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); border-width: 1px 0px 1px 1px; border-top-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: transparent; border-bottom-color: transparent; border-left-color: transparent; border-image: initial; border-right-style: initial; border-right-color: initial; border-top-left-radius: inherit; border-bottom-left-radius: inherit; }

.Toast-content { padding: 16px; }

.Toast-dismissButton { max-height: 54px; padding: 16px; color: inherit; background-color: transparent; border: 0px; }

.Toast-dismissButton:focus, .Toast-dismissButton:hover { outline: none; opacity: 0.7; }

.Toast-dismissButton:active { opacity: 0.5; }

.Toast--loading { color: var(--color-fg-default); box-shadow: inset 0 0 0 1px var(--color-border-default),var(--color-shadow-large); }

.Toast--loading .Toast-icon { background-color: var(--color-neutral-emphasis); }

.Toast--error { color: var(--color-fg-default); box-shadow: inset 0 0 0 1px var(--color-border-default),var(--color-shadow-large); }

.Toast--error .Toast-icon { background-color: var(--color-danger-emphasis); }

.Toast--warning { color: var(--color-fg-default); box-shadow: inset 0 0 0 1px var(--color-border-default),var(--color-shadow-large); }

.Toast--warning .Toast-icon { background-color: var(--color-attention-emphasis); }

.Toast--success { color: var(--color-fg-default); box-shadow: inset 0 0 0 1px var(--color-border-default),var(--color-shadow-large); }

.Toast--success .Toast-icon { background-color: var(--color-success-emphasis); }

.Toast--animateIn { animation: 0.18s cubic-bezier(0.22, 0.61, 0.36, 1) 0s 1 normal backwards running Toast--animateIn; }

@keyframes Toast--animateIn { 
  0% { opacity: 0; transform: translateY(100%); }
}

.Toast--animateOut { animation: 0.18s cubic-bezier(0.55, 0.06, 0.68, 0.19) 0s 1 normal forwards running Toast--animateOut; }

@keyframes Toast--animateOut { 
  100% { pointer-events: none; opacity: 0; transform: translateY(100%); }
}

.Toast--spinner { animation: 1000ms linear 0s infinite normal none running Toast--spinner; }

@keyframes Toast--spinner { 
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.boxed-group { position: relative; margin-bottom: 30px; border-radius: 6px; }

.boxed-group .Counter { color: var(--color-fg-on-emphasis); background-color: var(--color-neutral-emphasis); }

.boxed-group.flush .boxed-group-inner { padding: 0px; }

.boxed-group.condensed .boxed-group-inner { padding: 0px; font-size: 12px; }

.boxed-group > h3, .boxed-group .heading { display: block; padding: 9px 10px 10px; margin: 0px; font-size: 14px; line-height: 17px; background-color: var(--color-canvas-subtle); border-top-color: ; border-top-style: ; border-top-width: ; border-right-color: ; border-right-style: ; border-right-width: ; border-left-color: ; border-left-style: ; border-left-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-bottom: 0px; border-radius: 6px 6px 0px 0px; }

.boxed-group > h3 a, .boxed-group .heading a { color: inherit; }

.boxed-group > h3 a.boxed-group-breadcrumb, .boxed-group .heading a.boxed-group-breadcrumb { font-weight: 400; color: var(--color-fg-muted); text-decoration: none; }

.boxed-group > h3 .avatar, .boxed-group .heading .avatar { margin-top: -4px; }

.boxed-group .tabnav.heading { padding: 0px; }

.boxed-group .tabnav.heading .tabnav-tab.selected { border-top: 0px; }

.boxed-group .tabnav.heading li:first-child .selected { border-left-color: var(--color-canvas-default); border-top-left-radius: 6px; }

.boxed-group .tabnav-tab { border-top: 0px; border-radius: 0px; }

.boxed-group code.heading { font-size: 12px; }

.boxed-group.dangerzone > h3 { color: var(--color-fg-on-emphasis); background-color: var(--color-danger-emphasis); border: 1px solid var(--color-danger-emphasis); }

.boxed-group.dangerzone .boxed-group-inner { border-top: 0px; }

.boxed-group.condensed > h3 { padding: 6px 6px 7px; font-size: 12px; }

.boxed-group.condensed > h3 .octicon { padding: 0px 6px 0px 2px; }

.dashboard-sidebar .boxed-group { margin-bottom: 20px; }

.boxed-group .bleed-flush { width: 100%; padding: 0px 10px; margin-left: -10px; }

.boxed-group .compact { margin-top: 10px; margin-bottom: 10px; }

.boxed-group-inner { padding: 10px; color: var(--color-fg-muted); background: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.boxed-group-inner .markdown-body { padding: 20px 10px 10px; font-size: 13px; }

.boxed-group-inner.markdown-body { padding-top: 10px; padding-bottom: 10px; }

.boxed-group-inner.seamless { padding: 0px; }

.boxed-group-inner .tabnav { padding-right: 10px; padding-left: 10px; margin-right: -10px; margin-left: -10px; }

.boxed-group-inner .tabnav-tab.selected { border-top: 1px solid var(--color-border-default); }

.boxed-action { float: right; margin-left: 10px; }

.boxed-group-action { position: relative; z-index: 2; float: right; margin: 5px 10px 0px 0px; }

.boxed-group-action.flush { margin-top: 0px; margin-right: 0px; }

.field-with-errors { display: inline; }

.compact-options { margin: -6px 0px 13px; }

.compact-options > li { display: inline-block; margin: 0px 12px 0px 0px; font-weight: 600; list-style-type: none; }

.compact-options > li label { float: left; }

.compact-options > li .spinner { display: block; float: left; width: 16px; height: 16px; margin-left: 5px; }

.boxed-group-list { margin: 0px; list-style: none; }

.boxed-group-list:first-child > li:first-child { border-top: 0px; }

.boxed-group-list > li { display: block; padding: 5px 10px; margin-right: -10px; margin-left: -10px; line-height: 23px; border-bottom: 1px solid var(--color-border-default); }

.boxed-group-list > li:first-child { border-top: 1px solid var(--color-border-default); }

.boxed-group-list > li:last-of-type { border-bottom: 0px; }

.boxed-group-list > li.selected { background: var(--color-success-subtle); }

.boxed-group-list > li.approved .btn-sm, .boxed-group-list > li.rejected .btn-sm { display: none; }

.boxed-group-list > li.rejected a { text-decoration: line-through; }

.boxed-group-list > li .avatar { margin-top: -2px; margin-right: 4px; }

.boxed-group-list > li .octicon { width: 24px; margin-right: 4px; }

.boxed-group-list > li .btn-sm { float: right; margin: -1px 0px 0px 10px; }

.boxed-group-list > li .BtnGroup { float: right; }

.boxed-group-list > li .BtnGroup .btn-sm { float: left; }

.boxed-group.flush .boxed-group-list li { width: auto; padding-right: 0px; padding-left: 0px; margin-left: 0px; }

.boxed-group-list.standalone { margin-top: -1px; }

.boxed-group-list.standalone > li:first-child { border-top: 0px; }

.boxed-group-standalone { margin-top: -10px; margin-bottom: -10px; }

.boxed-group-standalone > li:last-child { border-radius: 0px 0px 6px 6px; }

.boxed-group-table { width: 100%; text-align: left; }

.boxed-group-table tr:last-child td { border-bottom: 0px; }

.boxed-group-table th { padding: 9px; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-muted); }

.boxed-group-table td { padding: 9px; vertical-align: top; border-bottom: 1px solid var(--color-border-muted); }

.ajax-error-message { position: fixed; top: 0px; left: 50%; z-index: 9999; width: 974px; margin: 0px 3px 0px -487px; transition: top 0.5s ease-in-out 0s; }

.ajax-error-message > .octicon-alert { vertical-align: text-top; }

.boxed-group-warning { padding: 10px 15px; margin: -10px -10px 10px; color: var(--color-fg-default); background-color: var(--color-attention-subtle); border-color: var(--color-attention-emphasis); border-style: solid; border-width: 1px 0px; }

.boxed-group-warning .btn-sm { margin: -5px 0px; }

.boxed-group-warning:first-child { border-top: 0px; }

.container { width: 980px; margin-right: auto; margin-left: auto; }

.container::before { display: table; content: ""; }

.container::after { display: table; clear: both; content: ""; }

.draft.octicon { color: var(--color-fg-muted); }

.closed.octicon, .reverted.octicon { color: var(--color-danger-fg); }

.open.octicon { color: var(--color-success-fg); }

.closed.octicon.octicon-issue-closed, .merged.octicon { color: var(--color-done-fg); }

.progress-bar { display: block; height: 15px; overflow: hidden; background-color: var(--color-border-muted); border-radius: 6px; }

.progress-bar .progress { display: block; height: 100%; background-color: var(--color-success-emphasis); }

.reverse-progress-container { position: relative; height: 3px; background-color: var(--color-border-muted); background-image: linear-gradient(to right, var(--color-success-emphasis), var(--color-accent-emphasis), var(--color-done-emphasis), var(--color-danger-emphasis), var(--color-severe-emphasis)); background-size: 100% 3px; }

.reverse-progress-bar { position: absolute; right: 0px; height: 100%; background-color: var(--color-border-muted); }

.progress-bar-small { height: 10px; }

.select-menu-button::after { display: inline-block; width: 0px; height: 0px; vertical-align: -2px; content: ""; border-width: 4px; border-style: solid; border-top-color: initial; border-image: initial; border-right-color: transparent; border-bottom-color: transparent; border-left-color: transparent; }

.select-menu-button.icon-only { padding-left: 7px; }

.select-menu-button.primary::after { border-top-color: var(--color-fg-on-emphasis); }

.select-menu-button-large::after { margin-left: 0.25em; border-width: 0.33em; }

.select-menu .spinner { float: left; margin: 4px 0px 0px -24px; }

.select-menu.active .select-menu-modal-holder { display: block; }

.select-menu.select-menu-modal-right { position: relative; }

.select-menu.select-menu-modal-right .select-menu-modal-holder { right: 0px; }

.select-menu .select-menu-clear-item { display: block; }

.select-menu .select-menu-clear-item .octicon { color: inherit; }

.select-menu .select-menu-clear-item + .select-menu-no-results { display: none !important; }

.select-menu.is-loading .select-menu-loading-overlay { display: block; }

.select-menu.is-loading .select-menu-modal { min-height: 200px; }

.select-menu.has-error .select-menu-error { display: block; }

.select-menu-error { display: none; }

.select-menu-loading-overlay { position: absolute; top: 0px; z-index: 5; display: none; width: 100%; height: 100%; background-color: var(--color-canvas-overlay); border: 1px solid transparent; border-radius: 5px; }

.select-menu-modal-holder { position: absolute; z-index: 30; display: none; }

.select-menu-modal { position: relative; width: 300px; margin-top: 4px; margin-bottom: 20px; overflow: hidden; font-size: 12px; color: var(--color-fg-default); background-color: var(--color-canvas-overlay); background-clip: padding-box; border: 1px solid var(--color-border-default); border-radius: 6px; box-shadow: var(--color-shadow-large); }

.select-menu-modal-narrow { width: 200px; }

.select-menu-header, .select-menu-divider { padding: 8px 10px; line-height: 16px; background: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-muted); }

.select-menu-header .select-menu-title, .select-menu-divider { font-weight: 600; color: var(--color-fg-default); }

.select-menu-divider { margin-top: -1px; border-top: 1px solid var(--color-border-muted); }

.select-menu-header .close-button, .select-menu-header .octicon { display: block; float: right; color: var(--color-fg-muted); cursor: pointer; }

.select-menu-header .close-button:hover, .select-menu-header .octicon:hover { color: var(--color-fg-default); }

.select-menu-header:focus { outline: none; }

.select-menu-filters { background-color: var(--color-canvas-overlay); }

.select-menu-text-filter { padding: 10px 10px 0px; }

.select-menu-text-filter:first-child:last-child { padding-bottom: 10px; border-bottom: 1px solid var(--color-border-muted); }

.select-menu-text-filter input { display: block; width: 100%; max-width: 100%; padding: 5px; border: 1px solid var(--color-border-muted); border-radius: 6px; }

.select-menu-text-filter input::placeholder { color: var(--color-fg-subtle); }

.select-menu-tabs { padding: 10px 10px 0px; border-bottom: 1px solid var(--color-border-muted); }

.select-menu-tabs ul { position: relative; bottom: -1px; }

.select-menu-tabs .select-menu-tab { display: inline-block; }

.select-menu-tabs a, .select-menu-tabs .select-menu-tab-nav { display: inline-block; padding: 4px 8px 2px; font-size: 11px; font-weight: 600; color: var(--color-fg-muted); text-decoration: none; cursor: pointer; background: transparent; border: 1px solid transparent; border-radius: 6px 6px 0px 0px; }

.select-menu-tabs a:hover, .select-menu-tabs .select-menu-tab-nav:hover { color: var(--color-fg-default); }

.select-menu-tabs a[aria-selected="true"], .select-menu-tabs a.selected, .select-menu-tabs .select-menu-tab-nav[aria-selected="true"], .select-menu-tabs .select-menu-tab-nav.selected { color: var(--color-fg-default); background-color: var(--color-canvas-overlay); border-top-color: ; border-right-color: ; border-left-color: ; border-bottom-color: var(--color-canvas-overlay); }

.select-menu-list { position: relative; max-height: 400px; overflow: auto; }

.select-menu-list.is-showing-new-item-form .select-menu-new-item-form { display: block; }

.select-menu-list.is-showing-new-item-form .select-menu-no-results, .select-menu-list.is-showing-new-item-form .select-menu-clear-item { display: none; }

.select-menu-blankslate { padding: 16px; text-align: center; }

.select-menu-blankslate svg { display: block; margin-right: auto; margin-bottom: 9px; margin-left: auto; fill: var(--color-fg-muted); }

.select-menu-blankslate h3 { font-size: 14px; color: var(--color-fg-default); }

.select-menu-blankslate p { width: 195px; margin-right: auto; margin-bottom: 0px; margin-left: auto; }

.select-menu-item { display: block; padding: 8px 8px 8px 30px; overflow: hidden; color: inherit; cursor: pointer; border-bottom: 1px solid var(--color-border-muted); }

.select-menu-item .select-menu-item-text .octicon-x { display: none; float: right; margin: 1px 10px 0px 0px; opacity: 0.6; }

.select-menu-item:hover { text-decoration: none; }

.select-menu-item.disabled, .select-menu-item[disabled], .select-menu-item[aria-disabled="true"], .select-menu-item.disabled.selected { color: var(--color-fg-muted); cursor: default; }

.select-menu-item.disabled .description, .select-menu-item[disabled] .description, .select-menu-item[aria-disabled="true"] .description, .select-menu-item.disabled.selected .description { color: var(--color-fg-muted); }

.select-menu-item.disabled.opaque, .select-menu-item[disabled].opaque, .select-menu-item[aria-disabled="true"].opaque, .select-menu-item.disabled.selected.opaque { opacity: 0.7; }

.select-menu-item.disabled .select-menu-item-gravatar, .select-menu-item[disabled] .select-menu-item-gravatar, .select-menu-item[aria-disabled="true"] .select-menu-item-gravatar, .select-menu-item.disabled.selected .select-menu-item-gravatar { opacity: 0.5; }

.select-menu-item .octicon { vertical-align: middle; }

.select-menu-item .octicon-check, .select-menu-item .octicon-circle-slash, .select-menu-item input[type="radio"]:not(:checked) + .octicon-check, .select-menu-item input[type="radio"]:not(:checked) + .octicon-circle-slash { visibility: hidden; }

.select-menu-item.selected .octicon-circle-slash.select-menu-item-icon { color: var(--color-fg-muted)  !important; }

.select-menu-item .octicon-circle-slash { color: var(--color-fg-muted); }

.select-menu-item.excluded { background-color: var(--color-canvas-subtle); }

.select-menu-item input[type="radio"] { display: none; }

.select-menu-item:focus { outline: none; }

.select-menu-item:focus .octicon, .select-menu-item:hover .octicon { color: inherit !important; }

.select-menu-item:hover, .select-menu-item:hover.selected, .select-menu-item:hover.select-menu-action, .select-menu-item:hover .description-inline, .select-menu-item:focus, .select-menu-item:focus.selected, .select-menu-item:focus.select-menu-action, .select-menu-item:focus .description-inline, .select-menu-item.navigation-focus, .select-menu-item.navigation-focus.selected, .select-menu-item.navigation-focus.select-menu-action, .select-menu-item.navigation-focus .description-inline, .select-menu-item.navigation-focus[aria-checked="true"], .select-menu-item[aria-checked="true"]:focus, .select-menu-item[aria-checked="true"]:hover, .select-menu-item[aria-selected="true"]:hover, .select-menu-item[aria-selected="true"]:focus, .select-menu-item[aria-selected="true"].select-menu-action, .select-menu-item[aria-selected="true"] .description-inline { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.select-menu-item:hover > .octicon, .select-menu-item:hover.selected > .octicon, .select-menu-item:hover.select-menu-action > .octicon, .select-menu-item:hover .description-inline > .octicon, .select-menu-item:focus > .octicon, .select-menu-item:focus.selected > .octicon, .select-menu-item:focus.select-menu-action > .octicon, .select-menu-item:focus .description-inline > .octicon, .select-menu-item.navigation-focus > .octicon, .select-menu-item.navigation-focus.selected > .octicon, .select-menu-item.navigation-focus.select-menu-action > .octicon, .select-menu-item.navigation-focus .description-inline > .octicon, .select-menu-item.navigation-focus[aria-checked="true"] > .octicon, .select-menu-item[aria-checked="true"]:focus > .octicon, .select-menu-item[aria-checked="true"]:hover > .octicon, .select-menu-item[aria-selected="true"]:hover > .octicon, .select-menu-item[aria-selected="true"]:focus > .octicon, .select-menu-item[aria-selected="true"].select-menu-action > .octicon, .select-menu-item[aria-selected="true"] .description-inline > .octicon { color: var(--color-fg-on-emphasis); }

.select-menu-item:hover .description, .select-menu-item:hover .description-warning, .select-menu-item:hover .select-menu-item-heading-warning, .select-menu-item:hover.selected .description, .select-menu-item:hover.selected .description-warning, .select-menu-item:hover.selected .select-menu-item-heading-warning, .select-menu-item:hover.select-menu-action .description, .select-menu-item:hover.select-menu-action .description-warning, .select-menu-item:hover.select-menu-action .select-menu-item-heading-warning, .select-menu-item:hover .description-inline .description, .select-menu-item:hover .description-inline .description-warning, .select-menu-item:hover .description-inline .select-menu-item-heading-warning, .select-menu-item:focus .description, .select-menu-item:focus .description-warning, .select-menu-item:focus .select-menu-item-heading-warning, .select-menu-item:focus.selected .description, .select-menu-item:focus.selected .description-warning, .select-menu-item:focus.selected .select-menu-item-heading-warning, .select-menu-item:focus.select-menu-action .description, .select-menu-item:focus.select-menu-action .description-warning, .select-menu-item:focus.select-menu-action .select-menu-item-heading-warning, .select-menu-item:focus .description-inline .description, .select-menu-item:focus .description-inline .description-warning, .select-menu-item:focus .description-inline .select-menu-item-heading-warning, .select-menu-item.navigation-focus .description, .select-menu-item.navigation-focus .description-warning, .select-menu-item.navigation-focus .select-menu-item-heading-warning, .select-menu-item.navigation-focus.selected .description, .select-menu-item.navigation-focus.selected .description-warning, .select-menu-item.navigation-focus.selected .select-menu-item-heading-warning, .select-menu-item.navigation-focus.select-menu-action .description, .select-menu-item.navigation-focus.select-menu-action .description-warning, .select-menu-item.navigation-focus.select-menu-action .select-menu-item-heading-warning, .select-menu-item.navigation-focus .description-inline .description, .select-menu-item.navigation-focus .description-inline .description-warning, .select-menu-item.navigation-focus .description-inline .select-menu-item-heading-warning, .select-menu-item.navigation-focus[aria-checked="true"] .description, .select-menu-item.navigation-focus[aria-checked="true"] .description-warning, .select-menu-item.navigation-focus[aria-checked="true"] .select-menu-item-heading-warning, .select-menu-item[aria-checked="true"]:focus .description, .select-menu-item[aria-checked="true"]:focus .description-warning, .select-menu-item[aria-checked="true"]:focus .select-menu-item-heading-warning, .select-menu-item[aria-checked="true"]:hover .description, .select-menu-item[aria-checked="true"]:hover .description-warning, .select-menu-item[aria-checked="true"]:hover .select-menu-item-heading-warning, .select-menu-item[aria-selected="true"]:hover .description, .select-menu-item[aria-selected="true"]:hover .description-warning, .select-menu-item[aria-selected="true"]:hover .select-menu-item-heading-warning, .select-menu-item[aria-selected="true"]:focus .description, .select-menu-item[aria-selected="true"]:focus .description-warning, .select-menu-item[aria-selected="true"]:focus .select-menu-item-heading-warning, .select-menu-item[aria-selected="true"].select-menu-action .description, .select-menu-item[aria-selected="true"].select-menu-action .description-warning, .select-menu-item[aria-selected="true"].select-menu-action .select-menu-item-heading-warning, .select-menu-item[aria-selected="true"] .description-inline .description, .select-menu-item[aria-selected="true"] .description-inline .description-warning, .select-menu-item[aria-selected="true"] .description-inline .select-menu-item-heading-warning { color: var(--color-fg-on-emphasis); }

.select-menu-item:hover.disabled, .select-menu-item[disabled]:hover, .select-menu-item[aria-disabled="true"]:hover, .select-menu-item[aria-selected="true"].disabled, .select-menu-item.navigation-focus.disabled { color: var(--color-fg-muted); }

.select-menu-item:hover.disabled .description, .select-menu-item[disabled]:hover .description, .select-menu-item[aria-disabled="true"]:hover .description, .select-menu-item[aria-selected="true"].disabled .description, .select-menu-item.navigation-focus.disabled .description { color: var(--color-fg-muted); }

.select-menu-item > .octicon-dash { display: none; }

.select-menu-item[aria-checked="mixed"] > .octicon-check { display: none; }

.select-menu-item[aria-checked="mixed"] > .octicon-dash { display: block; }

.select-menu-item input:checked + .octicon-check { color: inherit; visibility: visible; }

details-menu .select-menu-item[aria-checked="true"], details-menu .select-menu-item[aria-selected="true"], .select-menu-item.selected { color: var(--color-fg-default); }

details-menu .select-menu-item[aria-checked="true"] .description, details-menu .select-menu-item[aria-selected="true"] .description, .select-menu-item.selected .description { color: var(--color-fg-muted); }

details-menu .select-menu-item[aria-checked="true"] > .octicon, details-menu .select-menu-item[aria-selected="true"] > .octicon, .select-menu-item.selected > .octicon { color: var(--color-fg-default); }

details-menu .select-menu-item[aria-checked="true"] .octicon-check, details-menu .select-menu-item[aria-checked="true"] .octicon-circle-slash, details-menu .select-menu-item[aria-selected="true"] .octicon-check, details-menu .select-menu-item[aria-selected="true"] .octicon-circle-slash, .select-menu-item.selected .octicon-check, .select-menu-item.selected .octicon-circle-slash { color: inherit; visibility: visible; }

details-menu .select-menu-item[aria-checked="true"] .select-menu-item-text .octicon-x, details-menu .select-menu-item[aria-selected="true"] .select-menu-item-text .octicon-x, .select-menu-item.selected .select-menu-item-text .octicon-x { display: block; color: inherit; }

.select-menu.label-select-menu .select-menu-item:active { background-color: transparent !important; }

.select-menu-item:hover .Label, .select-menu-item:focus .Label { color: inherit; border-color: currentcolor; }

.select-menu-item a { color: inherit; text-decoration: none; }

.select-menu-item .hidden-select-button-text { display: none; }

.select-menu-item .css-truncate-target { max-width: 100%; }

.select-menu-item-icon { float: left; margin-left: -20px; }

form.select-menu-item > div:first-child { display: none !important; }

.select-menu-list:last-child .select-menu-item:last-child, .select-menu-item.last-visible { border-bottom: 0px; border-radius: 0px 0px 6px 6px; }

.select-menu-action { font-weight: 400; color: var(--color-fg-default); }

.select-menu-action > .octicon { color: inherit; }

.select-menu-action:hover { color: var(--color-accent-fg); }

.select-menu-no-results { display: none; padding: 9px; color: var(--color-fg-muted); cursor: auto; }

.select-menu-list.filterable-empty .select-menu-no-results, .select-menu-no-results:only-child { display: block; }

.select-menu-button-gravatar, .select-menu-item-gravatar { width: 20px; overflow: hidden; line-height: 0; }

.select-menu-button-gravatar img, .select-menu-item-gravatar img { display: inline-block; width: 20px; height: 20px; border-radius: 6px; }

.select-menu-item-gravatar { float: left; width: 20px; height: 20px; margin-right: 8px; border-radius: 6px; }

.select-menu-button-gravatar { float: left; margin-right: 5px; }

.select-menu-item-text { display: block; text-align: left; }

.select-menu-item-text .description { display: block; max-width: 265px; font-size: 12px; color: var(--color-fg-muted); }

.select-menu-item-text .description-inline { font-size: 10px; color: var(--color-fg-muted); }

.select-menu-item-text .description-warning { color: var(--color-danger-fg); }

.select-menu-item-text mark { font-weight: 600; color: inherit; background-color: inherit; }

.select-menu-item-heading { display: block; margin-top: 0px; margin-bottom: 0px; font-size: 14px; font-weight: 600; }

.select-menu-item-heading.select-menu-item-heading-warning { color: var(--color-danger-fg); }

.select-menu-item-heading .description { display: inline; font-weight: 400; }

.select-menu-new-item-form { display: none; }

.select-menu-new-item-form .octicon { color: var(--color-accent-fg); }

.table-list { display: table; width: 100%; color: var(--color-fg-muted); table-layout: fixed; border-bottom: 1px solid var(--color-border-default); }

.table-list ol { list-style-type: decimal; }

.table-list-bordered { border-bottom-color: var(--color-border-default); }

.table-list-bordered .table-list-cell:first-child { border-left: 1px solid var(--color-border-default); }

.table-list-bordered .table-list-cell:last-child { border-right: 1px solid var(--color-border-default); }

.table-list-item { position: relative; display: table-row; list-style: none; }

.table-list-item.unread .table-list-cell:first-child { box-shadow: 2px 0 0 var(--color-accent-emphasis) inset; }

.table-list-cell { position: relative; display: table-cell; padding: 8px 10px; font-size: 12px; vertical-align: top; border-top: 1px solid var(--color-border-default); }

.table-list-cell.flush-left { padding-left: 0px; }

.table-list-cell.flush-right { padding-right: 0px; }

.table-list-cell-checkbox { width: 30px; padding-right: 0px; padding-left: 0px; text-align: center; }

.table-list-header { position: relative; margin-top: 20px; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); border-radius: 6px 6px 0px 0px; }

.table-list-header::before { display: table; content: ""; }

.table-list-header::after { display: table; clear: both; content: ""; }

.table-list-header .btn-link { position: relative; display: inline-block; padding-top: 13px; padding-bottom: 13px; font-weight: 400; }

.table-list-heading { margin-left: 10px; }

.table-list-header-select-all { float: left; width: 30px; padding: 12px 10px; margin-right: 5px; margin-left: -1px; text-align: center; }

.table-list-header-meta { display: inline-block; padding-top: 13px; padding-bottom: 13px; color: var(--color-fg-muted); }

.table-list-header-toggle h4 { padding: 12px 0px; }

.table-list-filters:first-child .table-list-header-toggle:first-child { padding-left: 16px; }

.table-list-header-toggle.states .selected { font-weight: 600; }

.table-list-header-toggle .btn-link { color: var(--color-fg-muted); }

.table-list-header-toggle .btn-link .octicon { margin-right: 4px; }

.table-list-header-toggle .btn-link:hover { color: var(--color-fg-default); text-decoration: none; }

.table-list-header-toggle .btn-link.selected, .table-list-header-toggle .btn-link.selected:hover { color: var(--color-fg-default); }

.table-list-header-toggle .btn-link + .btn-link { margin-left: 10px; }

.table-list-header-toggle .btn-link:disabled, .table-list-header-toggle .btn-link.disabled { pointer-events: none; opacity: 0.5; }

.table-list-header-toggle .select-menu { position: relative; }

.table-list-header-toggle .select-menu-item[aria-checked="true"], .table-list-header-toggle .select-menu-item.selected { font-weight: 600; }

.table-list-header-toggle .select-menu-button { padding-right: 15px; padding-left: 15px; }

.table-list-header-toggle .select-menu-button:hover, .table-list-header-toggle .select-menu-button.selected, .table-list-header-toggle .select-menu-button.selected:hover { color: var(--color-fg-default); }

.table-list-header-toggle .select-menu-modal-holder { right: 10px; }

.table-list-header-toggle .select-menu-modal-holder .select-menu-modal { margin-top: -1px; }

.table-list-header-next { margin-top: 20px; margin-bottom: -1px; }

.table-list-header-next .table-list-header-select-all { padding-left: 14px; }

.table-list-header-next .select-all-dropdown { padding-top: 10px; padding-bottom: 10px; }

.bulk-actions-header { position: sticky; top: 0px; z-index: 32; height: 50px; }

.table-list-triage { display: none; }

.triage-mode .table-list-filters { display: none !important; }

.triage-mode .table-list-triage { display: block; }

.breadcrumb { font-size: 16px; color: var(--color-fg-muted); }

.breadcrumb .separator { white-space: pre-wrap; }

.breadcrumb .separator::before, .breadcrumb .separator::after { content: " "; }

.breadcrumb strong.final-path { color: var(--color-fg-default); }

.capped-cards { list-style: none; }

.capped-card-content { display: block; background: var(--color-canvas-subtle); }

.capped-card-content::before { display: table; content: ""; }

.capped-card-content::after { display: table; clear: both; content: ""; }

.details-collapse .collapse { position: relative; display: none; height: 0px; overflow: hidden; transition: height 0.35s ease-in-out 0s; }

.details-collapse.open .collapse { display: block; height: auto; overflow: visible; }

.collapsible-sidebar-widget-button { display: flex; padding: 0px; align-items: center; background-color: transparent; border: 0px; justify-content: space-between; }

.collapsible-sidebar-widget-indicator { transition: transform 0.25s ease 0s; transform: translate(0px, 0px) translate3d(0px, 0px, 0px); }

.collapsible-sidebar-widget-loader { display: none; visibility: hidden; opacity: 0; transition: opacity 0.25s ease 0s; animation-play-state: paused; }

.collapsible-sidebar-widget-content { width: 100%; max-height: 0px; overflow: hidden; opacity: 0; transition: max-height 0.25s ease-in-out 0s, opacity 0.25s ease-in-out 0s; }

.collapsible-sidebar-widget-loading .collapsible-sidebar-widget-indicator { display: none; }

.collapsible-sidebar-widget-loading .collapsible-sidebar-widget-loader { display: block; visibility: visible; opacity: 1; animation-play-state: running; }

.collapsible-sidebar-widget-active .collapsible-sidebar-widget-content { max-height: 100%; overflow: visible; opacity: 1; }

.collapsible-sidebar-widget-active .collapsible-sidebar-widget-indicator { display: block; transform: rotate(180deg); }

.collapsible-sidebar-widget-active .collapsible-sidebar-widget-loader { display: none; visibility: hidden; opacity: 0; }

.collapsible-sidebar-widget-active .collapsible-sidebar-widget-active-hidden { display: none; opacity: 0; }

.comment .email-format { line-height: 1.5; }

.previewable-edit .previewable-comment-form { display: none; }

.previewable-edit .previewable-comment-form::before { display: table; content: ""; }

.previewable-edit .previewable-comment-form::after { display: table; clear: both; content: ""; }

.previewable-edit .previewable-comment-form .tabnav-tabs { display: inline-block; }

.previewable-edit .previewable-comment-form .form-actions { float: right; margin-right: 10px; margin-bottom: 10px; }

.previewable-edit.is-comment-editing .timeline-comment-header { display: none !important; }

.is-comment-editing .previewable-comment-form { display: block; }

.is-comment-editing .timeline-comment-actions, .is-comment-editing .edit-comment-hide { display: none; }

.is-comment-loading .previewable-comment-form { opacity: 0.5; }

.comment-show-stale { display: none; }

.is-comment-stale .comment-show-stale { display: block; }

.comment-body { width: 100%; padding: 15px; overflow: visible; font-size: 14px; }

.comment-body .highlight { background-color: transparent; overflow: visible !important; }

.comment-form-textarea { width: 100%; max-width: 100%; height: 100px; min-height: 100px; margin: 0px; line-height: 1.6; }

.comment-form-textarea.dragover { border: solid 1px var(--color-accent-emphasis); }

.hide-reaction-suggestion:hover::before, .hide-reaction-suggestion:hover::after, .hide-reaction-suggestion:active::before, .hide-reaction-suggestion:active::after { display: none; }

.reaction-suggestion[data-reaction-suggestion-message]:hover::before, .reaction-suggestion[data-reaction-suggestion-message]:hover::after { display: inline-block; }

.reaction-suggestion[data-reaction-suggestion-message]::before, .reaction-suggestion[data-reaction-suggestion-message]::after { display: inline-block; text-decoration: none; animation-name: tooltip-appear; animation-duration: 0.1s; animation-fill-mode: forwards; animation-timing-function: ease-in; animation-delay: 0s; }

.reaction-suggestion[data-reaction-suggestion-message]::after { content: attr(data-reaction-suggestion-message); }

.discussion-topic-header { position: relative; padding: 10px; overflow-wrap: break-word; }

.comment-form-error { padding: 16px 8px; margin: 8px; color: var(--color-fg-default); background-color: var(--color-danger-subtle); border: 1px solid var(--color-danger-emphasis); border-radius: 6px; }

.email-format { line-height: 1.5em !important; }

.email-format div { white-space: pre-wrap; }

.email-format .email-hidden-reply { display: none; white-space: pre-wrap; }

.email-format .email-hidden-reply.expanded { display: block; }

.email-format .email-quoted-reply, .email-format .email-signature-reply { padding: 0px 15px; margin: 15px 0px; color: var(--color-fg-muted); border-left: 4px solid var(--color-border-default); }

.email-format .email-hidden-toggle a { display: inline-block; height: 12px; padding: 0px 9px; font-size: 12px; font-weight: 600; line-height: 6px; color: var(--color-fg-default); text-decoration: none; vertical-align: middle; background: var(--color-neutral-muted); border-radius: 1px; }

.email-format .email-hidden-toggle a:hover { background-color: var(--color-accent-muted); }

.email-format .email-hidden-toggle a:active { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.comment-email-format div { white-space: normal; }

.comment-email-format .email-hidden-reply { display: none; white-space: normal; }

.comment-email-format .email-hidden-reply.expanded { display: block; }

.comment-email-format blockquote, .comment-email-format p { margin: 0px; }

.locked-conversation .write-tab, .locked-conversation .preview-tab { color: rgb(198, 203, 209); }

.write-tab:focus, .preview-tab:focus { outline: 1px dotted var(--color-accent-emphasis); }

.manual-file-chooser-transparent { min-height: 0px; overflow: hidden; opacity: 0.01; }

.manual-file-chooser-transparent::-webkit-file-upload-button { cursor: pointer; }

.manual-file-chooser-transparent:focus { opacity: 1 !important; }

.markdown-body .highlight:hover .zeroclipboard-container, .markdown-body .snippet-clipboard-content:hover .zeroclipboard-container { display: block; animation: 200ms ease 0s 1 normal both running fade-in; }

.markdown-body .highlight .zeroclipboard-container, .markdown-body .snippet-clipboard-content .zeroclipboard-container { display: none; animation: 200ms ease 0s 1 normal both running fade-out; }

.rich-diff clipboard-copy { display: none; }

.commit-form { position: relative; padding: 15px; border: 1px solid var(--color-border-default); border-radius: 6px; }

.commit-form::after, .commit-form::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.commit-form::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.commit-form::before { background-color: var(--color-border-default); }

.commit-form .input-block { margin-top: 10px; margin-bottom: 10px; }

.commit-form-avatar { float: left; margin-left: -64px; border-radius: 6px; }

.commit-form-actions::before { display: table; content: ""; }

.commit-form-actions::after { display: table; clear: both; content: ""; }

.commit-form-actions .BtnGroup { margin-right: 5px; }

.merge-commit-message { resize: vertical; }

.commit-sha { padding: 0.2em 0.4em; font-size: 90%; font-weight: 400; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-muted); border-radius: 0.2em; }

.commit .commit-title, .commit .commit-title a { color: var(--color-fg-default); }

.commit .commit-title.blank, .commit .commit-title.blank a { color: var(--color-fg-muted); }

.commit .commit-title .issue-link { font-weight: 600; color: var(--color-accent-fg); }

.commit .sha-block, .commit .sha { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; }

.commit.open .commit-desc { display: block; }

.commit-link { font-weight: 400; color: var(--color-accent-fg); }

.commit-ref { position: relative; display: inline-block; padding: 0px 5px; font: 0.85em / 1.8 ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; color: var(--color-fg-muted); white-space: nowrap; background-color: var(--color-accent-subtle); border-radius: 6px; }

.commit-ref .user { color: var(--color-accent-fg); }

a.commit-ref:hover { color: var(--color-accent-fg); text-decoration: none; background-color: var(--color-accent-subtle); }

.commit-desc { display: none; }

.commit-desc pre { max-width: 700px; margin-top: 10px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 11px; line-height: 1.45; color: var(--color-fg-default); white-space: pre-wrap; }

.commit-desc + .commit-branches { padding-top: 8px; margin-top: 2px; border-top: solid 1px var(--color-border-subtle); }

.commit-author-section { color: var(--color-fg-default); }

.commit-author-section span.user-mention { font-weight: 400; }

.commit-tease-sha { display: inline-block; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 90%; color: var(--color-fg-default); }

.commits-list-item[aria-selected="true"], .commits-list-item.navigation-focus { background: rgb(246, 251, 255); }

.commits-list-item .commit-title { margin: 0px; font-size: 15px; font-weight: 600; color: var(--color-fg-default); }

.commits-list-item .commit-meta { margin-top: 1px; font-weight: 400; color: var(--color-fg-muted); }

.commits-list-item .status .octicon { height: 14px; line-height: 14px; }

.commits-list-item .commit-author { color: var(--color-fg-muted); }

.commits-list-item .octicon-arrow-right { margin: 0px 3px; }

.commits-list-item .btn-outline { margin-top: 2px; }

.commits-list-item .commit-desc pre { margin-top: 5px; margin-bottom: 10px; color: var(--color-fg-muted); }

.commits-list-item .commit-desc pre a { word-break: break-word; }

.commit-indicator { margin-left: 4px; }

.commit-links-group { margin-right: 5px; }

.commits-list-item + .commits-list-item { border-top: 1px solid var(--color-border-default); }

.full-commit { padding: 8px 8px 0px; margin: 10px 0px; font-size: 14px; background: var(--color-neutral-subtle); border: 1px solid var(--color-border-default); border-radius: 6px; }

.full-commit:first-child { margin-top: 0px; }

.full-commit div.commit-title { font-size: 18px; font-weight: 600; color: var(--color-fg-default); }

.full-commit .branches-list { display: inline; margin-right: 10px; margin-left: 2px; vertical-align: middle; list-style: none; }

.full-commit .branches-list li { display: inline-block; padding-left: 3px; font-weight: 600; color: var(--color-fg-default); }

.full-commit .branches-list li::before { padding-right: 6px; font-weight: 400; content: "+"; }

.full-commit .branches-list li:first-child { padding-left: 0px; }

.full-commit .branches-list li:first-child::before { padding-right: 0px; content: ""; }

.full-commit .branches-list li.loading { font-weight: 400; color: var(--color-fg-muted); }

.full-commit .branches-list li.pull-request { font-weight: 400; color: var(--color-fg-muted); }

.full-commit .branches-list li.pull-request::before { margin-left: -8px; content: ""; }

.full-commit .branches-list li.pull-request-error { margin-bottom: -1px; }

.full-commit .branches-list li a { color: inherit; }

.full-commit .commit-meta { padding: 8px; margin-right: -8px; margin-left: -8px; background: var(--color-canvas-default); border-top: 1px solid var(--color-border-default); border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.full-commit .sha-block { margin-left: 16px; font-size: 12px; line-height: 24px; color: var(--color-fg-muted); }

.full-commit .sha-block > .sha { color: var(--color-fg-default); }

.full-commit .sha-block > a { color: var(--color-fg-default); text-decoration: none; border-bottom: 1px dotted var(--color-border-muted); }

.full-commit .sha-block > a:hover { border-bottom: 1px solid var(--color-border-default); }

.full-commit .commit-desc { display: block; margin: -5px 0px 10px; }

.full-commit .commit-desc pre { max-width: 100%; overflow: visible; font-size: 13px; overflow-wrap: break-word; }

.branches-tag-list { display: inline; margin-right: 10px; margin-left: 2px; vertical-align: middle; list-style: none; }

.branches-tag-list .more-commit-details, .branches-tag-list.open .hidden-text-expander { display: none; }

.branches-tag-list.open .more-commit-details { display: inline-block; }

.branches-tag-list li { display: inline-block; padding-left: 3px; }

.branches-tag-list li:first-child { padding-left: 0px; font-weight: 600; color: var(--color-fg-default); }

.branches-tag-list li.loading { font-weight: 400; color: var(--color-fg-muted); }

.branches-tag-list li.abbrev-tags { cursor: pointer; }

.branches-tag-list li a { color: inherit; }

.commit-branches { font-size: 12px; color: var(--color-fg-muted); vertical-align: middle; }

.commit-branches .octicon { vertical-align: middle; }

.commit-loader .loader-error { display: none; margin: 0px; font-size: 12px; font-weight: 600; color: var(--color-danger-fg); }

.commit-loader.is-error .loader-loading { display: none; }

.commit-loader.is-error .loader-error { display: block; }

.commit-build-statuses { position: relative; display: inline-block; text-align: left; }

.commit-build-statuses .dropdown-menu { min-width: 362.667px; max-width: 544px; padding-top: 0px; padding-bottom: 0px; }

.commit-build-statuses .dropdown-menu .merge-status-list { max-height: 170px; border-bottom: 0px; }

.commit-build-statuses .dropdown-menu-w, .commit-build-statuses .dropdown-menu-e { top: -11px; }

.commit-build-statuses .merge-status-item:last-child { border-radius: 0px 0px 6px 6px; }

.dropdown-signed-commit .dropdown-menu { width: 260px; margin-top: 8px; font-size: 13px; line-height: 1.4; white-space: normal; }

.dropdown-signed-commit .dropdown-menu::after { border-bottom-color: var(--color-canvas-subtle); }

.dropdown-signed-commit .dropdown-menu-w { top: -28px; margin-top: 0px; }

.dropdown-signed-commit .dropdown-menu-w::after { border-bottom-color: transparent; border-left-color: var(--color-canvas-subtle); }

.signed-commit-header { line-height: 1.3; white-space: normal; border-collapse: separate; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-default); border-top-left-radius: 6px; border-top-right-radius: 6px; }

.signed-commit-header .octicon-verified { color: var(--color-success-fg); }

.signed-commit-header .octicon-unverified { color: var(--color-fg-muted); }

.signed-commit-footer { font-size: 12px; line-height: 1.5; }

.signed-commit-cert-info { margin-bottom: 6px; }

.signed-commit-cert-info td { vertical-align: top; }

.signed-commit-cert-info td:first-child { width: 44px; padding-right: 12px; }

.signed-commit-badge { display: inline-block; padding: 1px 4px; font-size: 10px; color: var(--color-fg-muted); vertical-align: middle; user-select: none; background: none; border: 1px solid var(--color-border-default); border-radius: 6px; }

.signed-commit-badge:hover { text-decoration: none; border-color: var(--color-neutral-muted); }

.signed-commit-badge.verified { color: var(--color-success-fg); }

.signed-commit-badge.verified:hover { border-color: var(--color-success-emphasis); }

.signed-commit-badge.unverified { color: var(--color-attention-fg); }

.signed-commit-badge.unverified:hover { border-color: var(--color-attention-emphasis); }

.signed-commit-badge-small { margin-top: -2px; margin-right: 3px; }

.signed-commit-badge-medium { padding: 3px 8px; font-size: 12px; border-radius: 6px; }

.signed-commit-badge-large { padding: 5px 12px; margin-right: 9px; font-size: 13px; line-height: 20px; border-radius: 6px; }

.signed-commit-verified-label { color: rgb(30, 126, 52); white-space: nowrap; }

.signed-commit-signer-name { font-size: 14px; text-align: left; }

.signed-commit-signer-name .signer { display: block; font-weight: 600; color: var(--color-fg-default); }

.table-of-contents { margin: 15px 0px; }

.table-of-contents li { padding: 7px 0px; list-style-type: none; }

.table-of-contents li + li { border-top: 1px solid var(--color-border-muted); }

.table-of-contents li > .octicon { margin-right: 3px; }

.table-of-contents .toc-diff-stats { padding-left: 20px; line-height: 26px; }

.table-of-contents .toc-diff-stats .octicon { float: left; margin-top: 3px; margin-left: -20px; color: rgb(198, 203, 209); }

.table-of-contents .toc-diff-stats .btn-link { font-weight: 600; }

.table-of-contents .toc-diff-stats + .content { padding-top: 5px; }

.table-of-contents .octicon-diff-removed { color: var(--color-danger-fg); }

.table-of-contents .octicon-diff-renamed { color: var(--color-fg-muted); }

.table-of-contents .octicon-diff-modified { color: var(--color-attention-fg); }

.table-of-contents .octicon-diff-added { color: var(--color-success-fg); }

@media (min-width: 768px) {
  .toc-select .select-menu-modal { min-width: 420px; }
}

.toc-select .select-menu-item .css-truncate { max-width: 290px; }

.toc-select .select-menu-item-heading, .toc-select .select-menu-item-text { color: var(--color-fg-default); }

.toc-select .select-menu-item-icon.octicon-diff-removed { color: var(--color-danger-fg); }

.toc-select .select-menu-item-icon.octicon-diff-renamed { color: var(--color-fg-muted); }

.toc-select .select-menu-item-icon.octicon-diff-modified { color: var(--color-attention-fg); }

.toc-select .select-menu-item-icon.octicon-diff-added { color: var(--color-success-fg); }

.toc-select[aria-selected="true"] .select-menu-item-heading, .toc-select[aria-selected="true"] .select-menu-item-text, .toc-select[aria-selected="true"] .color-fg-success, .toc-select[aria-selected="true"] .color-fg-danger, .toc-select[aria-selected="true"] .color-fg-muted, .toc-select[aria-selected="true"] .octicon-diff-removed, .toc-select[aria-selected="true"] .octicon-diff-renamed, .toc-select[aria-selected="true"] .octicon-diff-modified, .toc-select[aria-selected="true"] .octicon-diff-added, .toc-select[aria-selected="true"] .diffstat, .toc-select [role^="menuitem"]:focus .select-menu-item-heading, .toc-select [role^="menuitem"]:focus .select-menu-item-text, .toc-select [role^="menuitem"]:focus .color-fg-success, .toc-select [role^="menuitem"]:focus .color-fg-danger, .toc-select [role^="menuitem"]:focus .color-fg-muted, .toc-select [role^="menuitem"]:focus .octicon-diff-removed, .toc-select [role^="menuitem"]:focus .octicon-diff-renamed, .toc-select [role^="menuitem"]:focus .octicon-diff-modified, .toc-select [role^="menuitem"]:focus .octicon-diff-added, .toc-select [role^="menuitem"]:focus .diffstat, .toc-select [role^="menuitem"]:hover .select-menu-item-heading, .toc-select [role^="menuitem"]:hover .select-menu-item-text, .toc-select [role^="menuitem"]:hover .color-fg-success, .toc-select [role^="menuitem"]:hover .color-fg-danger, .toc-select [role^="menuitem"]:hover .color-fg-muted, .toc-select [role^="menuitem"]:hover .octicon-diff-removed, .toc-select [role^="menuitem"]:hover .octicon-diff-renamed, .toc-select [role^="menuitem"]:hover .octicon-diff-modified, .toc-select [role^="menuitem"]:hover .octicon-diff-added, .toc-select [role^="menuitem"]:hover .diffstat, .toc-select .navigation-focus .select-menu-item-heading, .toc-select .navigation-focus .select-menu-item-text, .toc-select .navigation-focus .color-fg-success, .toc-select .navigation-focus .color-fg-danger, .toc-select .navigation-focus .color-fg-muted, .toc-select .navigation-focus .octicon-diff-removed, .toc-select .navigation-focus .octicon-diff-renamed, .toc-select .navigation-focus .octicon-diff-modified, .toc-select .navigation-focus .octicon-diff-added, .toc-select .navigation-focus .diffstat { color: var(--color-fg-on-emphasis)  !important; }

.conversation-list-heading { height: 0px; margin: 32px 0px 16px; font-size: 16px; font-weight: 400; color: var(--color-fg-muted); text-align: center; border-bottom: 1px solid var(--color-border-default); }

.conversation-list-heading .inner { position: relative; top: -16px; display: inline-block; padding: 0px 4px; background: var(--color-canvas-default); }

.copyable-terminal { position: relative; padding: 10px 55px 10px 10px; background-color: var(--color-canvas-subtle); border-radius: 6px; }

.copyable-terminal-content { overflow: auto; }

.copyable-terminal-button { position: absolute; top: 5px; right: 5px; }

.copyable-terminal-button .zeroclipboard-button { float: right; }

.copyable-terminal-button .zeroclipboard-button .octicon { padding-left: 1px; margin: 0px auto; }

.blob-wrapper { overflow: auto hidden; }

.blob-wrapper table tr:nth-child(2n) { background-color: transparent; }

.page-blob.height-full .blob-wrapper { overflow-y: auto; }

.page-edit-blob.height-full .CodeMirror { height: 300px; }

.page-edit-blob.height-full .CodeMirror, .page-edit-blob.height-full .CodeMirror-scroll { display: flex; flex-direction: column; flex: 1 1 auto; }

.blob-wrapper-embedded { max-height: 240px; overflow-y: auto; }

.diff-table { width: 100%; border-collapse: separate; }

.diff-table .line-comments { padding: 10px; vertical-align: top; border-top: 1px solid var(--color-border-default); }

.diff-table .line-comments:first-child + .empty-cell { border-left-width: 1px; }

.diff-table tr:not(:last-child) .line-comments { border-top: 1px solid var(--color-border-default); border-bottom: 1px solid var(--color-border-default); }

.diff-view .bidi-line-alert, .diff-table .bidi-line-alert { position: absolute; left: -60px; margin: 2px; }

.comment-body .diff-view .bidi-line-alert { left: 0px; }

.blob-num { width: 1%; min-width: 50px; padding-right: 10px; padding-left: 10px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; line-height: 20px; color: var(--color-fg-subtle); text-align: right; white-space: nowrap; vertical-align: top; cursor: pointer; user-select: none; }

.blob-num:hover { color: var(--color-fg-default); }

.blob-num::before { content: attr(data-line-number); }

.blob-num.non-expandable { cursor: default; }

.blob-num.non-expandable:hover { color: var(--color-fg-subtle); }

.blob-code { position: relative; padding-right: 10px; padding-left: 10px; line-height: 20px; vertical-align: top; }

.blob-code-inner { overflow: visible; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; color: var(--color-fg-default); overflow-wrap: normal; white-space: pre; }

.blob-code-inner .x-first { border-top-left-radius: 0.2em; border-bottom-left-radius: 0.2em; }

.blob-code-inner .x-last { border-top-right-radius: 0.2em; border-bottom-right-radius: 0.2em; }

.blob-code-inner.highlighted, .blob-code-inner .highlighted { background-color: var(--color-attention-subtle); box-shadow: inset 2px 0 0 var(--color-attention-muted); }

.blob-code-inner::selection, .blob-code-inner ::selection { background-color: var(--color-accent-muted); }

.blob-code-marker::before { padding-right: 8px; content: attr(data-code-marker); }

.blob-code-marker-addition::before { content: "+ "; }

.blob-code-marker-deletion::before { content: "- "; }

.blob-code-marker-context::before { content: "  "; }

.soft-wrap .diff-table { table-layout: fixed; }

.soft-wrap .blob-code { padding-left: 18px; text-indent: -7px; }

.soft-wrap .blob-code-inner { overflow-wrap: break-word; white-space: pre-wrap; }

.soft-wrap .no-nl-marker { display: none; }

.soft-wrap .add-line-comment { margin-left: -28px; }

.blob-num-hunk, .blob-code-hunk, .blob-num-expandable { color: var(--color-fg-muted); vertical-align: middle; }

.blob-num-hunk, .blob-num-expandable { background-color: var(--color-diff-blob-hunk-num-bg); }

.blob-code-hunk { padding-top: 4px; padding-bottom: 4px; background-color: var(--color-accent-subtle); border-width: 1px 0px; }

.blob-expanded .blob-num, .blob-expanded .blob-code:not(.blob-code-context) { background-color: var(--color-canvas-subtle); }

.blob-expanded + tr:not(.blob-expanded) .blob-num, .blob-expanded + tr:not(.blob-expanded) .blob-code { border-top: 1px solid var(--color-border-muted); }

.blob-expanded .blob-num-hunk { border-top: 1px solid var(--color-border-muted); }

tr:not(.blob-expanded) + .blob-expanded .blob-num, tr:not(.blob-expanded) + .blob-expanded .blob-code { border-top: 1px solid var(--color-border-muted); }

.blob-num-expandable { width: auto; padding: 0px; font-size: 12px; text-align: center; }

.blob-num-expandable .directional-expander { display: block; width: auto; height: auto; margin-right: -1px; color: var(--color-diff-blob-expander-icon); cursor: pointer; }

.blob-num-expandable .single-expander { padding-top: 4px; padding-bottom: 4px; }

.blob-num-expandable .directional-expander:hover { color: var(--color-fg-on-emphasis); text-shadow: none; background-color: var(--color-accent-emphasis); border-color: var(--color-accent-emphasis); }

.blob-code-addition { background-color: var(--color-diff-blob-addition-line-bg); outline: transparent dotted 1px; }

.blob-code-addition .x { color: var(--color-diff-blob-addition-fg); background-color: var(--color-diff-blob-addition-word-bg); }

.blob-num-addition { color: var(--color-diff-blob-addition-num-text); background-color: var(--color-diff-blob-addition-num-bg); border-color: var(--color-success-emphasis); }

.blob-num-addition:hover { color: var(--color-fg-default); }

.blob-code-deletion { background-color: var(--color-diff-blob-deletion-line-bg); outline: transparent dashed 1px; }

.blob-code-deletion .x { color: var(--color-diff-blob-deletion-fg); background-color: var(--color-diff-blob-deletion-word-bg); }

.blob-num-deletion { color: var(--color-diff-blob-deletion-num-text); background-color: var(--color-diff-blob-deletion-num-bg); border-color: var(--color-danger-emphasis); }

.blob-num-deletion:hover { color: var(--color-fg-default); }

.is-selecting { cursor: ns-resize !important; }

.is-selecting .blob-num { cursor: ns-resize !important; }

.is-selecting .add-line-comment, .is-selecting a { pointer-events: none; cursor: ns-resize !important; }

.is-selecting .is-hovered .add-line-comment { opacity: 0; }

.is-selecting.file-diff-split { cursor: nwse-resize !important; }

.is-selecting.file-diff-split .blob-num { cursor: nwse-resize !important; }

.is-selecting.file-diff-split .empty-cell, .is-selecting.file-diff-split .add-line-comment, .is-selecting.file-diff-split a { pointer-events: none; cursor: nwse-resize !important; }

.selected-line { position: relative; }

.selected-line::after { position: absolute; top: 0px; left: 0px; display: block; width: 100%; height: 100%; box-sizing: border-box; pointer-events: none; content: ""; background: var(--color-attention-subtle); mix-blend-mode: var(--color-diff-blob-selected-line-highlight-mix-blend-mode); }

.selected-line.selected-line-top::after { border-top: 1px solid var(--color-attention-muted); }

.selected-line.selected-line-bottom::after { border-bottom: 1px solid var(--color-attention-muted); }

.selected-line:first-child::after, .selected-line.selected-line-left::after { border-left: 1px solid var(--color-attention-muted); }

.selected-line:last-child::after, .selected-line.selected-line-right::after { border-right: 1px solid var(--color-attention-muted); }

.is-commenting .selected-line.blob-code::before { position: absolute; top: 0px; left: -1px; display: block; width: 4px; height: 100%; content: ""; background: var(--color-accent-emphasis); }

.add-line-comment { position: relative; z-index: 5; float: left; width: 22px; height: 22px; margin: -2px -10px -2px -20px; line-height: 21px; color: var(--color-fg-on-emphasis); text-align: center; text-indent: 0px; cursor: pointer; background-color: var(--color-accent-emphasis); border-radius: 6px; box-shadow: var(--color-shadow-medium); opacity: 0; transition: transform 0.1s ease-in-out 0s; transform: scale(0.8, 0.8); }

.add-line-comment:hover { transform: scale(1, 1); }

.is-hovered .add-line-comment, .add-line-comment:focus { opacity: 1; }

.add-line-comment .octicon { vertical-align: text-top; pointer-events: none; }

.add-line-comment.octicon-check { background: rgb(51, 51, 51); opacity: 1; }

.inline-comment-form { border: 1px solid rgb(223, 226, 229); border-radius: 6px; }

.timeline-inline-comments { width: 100%; table-layout: fixed; }

.timeline-inline-comments .inline-comments, .show-inline-notes .inline-comments { display: table-row; }

.inline-comments { display: none; }

.inline-comments.is-collapsed { display: none; }

.inline-comments .line-comments.is-collapsed { visibility: hidden; }

.inline-comments .line-comments + .blob-num { border-left-width: 1px; }

.inline-comments .timeline-comment { margin-bottom: 10px; }

.inline-comments .inline-comment-form, .inline-comments .inline-comment-form-container { max-width: 780px; }

.comment-holder { max-width: 780px; }

.line-comments + .line-comments, .empty-cell + .line-comments { border-left: 1px solid var(--color-border-muted); }

.inline-comment-form-container .inline-comment-form, .inline-comment-form-container.open .inline-comment-form-actions { display: none; }

.inline-comment-form-container .inline-comment-form-actions, .inline-comment-form-container.open .inline-comment-form { display: block; }

body.split-diff .container, body.split-diff .container-lg, body.split-diff .container-xl, body.full-width .container, body.full-width .container-lg, body.full-width .container-xl { width: 100%; max-width: none; padding-right: 20px; padding-left: 20px; }

body.split-diff .repository-content, body.full-width .repository-content { width: 100%; }

body.split-diff .new-pr-form, body.full-width .new-pr-form { max-width: 980px; }

.file-diff-split { table-layout: fixed; }

.file-diff-split .blob-code + .blob-num { border-left: 1px solid var(--color-border-muted); }

.file-diff-split .blob-code-inner { overflow-wrap: break-word; white-space: pre-wrap; }

.file-diff-split .empty-cell { cursor: default; background-color: var(--color-neutral-subtle); border-right-color: var(--color-border-muted); }

@media (max-width: 1280px) {
  .file-diff-split .write-selected .comment-form-head { margin-bottom: 48px !important; }
  .file-diff-split markdown-toolbar { position: absolute; right: 8px; bottom: -40px; }
}

.submodule-diff-stats .octicon-diff-removed { color: var(--color-danger-fg); }

.submodule-diff-stats .octicon-diff-renamed { color: var(--color-fg-muted); }

.submodule-diff-stats .octicon-diff-modified { color: var(--color-attention-fg); }

.submodule-diff-stats .octicon-diff-added { color: var(--color-success-fg); }

.BlobToolbar { left: -17px; }

.BlobToolbar-dropdown { margin-left: -2px; }

.pl-token:hover, .pl-token.active { cursor: pointer; background: rgb(255, 234, 127); }

.discussion-timeline { position: relative; float: left; }

.discussion-timeline::before { position: absolute; top: 0px; bottom: 0px; left: 72px; z-index: 0; display: block; width: 2px; content: ""; background-color: var(--color-border-default); }

.discussion-timeline.team-discussion-timeline::before { bottom: 24px; left: 20px; z-index: auto; background-color: var(--color-border-default); }

.discussion-timeline.team-discussion-timeline .blankslate { background: var(--color-canvas-default); }

.discussion-sidebar-item { padding-top: 16px; font-size: 12px; color: var(--color-fg-muted); }

.discussion-sidebar-item .btn .octicon { margin-right: 0px; }

.discussion-sidebar-item .muted-icon { color: var(--color-fg-muted); }

.discussion-sidebar-item .muted-icon:hover { color: var(--color-accent-fg); text-decoration: none; cursor: pointer; }

.discussion-sidebar-item + .discussion-sidebar-item { margin-top: 16px; border-top: 1px solid var(--color-border-muted); }

.discussion-sidebar-item .select-menu { position: relative; }

.discussion-sidebar-item .select-menu-modal-holder { top: 25px; right: -1px; left: auto; }

.discussion-sidebar-heading { margin-bottom: 8px; font-size: 12px; color: var(--color-fg-muted); }

.discussion-sidebar-toggle { padding: 4px 0px; margin: -4px 0px 4px; }

.discussion-sidebar-toggle .octicon { float: right; color: var(--color-fg-muted); }

.discussion-sidebar-toggle:hover { color: var(--color-accent-fg); text-decoration: none; cursor: pointer; }

.discussion-sidebar-toggle:hover .octicon { color: inherit; }

button.discussion-sidebar-toggle { display: block; width: 100%; font-weight: 600; text-align: left; background: none; border: 0px; }

.sidebar-progress-bar .progress-bar { height: 8px; margin-bottom: 2px; border-radius: 6px; }

.sidebar-assignee .css-truncate-target { max-width: 110px; }

.sidebar-assignee .assignee { font-weight: 600; color: var(--color-fg-muted); vertical-align: middle; }

.sidebar-assignee .assignee:hover { color: var(--color-accent-fg); text-decoration: none; }

.sidebar-assignee .reviewers-status-icon { width: 14px; }

.sidebar-assignee .octicon { margin-top: 2px; }

.thread-subscribe-form.is-error .thread-subscribe-button { color: var(--color-danger-fg); }

.sidebar-notifications { position: relative; }

.sidebar-notifications .thread-subscription-status { padding: 0px; margin: 0px; border: 0px; }

.sidebar-notifications .thread-subscription-status .thread-subscribe-form { display: block; }

.sidebar-notifications .thread-subscription-status .reason { padding: 0px; margin: 4px 0px 0px; }

.sidebar-notifications .thread-subscription-status .btn-sm { display: block; width: 100%; }

.participation .participant-avatar { float: left; margin: 4px 0px 0px 4px; }

.participation a { color: var(--color-fg-muted); }

.participation a:hover { color: var(--color-accent-fg); text-decoration: none; }

.participation-avatars { margin-left: -4px; }

.participation-avatars::before { display: table; content: ""; }

.participation-avatars::after { display: table; clear: both; content: ""; }

.participation-more { float: left; margin: 8px 4px 0px; }

.inline-comment-form .form-actions, .timeline-new-comment .form-actions { padding: 0px 8px 8px; }

.inline-comment-form::before { display: table; content: ""; }

.inline-comment-form::after { display: table; clear: both; content: ""; }

.inline-comment-form .tabnav-tabs { display: inline-block; }

.inline-comment-form .form-actions { float: right; }

.gh-header-actions { float: right; margin-top: 4px; }

.gh-header-actions .btn-sm { float: left; margin-left: 4px; }

.gh-header-actions .btn-sm .octicon { margin-right: 0px; }

.gh-header { background-color: var(--color-canvas-default); }

.gh-header .gh-header-sticky { height: 1px; }

.gh-header .gh-header-sticky .meta { font-size: 12px; }

.gh-header .gh-header-sticky .sticky-content, .gh-header .gh-header-sticky .gh-header-shadow { display: none; }

.gh-header .gh-header-sticky.is-stuck { z-index: 110; height: 60px; }

.gh-header .gh-header-sticky.is-stuck .sticky-content { display: block; }

.gh-header .gh-header-sticky.is-stuck .css-truncate-target { max-width: 150px; }

.gh-header .gh-header-sticky.is-stuck + .gh-header-shadow { position: fixed; top: 0px; right: 0px; left: 0px; z-index: 109; display: block; height: 60px; content: ""; background-color: var(--color-canvas-default); border-bottom: 1px solid var(--color-border-default); }

.gh-header .gh-header-edit { display: none; }

.gh-header .gh-header-meta .base-ref { display: inline-block; }

.gh-header .gh-header-meta .commit-ref-dropdown { display: none; }

.gh-header.open .gh-header-show { display: none; }

.gh-header.open .gh-header-edit { display: block; }

.gh-header.open .gh-header-meta .base-ref { display: none; }

.gh-header.open .gh-header-meta .commit-ref-dropdown { display: inline-block; margin-top: -4px; vertical-align: top; }

.gh-header-title { margin-right: 150px; margin-bottom: 0px; font-weight: 400; line-height: 1.125; overflow-wrap: break-word; }

.gh-header-no-access .gh-header-title { margin-right: 0px; }

.gh-header-number { font-weight: 300; color: var(--color-fg-muted); }

.gh-header-meta { padding-bottom: 8px; margin-top: 8px; font-size: 14px; color: var(--color-fg-muted); border-bottom: 1px solid var(--color-border-default); }

.gh-header.issue .gh-header-meta { margin-bottom: 16px; }

.gh-header.pull .gh-header-meta { padding-bottom: 0px; border-bottom: 0px; }

.gh-header-meta .commit-ref .css-truncate-target, .gh-header-meta .commit-ref:hover .css-truncate-target { max-width: 80vw; }

.gh-header-meta .State { margin-right: 8px; }

.gh-header-meta .avatar { float: left; margin-top: -4px; margin-right: 4px; }

.timeline-comment-wrapper { position: relative; padding-left: 56px; margin-top: 16px; margin-bottom: 16px; }

.timeline-comment-avatar { float: left; margin-left: -56px; border-radius: 6px; }

.timeline-comment-avatar .avatar { width: 40px; height: 40px; }

.timeline-comment-avatar .avatar-child { width: 20px; height: 20px; }

.discussions-timeline-scroll-target { width: 100%; padding-top: 60px; margin-top: -60px; pointer-events: none !important; }

.discussions-timeline-scroll-target > * { pointer-events: auto; }

.timeline-comment { position: relative; color: var(--color-fg-default); background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.timeline-comment.will-transition-once { transition: border-color 0.65s ease-in-out 0s; }

.timeline-comment.will-transition-once .timeline-comment-header { transition: background-color 0.65s ease 0s, border-bottom-color 0.65s ease-in-out 0s; }

.timeline-comment.will-transition-once::before, .timeline-comment.will-transition-once::after { transition: border-right-color 0.65s ease-in-out 0s; }

.timeline-comment.current-user { border-color: var(--color-accent-muted); }

.timeline-comment.current-user .timeline-comment-header { background-color: var(--color-accent-subtle); border-bottom-color: var(--color-accent-muted); }

.timeline-comment.current-user .Label { border-color: var(--color-accent-muted); }

.timeline-comment.current-user .previewable-comment-form .comment-form-head.tabnav { color: var(--color-accent-muted); background-color: var(--color-accent-subtle); border-bottom-color: var(--color-accent-muted); }

.timeline-comment.unread-item, .timeline-comment.is-internal { border-color: var(--color-attention-muted); }

.timeline-comment.unread-item .timeline-comment-header, .timeline-comment.is-internal .timeline-comment-header { background-color: var(--color-attention-subtle); border-bottom-color: var(--color-attention-muted); }

.timeline-comment.unread-item .Label, .timeline-comment.is-internal .Label { border-color: var(--color-attention-muted); }

.timeline-comment.unread-item .previewable-comment-form .comment-form-head.tabnav, .timeline-comment.is-internal .previewable-comment-form .comment-form-head.tabnav { color: var(--color-attention-muted); background-color: var(--color-attention-subtle); border-bottom-color: var(--color-attention-muted); }

.timeline-comment:empty { display: none; }

.timeline-comment .comment + .comment { border-top: 1px solid var(--color-border-default); }

.timeline-comment .comment + .comment::before, .timeline-comment .comment + .comment::after { display: none; }

.timeline-comment .comment + .comment .timeline-comment-header { border-top-left-radius: 0px; border-top-right-radius: 0px; }

.timeline-comment--caret::after, .timeline-comment--caret::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.timeline-comment--caret::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-subtle), var(--color-canvas-subtle)); }

.timeline-comment--caret::before { background-color: var(--color-border-default); }

.is-pending .timeline-comment--caret::after, .is-pending .timeline-comment--caret::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.is-pending .timeline-comment--caret::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-attention-subtle), var(--color-attention-subtle)); }

.is-pending .timeline-comment--caret::before { background-color: var(--color-attention-emphasis); }

.timeline-comment--caret.current-user::after, .timeline-comment--caret.current-user::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.timeline-comment--caret.current-user::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-accent-subtle), var(--color-accent-subtle)); }

.timeline-comment--caret.current-user::before { background-color: var(--color-accent-muted); }

.timeline-comment--caret.unread-item::after, .timeline-comment--caret.unread-item::before, .timeline-comment--caret.is-internal::after, .timeline-comment--caret.is-internal::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.timeline-comment--caret.unread-item::after, .timeline-comment--caret.is-internal::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-attention-subtle), var(--color-attention-subtle)); }

.timeline-comment--caret.unread-item::before, .timeline-comment--caret.is-internal::before { background-color: var(--color-attention-muted); }

.timeline-comment--caret.timeline-comment--caret-nw::before, .timeline-comment--caret.timeline-comment--caret-nw::after { transform: rotate(90deg); }

.timeline-comment--caret.timeline-comment--caret-nw::before { top: -12px; left: 12px; }

.timeline-comment--caret.timeline-comment--caret-nw::after { top: -10px; left: 11px; }

.page-responsive .timeline-comment--caret::before, .page-responsive .timeline-comment--caret::after { display: none; }

@media (min-width: 768px) {
  .page-responsive .timeline-comment--caret::before, .page-responsive .timeline-comment--caret::after { display: block; }
}

:target .timeline-comment--caret::before { background-color: var(--color-accent-emphasis); }

:target .timeline-comment { z-index: 2; border-color: var(--color-accent-emphasis); box-shadow: var(--color-primer-shadow-focus); }

.review-comment:target { border: 1px solid var(--color-accent-emphasis); border-radius: 6px; box-shadow: var(--color-primer-shadow-focus); }

.timeline-comment-header { display: flex; align-items: center; padding-right: 16px; padding-left: 16px; color: var(--color-fg-muted); flex-direction: row-reverse; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-default); border-top-left-radius: 6px; border-top-right-radius: 6px; }

.timeline-comment-header:only-child { border-bottom: 0px; border-radius: 6px; }

.timeline-comment-header .author { color: var(--color-fg-muted); }

.timeline-comment-header code { word-break: break-all; }

.comment-type-icon { color: inherit; }

.timeline-comment-header-text { min-width: 0px; padding-top: 8px; padding-bottom: 8px; margin-bottom: 1px; flex: 1 1 auto; }

.timeline-comment-header-text code a { color: var(--color-fg-muted); }

.timeline-comment-actions { float: right; margin-left: 8px; }

.timeline-comment-actions .show-more-popover.dropdown-menu-sw { right: -6px; margin-top: -5px; }

.timeline-comment-action { display: inline-block; padding: 8px 4px; color: var(--color-fg-muted); }

.timeline-comment-action:hover, .timeline-comment-action:focus { color: var(--color-accent-fg); text-decoration: none; opacity: 1; }

.timeline-comment-action .octicon-check { height: 16px; }

.timeline-comment-action.disabled { color: var(--color-fg-muted); cursor: default; }

.timeline-comment-action.disabled:hover { color: var(--color-fg-muted); }

.compare-tab-comments .timeline-comment-actions { display: none; }

.timeline-new-comment { margin-bottom: 0px; }

.timeline-new-comment .comment-form-head { margin-bottom: 8px; }

.timeline-new-comment .previewable-comment-form .comment-body { padding: 4px 4px 16px; border-bottom: 1px solid var(--color-border-default); }

.comment-form-head .toolbar-commenting { float: right; }

.discussion-item-icon { float: left; width: 32px; height: 32px; margin-top: -5px; margin-left: -39px; line-height: 28px; color: var(--color-fg-muted); text-align: center; background-color: var(--color-timeline-badge-bg); border: 2px solid var(--color-canvas-default); border-radius: 50%; }

.discussion-item-header { color: var(--color-fg-muted); overflow-wrap: break-word; }

.discussion-item-header .discussion-item-private { vertical-align: -1px; }

.discussion-item-header:last-child { padding-bottom: 0px; }

.discussion-item-header .commit-ref { font-size: 85%; vertical-align: baseline; }

.discussion-item-header .btn-outline { float: right; padding: 4px 8px; margin-top: -4px; margin-left: 8px; }

.discussion-item-private { color: var(--color-fg-muted); }

.previewable-comment-form .comment-form-head.tabnav { padding: 8px 8px 0px; background: var(--color-canvas-subtle); border-radius: 6px 6px 0px 0px; }

.page-responsive .previewable-comment-form .comment-form-head.tabnav .toolbar-commenting { background: var(--color-canvas-default); }

@media (min-width: 1012px) {
  .page-responsive .previewable-comment-form .comment-form-head.tabnav .toolbar-commenting { background: transparent; }
}

@media (min-width: 768px) {
  .page-responsive .previewable-comment-form .comment-form-head.tabnav { background: var(--color-canvas-subtle); }
}

.previewable-comment-form .comment { border: 0px; }

.previewable-comment-form .comment-body { padding: 4px 4px 16px; background-color: transparent; border-bottom: 1px solid var(--color-border-default); }

.previewable-comment-form .timeline-comment .timeline-comment-actions { display: none; }

.new-discussion-timeline .composer .timeline-comment { margin-bottom: 8px; }

.new-discussion-timeline .composer .comment-form-head.tabnav { padding-top: 0px; background-color: var(--color-canvas-default); }

.composer.composer-responsive { padding-left: 0px; }

.composer.composer-responsive .discussion-topic-header { padding: 0px; }

.composer.composer-responsive .timeline-comment { border: 0px; }

.composer.composer-responsive .timeline-comment::before, .composer.composer-responsive .timeline-comment::after { display: none; }

.composer.composer-responsive .previewable-comment-form .write-content { margin: 0px; }

@media (min-width: 768px) {
  .composer.composer-responsive { padding-left: 56px; }
  .composer.composer-responsive .timeline-comment { border: 1px solid var(--color-border-default); }
  .composer.composer-responsive .timeline-comment::after, .composer.composer-responsive .timeline-comment::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }
  .composer.composer-responsive .timeline-comment::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }
  .composer.composer-responsive .timeline-comment::before { background-color: var(--color-border-default); }
}

.discussion-timeline-actions { background-color: var(--color-canvas-default); border-top: 2px solid var(--color-border-default); }

.discussion-timeline-actions .merge-pr { padding-top: 0px; border-top: 0px; }

.discussion-timeline-actions .thread-subscription-status { margin-top: 16px; }

.pagination-loader-container { background-color: var(--color-canvas-default); background-image: url("/images/modules/pulls/progressive-disclosure-line.svg"); background-repeat: repeat-x; background-position: center center; background-size: 16px; }

[data-color-mode="light"][data-light-theme*="dark"] .pagination-loader-container, [data-color-mode="dark"][data-dark-theme*="dark"] .pagination-loader-container { background-image: url("/images/modules/pulls/progressive-disclosure-line-dark.svg"); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] .pagination-loader-container { background-image: url("/images/modules/pulls/progressive-disclosure-line-dark.svg"); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] .pagination-loader-container { background-image: url("/images/modules/pulls/progressive-disclosure-line-dark.svg"); }
}

:target .timeline-comment-group .timeline-comment { border-color: var(--color-accent-emphasis); box-shadow: var(--color-primer-shadow-focus); }

.is-pending .form-actions { margin-right: 8px; margin-bottom: 4px; }

.is-pending .file, .is-pending .file-header, .is-pending .tabnav-tab.selected, .is-pending .comment-form-head.tabnav { border-color: var(--color-attention-emphasis); }

.is-pending .file-header, .is-pending .comment-form-head.tabnav { background-color: var(--color-attention-subtle); }

.discussion-item-icon-gray { background-color: var(--color-timeline-badge-bg)  !important; }

.new-reactions-summary-item { width: 26px; height: 26px; padding: 0px; line-height: 26px; background-color: var(--color-btn-bg); }

.new-reactions-summary-item:hover { background-color: var(--color-btn-hover-bg)  !important; border-color: var(--color-btn-hover-border)  !important; }

.new-reactions-summary-item .octicon { vertical-align: text-bottom; }

.new-reactions-dropdown[open] .new-reactions-summary-item { background-color: var(--color-btn-selected-bg)  !important; border-color: var(--color-btn-border)  !important; }

.new-reactions-dropdown .dropdown-menu-reactions { width: auto; padding: 0px 2px; }

.new-reactions-dropdown .dropdown-menu-reactions::before, .new-reactions-dropdown .dropdown-menu-reactions::after { background-color: transparent; border: 0px; }

.new-reactions-dropdown .dropdown-item-reaction { width: 32px; height: 32px; padding: 4px; margin: 4px 2px; }

.new-reactions-dropdown .dropdown-item-reaction:hover { background-color: var(--color-btn-hover-bg); }

.footer-octicon { color: var(--color-fg-subtle); }

.footer-octicon:hover { color: var(--color-fg-muted); }

.user-mention, .team-mention { font-weight: 600; color: var(--color-fg-default); white-space: nowrap; }

@media (max-width: 543px) {
  .notifications-component-menu-modal { margin: calc(10vh - 16px) 0px; }
}

@media (min-width: 544px) {
  .notifications-component-menu-modal, .notifications-component-dialog, .notifications-component-dialog-modal { width: 100%; }
}

@media (min-width: 768px) {
  .notifications-component-menu-modal, .notifications-component-dialog, .notifications-component-dialog-modal { min-width: 300px; }
}

.notifications-component-dialog:not([hidden]) + .notifications-component-dialog-overlay { position: fixed; inset: 0px; z-index: 80; display: block; cursor: default; content: " "; background: var(--color-primer-canvas-backdrop); }

@media (min-width: 544px) {
  .notifications-component-dialog:not([hidden]) + .notifications-component-dialog-overlay { display: none; }
}

.notifications-component-dialog { z-index: 99; animation: 0s ease 0s 1 normal none running none; }

@keyframes notifications-component-dialog-animation--sm { 
  0% { opacity: 0; transform: translateX(16px); }
}

@media (min-width: 544px) {
  .notifications-component-dialog { position: absolute; inset: auto; max-height: none; padding-top: 0px; margin: 0px; transform: none; }
}

.notifications-component-dialog .notifications-component-dialog-modal { animation: 0s ease 0s 1 normal none running none; }

.pagehead { position: relative; padding-top: 24px; padding-bottom: 24px; margin-bottom: 24px; border-bottom: 1px solid var(--color-border-default); }

.pagehead.admin { background: url("/images/modules/pagehead/background-yellowhatch-v3.png") 0px 0px repeat-x; }

.pagehead ul.pagehead-actions { position: relative; z-index: 31; float: right; margin: 0px; }

.pagehead .path-divider { margin: 0px 0.25em; }

.pagehead h1 { min-height: 32px; margin-top: 0px; margin-bottom: 0px; font-size: 20px; font-weight: 400; }

.pagehead h1 .avatar { margin-top: -2px; margin-right: 9px; margin-bottom: -2px; }

.pagehead .underline-nav { height: 69px; margin-top: -20px; margin-bottom: -20px; }

.pagehead-heading { color: inherit; }

.pagehead-actions > li { float: left; margin: 0px 10px 0px 0px; font-size: 11px; color: var(--color-fg-default); list-style-type: none; }

.pagehead-actions > li:last-child { margin-right: 0px; }

.pagehead-actions .octicon-mute { color: var(--color-danger-fg); }

.pagehead-actions .select-menu { position: relative; }

.pagehead-actions .select-menu::before { display: table; content: ""; }

.pagehead-actions .select-menu::after { display: table; clear: both; content: ""; }

.pagehead-actions .select-menu-modal-holder { top: 100%; }

.pagehead-tabs-item { float: left; padding: 8px 15px 11px; color: var(--color-fg-muted); white-space: nowrap; border-style: solid; border-color: transparent; border-image: initial; border-width: 3px 1px 1px; border-radius: 6px 6px 0px 0px; }

.pagehead-tabs-item .octicon { color: var(--color-fg-muted); }

.pagehead-tabs-item:hover { color: var(--color-fg-default); text-decoration: none; }

.pagehead-tabs-item.selected { font-weight: 600; color: var(--color-fg-default); background-color: var(--color-canvas-default); border-color: var(--color-severe-emphasis) var(--color-border-default) transparent; }

.pagehead-tabs-item.selected > .octicon { color: inherit; }

.reponav { position: relative; top: 1px; margin-top: -5px; }

.reponav::before { display: table; content: ""; }

.reponav::after { display: table; clear: both; content: ""; }

.reponav-item { float: left; padding: 7px 15px 8px; color: var(--color-fg-muted); white-space: nowrap; border-style: solid; border-color: transparent; border-image: initial; border-width: 3px 1px 1px; border-radius: 6px 6px 0px 0px; }

.reponav-item .octicon { color: var(--color-fg-muted); }

.reponav-item:hover, .reponav-item:focus { color: var(--color-fg-default); text-decoration: none; }

.reponav-item.selected { color: var(--color-fg-default); background-color: var(--color-canvas-default); border-color: var(--color-severe-emphasis) var(--color-border-default) transparent; }

.reponav-item.selected .octicon { color: inherit; }

.reponav-wrapper { position: relative; z-index: 2; overflow-y: hidden; background-color: var(--color-neutral-emphasis); }

.reponav-wrapper .reponav { top: 0px; padding-right: 8px; padding-left: 8px; margin-top: 0px; overflow-x: auto; color: rgba(255, 255, 255, 0.75); }

.reponav-wrapper .reponav-item { display: inline-block; float: none; padding: 4px 8px 16px; color: var(--color-fg-muted); border: 0px; }

.reponav-wrapper .reponav-item.selected { font-weight: 600; color: var(--color-fg-default); background-color: transparent; border: 0px; }

.steps { display: table; width: 100%; padding: 0px; margin: 30px auto 0px; overflow: hidden; list-style: none; border: 1px solid rgb(223, 226, 229); border-radius: 6px; box-shadow: rgba(27, 31, 35, 0.05) 0px 1px 3px; }

.steps li { display: table-cell; width: 33.3%; padding: 10px 15px; color: rgb(198, 203, 209); cursor: default; background-color: var(--color-canvas-subtle); border-left: 1px solid rgb(223, 226, 229); }

.steps li.current { color: var(--color-fg-default); background-color: var(--color-canvas-default); }

.steps li.current .octicon { color: var(--color-accent-fg); }

.steps li .octicon { float: left; margin-right: 15px; margin-bottom: 5px; }

.steps li .step { display: block; }

.steps li:first-child { border-left: 0px; }

.steps .complete { color: var(--color-fg-muted); }

.steps .complete .octicon { color: var(--color-success-fg); }

.prose-diff .anchor { display: none; }

.prose-diff .show-rich-diff { color: var(--color-accent-fg); text-decoration: none; cursor: pointer; }

.prose-diff .show-rich-diff:hover { text-decoration: underline; }

.prose-diff.collapsed .rich-diff-level-zero.expandable { cursor: pointer; }

.prose-diff.collapsed .rich-diff-level-zero.expandable .vicinity { display: block; }

.prose-diff.collapsed .rich-diff-level-zero.expandable .unchanged:not(.vicinity) { display: none; }

.prose-diff.collapsed .rich-diff-level-zero.expandable .octicon { display: block; margin: 20px auto; color: var(--color-fg-muted); }

.prose-diff.collapsed .rich-diff-level-zero.expandable:hover .octicon { color: var(--color-fg-muted); }

.prose-diff.collapsed .rich-diff-level-zero.expandable:only-child::before { font-size: 18px; color: var(--color-fg-muted); content: "Sorry, no visible changes to display."; }

.prose-diff.collapsed .rich-diff-level-zero.expandable:only-child:hover::before { color: var(--color-fg-default); }

.prose-diff.collapsed .rich-diff-level-zero.expandable > .removed, .prose-diff.collapsed .rich-diff-level-zero.expandable > del { display: none; text-decoration: none; }

.prose-diff .markdown-body { padding: 30px 30px 30px 15px; }

.prose-diff .markdown-body > ins { box-shadow: inset 4px 0 0 var(--color-success-muted); }

.prose-diff .markdown-body > del { text-decoration: none; box-shadow: inset 4px 0 0 var(--color-danger-muted); }

.prose-diff .markdown-body > ins, .prose-diff .markdown-body > del { display: block; border-radius: 0px; }

.prose-diff .markdown-body > ins > .rich-diff-level-zero, .prose-diff .markdown-body > ins > .rich-diff-level-one, .prose-diff .markdown-body > del > .rich-diff-level-zero, .prose-diff .markdown-body > del > .rich-diff-level-one { margin-left: 15px; }

.prose-diff .markdown-body > ins:first-child *, .prose-diff .markdown-body > del:first-child * { margin-top: 0px; }

.prose-diff .rich-diff-level-zero.added { box-shadow: inset 4px 0 0 var(--color-success-muted); }

.prose-diff .rich-diff-level-zero.removed { box-shadow: inset 4px 0 0 var(--color-danger-muted); }

.prose-diff .rich-diff-level-zero.changed { box-shadow: inset 4px 0 0 var(--color-attention-muted); }

.prose-diff .rich-diff-level-zero.unchanged, .prose-diff .rich-diff-level-zero.vicinity { margin-left: 15px; }

.prose-diff .rich-diff-level-zero.added, .prose-diff .rich-diff-level-zero.removed, .prose-diff .rich-diff-level-zero.changed { display: block; border-radius: 0px; }

.prose-diff .rich-diff-level-zero.added > .rich-diff-level-one, .prose-diff .rich-diff-level-zero.removed > .rich-diff-level-one, .prose-diff .rich-diff-level-zero.changed > .rich-diff-level-one { margin-left: 15px; }

.prose-diff .rich-diff-level-zero.added:first-child *, .prose-diff .rich-diff-level-zero.removed:first-child *, .prose-diff .rich-diff-level-zero.changed:first-child * { margin-top: 0px; }

.prose-diff :not(.changed) > :not(.github-user-ins):not(.github-user-del) > .removed, .prose-diff :not(.changed) > :not(.github-user-ins):not(.github-user-del) > del { text-decoration: none; }

.prose-diff .changed del, .prose-diff .changed del pre, .prose-diff .changed del code, .prose-diff .changed del > div, .prose-diff .changed .removed, .prose-diff .changed .removed pre, .prose-diff .changed .removed code, .prose-diff .changed .removed > div { color: var(--color-fg-default); text-decoration: line-through; background: var(--color-danger-subtle); }

.prose-diff .changed ins, .prose-diff .changed ins code, .prose-diff .changed ins pre, .prose-diff .changed .added { color: var(--color-fg-default); background: var(--color-success-subtle); border-bottom: 1px solid var(--color-success-muted); }

.prose-diff > .markdown-body .github-user-ins { text-decoration: underline; }

.prose-diff > .markdown-body .github-user-del { text-decoration: line-through; }

.prose-diff > .markdown-body li ul.added { background: var(--color-success-subtle); }

.prose-diff > .markdown-body li ul.removed { color: var(--color-fg-default); background: var(--color-danger-subtle); }

.prose-diff > .markdown-body li ul.removed:not(.github-user-ins) { text-decoration: line-through; }

.prose-diff > .markdown-body li.added.moved-up .octicon, .prose-diff > .markdown-body li.added.moved-down .octicon { margin-right: 5px; margin-left: 5px; color: var(--color-fg-muted); }

.prose-diff > .markdown-body li.added.moved { background: var(--color-attention-subtle); }

.prose-diff > .markdown-body li.removed.moved { display: none; }

.prose-diff > .markdown-body pre { padding: 10px 20px; }

.prose-diff > .markdown-body th.changed, .prose-diff > .markdown-body td.changed { background: var(--color-attention-subtle); border-left-color: var(--color-border-default); }

.prose-diff > .markdown-body :not(li.moved).removed { color: var(--color-fg-default); text-decoration: line-through; background: var(--color-danger-subtle); }

.prose-diff > .markdown-body :not(.github-user-ins):not(li.moved).removed { text-decoration: line-through; }

.prose-diff > .markdown-body :not(li.moved).added, .prose-diff > .markdown-body li:not(.moved).added { background: var(--color-success-subtle); }

.prose-diff > .markdown-body :not(.github-user-del):not(li.moved).added li:not(.moved):not(.github-user-del).added { text-decoration: none; }

.prose-diff > .markdown-body li:not(.moved).removed { color: var(--color-fg-default); background: var(--color-danger-subtle); }

.prose-diff > .markdown-body li:not(.moved):not(.github-user-ins).removed { text-decoration: line-through; }

.prose-diff > .markdown-body .added, .prose-diff > .markdown-body ins + .added, .prose-diff > .markdown-body ins { border-top: 0px; border-bottom: 0px; }

.prose-diff > .markdown-body .added:not(.github-user-del):not(.github-user-ins), .prose-diff > .markdown-body ins + .added:not(.github-user-del):not(.github-user-ins), .prose-diff > .markdown-body ins:not(.github-user-del):not(.github-user-ins) { text-decoration: none; }

.prose-diff > .markdown-body img.added, .prose-diff > .markdown-body img.removed { border-style: solid; border-width: 1px; }

.prose-diff > .markdown-body ins pre:not(.github-user-del):not(.github-user-ins), .prose-diff > .markdown-body ins code:not(.github-user-del):not(.github-user-ins), .prose-diff > .markdown-body ins > div:not(.github-user-del):not(.github-user-ins) { text-decoration: none; }

.prose-diff > .markdown-body ul > ins, .prose-diff > .markdown-body ul > del { display: block; padding: 0px; }

.prose-diff > .markdown-body .added > li, .prose-diff > .markdown-body .removed > li { margin-top: 0px; margin-bottom: 0px; }

span.changed_tag, em.changed_tag, strong.changed_tag, b.changed_tag, i.changed_tag, code.changed_tag { border-bottom: 1px dotted var(--color-border-default); border-radius: 0px; }

a.added_href, a.changed_href, span.removed_href { border-bottom: 1px dotted var(--color-border-default); border-radius: 0px; }

.diff-view .file-type-prose .rich-diff { display: none; }

.diff-view .display-rich-diff .rich-diff { display: block; }

.diff-view .display-rich-diff .file-diff { display: none; }

.protip { margin-top: 20px; color: var(--color-fg-muted); text-align: center; }

.protip strong { color: var(--color-fg-default); }

.protip code { padding: 2px; background-color: var(--color-canvas-subtle); border-radius: 6px; }

.add-reaction-btn { opacity: 0; transition: opacity 0.1s ease-in-out 0s; }

.page-responsive .add-reaction-btn { opacity: 1; }

@media (min-width: 768px) {
  .page-responsive .add-reaction-btn { opacity: 0; }
}

.reaction-popover-container[open] .add-reaction-btn { opacity: 1; }

.add-reactions-options-item { margin-top: -1px; margin-right: -1px; line-height: 29px; border: 1px solid transparent; }

.add-reactions-options-item .emoji { display: inline-block; transition: transform 0.15s cubic-bezier(0.2, 0, 0.13, 2) 0s; }

.add-reactions-options-item:hover .emoji, .add-reactions-options-item:focus .emoji { text-decoration: none !important; transform: scale(1.2) !important; }

.add-reactions-options-item:active { background-color: var(--color-accent-subtle); }

.page-responsive .add-reactions-options-item { height: 20vw; }

@media (min-width: 544px) {
  .page-responsive .add-reactions-options-item { height: auto; }
}

.social-reactions:not(.has-reactions) .reaction-summary-item { margin-bottom: 8px !important; }

@media (min-width: 768px) {
  .social-reactions:not(.has-reactions) .reaction-summary-item { margin-bottom: 0px; }
}

.comment-reactions { display: none; }

.comment-reactions::before { display: table; content: ""; }

.comment-reactions::after { display: table; clear: both; content: ""; }

.comment-reactions .reaction-popover-container .reactions-menu { z-index: 100; }

.page-responsive .comment-reactions { display: flex; }

@media (min-width: 768px) {
  .page-responsive .comment-reactions { display: none; }
  .page-responsive .comment-reactions.has-reactions { display: flex; }
}

.comment-reactions.has-reactions:hover .add-reaction-btn, .comment-reactions.has-reactions .add-reaction-btn:focus { opacity: 1; }

.comment-reactions.has-reactions:not(.social-reactions) { border-top: 1px solid var(--color-border-default); }

.comment-reactions .user-has-reacted { background-color: var(--color-accent-subtle); }

.comment-reactions .add-reaction-btn { border-right: 0px; }

.reaction-summary-item { float: left; padding: 9px 15px 7px; line-height: 18px; border-right: 1px solid var(--color-border-default); }

.reaction-summary-item:hover, .reaction-summary-item:focus { text-decoration: none; }

[data-color-mode="light"][data-light-theme*="dark"], [data-color-mode="dark"][data-dark-theme*="dark"] { --color-social-reaction-bg-hover:var(--color-scale-gray-7); --color-social-reaction-bg-reacted-hover:var(--color-scale-blue-8); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] { --color-social-reaction-bg-hover:var(--color-scale-gray-7); --color-social-reaction-bg-reacted-hover:var(--color-scale-blue-8); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] { --color-social-reaction-bg-hover:var(--color-scale-gray-7); --color-social-reaction-bg-reacted-hover:var(--color-scale-blue-8); }
}

:root, [data-color-mode="light"][data-light-theme*="light"], [data-color-mode="dark"][data-dark-theme*="light"] { --color-social-reaction-bg-hover:var(--color-scale-gray-1); --color-social-reaction-bg-reacted-hover:var(--color-scale-blue-1); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="light"] { --color-social-reaction-bg-hover:var(--color-scale-gray-1); --color-social-reaction-bg-reacted-hover:var(--color-scale-blue-1); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="light"] { --color-social-reaction-bg-hover:var(--color-scale-gray-1); --color-social-reaction-bg-reacted-hover:var(--color-scale-blue-1); }
}

.social-reaction-summary-container .has-reactions { margin: 0px 16px 16px; }

.social-reaction-summary-item:not(.add-reaction-btn) + .social-reaction-summary-item { margin-left: 8px; }

.social-reactions .comment-body { margin-left: 16px !important; }

.social-button-emoji { display: inline-block; width: 16px; height: 16px; line-height: 1.25; vertical-align: -1px; font-size: 1em !important; }

.social-reaction-summary-item { height: 26px; margin-right: 0px; font-size: 12px; line-height: 26px; background-color: transparent; border: 1px solid var(--color-border-default, #d2dff0); border-radius: 100px; padding: 0px 6px !important; }

.social-reaction-summary-item.user-has-reacted { background-color: var(--color-accent-subtle); border: 1px solid var(--color-accent-emphasis)  !important; }

.social-reaction-summary-item.user-has-reacted:hover { background-color: var(--color-social-reaction-bg-reacted-hover)  !important; }

.social-reaction-summary-item > span { height: 24px; padding: 0px 4px; margin-left: 2px; }

.social-reaction-summary-item:hover { background-color: var(--color-social-reaction-bg-hover); }

.social-reaction-summary-item:focus, .social-reaction-summary-item:focus-within, .social-reaction-summary-item:focus-visible { outline: 0px; box-shadow: var(--color-primer-shadow-focus); }

.comment-reactions-options .reaction-summary-item:first-child { border-bottom-left-radius: 6px; }

.reactions-with-gap .comment .comment-reactions { margin-left: 16px; border-top: 0px !important; }

.reactions-with-gap .comment .reaction-summary-item { margin-bottom: 16px; }

.reactions-with-gap .reaction-summary-item:not(.add-reaction-btn) { padding: 0px 8px; margin-right: 8px; font-size: 12px; line-height: 26px; border: 1px solid var(--color-border-default, #d2dff0); border-radius: 6px; }

.reactions-with-gap .reaction-summary-item:not(.add-reaction-btn) .emoji { font-size: 16px; }

.render-container { padding: 30px; line-height: 0; text-align: center; background: var(--color-canvas-subtle); border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.render-container .render-viewer { display: block; width: 1px; height: 1px; border: 0px; }

.render-container .octospinner { display: none; }

.render-container .render-viewer-error, .render-container .render-viewer-fatal, .render-container .render-viewer-invalid, .render-container .render-fullscreen { display: none; }

.render-container.is-render-automatic .octospinner { display: inline-block; }

.render-container.is-render-requested .octospinner { display: inline-block; }

.render-container.is-render-requested.is-render-failed .render-viewer-error { display: inline-block; }

.render-container.is-render-requested.is-render-failed .render-viewer, .render-container.is-render-requested.is-render-failed .render-viewer-fatal, .render-container.is-render-requested.is-render-failed .render-viewer-invalid, .render-container.is-render-requested.is-render-failed .octospinner { display: none; }

.render-container.is-render-requested.is-render-failed-fatal .render-viewer-fatal { display: inline-block; }

.render-container.is-render-requested.is-render-failed-fatal .render-viewer, .render-container.is-render-requested.is-render-failed-fatal .render-viewer-error, .render-container.is-render-requested.is-render-failed-fatal .render-viewer-invalid, .render-container.is-render-requested.is-render-failed-fatal .octospinner { display: none; }

.render-container.is-render-requested.is-render-failed-invalid .render-viewer-invalid { display: inline-block; }

.render-container.is-render-requested.is-render-failed-invalid .render-viewer, .render-container.is-render-requested.is-render-failed-invalid .render-viewer-error, .render-container.is-render-requested.is-render-failed-invalid .render-viewer-fatal, .render-container.is-render-requested.is-render-failed-invalid .octospinner { display: none; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) { height: 500px; padding: 0px; background: none; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-viewer { width: 100%; height: 100%; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-fullscreen { display: flex; }

.render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-viewer-error, .render-container.is-render-ready.is-render-requested:not(.is-render-failed) .render-viewer-fatal, .render-container.is-render-ready.is-render-requested:not(.is-render-failed) .octospinner { display: none; }

.render-notice { padding: 20px 15px; font-size: 14px; color: var(--color-fg-default); background-color: var(--color-canvas-subtle); border-color: var(--color-border-subtle); }

.Skeleton { color: rgba(0, 0, 0, 0); background-image: linear-gradient(270deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.1)); background-size: 400% 100%; animation: 8s ease-in-out 0s infinite normal none running skeleton-loading; }

.Skeleton * { visibility: hidden; }

.Skeleton--text { clip-path: inset(4px 0px round 3px); }

.is-error .Skeleton { display: none; }

@keyframes skeleton-loading { 
  0% { background-position: 200% 0px; }
  100% { background-position: -200% 0px; }
}

.authors-2 .AvatarStack { min-width: 36px !important; }

.authors-3 .AvatarStack { min-width: 46px !important; }

[aria-selected="true"] .AvatarStack-body, .navigation-focus .AvatarStack-body { background: rgb(246, 251, 255); }

.blame-commit .AvatarStack { margin-top: 3px; }

.tracked-in-parent-pill { position: relative; cursor: default; }

.tracked-in-parent-pill-truncated { position: absolute; left: 100%; display: none; white-space: nowrap; background: var(--color-canvas-default); border-left-width: 0px !important; border-top-left-radius: 0px !important; border-bottom-left-radius: 0px !important; }

.tracked-in-parent-pill:hover .tracked-in-parent-pill-truncated { display: block; }

.wizard-step-item { position: relative; padding: 8px 0px; margin-left: 16px; flex-direction: row; }

.wizard-step-item::before { position: absolute; top: 32px; bottom: 0px; left: 0px; display: block; width: 2px; height: 100%; content: ""; background-color: var(--color-border-default); }

.wizard-step-badge { position: relative; z-index: 1; display: flex; width: 32px; height: 32px; margin-right: 8px; margin-left: -15px; color: var(--color-fg-default); align-items: center; background-color: var(--color-border-default); border: 1px solid var(--color-canvas-default); border-radius: 50%; justify-content: center; flex-shrink: 0; }

.wizard-step-body { min-width: 0px; max-width: 100%; color: var(--color-fg-default); flex: 1 1 auto; }

.wizard-step-body .wizard-step-buttons { display: none; margin-top: 16px; justify-content: flex-end; }

.wizard-step-container { border: 0px; }

.wizard-step-container .wizard-step-content { display: none; width: 100%; padding: 16px 24px 24px; overflow: visible; font-size: 14px; }

.wizard-step-container.wizard-step-container-icon .wizard-step-content { padding: 24px; }

.wizard-step-header { padding-top: 4px; padding-left: 8px; }

.wizard-step-header > .wizard-step-title { min-width: 0px; margin-bottom: 4px; flex: 1 1 auto; color: var(--color-fg-muted); }

.wizard-step-icon { display: none; height: 96px; color: var(--color-accent-fg); background-image: linear-gradient(to right, var(--color-accent-subtle), var(--color-canvas-default)); justify-content: center; align-items: center; border-top-left-radius: 6px; border-top-right-radius: 6px; }

.wizard-step[data-single-page-wizard-step-complete="true"] .wizard-step-badge { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.wizard-step[data-single-page-wizard-step-complete="true"] .wizard-step-item::before { background-color: var(--color-accent-emphasis); }

.wizard-step[data-single-page-wizard-step-complete="true"] .wizard-step-title { color: var(--color-fg-default); }

.wizard-step[data-single-page-wizard-last-step="true"] .wizard-step-badge .wizard-step-check { display: block; }

.wizard-step[data-single-page-wizard-last-step="true"] .wizard-step-item::before { top: 0px; display: block; height: 16px; }

@media (min-width: 768px) {
  .wizard-step[data-single-page-wizard-last-step="true"] .wizard-step-item::before { display: none; }
}

.wizard-step[data-single-page-wizard-last-step="true"] .wizard-step-icon { color: var(--color-success-fg); background-image: linear-gradient(to right, var(--color-success-subtle), var(--color-canvas-default)); }

.wizard-step:not([data-single-page-wizard-last-step="true"]) .wizard-step-badge .wizard-step-check { display: none; }

.wizard-step:not([data-single-page-wizard-last-step="true"]) .wizard-step-badge::before { content: attr(data-single-page-wizard-step); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-badge { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.wizard-step[data-single-page-wizard-step-current="true"][data-single-page-wizard-last-step="true"] .wizard-step-badge { background-color: var(--color-success-emphasis); }

.wizard-step[data-single-page-wizard-step-current="true"][data-single-page-wizard-last-step="true"] .wizard-step-item::before { top: 42px; height: 16px; }

.wizard-step[data-single-page-wizard-step-current="true"][data-single-page-wizard-last-step="true"] .wizard-step-container-icon::after { background-image: linear-gradient(var(--color-success-subtle), var(--color-success-subtle)); }

.wizard-step[data-single-page-wizard-step-current="true"]:not([data-single-page-wizard-last-step="true"]) .wizard-step-container-icon::after { background-image: linear-gradient(var(--color-accent-subtle), var(--color-accent-subtle)); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-icon { display: flex; }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-item { flex-direction: column; }

@media (min-width: 768px) {
  .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-item { flex-direction: row; }
}

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-body { margin-top: 16px; margin-left: -16px; }

@media (min-width: 768px) {
  .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-body { margin-top: 0px; margin-left: 0px; }
}

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container { position: relative; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::after, .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::before { background-color: var(--color-border-default); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::before, .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::after { transform: rotate(90deg); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::before { position: absolute; top: -12px; right: 100%; left: 12px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::after { top: -10px; left: 11px; }

@media (min-width: 768px) {
  .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::before, .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::after { top: 11px; left: -8px; transform: rotate(0deg); }
  .wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container::after { margin-left: 1px; }
}

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container .wizard-step-header { display: none; }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container .wizard-step-content-header { margin-bottom: 16px; }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container .wizard-step-title { color: var(--color-fg-default); }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-container .wizard-step-content { display: block; }

.wizard-step[data-single-page-wizard-step-current="true"] .wizard-step-buttons { display: flex; }

.alert-label { color: var(--color-fg-on-emphasis); }

.graph-canvas .alert-label--critical { fill: var(--color-danger-emphasis); }

.graph-canvas .alert-label--high { fill: var(--color-severe-emphasis); }

.graph-canvas .alert-label--moderate { fill: var(--color-attention-emphasis); }

.graph-canvas .alert-label--low { fill: var(--color-neutral-emphasis); }

.advisory-form { background-color: var(--color-canvas-subtle); border-top: 1px solid var(--color-border-default); }

.advisory-form .form-control { background-color: var(--color-canvas-default); }

.advisory-form .form-actions { background-color: var(--color-canvas-default); }

.advisory-form .previewable-comment-form { background-color: var(--color-canvas-default); }

.advisory-credit-window-min { min-height: 72px; }

.advisory-credit-window-max { max-height: 370px; }

.emoji-tab.UnderlineNav-item { margin-right: 4px; }

.emoji-tab[role="tab"][aria-selected="true"] { font-weight: 600; color: var(--color-fg-default); border-bottom-color: var(--color-severe-emphasis); }

.emoji-tab[role="tab"][aria-selected="true"] .UnderlineNav-octicon { color: var(--color-fg-muted); }

.selected-emoji { z-index: 100; background-color: var(--color-accent-emphasis); }

.emoji-picker-container .emoji-picker-tab g-emoji { margin-right: auto; margin-left: 3px; }

.emoji-tab .emoji-icon { width: auto; }

.emoji-picker-container { z-index: 1; width: 395px; }

.emoji-picker-tab { height: 136px; padding-top: 8px; }

.emoji-picker-emoji-width { width: 32px; height: 28px; }

.emoji-picker-tab .btn-outline:not(:hover) { background-color: transparent; }

.emoji-picker-list { list-style: none; }

.notification-shelf { z-index: 34; }

.notification-shelf.is-stuck { z-index: 999; }

.notifications-v2 .archived-notifications-tab .notifications-list-item.notification-archived { display: block; }

.notifications-v2 .archived-notifications-tab .notifications-list-item.notification-read, .notifications-v2 .archived-notifications-tab .notifications-list-item.notification-unread { display: none; }

@media (max-width: 767px) {
  .notifications-v2 .commit-ref .css-truncate-target { word-break: break-all; white-space: normal; }
}

.notifications-v2 .mixed-notifications-tab .notifications-list-item.notification-archived, .notifications-v2 .mixed-notifications-tab .notifications-list-item.notification-read, .notifications-v2 .mixed-notifications-tab .notifications-list-item.notification-unread { display: block !important; }

@media (max-width: 543px) {
  .notifications-v2 .Box { border-right: 0px; border-left: 0px; border-radius: 0px; }
}

@media (max-width: 543px) {
  .notifications-v2 .Box .Box-header { border-right: 0px !important; border-left: 0px !important; border-radius: 0px !important; }
}

@media (max-width: 767px) {
  .notifications-v2 .AvatarStack--right { width: auto !important; min-width: auto !important; margin-left: 53px !important; }
}

@media (max-width: 767px) {
  .notifications-v2 .AvatarStack--right .AvatarStack-body { margin-right: 8px; position: relative !important; right: unset !important; flex-direction: row !important; }
}

@media (max-width: 767px) {
  .notifications-v2 .AvatarStack-body .avatar { position: relative !important; margin-right: -11px !important; margin-left: 0px !important; border-right: 1px solid rgb(255, 255, 255) !important; border-left: 0px !important; }
}

.notifications-v2 .thread-subscription-status { background-color: transparent !important; }

.notifications-v2 .notification-action-mark-archived, .notifications-v2 .notification-action-mark-unread, .notifications-v2 .notification-action-star, .notifications-v2 .notification-action-unsubscribe { display: block !important; }

.notifications-v2 .notification-action-mark-read, .notifications-v2 .notification-action-mark-unarchived, .notifications-v2 .notification-action-subscribe, .notifications-v2 .notification-action-unstar, .notifications-v2 .notification-is-starred-icon { display: none !important; }

.notifications-v2 .notification-unsubscribed .notification-action-unsubscribe { display: none !important; }

.notifications-v2 .notification-unsubscribed .notification-action-subscribe { display: block !important; }

.notifications-v2 .notification-unread .notification-action-mark-read { display: block !important; }

.notifications-v2 .notification-unread .notification-action-mark-unread { display: none !important; }

.notifications-v2 .notification-archived .notification-action-mark-archived, .notifications-v2 .notification-archived .notification-action-mark-read, .notifications-v2 .notification-archived .notification-action-mark-unread { display: none !important; }

.notifications-v2 .notification-archived .notification-action-mark-unarchived { display: block !important; }

.notifications-v2 .notification-starred .notification-action-star { display: none !important; }

.notifications-v2 .notification-starred .notification-is-starred-icon { display: inline-block !important; }

.notifications-v2 .notification-starred .notification-action-unstar { display: block !important; }

.notifications-v2 .unwatch-suggestions-alert.flash .octicon { margin-right: 4px; }

.notification-navigation .menu-item { color: var(--color-fg-muted); }

.notification-navigation .menu-item::before { display: none; }

.notification-navigation .menu-item .octicon { color: var(--color-fg-muted); }

.notification-navigation .menu-item.selected { background-color: var(--color-accent-subtle); }

.notification-navigation .menu-item.selected .octicon { color: var(--color-accent-fg)  !important; }

.notification-navigation .notification-configure-filters .octicon { color: var(--color-fg-muted)  !important; }

.notification-navigation .notification-configure-filters:hover .octicon { color: var(--color-accent-fg)  !important; }

.notifications-list-item .notification-list-item-link { color: var(--color-fg-muted)  !important; }

.notifications-list-item.notification-read, .notifications-list-item.notification-archived { background-color: var(--color-notifications-row-read-bg)  !important; }

.notifications-list-item.notification-unread { background-color: var(--color-notifications-row-bg)  !important; }

.notifications-list-item.notification-unread .notification-list-item-link { color: var(--color-fg-default)  !important; }

.notifications-list-item.notification-unread .notification-list-item-unread-indicator { background-color: var(--color-accent-emphasis); }

.notifications-list-item:hover { box-shadow: 2px 0 0 var(--color-accent-emphasis) inset; background-color: var(--color-accent-subtle)  !important; }

.notifications-list-item:hover .notification-list-item-link { color: var(--color-fg-default)  !important; }

.notifications-list-item:hover .notification-list-item-actions { display: flex !important; }

@media (max-width: 767px) {
  .notifications-list-item:hover .notification-list-item-actions { display: none !important; }
}

.notifications-list-item:hover .notification-list-item-actions .btn { color: var(--color-fg-muted)  !important; background-color: var(--color-accent-subtle)  !important; border: 0px !important; }

.notifications-list-item:hover .notification-list-item-actions .btn .octicon { color: var(--color-notifications-button-text)  !important; }

.notifications-list-item:hover .notification-list-item-actions .btn:hover { background-color: var(--color-notifications-button-hover-bg)  !important; }

.notifications-list-item:hover .notification-list-item-actions .btn:hover .octicon { color: var(--color-notifications-button-hover-text)  !important; }

.notifications-list-item:hover .notification-list-item-hide-on-hover { visibility: hidden !important; }

.notifications-list-item:hover .AvatarStack-body { background: var(--color-accent-subtle); }

.notifications-list-item.navigation-focus { box-shadow: 2px 0 0 var(--color-accent-emphasis) inset; background-color: var(--color-accent-subtle)  !important; }

.notifications-list-item.navigation-focus .notification-list-item-link { color: var(--color-fg-default)  !important; }

.notifications-list-item:last-child { border-bottom: 0px !important; }

.notifications-list-item .Label { font-size: 12px; }

.notifications-list-item .notification-list-item-unread-indicator { width: 8px; height: 8px; background: none; }

.notifications-list-item.notification-archived { display: none; }

.notifications-v2 .thread-subscribe-form { display: none !important; }

.notifications .read .avatar img { opacity: 0.5; }

.notifications .read .undo { display: block; }

.notifications .read .delete { visibility: hidden; }

.notifications .read[aria-selected="true"], .notifications .read.navigation-focus { background-color: rgb(245, 249, 252); }

.notifications .muted .unmute { display: block; }

.notifications .muted .mute { display: none; }

.notifications .unmute { display: none; }

.notification-thread-subscription:first-child { border-top: 1px solid var(--color-border-default); }

.notification-subscription-filters-repo .no-results { display: none; }

.notifications-list { float: left; width: 100%; }

.thread-subscription-status { padding: 10px; margin: 40px 0px 20px; color: var(--color-fg-muted); border: 1px solid var(--color-border-default); border-radius: 6px; }

.thread-subscription-status .btn-sm > .octicon { margin-right: 1px; }

.thread-subscription-status .reason { display: inline-block; margin: 0px 10px; vertical-align: middle; }

.thread-subscription-status .thread-subscribe-form { display: inline-block; vertical-align: middle; }

.subscription .loading { opacity: 0.5; }

.progress-pjax-loader { z-index: 99999; background: transparent; opacity: 0; transition: opacity 0.4s linear 0.4s; height: 2px !important; }

.progress-pjax-loader.is-loading { opacity: 1; transition: none 0s ease 0s; }

.progress-pjax-loader > .progress-pjax-loader-bar { background-color: rgb(121, 184, 255); transition: width 0.4s ease 0s; }

.starred .starred-button-icon { color: var(--color-scale-yellow-2); }

.user-lists-menu-action { color: var(--color-fg-default); }

.user-lists-menu-action:hover:not(:disabled) { color: var(--color-fg-default); background-color: var(--color-canvas-subtle); }

.user-lists-menu-action:focus:not(:disabled) { color: var(--color-fg-default); outline: 2px solid var(--color-accent-emphasis); outline-offset: 2px; }

.shelf { padding-top: 20px; margin-bottom: 20px; background-color: var(--color-canvas-default); border-bottom: 1px solid var(--color-border-muted); }

.shelf .container { position: relative; }

.intro-shelf { margin-top: 0px; background-image: linear-gradient(180deg, var(--color-canvas-default-transparent), var(--color-canvas-default)),linear-gradient(70deg, var(--color-accent-subtle) 32%, var(--color-success-subtle)); }

.orgs-help-shelf { padding-top: 20px; padding-bottom: 20px; margin-top: -20px; margin-bottom: 20px; }

.orgs-help-shelf .orgs-help-title { font-size: 30px; font-weight: 400; }

.orgs-help-shelf-content { width: 800px; margin: 50px auto; text-align: center; }

.orgs-help-shelf-content .orgs-help-lead { padding-right: 45px; padding-left: 45px; font-size: 18px; }

.orgs-help-shelf-content .orgs-help-divider { display: block; width: 150px; margin: 40px auto; content: ""; border-top: 1px solid var(--color-border-default); }

.orgs-help-lead { margin-top: 10px; margin-bottom: 30px; color: var(--color-fg-muted); }

.orgs-help-items { margin-bottom: 40px; }

.orgs-help-item-octicon { width: 70px; height: 70px; margin: 0px auto 15px; text-align: center; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 50px; }

.orgs-help-item-octicon .octicon { margin-top: 20px; color: var(--color-accent-fg); }

.orgs-help-item-title { margin-bottom: 10px; font-weight: 400; }

.orgs-help-item-content { margin-top: 0px; font-size: 14px; color: var(--color-fg-muted); }

.orgs-help-dismiss { float: right; margin-top: 5px; margin-right: 10px; font-size: 12px; color: var(--color-fg-muted); }

.orgs-help-dismiss:hover { color: var(--color-accent-fg); text-decoration: none; }

.orgs-help-dismiss .octicon { position: relative; top: 1px; }

.orgs-help-title { margin-top: 0px; margin-bottom: 0px; }

.org-sso, .business-sso { width: 340px; margin: 0px auto; }

.org-sso .sso-title, .business-sso .sso-title { font-size: 24px; font-weight: 300; letter-spacing: -0.5px; }

.org-sso .org-sso-panel, .org-sso .business-sso-panel, .business-sso .org-sso-panel, .business-sso .business-sso-panel { padding: 20px; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.org-sso .sso-recovery-callout, .business-sso .sso-recovery-callout { padding: 15px 10px; text-align: center; border: 1px solid var(--color-border-muted); border-radius: 6px; }

.sso-modal { padding: 16px; }

.sso-modal .org-sso, .sso-modal .business-sso { width: auto; }

.sso-modal .org-sso .org-sso-panel, .sso-modal .business-sso .business-sso-panel { border: 0px; }

.sso-modal .sso-prompt-success, .sso-modal .sso-prompt-error { display: none; }

.sso-modal.success .sso-prompt-default { display: none; }

.sso-modal.success .sso-prompt-success { display: block; }

.sso-modal.error .sso-prompt-default { display: none; }

.sso-modal.error .sso-prompt-error { display: block; }

.sso-modal.error .flash-error { margin-right: -35px; margin-left: -35px; border-right: 0px; border-left: 0px; border-radius: 0px; }

.tag-input-container { position: relative; }

.tag-input-container .suggester { position: absolute; z-index: 100; width: 100%; margin-top: -1px; }

.tag-input-container ul { list-style: none; }

.tag-input input { float: left; padding-left: 2px; margin: 0px; background: none; border: 0px; box-shadow: none; }

.tag-input input:focus { box-shadow: none; }

.task-list-item { list-style-type: none; }

.task-list-item label { font-weight: 400; }

.task-list-item.enabled label { cursor: pointer; }

.task-list-item + .task-list-item { margin-top: 3px; }

.task-list-item .handle { display: none; }

.task-list-item-checkbox { margin: 0px 0.2em 0.25em -1.6em; vertical-align: middle; }

.convert-to-issue-button { top: 2px; right: 4px; padding: 0px 2px; margin-right: 8px; user-select: none; background-color: var(--color-canvas-subtle); }

.convert-to-issue-button .octicon { fill: var(--color-fg-default); }

.convert-to-issue-button:hover .octicon, .convert-to-issue-button:focus .octicon { fill: var(--color-accent-fg); }

.reorderable-task-lists .markdown-body .contains-task-list { padding: 0px; }

.reorderable-task-lists .markdown-body li:not(.task-list-item) { margin-left: 26px; }

.reorderable-task-lists .markdown-body ol:not(.contains-task-list) li, .reorderable-task-lists .markdown-body ul:not(.contains-task-list) li { margin-left: 0px; }

.reorderable-task-lists .markdown-body .task-list-item { padding: 2px 15px 2px 42px; margin-right: -15px; margin-left: -15px; line-height: 1.5; border: 0px; }

.reorderable-task-lists .markdown-body .task-list-item + .task-list-item { margin-top: 0px; }

.reorderable-task-lists .markdown-body .task-list-item .handle { display: block; float: left; width: 20px; padding: 2px 0px 0px 2px; margin-left: -43px; opacity: 0; }

.reorderable-task-lists .markdown-body .task-list-item .drag-handle { fill: var(--color-fg-default); }

.reorderable-task-lists .markdown-body .task-list-item.hovered > .handle { opacity: 1; }

.reorderable-task-lists .markdown-body .task-list-item.is-dragging { opacity: 0; }

.comment-body .reference { font-weight: 600; white-space: nowrap; }

.comment-body .issue-link { white-space: normal; }

.comment-body .issue-link .issue-shorthand { font-weight: 400; color: var(--color-fg-muted); }

.comment-body .issue-link:hover .issue-shorthand, .comment-body .issue-link:focus .issue-shorthand { color: var(--color-accent-fg); }

.review-comment-contents .markdown-body .task-list-item { padding-left: 42px; margin-right: -12px; margin-left: -12px; border-top-left-radius: 6px; border-bottom-left-radius: 6px; }

.convert-to-issue-enabled .task-list-item .contains-task-list { padding: 4px 15px 0px 43px; margin: 0px -15px 0px -42px; }

.convert-to-issue-enabled .task-list-item.hovered { background-color: var(--color-canvas-subtle); }

.convert-to-issue-enabled .task-list-item.hovered .contains-task-list { background-color: var(--color-canvas-default); }

.convert-to-issue-enabled .task-list-item.hovered > .convert-to-issue-button { z-index: 20; width: auto; height: auto; overflow: visible; clip: auto; }

.convert-to-issue-enabled .task-list-item.hovered > .convert-to-issue-button svg { overflow: visible; }

.convert-to-issue-enabled .task-list-item.is-loading { color: var(--color-fg-muted); background-color: var(--color-accent-subtle); border-top: 1px solid var(--color-accent-subtle); border-bottom: 1px solid var(--color-canvas-default); border-left: 1px solid var(--color-canvas-default); }

.convert-to-issue-enabled .task-list-item.is-loading ul { color: var(--color-fg-default); background-color: var(--color-canvas-default); }

.convert-to-issue-enabled .task-list-item.is-loading > .handle { opacity: 0; }

.toolbar-commenting .dropdown-menu-s { width: 100px; }

.toolbar-commenting .dropdown-item { font-weight: 600; line-height: 1em; background: none; border: 0px; }

.toolbar-commenting .dropdown-item:hover { color: var(--color-accent-fg); }

.toolbar-commenting .dropdown-item:focus { color: var(--color-accent-fg); outline: none; }

.toolbar-item { display: block; float: left; padding: 4px; font-size: 14px; color: var(--color-fg-muted); cursor: pointer; background: none; border: 0px; }

.toolbar-item.dropdown, .toolbar-item.select-menu { padding: 0px; }

.toolbar-item .select-menu-modal { margin-top: 2px; }

.toolbar-item .select-menu-item { padding-left: 8px; }

.toolbar-item .menu-target { display: block; padding: 4px; color: var(--color-fg-muted); background: none; border: 0px; }

.toolbar-item .menu-target:hover, .toolbar-item:hover { color: var(--color-accent-fg); }

.toolbar-item .menu-target:focus, .toolbar-item:focus { color: var(--color-accent-fg); outline: none; }

.toolbar-item:disabled { color: var(--color-fg-muted); }

.topic-tag { display: inline-block; padding: 0.3em 0.9em; margin: 0px 0.5em 0.5em 0px; white-space: nowrap; background-color: var(--color-accent-subtle); border-radius: 6px; }

.topic-tag-link:hover { text-decoration: none; background-color: rgb(221, 238, 255); }

.delete-topic-button, .delete-topic-link { display: inline-block; width: 26px; color: var(--color-fg-muted); background-color: var(--color-accent-subtle); border-width: 0px 0px 0px 1px; border-top-style: initial; border-top-color: initial; border-right-style: initial; border-right-color: initial; border-bottom-style: initial; border-bottom-color: initial; border-left-style: solid; border-left-color: rgb(180, 217, 255); border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.delete-topic-button:hover, .delete-topic-link:hover { background-color: rgb(221, 238, 255); }

.topic-tag-action:hover .delete-topic-link { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.topic-tag-outline { background: transparent; box-shadow: rgb(200, 225, 255) 0px 0px 0px 1px inset; }

.delete-topic-link { padding-right: 8px; padding-left: 8px; margin-left: 8px; line-height: 1.75; }

.delete-topic-link:hover { text-decoration: none; }

.invalid-topic .delete-topic-button { color: var(--color-fg-default); background-color: var(--color-danger-subtle); border-left-color: var(--color-danger-emphasis); }

.invalid-topic .delete-topic-button:hover { background-color: rgb(255, 200, 206); }

.topic-tag-action { display: inline-flex; align-items: center; padding-left: 0.8em; margin: 0.4em 0.4em 0px 0px; background-color: var(--color-accent-subtle); border-radius: 6px; }

.topic-tag-action.invalid-topic { color: var(--color-fg-default); background-color: var(--color-danger-subtle); border-color: var(--color-danger-emphasis); }

.topic-tag-action .add-topic-button, .topic-tag-action .remove-topic-button { display: inline-block; width: 26px; font-size: 14px; color: var(--color-fg-muted); background-color: var(--color-accent-subtle); border-width: 0px 0px 0px 1px; border-top-style: initial; border-top-color: initial; border-right-style: initial; border-right-color: initial; border-bottom-style: initial; border-bottom-color: initial; border-left-style: solid; border-left-color: rgb(180, 217, 255); }

.topic-tag-action .add-topic-button:hover, .topic-tag-action .remove-topic-button:hover { color: var(--color-fg-on-emphasis); }

.topic-tag-action .add-topic-button:hover { background-color: var(--color-success-emphasis); }

.topic-tag-action .remove-topic-button { border-right: 0px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.topic-tag-action .remove-topic-button:hover { background-color: var(--color-danger-emphasis); }

.topic-input-container .tag-input { width: 908px; cursor: text; }

.topic-input-container .tag-input.org-repo-tag-input { width: 100%; }

.topic-input-container .tag-input .tag-input-inner { min-height: 26px; background-image: none; }

.topic-input-container .topic-tag { margin-top: 2px; }

.topic .css-truncate-target { max-width: 75%; }

.topic-list .topic-list-item + .topic-list-item { border-top: 1px solid var(--color-border-default); }

.topic-box .starred { color: var(--color-attention-fg); border: 0px; }

.topic-box .unstarred { color: var(--color-fg-muted); border: 0px; }

.user-status-suggestions { height: 98px; transition: height 100ms ease-out 0s, opacity 200ms ease-in 0s; }

.user-status-suggestions.collapsed { height: 0px; opacity: 0; }

.user-status-container, .user-status-container .team-mention, .user-status-container .user-mention { white-space: normal; }

.user-status-container { word-break: break-word; overflow-wrap: break-word; }

.user-status-container .input-group-button .btn { width: 46px; height: 34px; line-height: 0; }

.user-status-container .input-group-button g-emoji { font-size: 1.3em; line-height: 18px; }

.user-status-container .team-mention, .user-status-container .user-mention { white-space: normal; }

.user-status-container img.emoji { width: 18px; height: 18px; }

.emoji-status-width { width: 20px; }

.user-status-org-button .user-status-org-detail { color: var(--color-fg-muted); }

.user-status-org-button:hover .user-status-org-detail, .user-status-org-button:focus .user-status-org-detail { color: var(--color-fg-on-emphasis); }

.user-status-org-button.selected { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.user-status-org-button.selected .user-status-org-detail { color: var(--color-fg-on-emphasis); }

.user-status-limited-availability-compact { width: 8px; height: 8px; background-color: var(--color-attention-emphasis); }

.user-status-message-wrapper { color: var(--color-fg-default); }

.toggle-user-status-edit:hover .user-status-message-wrapper, .toggle-user-status-edit:focus .user-status-message-wrapper { color: var(--color-accent-fg); }

.user-status-message-wrapper div { display: inline; }

.user-status-header g-emoji { font-size: 1.25em; }

.user-status-message-wrapper .g-emoji { display: inline-block; }

.user-status-limited-availability-container { margin-top: 16px; margin-bottom: 16px; }

@media only screen and (max-height: 560px) {
  .user-status-suggestions { display: none; }
  .user-status-limited-availability-container { margin-top: 8px; margin-bottom: 8px; }
}

.user-status-circle-badge-container { position: absolute; bottom: 0px; left: 100%; z-index: 2; width: 38px; height: 38px; margin-bottom: 32px; margin-left: -40px; }

.user-status-circle-badge-container .user-status-emoji-container { width: 20px; height: 20px; margin-right: 0px !important; }

.user-status-circle-badge-container .user-status-message-wrapper { width: 0px; overflow: hidden; line-height: 20px; opacity: 0; transition: all 0.1s ease 0s; padding-top: 0px !important; }

.user-status-circle-badge-container .user-status-busy { background-image: linear-gradient(var(--color-attention-subtle), var(--color-attention-subtle)); background-color: var(--color-canvas-default)  !important; }

.user-status-circle-badge-container.user-status-editable:hover, .user-status-circle-badge-container.user-status-has-content:hover { width: auto; max-width: 544px; }

.user-status-circle-badge-container.user-status-editable:hover .user-status-emoji-container, .user-status-circle-badge-container.user-status-has-content:hover .user-status-emoji-container { margin-right: 8px !important; }

.user-status-circle-badge-container.user-status-editable:hover .user-status-message-wrapper, .user-status-circle-badge-container.user-status-has-content:hover .user-status-message-wrapper { width: 100%; opacity: 1; }

.user-status-circle-badge-container.user-status-editable:hover .user-status-circle-badge, .user-status-circle-badge-container.user-status-has-content:hover .user-status-circle-badge { box-shadow: var(--color-shadow-medium); }

.user-status-circle-badge-container .user-status-message-wrapper .team-mention, .user-status-circle-badge-container .user-status-message-wrapper .user-mention { white-space: nowrap; }

.user-status-circle-badge { background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 2em; box-shadow: var(--color-shadow-small); }

.notification-focus-mode-sidebar { position: fixed; top: 55px; right: -340px; z-index: 100; width: 340px; height: 100vh; }

.notification-focus-mode-sidebar.active { right: 40px; }

.notification-focus-mode-sidebar .focus-pagination-next-item { height: 1px; }

.notification-focus-mode-sidebar .notification-focus-mode-header { z-index: 101; }

.notification-focus-mode-sidebar .notification-focus-mode-list { height: 60vh; }

.focus-notification-item.current-focused-item { background: var(--color-border-muted)  !important; }

.focus-notification-item .focus-item-controls { display: none !important; }

.focus-notification-item.navigation-focus .focus-item-controls { display: flex !important; }

.focus-notification-item.navigation-focus .focus-item-metadata { display: none !important; }

.command-palette { box-shadow: var(--color-overlay-shadow); }

.command-palette-details-summary { list-style: none; }

.command-palette-details-summary::-webkit-details-marker { display: none; }

@media (min-width: 768px) {
  .command-palette-details-dialog { width: 512px; }
}

@media (min-width: 1012px) {
  .command-palette-details-dialog { width: 640px; }
}

@media (min-width: 1280px) {
  .command-palette-details-dialog { width: 720px; }
}

.item-stack-transition-height, .page-stack-transition-height { overflow-y: scroll; transition-timing-function: cubic-bezier(0.25, 0.46, 0.45, 0.94); transition-duration: 0.2s; transition-property: max-height, min-height; }

.item-stack-transition-height.no-transition, .page-stack-transition-height.no-transition { transition-duration: 0s; }

.command-palette-input-group { position: relative; z-index: 0; padding-left: 0px; color: var(--color-fg-subtle); }

.command-palette-input-group .command-palette-typeahead { position: absolute; z-index: 1; padding: inherit; pointer-events: none; }

.command-palette-input-group .command-palette-typeahead .typeahead-segment { white-space: pre; }

.command-palette-input-group .command-palette-typeahead .typeahead-segment.input-mirror { opacity: 0; }

.command-palette-input-group .typeahead-input { padding: inherit; }

@media (min-width: 1012px) {
  .hx_actions-sidebar { max-width: 320px; }
}

.hx_text-blue-light { color: var(--color-accent-fg)  !important; }

.hx_actions_timer_input { }

.hx_actions_timer_input::-webkit-outer-spin-button, .hx_actions_timer_input::-webkit-inner-spin-button { appearance: none; }

.hx_anim-fade-out { animation-name: hx-fade-out; animation-duration: 1s; animation-timing-function: ease-out; animation-fill-mode: forwards; }

@keyframes hx-fade-out { 
  0% { opacity: 1; }
  100% { opacity: 0; }
}

.AvatarStack--large { min-width: 44px; height: 32px; }

.AvatarStack--large.AvatarStack--two { min-width: 48px; }

.AvatarStack--large.AvatarStack--three-plus { min-width: 52px; }

.AvatarStack--large .AvatarStack-body .avatar { width: 32px; height: 32px; margin-right: -28px; }

.AvatarStack--large .AvatarStack-body:hover .avatar { margin-right: 4px; }

.AvatarStack--large .avatar.avatar-more::before { width: 32px; }

.AvatarStack--large .avatar.avatar-more::after { width: 30px; }

.AvatarStack--large .avatar.avatar-more::after, .AvatarStack--large .avatar.avatar-more::before { height: 32px; }

.hx_avatar_stack_commit .AvatarStack { height: 24px; min-width: 24px; }

.hx_avatar_stack_commit .AvatarStack .avatar { width: 24px; height: 24px; }

.hx_avatar_stack_commit .AvatarStack.AvatarStack--two { min-width: 40px; }

.hx_avatar_stack_commit .AvatarStack.AvatarStack--three-plus { min-width: 44px; }

.hx_flex-avatar-stack { display: flex; align-items: center; }

.hx_flex-avatar-stack-item { min-width: 0px; max-width: 24px; }

.hx_flex-avatar-stack-item .avatar { display: block; border: 2px solid var(--color-canvas-default); background-color: var(--color-canvas-default); box-shadow: none; }

.hx_flex-avatar-stack-item:last-of-type { flex-shrink: 0; max-width: none; }

.Box-row--focus-gray.navigation-focus .AvatarStack-body { background-color: var(--color-canvas-subtle); }

.AvatarStack-body:not(:hover) { background-color: transparent; }

.AvatarStack--three-plus.AvatarStack--three-plus .avatar-more { display: none; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body .avatar:nth-child(n+4) { display: flex; opacity: 1; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) .avatar:nth-of-type(n+6) { display: none; opacity: 0; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body > .avatar:nth-of-type(1) { z-index: 5; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body > .avatar:nth-of-type(2) { z-index: 4; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body > .avatar:nth-of-type(3) { z-index: 3; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body > .avatar:nth-of-type(4) { z-index: 2; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body > .avatar:nth-of-type(5) { z-index: 1; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more + .avatar:nth-of-type(3) img { opacity: 0.5; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(4) img { opacity: 0.33; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(5) img { opacity: 0.25; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more + .avatar:nth-of-type(3) { margin-right: 0px; margin-left: -6px; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(4) { margin-right: 0px; margin-left: -18px; }

.AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(5) { margin-right: 0px; margin-left: -18px; }

.AvatarStack--three-plus.AvatarStack--three-plus.AvatarStack--right .AvatarStack-body:not(:hover) > .avatar-more + .avatar:nth-of-type(3) { margin-right: -6px; margin-left: 0px; }

.AvatarStack--three-plus.AvatarStack--three-plus.AvatarStack--right .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(4) { margin-right: -18px; margin-left: 0px; }

.AvatarStack--three-plus.AvatarStack--three-plus.AvatarStack--right .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(5) { margin-right: -18px; margin-left: 0px; }

.AvatarStack--three-plus.AvatarStack--three-plus.AvatarStack--large .AvatarStack-body:not(:hover) > .avatar-more + .avatar:nth-of-type(3) { margin-right: 0px; margin-left: -2px; }

.AvatarStack--three-plus.AvatarStack--three-plus.AvatarStack--large .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(4) { margin-right: 0px; margin-left: -30px; }

.AvatarStack--three-plus.AvatarStack--three-plus.AvatarStack--large .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(5) { margin-right: 0px; margin-left: -30px; }

.hx_avatar_stack_commit .AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more + .avatar:nth-of-type(3) { margin-right: 0px; margin-left: -10px; }

.hx_avatar_stack_commit .AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(4) { margin-right: 0px; margin-left: -21px; }

.hx_avatar_stack_commit .AvatarStack--three-plus.AvatarStack--three-plus .AvatarStack-body:not(:hover) > .avatar-more ~ .avatar:nth-of-type(5) { margin-right: 0px; margin-left: -21px; }

.hx_badge-search-container { cursor: text; }

.hx_badge-search-container .hx_badge-input { border: 0px; outline: 0px; box-shadow: none; }

.hx_badge-search-container .hx_badge-input:focus { border: 0px !important; box-shadow: none !important; }

.hx_badge-search-container .hx_badge-input::placeholder { font-size: 12px; }

.hx_badge-search-container .hx_badge-input-inline { height: 30px; }

.hx_badge { cursor: pointer; }

.hx_badge[aria-pressed="true"] { color: var(--color-fg-on-emphasis)  !important; background-color: var(--color-accent-emphasis)  !important; border-color: var(--color-accent-emphasis)  !important; }

.hx_badge-align { height: 40px !important; }

.hx_Box--firstRowRounded0 .Box-row:first-of-type { border-top-left-radius: 0px; border-top-right-radius: 0px; }

.Box-row:first-of-type { border-top-color: transparent; }

.hx_Box-row--with-top-border:first-of-type { border-top-color: inherit; }

.Box--overlay [data-close-dialog], .Box-overlay--narrow [data-close-dialog], .Box-overlay--wide [data-close-dialog] { z-index: 1; }

.dropdown-item.btn-link:disabled, .dropdown-item.btn-link:disabled:hover, .dropdown-item.btn-link[aria-disabled="true"], .dropdown-item.btn-link[aria-disabled="true"]:hover { background-color: transparent; }

@media (hover: hover) {
  .hx_menuitem--focus { background-color: var(--color-canvas-subtle); }
}

@media (-webkit-min-device-pixel-ratio: 2) and (min-resolution: 0.001dpcm) {
  g-emoji { font-size: 1.25em; }
}

.hx_create-pr-button:hover { border-right-width: 0px; }

.hx_create-pr-button:hover + .BtnGroup-parent .BtnGroup-item { border-left-width: 1px; }

summary[type="button"].btn { appearance: none; }

.form-control:-webkit-autofill { box-shadow: inset 0 0 0 32px var(--color-canvas-default)  !important; }

.form-control:-webkit-autofill:focus { box-shadow: inset 0 0 0 32px var(--color-canvas-default),var(--color-primer-shadow-focus)  !important; }

.form-control:-webkit-autofill { -webkit-text-fill-color: var(--color-fg-default); }

::-webkit-calendar-picker-indicator { filter: invert(50%); }

[data-color-mode="light"][data-light-theme*="dark"], [data-color-mode="dark"][data-dark-theme*="dark"] { --color-workflow-card-connector:var(--color-scale-gray-5); --color-workflow-card-connector-bg:var(--color-scale-gray-5); --color-workflow-card-connector-inactive:var(--color-border-default); --color-workflow-card-connector-inactive-bg:var(--color-border-default); --color-workflow-card-connector-highlight:var(--color-scale-blue-5); --color-workflow-card-connector-highlight-bg:var(--color-scale-blue-5); --color-workflow-card-bg:var(--color-scale-gray-7); --color-workflow-card-inactive-bg:var(--color-canvas-inset); --color-workflow-card-header-shadow:rgba(27, 31, 35, 0.04); --color-workflow-card-progress-complete-bg:var(--color-scale-blue-5); --color-workflow-card-progress-incomplete-bg:var(--color-scale-gray-6); --color-discussions-state-answered-icon:var(--color-scale-green-3); --color-bg-discussions-row-emoji-box:var(--color-scale-gray-6); --color-notifications-button-text:var(--color-scale-white); --color-notifications-button-hover-text:var(--color-scale-white); --color-notifications-button-hover-bg:var(--color-scale-blue-4); --color-notifications-row-read-bg:var(--color-canvas-default); --color-notifications-row-bg:var(--color-canvas-subtle); --color-page-header-bg:var(--color-canvas-default); --color-icon-directory:var(--color-fg-muted); --color-checks-step-error-icon:var(--color-scale-red-4); --color-calendar-halloween-graph-day-L1-bg:#631c03; --color-calendar-halloween-graph-day-L2-bg:#bd561d; --color-calendar-halloween-graph-day-L3-bg:#fa7a18; --color-calendar-halloween-graph-day-L4-bg:#fddf68; --color-calendar-graph-day-bg:var(--color-scale-gray-8); --color-calendar-graph-day-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L1-bg:#0e4429; --color-calendar-graph-day-L2-bg:#006d32; --color-calendar-graph-day-L3-bg:#26a641; --color-calendar-graph-day-L4-bg:#39d353; --color-calendar-graph-day-L1-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L2-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L3-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L4-border:rgba(255, 255, 255, 0.05); --color-user-mention-fg:var(--color-scale-yellow-0); --color-user-mention-bg:var(--color-scale-yellow-8); --color-text-white:var(--color-scale-white); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] { --color-workflow-card-connector:var(--color-scale-gray-5); --color-workflow-card-connector-bg:var(--color-scale-gray-5); --color-workflow-card-connector-inactive:var(--color-border-default); --color-workflow-card-connector-inactive-bg:var(--color-border-default); --color-workflow-card-connector-highlight:var(--color-scale-blue-5); --color-workflow-card-connector-highlight-bg:var(--color-scale-blue-5); --color-workflow-card-bg:var(--color-scale-gray-7); --color-workflow-card-inactive-bg:var(--color-canvas-inset); --color-workflow-card-header-shadow:rgba(27, 31, 35, 0.04); --color-workflow-card-progress-complete-bg:var(--color-scale-blue-5); --color-workflow-card-progress-incomplete-bg:var(--color-scale-gray-6); --color-discussions-state-answered-icon:var(--color-scale-green-3); --color-bg-discussions-row-emoji-box:var(--color-scale-gray-6); --color-notifications-button-text:var(--color-scale-white); --color-notifications-button-hover-text:var(--color-scale-white); --color-notifications-button-hover-bg:var(--color-scale-blue-4); --color-notifications-row-read-bg:var(--color-canvas-default); --color-notifications-row-bg:var(--color-canvas-subtle); --color-page-header-bg:var(--color-canvas-default); --color-icon-directory:var(--color-fg-muted); --color-checks-step-error-icon:var(--color-scale-red-4); --color-calendar-halloween-graph-day-L1-bg:#631c03; --color-calendar-halloween-graph-day-L2-bg:#bd561d; --color-calendar-halloween-graph-day-L3-bg:#fa7a18; --color-calendar-halloween-graph-day-L4-bg:#fddf68; --color-calendar-graph-day-bg:var(--color-scale-gray-8); --color-calendar-graph-day-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L1-bg:#0e4429; --color-calendar-graph-day-L2-bg:#006d32; --color-calendar-graph-day-L3-bg:#26a641; --color-calendar-graph-day-L4-bg:#39d353; --color-calendar-graph-day-L1-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L2-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L3-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L4-border:rgba(255, 255, 255, 0.05); --color-user-mention-fg:var(--color-scale-yellow-0); --color-user-mention-bg:var(--color-scale-yellow-8); --color-text-white:var(--color-scale-white); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] { --color-workflow-card-connector:var(--color-scale-gray-5); --color-workflow-card-connector-bg:var(--color-scale-gray-5); --color-workflow-card-connector-inactive:var(--color-border-default); --color-workflow-card-connector-inactive-bg:var(--color-border-default); --color-workflow-card-connector-highlight:var(--color-scale-blue-5); --color-workflow-card-connector-highlight-bg:var(--color-scale-blue-5); --color-workflow-card-bg:var(--color-scale-gray-7); --color-workflow-card-inactive-bg:var(--color-canvas-inset); --color-workflow-card-header-shadow:rgba(27, 31, 35, 0.04); --color-workflow-card-progress-complete-bg:var(--color-scale-blue-5); --color-workflow-card-progress-incomplete-bg:var(--color-scale-gray-6); --color-discussions-state-answered-icon:var(--color-scale-green-3); --color-bg-discussions-row-emoji-box:var(--color-scale-gray-6); --color-notifications-button-text:var(--color-scale-white); --color-notifications-button-hover-text:var(--color-scale-white); --color-notifications-button-hover-bg:var(--color-scale-blue-4); --color-notifications-row-read-bg:var(--color-canvas-default); --color-notifications-row-bg:var(--color-canvas-subtle); --color-page-header-bg:var(--color-canvas-default); --color-icon-directory:var(--color-fg-muted); --color-checks-step-error-icon:var(--color-scale-red-4); --color-calendar-halloween-graph-day-L1-bg:#631c03; --color-calendar-halloween-graph-day-L2-bg:#bd561d; --color-calendar-halloween-graph-day-L3-bg:#fa7a18; --color-calendar-halloween-graph-day-L4-bg:#fddf68; --color-calendar-graph-day-bg:var(--color-scale-gray-8); --color-calendar-graph-day-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L1-bg:#0e4429; --color-calendar-graph-day-L2-bg:#006d32; --color-calendar-graph-day-L3-bg:#26a641; --color-calendar-graph-day-L4-bg:#39d353; --color-calendar-graph-day-L1-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L2-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L3-border:rgba(255, 255, 255, 0.05); --color-calendar-graph-day-L4-border:rgba(255, 255, 255, 0.05); --color-user-mention-fg:var(--color-scale-yellow-0); --color-user-mention-bg:var(--color-scale-yellow-8); --color-text-white:var(--color-scale-white); }
}

:root, [data-color-mode="light"][data-light-theme*="light"], [data-color-mode="dark"][data-dark-theme*="light"] { --color-workflow-card-connector:var(--color-scale-gray-3); --color-workflow-card-connector-bg:var(--color-scale-gray-3); --color-workflow-card-connector-inactive:var(--color-border-default); --color-workflow-card-connector-inactive-bg:var(--color-border-default); --color-workflow-card-connector-highlight:var(--color-scale-blue-4); --color-workflow-card-connector-highlight-bg:var(--color-scale-blue-4); --color-workflow-card-bg:var(--color-scale-white); --color-workflow-card-inactive-bg:var(--color-canvas-inset); --color-workflow-card-header-shadow:rgba(0, 0, 0, 0); --color-workflow-card-progress-complete-bg:var(--color-scale-blue-4); --color-workflow-card-progress-incomplete-bg:var(--color-scale-gray-2); --color-discussions-state-answered-icon:var(--color-scale-white); --color-bg-discussions-row-emoji-box:rgba(209, 213, 218, 0.5); --color-notifications-button-text:var(--color-fg-muted); --color-notifications-button-hover-text:var(--color-fg-default); --color-notifications-button-hover-bg:var(--color-scale-gray-2); --color-notifications-row-read-bg:var(--color-canvas-subtle); --color-notifications-row-bg:var(--color-scale-white); --color-page-header-bg:var(--color-canvas-subtle); --color-icon-directory:var(--color-scale-blue-3); --color-checks-step-error-icon:var(--color-scale-red-4); --color-calendar-halloween-graph-day-L1-bg:#ffee4a; --color-calendar-halloween-graph-day-L2-bg:#ffc501; --color-calendar-halloween-graph-day-L3-bg:#fe9600; --color-calendar-halloween-graph-day-L4-bg:#03001c; --color-calendar-graph-day-bg:#ebedf0; --color-calendar-graph-day-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L1-bg:#9be9a8; --color-calendar-graph-day-L2-bg:#40c463; --color-calendar-graph-day-L3-bg:#30a14e; --color-calendar-graph-day-L4-bg:#216e39; --color-calendar-graph-day-L1-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L2-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L3-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L4-border:rgba(27, 31, 35, 0.06); --color-user-mention-fg:var(--color-fg-default); --color-user-mention-bg:var(--color-attention-subtle); --color-text-white:var(--color-scale-white); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="light"] { --color-workflow-card-connector:var(--color-scale-gray-3); --color-workflow-card-connector-bg:var(--color-scale-gray-3); --color-workflow-card-connector-inactive:var(--color-border-default); --color-workflow-card-connector-inactive-bg:var(--color-border-default); --color-workflow-card-connector-highlight:var(--color-scale-blue-4); --color-workflow-card-connector-highlight-bg:var(--color-scale-blue-4); --color-workflow-card-bg:var(--color-scale-white); --color-workflow-card-inactive-bg:var(--color-canvas-inset); --color-workflow-card-header-shadow:rgba(0, 0, 0, 0); --color-workflow-card-progress-complete-bg:var(--color-scale-blue-4); --color-workflow-card-progress-incomplete-bg:var(--color-scale-gray-2); --color-discussions-state-answered-icon:var(--color-scale-white); --color-bg-discussions-row-emoji-box:rgba(209, 213, 218, 0.5); --color-notifications-button-text:var(--color-fg-muted); --color-notifications-button-hover-text:var(--color-fg-default); --color-notifications-button-hover-bg:var(--color-scale-gray-2); --color-notifications-row-read-bg:var(--color-canvas-subtle); --color-notifications-row-bg:var(--color-scale-white); --color-page-header-bg:var(--color-canvas-subtle); --color-icon-directory:var(--color-scale-blue-3); --color-checks-step-error-icon:var(--color-scale-red-4); --color-calendar-halloween-graph-day-L1-bg:#ffee4a; --color-calendar-halloween-graph-day-L2-bg:#ffc501; --color-calendar-halloween-graph-day-L3-bg:#fe9600; --color-calendar-halloween-graph-day-L4-bg:#03001c; --color-calendar-graph-day-bg:#ebedf0; --color-calendar-graph-day-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L1-bg:#9be9a8; --color-calendar-graph-day-L2-bg:#40c463; --color-calendar-graph-day-L3-bg:#30a14e; --color-calendar-graph-day-L4-bg:#216e39; --color-calendar-graph-day-L1-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L2-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L3-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L4-border:rgba(27, 31, 35, 0.06); --color-user-mention-fg:var(--color-fg-default); --color-user-mention-bg:var(--color-attention-subtle); --color-text-white:var(--color-scale-white); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="light"] { --color-workflow-card-connector:var(--color-scale-gray-3); --color-workflow-card-connector-bg:var(--color-scale-gray-3); --color-workflow-card-connector-inactive:var(--color-border-default); --color-workflow-card-connector-inactive-bg:var(--color-border-default); --color-workflow-card-connector-highlight:var(--color-scale-blue-4); --color-workflow-card-connector-highlight-bg:var(--color-scale-blue-4); --color-workflow-card-bg:var(--color-scale-white); --color-workflow-card-inactive-bg:var(--color-canvas-inset); --color-workflow-card-header-shadow:rgba(0, 0, 0, 0); --color-workflow-card-progress-complete-bg:var(--color-scale-blue-4); --color-workflow-card-progress-incomplete-bg:var(--color-scale-gray-2); --color-discussions-state-answered-icon:var(--color-scale-white); --color-bg-discussions-row-emoji-box:rgba(209, 213, 218, 0.5); --color-notifications-button-text:var(--color-fg-muted); --color-notifications-button-hover-text:var(--color-fg-default); --color-notifications-button-hover-bg:var(--color-scale-gray-2); --color-notifications-row-read-bg:var(--color-canvas-subtle); --color-notifications-row-bg:var(--color-scale-white); --color-page-header-bg:var(--color-canvas-subtle); --color-icon-directory:var(--color-scale-blue-3); --color-checks-step-error-icon:var(--color-scale-red-4); --color-calendar-halloween-graph-day-L1-bg:#ffee4a; --color-calendar-halloween-graph-day-L2-bg:#ffc501; --color-calendar-halloween-graph-day-L3-bg:#fe9600; --color-calendar-halloween-graph-day-L4-bg:#03001c; --color-calendar-graph-day-bg:#ebedf0; --color-calendar-graph-day-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L1-bg:#9be9a8; --color-calendar-graph-day-L2-bg:#40c463; --color-calendar-graph-day-L3-bg:#30a14e; --color-calendar-graph-day-L4-bg:#216e39; --color-calendar-graph-day-L1-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L2-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L3-border:rgba(27, 31, 35, 0.06); --color-calendar-graph-day-L4-border:rgba(27, 31, 35, 0.06); --color-user-mention-fg:var(--color-fg-default); --color-user-mention-bg:var(--color-attention-subtle); --color-text-white:var(--color-scale-white); }
}

.hx_color-icon-directory { color: var(--color-icon-directory); }

:checked + .hx_theme-toggle { border-color: var(--color-accent-emphasis); }

.hx_comment-box--tip::after { background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default))  !important; }

.hx_keyword-hl { background-color: var(--color-search-keyword-hl); }

.hx_dot-fill-pending-icon { color: var(--color-attention-emphasis)  !important; }

@media (max-width: 543px) {
  [data-color-mode="light"][data-light-theme*="dark"], [data-color-mode="dark"][data-dark-theme*="dark"] { --color-fg-default: var(--color-scale-gray-0); --color-canvas-default: var(--color-scale-gray-8); }
}

@media (max-width: 543px) and (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] { --color-fg-default: var(--color-scale-gray-0); --color-canvas-default: var(--color-scale-gray-8); }
}

@media (max-width: 543px) and (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] { --color-fg-default: var(--color-scale-gray-0); --color-canvas-default: var(--color-scale-gray-8); }
}

:root[data-color-mode="dark"] .entry-content [href$="#gh-light-mode-only"], :root[data-color-mode="dark"] .comment-body [href$="#gh-light-mode-only"], :root[data-color-mode="dark"] .readme [href$="#gh-light-mode-only"] { display: none; }

:root[data-color-mode="light"] .entry-content [href$="#gh-dark-mode-only"], :root[data-color-mode="light"] .comment-body [href$="#gh-dark-mode-only"], :root[data-color-mode="light"] .readme [href$="#gh-dark-mode-only"] { display: none; }

@media (prefers-color-scheme: dark) {
  :root[data-color-mode="auto"] .entry-content [href$="#gh-light-mode-only"], :root[data-color-mode="auto"] .comment-body [href$="#gh-light-mode-only"], :root[data-color-mode="auto"] .readme [href$="#gh-light-mode-only"] { display: none; }
}

@media (prefers-color-scheme: light) {
  :root[data-color-mode="auto"] .entry-content [href$="#gh-dark-mode-only"], :root[data-color-mode="auto"] .comment-body [href$="#gh-dark-mode-only"], :root[data-color-mode="auto"] .readme [href$="#gh-dark-mode-only"] { display: none; }
}

.dropdown-item:focus [class*="color-text-"], .dropdown-item:hover [class*="color-text-"] { color: inherit !important; }

.filter-item.selected [class*="color-text-"] { color: inherit !important; }

body:not(.intent-mouse) .hx_focus-input:focus + .hx_focus-target { box-shadow: var(--color-btn-shadow-input-focus); }

.is-auto-complete-loading .form-control { padding-right: 30px; background-image: url("/images/spinners/octocat-spinner-32.gif"); background-size: 16px; }

.hx_breadcrumb-header .header-search-wrapper { height: 32px; }

.hx_breadcrumb-header .notification-indicator .mail-status, .hx_breadcrumb-header .feature-preview-indicator { background-image: none; background-color: var(--color-accent-emphasis); }

.hx_breadcrumb-header .Header-link, .hx_breadcrumb-header .Header-current-page { color: var(--color-header-logo); }

.hx_breadcrumb-header-crumbs .Header-link, .hx_breadcrumb-header-logo { transition: opacity 0.1s ease-out 0s; }

.hx_breadcrumb-header-crumbs .Header-link:hover, .hx_breadcrumb-header-logo:hover { color: var(--color-header-text); opacity: 0.75; }

.hx_breadcrumb-header-divider { color: var(--color-header-divider); }

.Header-button { background-color: var(--color-scale-gray-8); border-radius: 6px; border: 1px solid var(--color-scale-gray-6); transition: background-color 0.2s cubic-bezier(0.3, 0, 0.5, 1) 0s; }

.Header-button .octicon { color: var(--color-header-logo); }

.Header-button:hover, .Header-button:focus, .Header-button:active { background-color: transparent; }

.Header-button:hover .octicon, .Header-button:focus .octicon, .Header-button:active .octicon { color: var(--color-header-text); box-shadow: none; }

.hx_breadcrumb-header-dropdown::before, .hx_breadcrumb-header-dropdown::after { display: none; }

.hx_breadcrumb-header-dropdown .dropdown-item { transition: background-color 60ms ease-out 0s; line-height: 40px; }

.hx_breadcrumb-header-dropdown .dropdown-item:hover { color: var(--color-fg-default); background-color: var(--color-canvas-subtle); }

.icon-sponsor, .icon-sponsoring { transition: transform 0.15s cubic-bezier(0.2, 0, 0.13, 2) 0s; transform: scale(1); }

.btn:hover .icon-sponsor, .btn:focus .icon-sponsor, .Label:hover .icon-sponsor, .Label:focus .icon-sponsor, .btn:hover .icon-sponsoring, .btn:focus .icon-sponsoring, .Label:hover .icon-sponsoring, .Label:focus .icon-sponsoring { transform: scale(1.1); }

.icon-sponsor { overflow: visible !important; }

.hx_kbd { border: 1px solid var(--color-border-default); background-color: var(--color-canvas-default); border-radius: 6px; font-size: 12px; font-weight: 400; display: inline-block; box-shadow: none; line-height: 1.5; color: var(--color-fg-muted); text-align: center; padding: 0px 4px; min-width: 21px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"; }

.hx_hit-user em, .hx_hit-package em, .hx_hit-marketplace em, .hx_hit-highlighting-wrapper em, .hx_hit-commit em, .hx_hit-issue em, .hx_hit-repo em, .hx_hit-wiki em { font-style: normal; font-weight: 600; }

.SelectMenu-list.select-menu-list { max-height: none; }

@media (max-width: 543px) {
  .SelectMenu-modal { width: unset !important; }
}

.SelectMenu--hasFilter .SelectMenu-list { contain: content; }

.SelectMenu-item:disabled, .SelectMenu-item[aria-disabled="true"] { color: var(--color-fg-muted); pointer-events: none; }

.SelectMenu .SelectMenu-item .is-filtering { color: var(--color-fg-muted); }

.SelectMenu .SelectMenu-item .is-filtering b { color: var(--color-fg-default); }

label.SelectMenu-item { font-weight: 400; }

label.SelectMenu-item[aria-checked="true"] { font-weight: 600; }

.Box--responsive { margin-right: -15px; margin-left: -15px; border-left: 0px; border-right: 0px; border-radius: 0px; }

.Box--responsive .Box-row--unread { position: relative; box-shadow: none; }

.Box--responsive .Box-row--unread::before { width: 8px; height: 8px; color: rgb(255, 255, 255); background-image: linear-gradient(rgb(84, 163, 255), rgb(0, 110, 237)); background-clip: padding-box; border-radius: 50%; content: ""; display: inline-block; top: 36px; left: 20px; position: absolute; }

.Box--responsive .Box-header { border-left-width: 0px; border-right-width: 0px; border-radius: 0px; }

@media (min-width: 544px) {
  .Box--responsive { margin-right: 0px; margin-left: 0px; border: 1px solid var(--color-border-default); border-radius: 6px; }
  .Box--responsive .Box-header { border-left-width: 1px; border-right-width: 1px; border-top-left-radius: 6px; border-top-right-radius: 6px; }
  .Box--responsive .Box-row--unread { box-shadow: 2px 0 0 var(--color-accent-emphasis) inset; }
  .Box--responsive .Box-row--unread::before { display: none; }
}

@media (max-width: 767px) {
  .page-responsive .dropdown-menu, .page-responsive .dropdown-item { padding-top: 8px; padding-bottom: 8px; }
  .page-responsive .hx_dropdown-fullscreen[open] > summary::before { background-color: var(--color-primer-canvas-backdrop); }
  .page-responsive .hx_dropdown-fullscreen .dropdown-menu { position: fixed; top: auto; bottom: 20%; max-height: calc(80% - 16px); overflow-y: auto; transform: none; animation: 0.24s cubic-bezier(0, 0.1, 0.1, 1) 0s 1 normal backwards running dropdown-menu-animation; right: 16px !important; left: 16px !important; width: auto !important; max-width: none !important; margin: 0px !important; }
  .page-responsive .hx_dropdown-fullscreen .dropdown-menu::before, .page-responsive .hx_dropdown-fullscreen .dropdown-menu::after { display: none; }
  @keyframes dropdown-menu-animation { 
  0% { opacity: 0; transform: scale(0.9); }
}
  .page-responsive .hx_dropdown-fullscreen .dropdown-item { padding-top: 16px; padding-bottom: 16px; }
}

.page-responsive .pagination > * { display: none; }

.page-responsive .pagination > :first-child, .page-responsive .pagination > :last-child, .page-responsive .pagination > .previous_page, .page-responsive .pagination > .next_page { display: inline-block; }

@media (min-width: 544px) {
  .page-responsive .pagination > :nth-child(2), .page-responsive .pagination > :nth-last-child(2), .page-responsive .pagination > .current, .page-responsive .pagination > .gap { display: inline-block; }
}

@media (min-width: 768px) {
  .page-responsive .pagination > * { display: inline-block; }
}

.hx_rsm-close-button { display: none !important; }

@media (max-width: 767px) {
  .page-responsive .hx_rsm[open] > summary::before { background-color: var(--color-primer-canvas-backdrop); }
  .page-responsive .hx_rsm .select-menu-modal, .page-responsive .hx_rsm-modal { display: flex; flex-direction: column; margin: 0px; width: auto; height: 80%; top: 75px; left: 16px; position: fixed !important; right: 16px !important; }
  .page-responsive .hx_rsm--auto-height .select-menu-modal { height: auto; max-height: calc(80% - 16px); top: auto; bottom: 20%; }
  .page-responsive .hx_rsm .select-menu-header, .page-responsive .hx_rsm .select-menu-text-filter.select-menu-text-filter { padding: 16px; border-top-left-radius: inherit; border-top-right-radius: inherit; }
  .page-responsive .hx_rsm .js-project-menu-container, .page-responsive .hx_rsm tab-container, .page-responsive .hx_rsm-content { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0px; }
  .page-responsive .hx_rsm .select-menu-list { flex: 1 1 auto; max-height: none; }
  .page-responsive .hx_rsm-content > .select-menu-item { flex-shrink: 0; }
  .page-responsive .hx_rsm .select-menu-item { padding-top: 16px; padding-bottom: 16px; padding-left: 40px; }
  .page-responsive .hx_rsm .close-button, .page-responsive .hx_rsm-close-button { position: relative; display: block !important; }
  .page-responsive .hx_rsm .close-button::before, .page-responsive .hx_rsm-close-button::before { content: ""; position: absolute; inset: -16px; }
  .page-responsive .hx_rsm .close-button .octicon-x, .page-responsive .hx_rsm-close-button .octicon-x { color: var(--color-fg-muted); }
  .page-responsive .hx_rsm .select-menu-loading-overlay { animation-delay: 1s; }
  .page-responsive .hx_rsm .select-menu-button::before, .page-responsive .hx_rsm-trigger::before { animation: 0.24s cubic-bezier(0, 0, 0.2, 1) 0s 1 normal backwards running hx_rsm-trigger-animation; }
  @keyframes hx_rsm-trigger-animation { 
  0% { opacity: 0; }
}
  .page-responsive .hx_rsm .select-menu-modal, .page-responsive .hx_rsm-modal { animation: 0.24s cubic-bezier(0, 0.1, 0.1, 1) 0.12s 1 normal backwards running hx_rsm-modal-animation; }
  @keyframes hx_rsm-modal-animation { 
  0% { opacity: 0; transform: scale(0.9); }
}
  .page-responsive .hx_rsm-dialog { height: auto; max-height: 80%; max-width: none; transform: none; }
  .page-responsive .hx_rsm-dialog-content { flex: 1 1 0%; min-height: 0px; }
}

@media (max-width: 767px) and (max-height: 500px) {
  .page-responsive .hx_rsm .select-menu-modal, .page-responsive .hx_rsm-modal { height: auto; bottom: 16px; }
}

.select-menu-modal { border-color: var(--color-border-default); box-shadow: var(--color-shadow-large); }

.select-menu-header, .select-menu-filters { background: var(--color-canvas-overlay); }

.select-menu-text-filter input { padding: 5px 12px; }

.js-project-menu-container .select-menu-item:last-child { border-bottom: 0px; border-bottom-left-radius: 6px !important; border-bottom-right-radius: 6px !important; }

.select-menu-item { text-align: left; background-color: var(--color-canvas-overlay); border-top: 0px; border-right: 0px; border-left: 0px; }

.preview-selected .tabnav--responsive { border-bottom: 1px solid var(--color-border-default); }

.tabnav--responsive .tabnav-tabs { z-index: 1; }

@media (max-width: 767px) {
  .tabnav--responsive .tabnav-tab { background-color: var(--color-canvas-subtle); border-top-color: ; border-top-style: ; border-top-width: ; border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: ; border-bottom-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-left: 0px; border-radius: 0px; }
  .tabnav--responsive .tabnav-tab:first-child { border-left: 1px solid var(--color-border-default); }
  .tabnav--responsive .tabnav-tab[aria-selected="true"], .tabnav--responsive .tabnav-tab.selected { border-bottom: 0px; background-color: var(--color-canvas-default); }
}

@media (max-width: 767px) {
  .hx_sm-hide-drag-drop textarea { border-bottom: 1px solid var(--color-border-default); border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; }
  .hx_sm-hide-drag-drop .hx_drag-and-drop { display: none !important; }
}

@media (hover: none) {
  .tooltipped:hover::before, .tooltipped:hover::after { display: none; }
}

@media (hover: none) {
  .markdown-body h1 .octicon-link, .markdown-body h2 .octicon-link, .markdown-body h3 .octicon-link, .markdown-body h4 .octicon-link, .markdown-body h5 .octicon-link, .markdown-body h6 .octicon-link { visibility: visible !important; }
}

.hx_UnderlineNav .UnderlineNav-item { margin: 0px; padding: 7px 12px 8px !important; }

.hx_underlinenav-item { display: flex; align-items: center; }

.hx_underlinenav-item .UnderlineNav-octicon { margin-right: 6px; }

.hx_underlinenav-item [data-content]::before { content: attr(data-content); display: block; font-weight: 600; height: 0px; visibility: hidden; }

.hx_underlinenav-item-ts { letter-spacing: 0.01em; transition: text-shadow 0.3s ease 0s; }

.hx_underlinenav-item-ts[role="tab"][aria-selected="true"] { font-weight: 400; text-shadow: 0 0 0.6px var(--color-fg-default); }

.min-width-lg { min-width: 1012px; }

.min-width-xl { min-width: 1280px; }

.min-height-0 { min-height: 0px !important; }

.ws-pre-wrap { white-space: pre-wrap; }

.cursor-pointer { cursor: pointer; }

.cursor-default { cursor: default; }

@media screen and (prefers-reduced-motion: no-preference) {
  .hide-no-pref-motion { visibility: hidden; display: none !important; }
}

@media screen and (prefers-reduced-motion: reduce) {
  .hide-reduced-motion { visibility: hidden; display: none !important; }
}

.text-capitalize { text-transform: capitalize !important; }

.starring-container .unstarred, .starring-container.on .starred { display: block; }

.starring-container.on .unstarred, .starring-container .starred { display: none; }

.starring-container.loading { opacity: 0.5; }

.user-following-container .follow, .user-following-container.on .unfollow { display: inline-block; }

.user-following-container.on .follow, .user-following-container .unfollow { display: none; }

.user-following-container.loading { opacity: 0.5; }

.btn-states .btn-state-alternate { display: none; }

.btn-states:hover .btn-state-default { display: none; }

.btn-states:hover .btn-state-alternate { display: inline-block; }

.hidden-when-empty:empty { display: none !important; }

.cm-number, .cm-atom { color: var(--color-codemirror-syntax-constant); }

auto-check .is-autocheck-loading, auto-check .is-autocheck-successful, auto-check .is-autocheck-errored { padding-right: 30px; }

auto-check .is-autocheck-loading { background-image: url("/images/spinners/octocat-spinner-16px.gif"); }

auto-check .is-autocheck-successful { background-image: url("/images/modules/ajax/success.png"); }

auto-check .is-autocheck-errored { background-image: url("/images/modules/ajax/error.png"); }

@media only screen and (-webkit-min-device-pixel-ratio: 2), not all, not all, not all, only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
  auto-check .is-autocheck-loading, auto-check .is-autocheck-successful, auto-check .is-autocheck-errored { background-size: 16px 16px; }
  auto-check .is-autocheck-loading { background-image: url("/images/spinners/octocat-spinner-32.gif"); }
  auto-check .is-autocheck-successful { background-image: url("/images/modules/ajax/success@2x.png"); }
  auto-check .is-autocheck-errored { background-image: url("/images/modules/ajax/error@2x.png"); }
}

.hx_text-body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji" !important; }

.hx_disabled-form-checkbox-label.form-checkbox.disabled { color: var(--color-fg-muted); }

.autocomplete-item { background-color: transparent; }

.ColorSwatch { display: inline-block; width: 1em; height: 1em; vertical-align: middle; border: 1px solid var(--color-border-subtle); border-radius: 6px; }

.label-select-menu .color, .ColorSwatch { border-radius: 2em; }

.details-overlay[open] > .dropdown-item:hover { color: inherit; background: var(--color-canvas-default); }

remote-input[loading] .form-control { padding-right: 30px; background-image: url("/images/spinners/octocat-spinner-32.gif"); background-size: 16px; }

.hx_form-control-spinner { display: none; position: absolute; top: 24px; right: 24px; }

@media (min-width: 767px) {
  .hx_form-control-spinner { top: 18px; right: 18px; }
}

.hx_form-control-spinner-wrapper { position: relative; }

.hx_form-control-spinner-wrapper .is-loading.form-control { padding-right: 28px; }

.hx_form-control-spinner-wrapper .is-loading + .hx_form-control-spinner { display: block; }

.hidden-radio-input { width: 0px; height: 0px; position: absolute; appearance: none; }

.BorderGrid { display: table; border-collapse: collapse; border-style: hidden; table-layout: fixed; width: 100%; }

.BorderGrid { margin-top: -16px; margin-bottom: -16px; }

.BorderGrid .BorderGrid-cell { padding-top: 16px; padding-bottom: 16px; }

.BorderGrid--spacious { margin-top: -24px; margin-bottom: -24px; }

.BorderGrid--spacious .BorderGrid-cell { padding-top: 24px; padding-bottom: 24px; }

.BorderGrid-row { display: table-row; }

.BorderGrid-cell { display: table-cell; border: 1px solid var(--color-border-muted); }

.drag-and-drop { border-color: var(--color-border-default); }

.input-sm { min-height: 28px; }

.btn .octicon-triangle-down { margin-right: 0px; }

.UnderlineNav-item.selected .UnderlineNav-octicon, .UnderlineNav-item[aria-current]:not([aria-current="false"]) .UnderlineNav-octicon, .UnderlineNav-item[role="tab"][aria-selected="true"] .UnderlineNav-octicon { color: inherit; }

.break-line-anywhere { line-break: anywhere !important; }

.form-checkbox input[type="checkbox"], .form-checkbox input[type="radio"] { margin-top: 4px; }

.status-indicator-success::before, .status-indicator-failed::before { content: none; }

.hx_status-indicator .status-indicator-spinner { display: none; }

.hx_status-indicator.status-indicator-loading { background-image: none; }

.hx_status-indicator.status-indicator-loading .status-indicator-spinner { display: inline-block; }

.markdown-title code { padding: 2px 4px; background-color: var(--color-neutral-muted); font-size: 0.9em; line-height: 1; border-radius: 6px; }

.IssueLabel--big.lh-condensed { display: inline-block; padding: 0px 10px; font-size: 12px; font-weight: 500; border: 1px solid transparent; border-radius: 2em; line-height: 22px !important; }

.hx_IssueLabel { --perceived-lightness: calc( ((var(--label-r) * 0.2126) + (var(--label-g) * 0.7152) + (var(--label-b) * 0.0722)) / 255 ); --lightness-switch: max(0, min(calc((var(--perceived-lightness) - var(--lightness-threshold)) * -1000), 1)); }

:root .hx_IssueLabel, [data-color-mode="light"][data-light-theme*="light"] .hx_IssueLabel, [data-color-mode="dark"][data-dark-theme*="light"] .hx_IssueLabel { --lightness-threshold: 0.453; --border-threshold: 0.96; --border-alpha: max(0, min(calc((var(--perceived-lightness) - var(--border-threshold)) * 100), 1)); background: rgb(var(--label-r), var(--label-g), var(--label-b)); color: hsl(0, 0%, calc(var(--lightness-switch) * 100%)); border-color: hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) - 25) * 1%), var(--border-alpha)); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="light"] .hx_IssueLabel { --lightness-threshold: 0.453; --border-threshold: 0.96; --border-alpha: max(0, min(calc((var(--perceived-lightness) - var(--border-threshold)) * 100), 1)); background: rgb(var(--label-r), var(--label-g), var(--label-b)); color: hsl(0, 0%, calc(var(--lightness-switch) * 100%)); border-color: hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) - 25) * 1%), var(--border-alpha)); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="light"] .hx_IssueLabel { --lightness-threshold: 0.453; --border-threshold: 0.96; --border-alpha: max(0, min(calc((var(--perceived-lightness) - var(--border-threshold)) * 100), 1)); background: rgb(var(--label-r), var(--label-g), var(--label-b)); color: hsl(0, 0%, calc(var(--lightness-switch) * 100%)); border-color: hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) - 25) * 1%), var(--border-alpha)); }
}

[data-color-mode="light"][data-light-theme*="dark"] .hx_IssueLabel, [data-color-mode="dark"][data-dark-theme*="dark"] .hx_IssueLabel { --lightness-threshold: 0.6; --background-alpha: 0.18; --border-alpha: 0.3; --lighten-by: calc(((var(--lightness-threshold) - var(--perceived-lightness)) * 100) * var(--lightness-switch)); background: rgba(var(--label-r), var(--label-g), var(--label-b), var(--background-alpha)); color: hsl(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%)); border-color: hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%), var(--border-alpha)); }

@media (prefers-color-scheme: light) {
  [data-color-mode="auto"][data-light-theme*="dark"] .hx_IssueLabel { --lightness-threshold: 0.6; --background-alpha: 0.18; --border-alpha: 0.3; --lighten-by: calc(((var(--lightness-threshold) - var(--perceived-lightness)) * 100) * var(--lightness-switch)); background: rgba(var(--label-r), var(--label-g), var(--label-b), var(--background-alpha)); color: hsl(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%)); border-color: hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%), var(--border-alpha)); }
}

@media (prefers-color-scheme: dark) {
  [data-color-mode="auto"][data-dark-theme*="dark"] .hx_IssueLabel { --lightness-threshold: 0.6; --background-alpha: 0.18; --border-alpha: 0.3; --lighten-by: calc(((var(--lightness-threshold) - var(--perceived-lightness)) * 100) * var(--lightness-switch)); background: rgba(var(--label-r), var(--label-g), var(--label-b), var(--background-alpha)); color: hsl(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%)); border-color: hsla(var(--label-h), calc(var(--label-s) * 1%), calc((var(--label-l) + var(--lighten-by)) * 1%), var(--border-alpha)); }
}

.signed-commit-badge-small, .signed-commit-badge-medium, .signed-commit-badge-large { display: inline-block; padding: 0px 7px; font-size: 12px; font-weight: 500; line-height: 18px; border-width: 1px; border-style: solid; border-image: initial; border-radius: 2em; border-color: var(--color-border-default); }

.signed-commit-badge-small { margin-top: 0px; }

.signed-commit-badge-large { padding-right: 10px; padding-left: 10px; line-height: 22px; }

.topic-tag-action, .delete-topic-button, .topic-tag { display: inline-block; padding: 0px 10px; font-size: 12px; font-weight: 500; border-radius: 2em; line-height: 22px; color: var(--color-accent-fg); background-color: var(--color-accent-subtle); border: 1px solid var(--color-topic-tag-border, transparent); }

.topic-tag-action:active, .topic-tag-action:hover, .delete-topic-button:active, .delete-topic-button:hover, .topic-tag:active, .topic-tag:hover { background-color: var(--color-accent-emphasis); color: var(--color-fg-on-emphasis); }

.topic-tag { margin: 0px 0.125em 0.333em 0px; }

.topic-tag-outline { background: transparent; }

.topic-tag-action { display: inline-flex; padding-right: 0px; margin: 0.6em 0.5em 0px 0px; }

.delete-topic-button, .topic-tag-action .add-topic-button, .topic-tag-action .remove-topic-button { width: 24px; padding: 0px; height: 24px; color: inherit; border-top-color: transparent; border-right-color: transparent; border-bottom-color: transparent; border-left: 0px; border-radius: 2em; display: flex; align-items: center; justify-content: center; }

.rounded-1 { border-radius: 6px !important; }

.rounded-top-1 { border-top-left-radius: 6px !important; border-top-right-radius: 6px !important; }

.rounded-right-1 { border-top-right-radius: 6px !important; border-bottom-right-radius: 6px !important; }

.rounded-bottom-1 { border-bottom-right-radius: 6px !important; border-bottom-left-radius: 6px !important; }

.rounded-left-1 { border-bottom-left-radius: 6px !important; border-top-left-radius: 6px !important; }

.branch-action-item.color-border-default { border-color: var(--color-border-default)  !important; }

.user-profile-nav .UnderlineNav-item { line-height: 30px; white-space: nowrap; margin-right: 0px !important; }

.user-status-container .input-group-button .btn { height: 32px; }

.tree-finder-input { min-height: 32px; }

.notification-list-item-actions .btn { box-shadow: none; }

.reponav-item, .pagehead-tabs-item { border-radius: 4px 4px 0px 0px; }

.reponav-item.selected, .pagehead-tabs-item.selected { border-top-color: rgb(249, 130, 108); }

.reponav-item .hx_reponav_item_counter { min-width: 0px; line-height: 1.25; }

.auto-search-group > .octicon { top: 8px; }

.subnav-search > button.mt-2 { margin-top: 6px !important; }

.completeness-indicator-success { background-color: var(--color-btn-primary-bg); color: var(--color-fg-on-emphasis); }

.pagination-loader-container button.color-bg-default.border-0 { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.avatar-user { border-radius: 50% !important; }

.user-profile-sticky-bar::after, .user-profile-mini-vcard { height: 48px; }

.hx_remove-comment-thread-vertical-line::after { display: none !important; }

@media (max-width: 543px) {
  .minimized-comment.hx_make-comment-take-up-space-on-sm-screens > details > div { padding-left: 0px !important; }
}

@media (max-width: 543px) {
  .minimized-comment.hx_center-show-toggle-button-on-sm-screens > details > summary > div { flex-direction: column; }
  .minimized-comment.hx_center-show-toggle-button-on-sm-screens > details > summary > div .review-comment-contents { }
}

.hx_add-margin-to-comment-textfield .write-content { margin: 8px !important; }

@media (max-width: 543px) {
  .hx_make-reply-from-action-buttons-small .form-actions button { padding: 3px 8px; font-size: 12px; line-height: 20px; }
  .hx_make-reply-from-action-buttons-small .form-actions button .octicon { vertical-align: text-top; }
}

@media (max-width: 543px) {
  .hx_remove-tab-side-borders-at-small-sizes .tabnav-tab:first-of-type { border-left: 0px; }
  .hx_remove-tab-side-borders-at-small-sizes .tabnav-tab:last-of-type { border-right: 0px; }
}

.hx_remove-border-bottom-on-last-post .review-comment:last-of-type { border-bottom: 0px !important; }

.hx_details-with-rotating-caret[open] > .btn-link .hx_dropdown-caret-rotatable { border-width: 0px 4px 4px; border-top-color: transparent; border-bottom-color: var(--color-accent-emphasis); }

.hx_disabled-input { margin-right: -4px !important; margin-left: -4px !important; }

.hx_disabled-input sidebar-memex-input[disabled]:not(.no-pointer) * { cursor: pointer; }

.hx_disabled-input sidebar-memex-input:not([disabled]) .Box-row--hover-gray { background-color: var(--color-canvas-subtle); }

.hx_disabled-input .Box-row--hover-gray svg.octicon-pencil { opacity: 0; visibility: hidden; }

.hx_disabled-input .Box-row--hover-gray:hover, .hx_disabled-input .Box-row--hover-gray:focus { padding-top: 8px !important; padding-bottom: 8px !important; }

.hx_disabled-input .Box-row--hover-gray:hover svg.octicon-pencil, .hx_disabled-input .Box-row--hover-gray:focus svg.octicon-pencil { opacity: 1; visibility: visible; }

.hx_disabled-input input:not(:disabled) { margin-top: 8px !important; margin-bottom: 8px !important; }

.hx_disabled-input input[disabled], .hx_disabled-input select[disabled], .hx_disabled-input .form-control[contenteditable="false"] { background: transparent; padding-right: 0px; padding-left: 0px; border: 0px; box-shadow: none; margin-right: 0px; opacity: 1; color: var(--color-fg-default)  !important; }

.hx_disabled-input text-expander input[type="text"][disabled] { display: none; }

.hx_disabled-input text-expander input[type="text"][disabled] + div.form-control { display: block; }

.hx_disabled-input text-expander input[type="text"] + div.form-control { display: none; }

.hx_disabled-input input[type="date"][disabled] { display: none; }

.hx_disabled-input input[type="date"][disabled] + div.form-control { display: block; }

.hx_disabled-input input[type="date"] + div.form-control { display: none; }

.hx_disabled-input input[disabled]::placeholder, .hx_disabled-input selected[disabled]::placeholder { color: var(--color-fg-default)  !important; }

.hx_disabled-input .form-select { background-image: none !important; }

.hx_disabled-input .Box-row--focus-gray:focus { background: var(--color-canvas-subtle); }

.summary-iteration .inline-status { display: none; }

.summary-iteration .block-status { display: inline-block; }

.list-iteration .inline-status { display: inline; }

.list-iteration .block-status { display: none; }

.hx_tabnav-in-dropdown { border-radius: 5px 5px 0px 0px; }

.hx_tabnav-in-dropdown .tabnav-tabs .hx_tabnav-in-dropdown-wrapper:first-child .tabnav-tab.selected, .hx_tabnav-in-dropdown .tabnav-tabs .hx_tabnav-in-dropdown-wrapper:first-child .tabnav-tab[aria-selected="true"], .hx_tabnav-in-dropdown .tabnav-tabs .hx_tabnav-in-dropdown-wrapper:first-child .tabnav-tab[aria-current]:not([aria-current="false"]) { border-left: 0px; }

.hx_tabnav-in-dropdown .tabnav-tabs .hx_tabnav-in-dropdown-wrapper:last-child .tabnav-tab.selected, .hx_tabnav-in-dropdown .tabnav-tabs .hx_tabnav-in-dropdown-wrapper:last-child .tabnav-tab[aria-selected="true"], .hx_tabnav-in-dropdown .tabnav-tabs .hx_tabnav-in-dropdown-wrapper:last-child .tabnav-tab[aria-current]:not([aria-current="false"]) { border-right: 0px; }

.hx_tabnav-in-dropdown .tabnav-tab.selected, .hx_tabnav-in-dropdown .tabnav-tab[aria-selected="true"], .hx_tabnav-in-dropdown .tabnav-tab[aria-current]:not([aria-current="false"]) { margin-top: -1px; background-color: var(--color-canvas-overlay); }

.hx_tabnav-in-dropdown #cloud-tab[aria-selected="false"]::after { content: ""; display: inline-block; position: absolute; left: auto; right: 10px; top: -14px; border-top: 7px solid transparent; border-right: 7px solid transparent; border-left: 7px solid transparent; border-image: initial; border-bottom: 7px solid var(--color-canvas-subtle); z-index: 10; }

.details-overlay-dark[open] > summary::before { z-index: 111 !important; }

.hx_tooltip { position: absolute; z-index: 1000000; padding: 0.5em 0.75em; font: 11px / 1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"; -webkit-font-smoothing: subpixel-antialiased; color: var(--color-fg-on-emphasis); text-align: center; text-decoration: none; text-shadow: none; text-transform: none; letter-spacing: normal; overflow-wrap: break-word; white-space: pre; background: var(--color-neutral-emphasis-plus); border-radius: 6px; opacity: 0; }

.hx_tooltip::before { position: absolute; z-index: 1000001; color: var(--color-neutral-emphasis-plus); content: ""; border: 6px solid transparent; opacity: 0; }

@keyframes tooltip-appear { 
  0% { opacity: 0; }
  100% { opacity: 1; }
}

.hx_tooltip::after { position: absolute; display: block; right: 0px; left: 0px; height: 12px; content: ""; }

.hx_tooltip-open, .hx_tooltip-open::before { animation-name: tooltip-appear; animation-duration: 0.1s; animation-fill-mode: forwards; animation-timing-function: ease-in; animation-delay: 0.4s; }

.hx_tooltip-s::before, .hx_tooltip-se::before, .hx_tooltip-sw::before { right: 50%; bottom: 100%; margin-right: -6px; border-bottom-color: var(--color-neutral-emphasis-plus); }

.hx_tooltip-s::after, .hx_tooltip-se::after, .hx_tooltip-sw::after { bottom: 100%; }

.hx_tooltip-n::before, .hx_tooltip-ne::before, .hx_tooltip-nw::before { top: 100%; right: 50%; margin-right: -6px; border-top-color: var(--color-neutral-emphasis-plus); }

.hx_tooltip-n::after, .hx_tooltip-ne::after, .hx_tooltip-nw::after { top: 100%; }

.hx_tooltip-se::before, .hx_tooltip-ne::before { right: auto; }

.hx_tooltip-sw::before, .hx_tooltip-nw::before { right: 0px; margin-right: 6px; }

.hx_tooltip-w::before { top: 50%; bottom: 50%; left: 100%; margin-top: -6px; border-left-color: var(--color-neutral-emphasis-plus); }

.hx_tooltip-e::before { top: 50%; right: 100%; bottom: 50%; margin-top: -6px; border-right-color: var(--color-neutral-emphasis-plus); }

@media screen and (max-width: 544px) {
  .hx_tooltip { max-width: 250px; overflow-wrap: break-word; white-space: normal; }
}
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://github.githubassets.com/assets/tab-size-fix-30224561f6d0a13e045c2e9a5b1e5682.css

@charset "utf-8";

.diff-table .blob-code.blob-code-inner { padding-left: 22px; }

.blob-code-marker::before { position: absolute; top: 1px; left: 8px; content: attr(data-code-marker); }

.blob-code-marker-addition::before { position: absolute; top: 1px; left: 8px; content: "+ "; }

.blob-code-marker-deletion::before { position: absolute; top: 1px; left: 8px; content: "- "; }

.blob-code-marker-context::before { position: absolute; top: 1px; left: 8px; content: "  "; }

.blob-code-context, .blob-code-addition, .blob-code-deletion { padding-left: 22px; }

.blob-code-inner.blob-code-addition, .blob-code-inner.blob-code-deletion { position: relative; padding-left: 22px !important; }

.soft-wrap .blob-code-context, .soft-wrap .blob-code-addition, .soft-wrap .blob-code-deletion { padding-left: 24px; text-indent: 0px; }

.soft-wrap .blob-code-marker-context::before, .soft-wrap .blob-code-marker-addition::before, .soft-wrap .blob-code-marker-deletion::before { top: 4px; }

.soft-wrap .add-line-comment { margin-top: 0px; margin-left: -24px; }

.add-line-comment { margin-left: -32px; }
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/css
Content-Transfer-Encoding: binary
Content-Location: https://github.githubassets.com/assets/github-25bf40139dbecd8ef14cfee484cd801e.css

@charset "utf-8";

:root { --border-width: 1px; --border-style: solid; --font-size-small: 12px; --font-weight-semibold: 500; --size-2: 20px; }

.min-height-full { min-height: 100vh !important; }

.marketing-section { position: relative; padding-top: 80px; padding-bottom: 80px; font-size: 16px; line-height: 1.5; text-align: center; border-bottom: 1px solid var(--color-border-default); }

.marketing-section::before { display: table; content: ""; }

.marketing-section::after { display: table; clear: both; content: ""; }

.marketing-section h3 { font-size: 21px; font-weight: 400; }

.marketing-hero-octicon { position: relative; width: 100px; height: 100px; margin: 0px auto 15px; text-align: center; border: solid 1px var(--color-border-default); border-radius: 50px; }

.marketing-hero-octicon .octicon { margin-top: 22px; color: var(--color-accent-fg); }

.marketing-hero-octicon .octicon-checklist { position: relative; right: -3px; }

.hanging-icon-list { list-style-type: none; }

.hanging-icon-list li { padding-left: 25px; margin: 10px 0px; font-size: 14px; }

.hanging-icon-list .octicon { float: left; margin-top: 3px; margin-left: -25px; color: var(--color-fg-muted); }

.hanging-icon-list .octicon-check { color: var(--color-success-fg); }

.hanging-icon-list .octicon-x { color: var(--color-danger-fg); }

.integrations-hero-octicon.marketing-hero-octicon { width: 75px; height: 75px; border-width: 5px; }

.integrations-hero-octicon.marketing-hero-octicon .octicon { margin-top: 15px; }

.marketing-blue-octicon { color: rgb(52, 172, 191); border-color: rgb(52, 172, 191); }

.marketing-blue-octicon .octicon { color: rgb(52, 172, 191); }

.marketing-turquoise-octicon { color: rgb(117, 187, 182); border-color: rgb(117, 187, 182); }

.marketing-turquoise-octicon .octicon { color: rgb(117, 187, 182); }

.marketing-purple-octicon { color: rgb(176, 134, 183); border-color: rgb(176, 134, 183); }

.marketing-purple-octicon .octicon { color: rgb(176, 134, 183); }

.marketing-graphic { position: relative; }

.intgrs-dir .marketing-graphic { padding-right: 0px; margin: 0px; }

.intgrs-dir .footer { margin-top: 40px; }

.intgrs-dir-section h2 { margin-top: 0px; margin-bottom: 20px; font-size: 26px; font-weight: 300; }

.intgrs-dir-intro { padding: 40px 0px; margin: 0px; text-align: left; background-image: linear-gradient(-110deg, rgb(72, 34, 125) 0%, rgb(47, 86, 156) 100%); border-bottom: 0px; }

.pagehead + .intgrs-dir-intro { margin-top: -20px; }

.intgrs-dir-intro .directory-header-back { margin-top: 10px; font-size: 18px; color: rgb(255, 255, 255); }

.intgrs-dir-intro .directory-header-back:hover { color: rgb(215, 222, 241); text-decoration: none; }

.intgrs-dir-intro .directory-header-back .octicon { vertical-align: middle; }

.intgrs-dir-intro .directory-header-back .header-link { color: var(--color-accent-fg); }

.intgrs-dir-intro .directory-tag-line { margin-bottom: 0px; font-size: 28px; font-weight: 400; color: rgb(255, 255, 255); }

.intgrs-dir-intro .lead { margin-top: 10px; margin-bottom: 6px; font-size: 18px; font-weight: 400; color: rgb(215, 222, 241); }

.intgrs-lstng-search { display: inline-block; width: 33%; margin-left: 20px; }

.intgrs-lstng-search .subnav-search-input { width: 100%; }

.intgrs-lstng-categories-container { display: inline-block; float: left; width: 20%; }

.intgrs-lstng-categories-container .intgrs-lstng-categories { top: 0px; }

.intgrs-lstng-categories-container .filter-item { padding: 6px 10px; margin-right: -10px; margin-left: -10px; }

.intgrs-lstng-container { display: inline-block; width: 80%; text-align: left; }

.intgrs-lstng-item { position: relative; display: inline-flex; width: 30.8%; font-size: 14px; border: 1px solid var(--color-border-muted); border-radius: 4px; transition: border-color 0.15s ease 0s, transform 0.15s ease 0s, box-shadow 0.15s ease 0s, color 0.15s ease 0s; }

.intgrs-lstng-item:hover { border-color: rgb(81, 167, 232); box-shadow: rgba(81, 167, 232, 0.5) 0px 0px 5px; transform: scale(1.05); }

.intgrs-lstng-item .intgrs-lstng-logo { display: block; margin: 0px auto 10px; }

.intgrs-lstng-item .draft-tag { position: absolute; top: -1px; left: 10px; }

.intgrs-lstng-item-link { display: block; width: 100%; height: 181px; padding-top: 20px; }

.intgrs-lstng-item-link:hover { text-decoration: none; }

.intgrs-lstng-item-link:hover .intgrs-lstng-item-header { color: var(--color-accent-fg); }

.intgrs-lstng-item-header { margin: 15px 10px 0px; font-size: 14px; font-weight: 600; color: var(--color-fg-default); }

.intgrs-lstng-item-description { position: relative; height: 2.8em; padding: 0px 10px; margin-top: 5px; overflow: hidden; font-size: 13px; color: var(--color-fg-muted); }

.intgrs-lstng-item-description::after { position: absolute; right: 0px; bottom: 0px; padding: 0px 15px 0px 20px; color: transparent; content: " "; background-image: linear-gradient(to right, rgba(255, 255, 255, 0), rgb(255, 255, 255) 80%); }

.intgr-admin-link { position: relative; display: inline-block; height: 25px; padding-left: 23px; font-size: 13px; vertical-align: middle; border: 1px solid var(--color-border-muted); border-radius: 6px; }

.intgr-admin-link.draft-tag { padding-left: 25px; border: 0px; }

.intgr-admin-link.draft-tag .octicon, .intgr-admin-link.draft-tag:hover .octicon { color: rgb(255, 255, 255); }

.intgr-admin-link.draft-tag:hover { text-decoration: none; background-color: rgb(0, 0, 0); }

.intgr-admin-link:hover .octicon { color: var(--color-accent-fg); }

.intgr-admin-link .octicon { position: absolute; top: 3px; left: 5px; color: var(--color-fg-muted); }

.intgr-feat-header { position: relative; width: 85%; padding: 0px 65px 10px; color: rgb(215, 222, 241); }

.intgr-feat-header .intgr-admin-link { border-color: rgba(215, 222, 241, 0.6); }

.intgr-feat-header .intgr-admin-link .octicon { color: rgb(215, 222, 241); }

.intgr-feat-header .intgr-admin-link:hover .octicon { color: rgb(255, 255, 255); }

.intgr-feat-header .marketing-hero-octicon { position: absolute; top: 0px; left: 5px; width: 50px; height: 50px; border-width: 3px; }

.intgr-feat-header .marketing-hero-octicon .octicon { margin-top: 11px; }

.intgr-feat-header h2 { margin: 0px; font-size: 25px; line-height: 50px; color: rgb(255, 255, 255); }

.intgr-feat-header p { max-width: 580px; margin: 0px; font-size: 18px; }

.integrations-breadcrumb { display: inline-block; font-weight: 400; color: var(--color-accent-fg); }

.integrations-breadcrumb-link { line-height: 0; color: rgb(215, 222, 241); }

.integrations-breadcrumb-link:hover { color: rgb(255, 255, 255); text-decoration: none; }

.integrations-auth-wrapper { width: 511px; margin: 60px auto; }

.integrations-auth-header { font-size: 20px; text-align: center; }

.integrations-permissions-group dt { font-size: 18px; font-weight: 400; }

.integrations-permissions-group .integrations-permission { position: relative; padding-left: 22px; margin-bottom: 10px; list-style-type: none; }

.integrations-permissions-group .integrations-permission .octicon { position: absolute; top: 1px; left: 0px; margin-right: 10px; }

.integrations-install-target .select-menu { vertical-align: middle; }

.integrations-install-target input[type="radio"] { margin-right: 10px; }

.integrations-install-target .flash { background-color: transparent; }

.integrations-install-target .flash-error { background-color: transparent; border: 0px; }

.integrations-install-target .octicon-lock, .integrations-install-target .octicon-repo { margin-right: 3px; }

.integrations-install-target .octicon-lock { color: var(--color-attention-fg); }

.integrations-install-target .private { background-color: rgb(255, 249, 234); }

.integrations-install-target [aria-selected="true"].private, .integrations-install-target .navigation-focus.private { background-color: rgb(64, 120, 192); }

.integrations-install-target [aria-selected="true"].octicon-lock, .integrations-install-target .navigation-focus .octicon-lock { color: inherit; }

.integrations-setup-note { margin: 10px 0px; }

.listgroup-item { line-height: inherit; }

.listgroup-item.disabled { background-color: var(--color-canvas-subtle); }

.listgroup-item.disabled .listgroup-item-title { color: var(--color-fg-default); }

.integration-key-management-wrapper .integration-key-downloading { display: none; }

.integration-key-management-wrapper .integration-key-list { display: none; }

.integration-key-management-wrapper .flash-error { display: none; }

.integration-key-management-wrapper .blankslate { margin-bottom: 30px; }

.integration-key-management-wrapper .action .deletable { display: none; }

.integration-key-management-wrapper .action .undeletable { display: block; }

.integration-key-management-wrapper.multi-keys .action .deletable { display: block; }

.integration-key-management-wrapper.multi-keys .action .undeletable { display: none; }

.integration-key-management-wrapper.error .flash-error { display: block; }

.integration-key-management-wrapper.error .integration-key { opacity: 0.5; }

.integration-key-management-wrapper.error .action .deletable { display: none; }

.integration-key-management-wrapper.error .action .undeletable { display: block; }

.integration-key-management-wrapper.downloading .blankslate { display: none; }

.integration-key-management-wrapper.downloading .integration-key-downloading { display: block; }

.integration-key-management-wrapper.downloading .integration-key-list { display: block; }

.integration-key-management-wrapper.has-keys .blankslate { display: none; }

.integration-key-management-wrapper.has-keys .integration-key-list { display: block; }

.link-small { color: var(--color-fg-muted); transition: color 500ms ease 0s; }

.listgroup-item:hover .link-small { color: var(--color-accent-fg); }

.manifest-errors { border-left: 6px solid var(--color-danger-emphasis); border-radius: 0px 6px 6px 0px; }

.sub-permissions-error { max-width: unset !important; }

.not-found-octocat-wrapper { width: 71px; height: 71px; border-radius: 45px; }

.not-found-octocat-wrapper::after { position: absolute; top: 58px; left: 45px; z-index: -2; display: block; width: 4px; height: 4px; vertical-align: baseline; content: ""; background: var(--color-canvas-default); border-radius: 4px; box-shadow: rgb(255, 255, 255) 0px 4px 0px, rgb(255, 255, 255) 0px 8px 0px, rgb(255, 255, 255) 0px 12px 0px, rgb(255, 255, 255) 0px 16px 0px, rgb(255, 255, 255) 0px 20px 0px; animation-name: pull-string; animation-duration: 0.75s; animation-fill-mode: forwards; animation-delay: 0.5s; }

@keyframes lightbulb { 
  0%, 8%, 14% { opacity: 0.1; }
  0%, 10%, 25% { opacity: 0.25; }
  5%, 30%, 50%, 70% { opacity: 0.5; }
  16%, 60%, 80% { opacity: 0.75; }
  90% { opacity: 0.8; }
  94% { opacity: 0.5; }
  100% { opacity: 1; }
}

.not-found-lightbulb-ani { z-index: 1; opacity: 0.25; animation-name: lightbulb; animation-duration: 2.5s; animation-fill-mode: forwards; animation-delay: 1.3s; }

@keyframes pull-string { 
  50% { transform: translate3d(0px, 12px, 0px); }
  75% { opacity: 1; transform: none; }
  100% { opacity: 0; }
}

.billing-plans tbody td { width: 25%; vertical-align: middle; }

.billing-plans .current { background-color: rgb(242, 255, 237); }

.billing-plans .name { font-size: 14px; font-weight: 600; color: var(--color-fg-default); }

.billing-plans .coupon { font-size: 12px; }

.billing-plans .coupon td { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); }

.billing-plans .coupon .text-right { white-space: nowrap; }

.billing-plans .coupon.expiring td { background-color: rgb(223, 110, 0); }

.billing-plans .coupon.expiring .coupon-label::after { border-bottom-color: rgb(223, 110, 0); }

.billing-plans tbody > .selected { background-color: rgb(253, 255, 206); }

.coupon-label { position: relative; padding: 9px; margin: -9px; }

.coupon-label::after { position: absolute; bottom: 100%; left: 15px; width: 0px; height: 0px; pointer-events: none; content: " "; border-style: solid; border-top-color: transparent; border-right-color: transparent; border-left-color: transparent; border-image: initial; border-width: 5px; border-bottom-color: var(--color-success-emphasis); }

.boxed-group-table .toggle-currency { font-size: 11px; font-weight: 400; }

.has-removed-contents { display: none; }

.currency-notice { margin-bottom: 10px; }

.org-login { margin-top: -30px; margin-bottom: 30px; }

.org-login img { width: 450px; padding: 1px; margin: 10px -25px; border: 1px solid var(--color-border-default); }

.plan-notice { padding: 10px; margin-bottom: 0px; border-top: 1px solid var(--color-border-muted); }

.workflow-dispatch .loading-overlay { display: none !important; }

.workflow-dispatch .is-loading .loading-overlay { display: flex !important; }

.workflow-dispatch .is-loading .branch-selection { display: none; }

.member-list-item .member-username { display: inline; }

.member-list-item .member-link { display: inline; }

.actor-and-action { font-weight: 600; }

.vertical-separator { margin-right: 8px; margin-left: 5px; border-left: 1px solid var(--color-border-default); }

.audit-log-search .audit-search-form { margin-bottom: 10px; }

.audit-log-search .audit-results-actions { margin: 15px 0px; }

.audit-log-search .audit-search-clear { margin-bottom: 0px; }

.billing-addon-items table input { width: 5em; }

.billing-addon-items td { vertical-align: middle; border-bottom: 0px; }

.billing-addon-items td.fixed { width: 150px; }

.billing-addon-items td.black { color: var(--color-fg-default); }

.billing-addon-items tr { border-bottom: 1px solid var(--color-border-muted); }

.billing-addon-items tr:last-child { border-bottom-width: 0px; }

.billing-addon-items tr:nth-child(2n) { background-color: var(--color-canvas-subtle); }

.billing-addon-items tr.total-row { color: var(--color-danger-fg); background-color: var(--color-canvas-default); }

.billing-addon-items .new-addon-items { margin-left: 5px; }

.billing-addon-items .addon-cost { color: var(--color-fg-muted); }

.billing-addon-items .discounted-original-price { color: var(--color-fg-muted); }

.billing-addon-items .form-submit, .billing-addon-items .payment-method { margin-left: 8px; }

.billing-addon-items .payment-summary { margin-right: 8px; margin-left: 8px; }

.billing-credit-card .javascript-disabled-overlay { position: absolute; top: 0px; left: 0px; z-index: 1; display: none; width: 100%; height: 100%; background-color: var(--color-canvas-default); opacity: 0.5; }

.billing-credit-card.disabled .javascript-disabled-overlay { display: block; }

.billing-extra-box { padding-left: 10px; margin: 10px 0px; border-left: 6px solid var(--color-border-muted); }

.billing-vat-box { padding-left: 10px; margin: 10px 0px; border-left: 6px solid var(--color-border-muted); }

.billing-section .action-button { float: right; margin-bottom: 5px; margin-left: 10px; }

.billing-section .section-label { position: absolute; width: 85px; font-weight: 400; color: var(--color-fg-muted); text-align: right; }

.billing-section .section-content { margin-left: 100px; color: var(--color-fg-default); }

.billing-section:last-child { border-bottom: 0px; }

.billing-section .usage-bar { max-width: 304px; }

.usage-bar { width: 100%; margin: 5px 0px 0px; background: rgb(238, 238, 238); border-radius: 20px; }

.usage-bar.exceeded .progress { background-color: var(--color-danger-emphasis)  !important; }

.usage-bar .progress { position: relative; max-width: 100%; height: 5px; background-color: var(--color-success-emphasis); border-radius: 20px; transition: width 0.3s ease 0s; }

.usage-bar .progress.no-highlight { background: var(--color-neutral-muted); }

.usage-bar .progress--orange { background-color: var(--color-severe-emphasis); }

.usage-bar .progress--purple { background-color: var(--color-done-emphasis); }

.lfs-data-pack-field { margin: -6px 0px; }

.packs-table .desc { width: 1%; white-space: nowrap; }

.lfs-data-icon { color: var(--color-fg-muted); text-align: center; }

.lfs-data-icon.dark { color: var(--color-fg-default); }

.lfs-data-icon.octicon-database { margin-right: 3px; margin-left: 2px; }

.setup-wrapper .paypal-container { margin-bottom: 30px; }

.setup-wrapper .paypal-logged-in .paypal-container { margin-bottom: 10px; }

.payment-methods { position: relative; }

.payment-methods .selected-payment-method { display: none; }

.payment-methods .selected-payment-method::before { display: table; content: ""; }

.payment-methods .selected-payment-method::after { display: table; clear: both; content: ""; }

.payment-methods .selected-payment-method.active { display: block; }

.payment-methods .form-group dd .form-control.short.input-vat { width: 300px; }

.payment-methods .pay-with-header { margin: 5px 0px; }

.payment-methods .pay-with-paypal .setup-creditcard-form, .payment-methods .pay-with-paypal .paypal-form-actions, .payment-methods .pay-with-paypal .terms, .payment-methods .pay-with-paypal .paypal-signed-in, .payment-methods .pay-with-paypal .paypal-down-flash, .payment-methods .pay-with-paypal .loading-paypal-spinner { display: none; }

.payment-methods.paypal-loading .loading-paypal-spinner { display: block; }

.payment-methods.paypal-down .paypal-down-flash { display: block; }

.payment-methods.paypal-logged-in .paypal-sign-in { display: none; }

.payment-methods.paypal-logged-in .setup-creditcard-form, .payment-methods.paypal-logged-in .paypal-form-actions, .payment-methods.paypal-logged-in .terms, .payment-methods.paypal-logged-in .paypal-signed-in { display: block; }

.payment-methods.has-paypal-account .paypal-sign-in { display: none; }

.payment-methods.has-paypal-account .paypal-signed-in { display: block; }

.paypal-label { margin: 15px 0px 10px; font-weight: 600; }

.paypal-container { display: inline-block; margin-bottom: 15px; vertical-align: top; background-color: var(--color-canvas-subtle); border-radius: 4px; }

.braintree-paypal-loggedin { border-radius: 4px; padding: 11px 16px !important; background-position: 12px 50% !important; border: 1px solid var(--color-border-muted)  !important; }

.bt-pp-name { margin-left: 20px !important; }

.bt-pp-email { margin-left: 15px !important; }

.bt-pp-cancel { font-size: 0px !important; line-height: 1 !important; color: var(--color-danger-fg)  !important; text-decoration: none !important; }

.payment-history .id, .payment-history .date, .payment-history .receipt, .payment-history .status, .payment-history .amount { white-space: nowrap; }

.payment-history .break-all { word-break: break-all; }

.payment-history .receipt { text-align: center; }

.payment-history .currency, .payment-history .status { color: var(--color-fg-muted); }

.payment-history .status-icon { width: 14px; text-align: center; }

.payment-history .succeeded .status { color: var(--color-success-fg); }

.payment-history .refunded, .payment-history .failed { background: var(--color-canvas-subtle); }

.payment-history .refunded td, .payment-history .failed td { opacity: 0.5; }

.payment-history .refunded .receipt, .payment-history .refunded .status, .payment-history .failed .receipt, .payment-history .failed .status { opacity: 1; }

.payment-history .refunded .status { color: var(--color-fg-muted); }

.payment-history .failed .status { color: var(--color-danger-fg); }

.paypal-icon { margin: 0px 2px 0px 1px; vertical-align: middle; }

.boxed-group .boxed-group-content { margin: 10px; }

.currency-container .local-currency, .currency-container .local-currency-block { display: none; }

.currency-container.open .local-currency { display: inline; }

.currency-container.open .local-currency-block { display: block; }

.currency-container.open .default-currency { display: none; }

.strong-label { display: inline-block; margin-bottom: 5px; font-weight: 600; }

.discounted-original-price { font-weight: 400; color: var(--color-fg-muted); text-decoration: line-through; }

.billing-manager-input { width: 500px; }

.billing-manager-banner { padding: 30px 20px; margin-bottom: 30px; overflow: hidden; background: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-muted); }

.billing-manager-banner .container { position: relative; }

.billing-manager-banner-text { margin-left: 210px; font-size: 14px; color: var(--color-fg-muted); }

.billing-manager-banner-text .btn { margin-top: 8px; margin-right: 8px; }

.billing-manager-banner-title { font-size: 12px; font-weight: 600; color: var(--color-fg-muted); }

.billing-manager-icon { position: absolute; top: -35px; left: 0px; width: 180px; height: 180px; font-size: 180px; color: var(--color-fg-muted); }

.seats-change-arrow { margin: 0px 10px; }

.plan-choice { position: relative; display: block; padding: 16px 16px 16px 40px; font-weight: 400; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); }

.plan-choice.open, .plan-choice.selected { background-color: var(--color-canvas-default); }

.plan-choice--experiment { cursor: pointer; transition: transform 0.3s ease 0s, box-shadow 0.3s ease 0s, border-color 0.3s ease 0s; }

.plan-choice--experiment.open, .plan-choice--experiment.selected { border-color: var(--color-border-default); box-shadow: var(--color-shadow-large); transform: scale(1.025); }

.plan-choice--experiment.open .plan-choice-icon, .plan-choice--experiment.selected .plan-choice-icon { background-color: var(--color-success-emphasis); box-shadow: var(--color-shadow-small); }

.plan-choice--experiment.open .plan-choice-icon .octicon, .plan-choice--experiment.selected .plan-choice-icon .octicon { transform: scale(1); }

.plan-choice--experiment.plan-choice--green.open, .plan-choice--experiment.plan-choice--green.selected { border-color: var(--color-success-emphasis); }

.plan-choice--experiment.plan-choice--green.open .plan-choice-icon, .plan-choice--experiment.plan-choice--green.selected .plan-choice-icon { background-color: var(--color-success-emphasis); }

.plan-choice--experiment.plan-choice--purple.open, .plan-choice--experiment.plan-choice--purple.selected { border-color: var(--color-done-emphasis); }

.plan-choice--experiment.plan-choice--purple.open .plan-choice-icon, .plan-choice--experiment.plan-choice--purple.selected .plan-choice-icon { background-color: var(--color-done-fg); }

.plan-choice-icon { transition: box-shadow 0.3s ease 0s; }

.plan-choice-icon .octicon { transition: transform 0.2s ease 0s; transform: scale(0.5); }

.plan-choice-radio { position: absolute; top: 18px; left: 15px; }

.plan-choice-exp { margin-top: 5px; font-size: 12px; color: var(--color-fg-muted); }

.seat-field { width: 50px; margin-right: 5px; }

.billing-line-items { margin-top: 10px; }

.billing-line-item { padding: 10px 0px; font-size: 12px; list-style: none; border-top: 1px solid var(--color-border-default); }

.billing-line-item::before { display: table; content: ""; }

.billing-line-item::after { display: table; clear: both; content: ""; }

.billing-line-item-last { font-weight: 600; border-top-width: 3px; }

.line-item-value { float: right; }

.condensed-payment-methods .vat-field { width: 100%; }

.condensed-payment-methods .state-field { width: 30%; }

.condensed-payment-methods .postcode-field { width: 28%; }

.condensed-payment-methods .country-field { width: 42%; }

.condensed-payment-methods .is-international .country-field { width: 72%; }

.condensed-payment-methods .is-international.no-postcodes .country-field { width: 100%; }

.zuora-billing-section.PaymentMethod--creditcard:not(.has-removed-contents) ~ .SignUpContinueActions { display: none; }

.zuora-billing-section.PaymentMethod--creditcard-added ~ .SignUpContinueActions { display: block; }

.zuora-billing-section.PaymentMethod--paypal ~ .SignUpContinueActions { display: block; }

.new-org-billing-form .z_hppm_iframe { width: 100% !important; }

.billing-tooltip-underline { cursor: help; border-bottom: 1px dotted; }

.billing-box-accordion[open] .octicon-chevron-right { height: auto; transform: rotate(90deg); }

.billing-box-accordion:hover .billing-box-accordion-state .octicon { color: var(--color-fg-muted); }

.billing-box-accordion-chevron[open] .octicon-chevron-right { height: auto; transform: rotate(90deg); }

.billing-box-accordion-state .octicon { color: var(--color-fg-muted); transition: transform 0.09s ease-out 0s; }

.billing-box-progress { padding-top: 1px; margin-bottom: 6px; }

.Details-element:focus { outline: none; }

.organization-radio-button-budget-disabled { color: var(--color-fg-muted); background-color: var(--color-canvas-subtle); }

.organization-radio-button-budget-disabled label p { color: var(--color-fg-muted)  !important; }

.required-asterisked::after { color: var(--color-danger-fg); content: " *"; }

.blame-commit { user-select: none; }

.blame-commit[data-heat="1"] { border-right: 2px solid rgb(246, 106, 10); }

.blame-commit[data-heat="2"] { border-right: 2px solid rgba(246, 106, 10, 0.9); }

.blame-commit[data-heat="3"] { border-right: 2px solid rgba(246, 106, 10, 0.8); }

.blame-commit[data-heat="4"] { border-right: 2px solid rgba(246, 106, 10, 0.7); }

.blame-commit[data-heat="5"] { border-right: 2px solid rgba(246, 106, 10, 0.6); }

.blame-commit[data-heat="6"] { border-right: 2px solid rgba(246, 106, 10, 0.5); }

.blame-commit[data-heat="7"] { border-right: 2px solid rgba(246, 106, 10, 0.4); }

.blame-commit[data-heat="8"] { border-right: 2px solid rgba(246, 106, 10, 0.3); }

.blame-commit[data-heat="9"] { border-right: 2px solid rgba(246, 106, 10, 0.2); }

.blame-commit[data-heat="10"] { border-right: 2px solid rgba(246, 106, 10, 0.1); }

.heat[data-heat="1"] { background: rgb(246, 106, 10); }

.heat[data-heat="2"] { background: rgba(246, 106, 10, 0.9); }

.heat[data-heat="3"] { background: rgba(246, 106, 10, 0.8); }

.heat[data-heat="4"] { background: rgba(246, 106, 10, 0.7); }

.heat[data-heat="5"] { background: rgba(246, 106, 10, 0.6); }

.heat[data-heat="6"] { background: rgba(246, 106, 10, 0.5); }

.heat[data-heat="7"] { background: rgba(246, 106, 10, 0.4); }

.heat[data-heat="8"] { background: rgba(246, 106, 10, 0.3); }

.heat[data-heat="9"] { background: rgba(246, 106, 10, 0.2); }

.heat[data-heat="10"] { background: rgba(246, 106, 10, 0.1); }

.blame-commit-date { font-size: 11px; line-height: 25px; flex-shrink: 0; }

.blame-commit-date[data-heat="1"] { color: rgb(194, 78, 0); }

.blame-commit-date[data-heat="2"] { color: rgb(172, 87, 31); }

.blame-commit-date[data-heat="3"] { color: rgb(163, 91, 44); }

.blame-commit-date[data-heat="4"] { color: rgb(154, 95, 56); }

.blame-commit-date[data-heat="5"] { color: rgb(146, 98, 69); }

.blame-commit-date[data-heat="6"] { color: rgb(137, 102, 81); }

.blame-commit-date[data-heat="7"] { color: rgb(128, 106, 94); }

.blame-commit-date[data-heat="8"] { color: rgb(119, 109, 106); }

.blame-commit-date[data-heat="9"] { color: rgb(110, 113, 119); }

.blame-commit-date[data-heat="10"] { color: rgb(106, 115, 125); }

.line-age-legend .heat { width: 2px; height: 10px; margin: 2px 1px 0px; }

.blame-breadcrumb .css-truncate-target { max-width: 680px; }

.blame-commit-info { width: 450px; height: 26px; }

.blame-commit-content { flex-grow: 2; overflow: hidden; }

.blame-commit-message { text-overflow: ellipsis; }

.blame-commit-message .message.blank { color: var(--color-fg-muted); }

.blob-reblame { min-width: 24px; user-select: none; }

.reblame-link { padding-top: 2px; color: var(--color-fg-muted); opacity: 0.3; }

.blame-hunk g-emoji { font-size: 14px !important; }

.blame-hunk:hover .reblame-link { opacity: 1; }

.blame-container .blame-blob-num, .blame-container .blob-code-inner { padding-top: 3px; padding-bottom: 3px; }

.blame-container .blob-code-inner { flex-grow: 1; }

.editor-abort { display: inline; font-size: 14px; }

.blob-interaction-bar { position: relative; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-default); }

.blob-interaction-bar::before { display: table; content: ""; }

.blob-interaction-bar::after { display: table; clear: both; content: ""; }

.blob-interaction-bar .octicon-search { position: absolute; top: 6px; left: 10px; font-size: 12px; color: var(--color-fg-muted); }

.blob-filter { width: 100%; padding: 4px 20px 5px 30px; font-size: 12px; border: 0px; border-radius: 0px; outline: none; }

.blob-filter:focus { outline: none; }

.html-blob { margin-bottom: 15px; }

.TagsearchPopover { width: inherit; max-width: 600px; }

.TagsearchPopover-content { max-height: 300px; }

.TagsearchPopover-list .TagsearchPopover-list-item:hover { background-color: var(--color-canvas-subtle); }

.TagsearchPopover-list .TagsearchPopover-list-item .TagsearchPopover-item:hover { text-decoration: none; }

.TagsearchPopover-list .blob-code-inner { white-space: pre-wrap; }

.blob-code-content .bidi-line-alert { position: absolute; left: 0px; margin: -2px 2px; }

.csv-data .bidi-line-alert { position: absolute; margin: 2px 4px; }

.linejump .linejump-input { width: 340px; background-color: var(--color-canvas-subtle); }

.linejump .linejump-input, .linejump .btn { padding: 10px 15px; font-size: 16px; }

.CopyBlock { line-height: 20px; cursor: pointer; }

.CopyBlock .octicon-copy { display: none; }

.CopyBlock:hover, .CopyBlock:focus, .CopyBlock:active { background-color: var(--color-canvas-default); outline: none; }

.CopyBlock:hover .octicon-copy, .CopyBlock:focus .octicon-copy, .CopyBlock:active .octicon-copy { display: inline-block; }

.blob-header.is-stuck { border-top: 0px; border-top-left-radius: 0px; border-top-right-radius: 0px; }

.commit-form-avatar { margin-left: -64px; }

.file-commit-form { padding-left: 64px; }

.file-commit-form--full { position: absolute; bottom: 0px; left: 0px; z-index: 10; width: 100%; padding-top: 16px; padding-left: 0px; margin-top: 16px; margin-bottom: 16px; background: var(--color-canvas-default); }

@media (min-width: 1012px) {
  .file-commit-form--full { inset: 0px 0px auto auto; width: auto; margin-top: 0px; margin-bottom: 0px; }
}

.file-commit-form--full .commit-form { padding: 0px; margin-bottom: 24px; border: 0px; }

.file-commit-form--full .commit-form::before { display: none; }

.file-commit-form-dropdown { position: fixed; top: 0px; left: 0px; width: 100%; height: 100%; }

.file-commit-form-dropdown::after { display: none; }

@media (min-width: 1012px) {
  .file-commit-form-dropdown { position: absolute; top: auto; left: auto; width: 420px; height: auto; }
  .file-commit-form-dropdown::after { display: inline-block; }
}

.commit-form::after, .commit-form::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.commit-form::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.commit-form::before { background-color: var(--color-border-default); }

.quick-pull-new-branch-icon { top: 9px; left: 10px; }

.code-formatting-menu { width: 260px; }

.file-test-workflow-dropdown { top: 6px; width: 378px; max-width: 378px !important; }

.CodeMirror-hints { position: absolute; z-index: 10; max-height: 20em; margin: 0px; overflow-y: auto; font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, monospace; font-size: 12px; list-style: none; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; box-shadow: var(--color-shadow-medium); }

.CodeMirror-hint { padding: 2px 8px; margin: 0px; color: var(--color-fg-default); white-space: pre; cursor: pointer; }

.CodeMirror-hint .CodeMirror-hint:first-child { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.CodeMirror-hint .CodeMirror-hint:last-child { border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.CodeMirror-hint-active { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.CodeMirror-lint-tooltip { position: fixed; z-index: 100; min-width: 300px; max-width: 600px; opacity: 0; transition: opacity 0.4s ease 0s; }

.CodeMirror-lint-mark-error { position: relative; cursor: help; }

.CodeMirror-lint-mark-error::before { position: absolute; top: 90%; width: 100%; height: 0.25em; content: ""; background-image: ; background-position-x: ; background-position-y: ; background-attachment: ; background-origin: ; background-clip: ; background-color: ; background-repeat: repeat-x, repeat-x; background-size: 0.5em 0.5em; }

.CodeMirror-lint-mark-warning { position: relative; cursor: help; }

.CodeMirror-lint-mark-warning::before { position: absolute; top: 90%; width: 100%; height: 0.25em; content: ""; background-image: ; background-position-x: ; background-position-y: ; background-attachment: ; background-origin: ; background-clip: ; background-color: ; background-repeat: repeat-x, repeat-x; background-size: 0.5em 0.5em; }

.CodeMirror-lint-mark-info { position: relative; cursor: help; }

.CodeMirror-lint-mark-info::before { position: absolute; top: 90%; width: 100%; height: 0.25em; content: ""; background-image: ; background-position-x: ; background-position-y: ; background-attachment: ; background-origin: ; background-clip: ; background-color: ; background-repeat: repeat-x, repeat-x; background-size: 0.5em 0.5em; }

.CodeMirror-hint-active .CodeMirror-hint-description { color: var(--color-fg-on-emphasis)  !important; }

.merge-pr { padding-top: 10px; margin: 20px 0px 0px; border-top: 1px solid var(--color-border-default); }

.merge-pr.open .merge-branch-form { display: block; }

.merge-pr.open .branch-action { display: none; }

.merge-pr.is-merging-jump.open .merge-branch-form, .merge-pr.is-merging-group.open .merge-branch-form, .merge-pr.is-merging-solo.open .merge-branch-form { display: none; }

.merge-pr.is-merging-jump.open .queue-branch-form, .merge-pr.is-merging-group.open .queue-branch-form, .merge-pr.is-merging-solo.open .queue-branch-form { display: block; }

.status-heading { margin-bottom: 1px; }

.merge-status-list { max-height: 0px; padding: 0px; margin: 15px -15px -16px -55px; overflow-y: auto; border-top-color: ; border-top-style: ; border-right-color: ; border-right-style: ; border-bottom-color: ; border-bottom-style: ; border-left-color: ; border-left-style: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-width: 1px 0px 0px; transition: max-height 0.25s ease-in-out 0s; }

.statuses-toggle-opened { display: none; }

.merge-status-item { position: relative; padding: 10px 15px; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-default); }

.merge-status-item:last-child:not(.review-item) { border-bottom: 0px; }

.merge-status-item .css-truncate-target { max-width: 100%; }

.merge-status-item .dismiss-review-form { display: none; }

.merge-status-item.open .review-status-item { display: none !important; }

.merge-status-item.open .dismiss-review-form { display: block; }

.status-meta { color: var(--color-fg-muted); }

.status-meta-file-name { padding: 0.2em 0.4em; margin: 0px; font-size: 85%; background-color: rgba(27, 31, 35, 0.05); border-radius: 6px; }

.status-actions { margin-left: auto; }

.branch-action-item-icon { float: left; margin-left: -40px; }

.merge-status-icon { min-width: 30px; margin-right: 12px; }

.branch-action { padding-left: 55px; margin-top: 16px; margin-bottom: 16px; }

.branch-action .merge-branch-heading { margin-bottom: 4px; }

.branch-action-icon { float: left; width: 40px; height: 40px; margin-left: -55px; color: var(--color-fg-on-emphasis); border-radius: 6px; }

.branch-action-body { position: relative; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.branch-action-body .spinner { display: block; float: left; width: 32px; height: 32px; margin-right: 15px; background: url("/images/spinners/octocat-spinner-32.gif") no-repeat; }

.branch-action-body .merge-message, .branch-action-body .merge-branch-form, .branch-action-body .queue-branch-form { padding: 16px; background-color: var(--color-canvas-subtle); border-top: 1px solid var(--color-border-default); border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.post-merge-message { padding: 16px; }

.branch-action-item { padding: 15px 15px 15px 55px; font-size: 13px; line-height: 1.4; }

.branch-action-item + .branch-action-item, .branch-action-item + .mergeability-details { border-top: 1px solid var(--color-border-default); }

.branch-action-item.open > .merge-status-list-wrapper > .merge-status-list, .branch-action-item.open > .merge-status-list { max-height: 231px; margin-bottom: -15px; }

.branch-action-item.open .statuses-toggle-opened { display: inline; }

.branch-action-item.open .statuses-toggle-closed { display: none; }

.branch-action-btn { margin-left: 15px; }

.branch-action-item-simple { padding-left: 15px; }

.branch-action-item-simple .merge-status-list { margin-left: -15px; }

.branch-action-item-simple .merge-status-item { padding-left: 12px; }

.branch-action-state-clean .branch-action-icon { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); border: 1px solid transparent; }

.branch-action-state-clean .branch-action-body { border-color: var(--color-success-emphasis); }

.branch-action-state-clean .branch-action-body::after, .branch-action-state-clean .branch-action-body::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.branch-action-state-clean .branch-action-body::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.branch-action-state-clean .branch-action-body::before { background-color: var(--color-success-emphasis); }

.branch-action-state-unknown .branch-action-icon, .branch-action-state-unstable .branch-action-icon { color: var(--color-fg-on-emphasis); background-color: var(--color-attention-emphasis); border: 1px solid transparent; }

.branch-action-state-unknown .branch-action-body, .branch-action-state-unstable .branch-action-body { border-color: var(--color-attention-emphasis); }

.branch-action-state-unknown .branch-action-body::after, .branch-action-state-unknown .branch-action-body::before, .branch-action-state-unstable .branch-action-body::after, .branch-action-state-unstable .branch-action-body::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.branch-action-state-unknown .branch-action-body::after, .branch-action-state-unstable .branch-action-body::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.branch-action-state-unknown .branch-action-body::before, .branch-action-state-unstable .branch-action-body::before { background-color: var(--color-attention-emphasis); }

.branch-action-state-merged .branch-action-icon { color: var(--color-fg-on-emphasis); background-color: var(--color-done-emphasis); border: 1px solid transparent; }

.branch-action-state-merged .branch-action-body { border-color: var(--color-done-emphasis); }

.branch-action-state-merged .branch-action-body::after, .branch-action-state-merged .branch-action-body::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.branch-action-state-merged .branch-action-body::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.branch-action-state-merged .branch-action-body::before { background-color: var(--color-done-emphasis); }

.branch-action-state-dirty .branch-action-icon, .branch-action-state-closed-dirty .branch-action-icon, .is-rebasing .branch-action-state-dirty-if-rebasing .branch-action-icon { color: var(--color-fg-on-emphasis); background-color: var(--color-neutral-emphasis); border: 1px solid transparent; }

.branch-action-state-dirty .branch-action-body, .branch-action-state-closed-dirty .branch-action-body, .is-rebasing .branch-action-state-dirty-if-rebasing .branch-action-body { border-color: var(--color-border-default); }

.branch-action-state-dirty .branch-action-body::after, .branch-action-state-dirty .branch-action-body::before, .branch-action-state-closed-dirty .branch-action-body::after, .branch-action-state-closed-dirty .branch-action-body::before, .is-rebasing .branch-action-state-dirty-if-rebasing .branch-action-body::after, .is-rebasing .branch-action-state-dirty-if-rebasing .branch-action-body::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.branch-action-state-dirty .branch-action-body::after, .branch-action-state-closed-dirty .branch-action-body::after, .is-rebasing .branch-action-state-dirty-if-rebasing .branch-action-body::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.branch-action-state-dirty .branch-action-body::before, .branch-action-state-closed-dirty .branch-action-body::before, .is-rebasing .branch-action-state-dirty-if-rebasing .branch-action-body::before { background-color: var(--color-border-default); }

.branch-action-state-error .branch-action-icon, .is-merging .branch-action-state-error-if-merging .branch-action-icon { color: var(--color-fg-on-emphasis); background-color: var(--color-danger-emphasis); border: 1px solid transparent; }

.branch-action-state-error .branch-action-body, .is-merging .branch-action-state-error-if-merging .branch-action-body { border-color: var(--color-danger-emphasis); }

.branch-action-state-error .branch-action-body::after, .branch-action-state-error .branch-action-body::before, .is-merging .branch-action-state-error-if-merging .branch-action-body::after, .is-merging .branch-action-state-error-if-merging .branch-action-body::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.branch-action-state-error .branch-action-body::after, .is-merging .branch-action-state-error-if-merging .branch-action-body::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.branch-action-state-error .branch-action-body::before, .is-merging .branch-action-state-error-if-merging .branch-action-body::before { background-color: var(--color-danger-emphasis); }

.enqueued-pull-request .branch-action-body::after, .enqueued-pull-request .branch-action-body::before { position: absolute; top: 11px; right: 100%; left: -8px; display: block; width: 8px; height: 16px; pointer-events: none; content: " "; clip-path: polygon(0px 50%, 100% 0px, 100% 100%); }

.enqueued-pull-request .branch-action-body::after { margin-left: 1px; background-color: var(--color-canvas-default); background-image: linear-gradient(var(--color-canvas-default), var(--color-canvas-default)); }

.enqueued-pull-request .branch-action-body::before { background-color: var(--color-attention-emphasis); }

@media only screen and (-webkit-min-device-pixel-ratio: 2), not all, not all, not all, only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
  .branch-action-body .spinner { background-image: url("/images/spinners/octocat-spinner-64.gif"); background-size: 32px 32px; }
}

.merge-branch-form, .queue-branch-form { display: none; margin: 15px 0px; }

.merge-branch-form .commit-form, .queue-branch-form .commit-form { border-color: var(--color-success-emphasis); }

.merge-branch-form .commit-form::before, .queue-branch-form .commit-form::before { display: none; }

@media (min-width: 768px) {
  .merge-branch-form .commit-form::before, .queue-branch-form .commit-form::before { display: block; border-right-color: var(--color-border-default); }
}

.merge-branch-form .commit-form::after, .queue-branch-form .commit-form::after { display: none; }

@media (min-width: 768px) {
  .merge-branch-form .commit-form::after, .queue-branch-form .commit-form::after { display: block; }
}

.merge-branch-form.error .commit-form, .merge-branch-form.danger .commit-form, .queue-branch-form.error .commit-form, .queue-branch-form.danger .commit-form { border-color: var(--color-danger-emphasis); }

.merge-branch-form.error .commit-form::before, .merge-branch-form.danger .commit-form::before, .queue-branch-form.error .commit-form::before, .queue-branch-form.danger .commit-form::before { border-right-color: var(--color-danger-emphasis); }

.merge-button-matrix-merge-form .merge-branch-form { display: block; }

.completeness-indicator { width: 30px; height: 30px; text-align: center; }

.completeness-indicator .octicon { display: block; margin-top: 6px; margin-right: auto; margin-left: auto; }

.completeness-indicator .octicon-alert { margin-top: 6px; }

.completeness-indicator-success { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); border: 1px solid transparent; border-radius: 50%; }

.completeness-indicator-error { color: var(--color-fg-on-emphasis); background-color: var(--color-danger-emphasis); border: 1px solid transparent; border-radius: 50%; }

.completeness-indicator-problem { color: var(--color-fg-on-emphasis); background-color: var(--color-neutral-emphasis); border: 1px solid transparent; border-radius: 50%; }

.completeness-indicator-warning { color: var(--color-fg-on-emphasis); background-color: var(--color-attention-emphasis); border: 1px solid transparent; border-radius: 50%; }

.pull-merging .pull-merging-error { display: none; }

.pull-merging.is-error .pull-merging-error { display: block; }

.pull-merging.is-error .merge-pr { display: none; }

.RecentBranches { background-color: var(--color-attention-subtle); border: 1px solid var(--color-attention-emphasis); border-radius: 6px; }

.RecentBranches-item { line-height: 28px; color: var(--color-fg-default); }

.RecentBranches-item + .RecentBranches-item { border-top: 1px solid var(--color-attention-emphasis); }

.RecentBranches-item-link { color: var(--color-fg-default); }

.RecentBranches-item-link.css-truncate-target { max-width: 400px; }

.range-editor { position: relative; padding: 5px 15px 5px 40px; margin-top: 15px; margin-bottom: 15px; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); border-radius: 6px; }

.range-editor .dots { font-size: 16px; }

.range-editor .select-menu { position: relative; display: inline-block; }

.range-editor .select-menu.fork-suggester { display: none; }

.range-editor .branch-name { line-height: 22px; }

.range-editor .branch .css-truncate-target, .range-editor .fork-suggester .css-truncate-target { max-width: 180px; }

.range-editor .pre-mergability { display: inline-block; padding: 5px; line-height: 26px; vertical-align: middle; }

.range-editor .pre-mergability .octicon { vertical-align: text-bottom; }

.range-editor.is-cross-repo .select-menu.fork-suggester { display: inline-block; }

.range-editor-icon { float: left; margin-top: 10px; margin-left: -25px; color: var(--color-fg-muted); }

.compare-pr-header { display: none; }

.is-pr-composer-expanded .compare-show-header { display: none; }

.is-pr-composer-expanded .compare-pr-header { display: block; }

.range-cross-repo-pair { display: inline-block; padding: 5px; white-space: nowrap; }

.branches .clear-search { display: none; }

.branches .loading-overlay { position: absolute; top: 0px; z-index: 20; display: none; width: 100%; height: 100%; padding-top: 50px; text-align: center; }

.branches .loading-overlay::before { position: absolute; inset: 0px; content: ""; background-color: var(--color-canvas-default); opacity: 0.7; }

.branches .loading-overlay .spinner { display: inline-block; }

.branches.is-loading .loading-overlay { display: block; }

.branches.is-search-mode .clear-search { display: inline-block; }

.branch-a-b-count .count-half { position: relative; float: left; width: 90px; padding-bottom: 6px; text-align: right; }

.branch-a-b-count .count-half:last-child { text-align: left; border-left: 1px solid var(--color-border-default); }

.branch-a-b-count .count-value { position: relative; top: -1px; display: block; padding: 0px 3px; font-size: 10px; }

.branch-a-b-count .bar { position: absolute; min-width: 3px; height: 4px; }

.branch-a-b-count .meter { position: absolute; height: 4px; background-color: var(--color-neutral-muted); }

.branch-a-b-count .meter.zero { background-color: transparent; }

.branch-a-b-count .bar-behind { right: 0px; border-radius: 6px 0px 0px 6px; }

.branch-a-b-count .bar-behind .meter { right: 0px; border-radius: 6px 0px 0px 6px; }

.branch-a-b-count .bar-ahead { left: 0px; border-radius: 0px 6px 6px 0px; }

.branch-a-b-count .bar-ahead .meter { border-radius: 0px 6px 6px 0px; }

.branch-a-b-count .bar-ahead.even, .branch-a-b-count .bar-behind.even { min-width: 2px; background: rgb(234, 236, 239); }

@media (max-width: 767px) {
  .branch-info-dropdown-size { top: 6px; width: 300px; max-width: 300px !important; }
  .branch-contribute-right { right: auto; left: -10px; }
  .branch-contribute-right::before, .branch-contribute-right::after { right: auto; left: 10px; }
}

@media (min-width: 767px) {
  .branch-info-dropdown-size { top: 6px; width: 378px; max-width: 378px !important; }
}

.admin-options-block .admin-option-button { margin-top: 8px; }

.admin-options-block .policy-enforcement { display: inline; margin-left: 8px; color: var(--color-fg-muted); }

.admin-options-block .policy-enforcement label { font-size: 13px; }

.admin-options-block .disabled { color: var(--color-fg-muted); }

.admin-options-block .disabled .note { color: var(--color-fg-muted); }

.overflow-scroll-y { overflow: hidden scroll !important; }

.business-menu-item:not([aria-current="page"]) + .business-sub-menu { display: none; }

.business-menu-icon { width: 16px; margin-right: 8px; }

.deprovisioning-checkbox > .show-if-disabled { display: none; }

.deprovisioning-checkbox.checkbox-disabled { color: var(--color-fg-muted); }

.deprovisioning-checkbox.checkbox-disabled > .show-if-disabled { display: inherit; }

body.full-width-p-0 .new-discussion-timeline { padding: 0px !important; }

body.full-width-p-0 .footer .mt-6 { margin-top: 0px !important; border-top: 0px !important; }

body.full-width-p-0 .tabnav .tabnav-extra { margin-right: 24px; }

body.full-width-p-0 .tabnav .tabnav-tabs { margin-left: 16px; }

.checks-summary-conclusion { width: 32px; height: 32px; line-height: 32px; border-radius: 50%; }

.actions-full-screen .pagehead, .actions-full-screen .hide-full-screen, .actions-full-screen .Header-old, .actions-full-screen .Header { display: none; }

.checks-list-item.selected .checks-list-item-name { background-color: var(--color-accent-emphasis)  !important; }

.checks-list-item.selected .selected-color-white { color: var(--color-fg-on-emphasis)  !important; }

.checks-list-item-icon { width: 16px; }

.checks-summary-meta .octicon { width: 16px; }

.checks-results-items .octicon-fold { display: none; }

.checks-results-items .Details--on .octicon-fold { display: inline-block; }

.checks-results-items .Details--on .octicon-unfold { display: none; }

.check-annotation { border-left: 0px; border-top-left-radius: 0px; border-bottom-left-radius: 0px; }

.check-annotation::after { position: absolute; top: -1px; bottom: -1px; left: 0px; display: block; width: 4px; content: " "; }

.check-annotation .annotation-actions { top: 4px; right: 8px; }

.check-annotation .annotation-octicon { width: 16px; }

.check-annotation.Details--on .Details-content--hidden { display: block !important; }

.annotation-title { word-break: break-all; }

.check-annotation-failure::after { background-color: var(--color-danger-emphasis); }

.check-annotation-failure .annotation-title { color: var(--color-danger-fg); }

.check-annotation-warning::after { background-color: var(--color-attention-emphasis); }

.check-annotation-warning .octicon-alert { color: var(--color-attention-fg); }

.check-annotation-warning .annotation-title { color: var(--color-attention-fg); }

.neutral-check { color: var(--color-fg-muted); }

.CheckRunContainer { background-color: var(--color-checks-bg); border-top: var(--color-checks-container-border-width) solid var(--color-border-default); border-left: var(--color-checks-container-border-width) solid var(--color-border-default); }

.CheckRun { background-color: var(--color-checks-bg); border-color: var(--color-border-muted)  !important; border-width: var(--color-checks-run-border-width)  !important; }

.CheckStep-header { height: 36px; line-height: 20px; color: var(--color-checks-text-secondary); }

.CheckStep-header-dropdown-menu { color: var(--color-scale-white); background: var(--color-checks-dropdown-bg); border-color: var(--color-checks-dropdown-border); box-shadow: 0 8px 24px var(--color-checks-dropdown-shadow)  !important; }

.CheckStep-header-dropdown-menu::before { border-bottom-color: var(--color-checks-dropdown-border); }

.CheckStep-header-dropdown-menu::after { border-bottom-color: var(--color-checks-dropdown-bg); }

.CheckStep-header-dropdown-menu .dropdown-header { color: var(--color-checks-text-secondary); }

.CheckStep-header-dropdown-menu .dropdown-divider { border-top-color: var(--color-checks-dropdown-border); }

.CheckStep-header-dropdown-menu .dropdown-item { color: var(--color-checks-dropdown-text)  !important; }

.CheckStep-header-dropdown-menu .dropdown-item:hover { color: var(--color-checks-dropdown-hover-text)  !important; background-color: var(--color-checks-dropdown-hover-bg)  !important; }

.CheckStep-header-dropdown-menu.dropdown-menu-w::before { border-color: transparent transparent transparent var(--color-checks-dropdown-border); }

.CheckStep-header-dropdown-menu.dropdown-menu-w::after { border-color: transparent transparent transparent var(--color-checks-dropdown-bg); }

.CheckStep-header-dropdown-menu.dropdown-menu-e::before { border-color: transparent var(--color-checks-dropdown-border) transparent transparent; }

.CheckStep-header-dropdown-menu.dropdown-menu-e::after { border-color: transparent var(--color-checks-dropdown-bg) transparent transparent; }

.CheckStep-header-dropdown-menu.dropdown-menu-ne::before { border-color: var(--color-checks-dropdown-border) transparent transparent transparent; }

.CheckStep-header-dropdown-menu.dropdown-menu-ne::after { border-color: var(--color-checks-dropdown-bg) transparent transparent transparent; }

.CheckRun-search details[open] .CheckStep-header-dropdown, .CheckStep-header-dropdown:hover { color: var(--color-checks-dropdown-btn-hover-text); background-color: var(--color-checks-dropdown-btn-hover-bg)  !important; }

.CheckRun-search details[open] .octicon, .CheckStep-header-dropdown:hover .octicon { color: var(--color-checks-btn-hover-icon)  !important; }

.CheckStep[open] .CheckStep-header { color: var(--color-checks-text-primary); }

.CheckStep[open] .CheckStep-header, .CheckStep-header:hover { background-color: var(--color-checks-step-header-open-bg); box-shadow: 0 -2px 0 2px var(--color-checks-bg); }

.WorkflowRunLogsScroll { }

.WorkflowRunLogsScroll::-webkit-scrollbar { width: 12px; }

.WorkflowRunLogsScroll::-webkit-scrollbar-thumb { background-color: var(--color-checks-scrollbar-thumb-bg); border-color: var(--color-checks-bg); border-style: solid; border-width: 3px; border-radius: 6px; }

.CheckStep-header-label { color: var(--color-checks-header-label-text); }

.CheckStep[open] .CheckStep-header-label { color: var(--color-checks-header-label-open-text); }

.CheckRun-search { width: 280px; }

.CheckRun-header { height: 80px; background-color: var(--color-checks-bg); border-top: 0px; border-bottom: 1px solid var(--color-checks-header-border); }

.CheckRun-header summary { padding: 6px 8px 5px; }

.CheckRun-header a { color: var(--color-checks-text-link); }

.CheckRun-header .btn-link:not([disabled]), .CheckRun-header .btn.btn-link:not([disabled]) .octicon, .CheckRun-header .btn-link:not([disabled]) .octicon { color: var(--color-checks-btn-icon); }

.CheckRun-header .btn-link:hover:not([disabled]), .CheckRun-header .btn.btn-link:hover:not([disabled]) .octicon { color: var(--color-checks-btn-hover-icon); background-color: var(--color-checks-btn-hover-bg); }

.CheckRun-header-timestamp { color: var(--color-checks-text-secondary); }

.CheckRun-log-title { color: var(--color-checks-text-primary); }

.Deployment-header-text { color: var(--color-checks-text-primary); }

.CheckRun-search-input { padding-top: 6px; padding-right: 88px; padding-bottom: 6px; color: var(--color-checks-input-text); background-color: var(--color-checks-input-bg); border-color: transparent; box-shadow: var(--color-checks-input-shadow)  !important; }

.CheckRun-search-input::placeholder { color: var(--color-checks-input-placeholder-text); }

.CheckRun-search-input:focus { color: var(--color-checks-text-primary); }

.CheckStep-chevron { transition: transform 0.1s ease 0s; }

[open] .CheckStep-chevron { transform: rotate(90deg); }

.CheckRun-header-counter { color: var(--color-checks-text-secondary); background-color: var(--color-checks-input-bg); }

.CheckRun-search-icon { color: var(--color-checks-header-icon); }

.CheckStep-line { line-height: 20px; color: var(--color-checks-line-text); }

.CheckStep-line .CheckStep-line-number { width: 48px; overflow: hidden; color: var(--color-checks-line-num-text); text-align: right; text-decoration: none; text-overflow: ellipsis; white-space: nowrap; user-select: none; }

.CheckStep-line .CheckStep-line-timestamp { display: none; color: var(--color-checks-line-timestamp-text); }

.CheckStep-line .CheckStep-line-content { overflow-x: auto; white-space: pre-wrap; }

.CheckStep-line .CheckStep-line-content a { color: var(--color-checks-line-text); text-decoration: underline; }

.CheckStep-line:hover { color: var(--color-checks-text-primary); background-color: var(--color-checks-line-hover-bg); }

.CheckStep-line.selected { color: var(--color-checks-text-primary); background-color: var(--color-checks-line-selected-bg)  !important; }

.CheckStep-line.selected .CheckStep-line-number { color: var(--color-checks-line-selected-num-text); text-decoration: underline; }

.CheckStep-line .dt-fm { padding-top: 2px; padding-bottom: 1px; background: var(--color-checks-line-dt-fm-bg); border-radius: 2px; color: var(--color-checks-line-dt-fm-text)  !important; }

.CheckStep-line .dt-fm.select { background: var(--color-accent-emphasis); color: var(--color-fg-on-emphasis)  !important; }

.CheckRun-line { color: var(--color-checks-line-text); background-color: var(--color-checks-line-selected-bg); }

.CheckRun-line .CheckRun-line-timestamp { display: none; color: var(--color-checks-line-timestamp-text); }

.CheckRun-line:hover { color: var(--color-checks-text-primary); }

.CheckRun-show-timestamps .CheckStep-line-timestamp { display: inline; }

.Blocked-Check-Warning { padding-top: 1px; padding-bottom: 1px; margin-right: 24px; margin-left: 24px; background-color: var(--color-checks-gate-bg)  !important; }

.Blocked-Check-Warning .Content-Text { color: var(--color-checks-gate-text); }

.Blocked-Check-Warning .Blocked-Check-Text { color: var(--color-checks-gate-waiting-text); }

.CheckStep { padding-right: 6px; }

.CheckStep .log-line-command { color: var(--color-checks-logline-command-text); }

.CheckStep .log-line-command a { color: var(--color-checks-logline-command-text); }

.CheckStep .log-line-command .CheckStep-line-number { color: var(--color-checks-logline-num-text); }

.CheckStep .log-line-debug { color: var(--color-checks-logline-debug-text); }

.CheckStep .log-line-debug a { color: var(--color-checks-logline-debug-text); }

.CheckStep .log-line-debug .CheckStep-line-number { color: var(--color-checks-logline-num-text); }

.CheckStep .log-download-error { margin-left: 8px; color: var(--color-checks-logline-error-text); background-color: var(--color-checks-logline-error-bg); }

.CheckStep .log-line-error { background-color: var(--color-checks-logline-error-bg); }

.CheckStep .log-line-error .CheckStep-line-content { color: var(--color-checks-logline-error-text); }

.CheckStep .log-line-error .CheckStep-line-number { color: var(--color-checks-logline-error-num-text); }

.CheckStep .log-line-info { font-weight: 600; color: var(--color-checks-logline-text); }

.CheckStep .log-line-info a { color: var(--color-checks-logline-text); }

.CheckStep .log-line-info .CheckStep-line-number { color: var(--color-checks-logline-num-text); }

.CheckStep .log-line-verbose { font-weight: 600; color: var(--color-checks-logline-text); }

.CheckStep .log-line-verbose a { color: var(--color-checks-logline-text); }

.CheckStep .log-line-verbose .CheckStep-line-number { color: var(--color-checks-logline-num-text); }

.CheckStep .log-line-warning { background-color: var(--color-checks-logline-warning-bg); }

.CheckStep .log-line-warning .CheckStep-line-content { color: var(--color-checks-logline-warning-text); }

.CheckStep .log-line-warning .CheckStep-line-number { color: var(--color-checks-logline-warning-num-text); }

.CheckStep .log-line-notice a { color: var(--color-checks-logline-text); }

.CheckStep .log-line-notice .CheckStep-line-number { color: var(--color-checks-logline-num-text); }

.CheckStep .log-line-section { font-weight: 600; color: var(--color-checks-logline-section-text); }

.CheckStep .log-line-section a { color: var(--color-checks-logline-section-text); }

.CheckStep .log-line-section .CheckStep-line-number { color: var(--color-checks-logline-num-text); }

.CheckStep .CheckStep-error-text { font-weight: 600; color: var(--color-checks-step-error-text); }

.CheckStep .CheckStep-warning-text { font-weight: 600; color: var(--color-checks-step-warning-text); }

.CheckStep .CheckStep-notice-text { font-weight: 600; }

.CheckStep a:hover { color: var(--color-checks-text-link)  !important; }

.CheckStep .ansifg-b { color: var(--color-checks-ansi-black); }

.CheckStep .ansifg-r { color: var(--color-checks-ansi-red); }

.CheckStep .ansifg-g { color: var(--color-checks-ansi-green); }

.CheckStep .ansifg-y { color: var(--color-checks-ansi-yellow); }

.CheckStep .ansifg-bl { color: var(--color-checks-ansi-blue); }

.CheckStep .ansifg-m { color: var(--color-checks-ansi-magenta); }

.CheckStep .ansifg-c { color: var(--color-checks-ansi-cyan); }

.CheckStep .ansifg-w { color: var(--color-checks-ansi-white); }

.CheckStep .ansifg-gr { color: var(--color-checks-ansi-gray); }

.CheckStep .ansifg-b-br { color: var(--color-checks-ansi-black-bright); }

.CheckStep .ansifg-r-br { color: var(--color-checks-ansi-red-bright); }

.CheckStep .ansifg-g-br { color: var(--color-checks-ansi-green-bright); }

.CheckStep .ansifg-y-br { color: var(--color-checks-ansi-yellow-bright); }

.CheckStep .ansifg-bl-br { color: var(--color-checks-ansi-blue-bright); }

.CheckStep .ansifg-m-br { color: var(--color-checks-ansi-magenta-bright); }

.CheckStep .ansifg-c-br { color: var(--color-checks-ansi-cyan-bright); }

.CheckStep .ansifg-w-br { color: var(--color-checks-ansi-white-bright); }

.CheckStep .ansibg-b { background-color: var(--color-checks-ansi-black); }

.CheckStep .ansibg-r { background-color: var(--color-checks-ansi-red); }

.CheckStep .ansibg-g { background-color: var(--color-checks-ansi-green); }

.CheckStep .ansibg-y { background-color: var(--color-checks-ansi-yellow); }

.CheckStep .ansibg-bl { background-color: var(--color-checks-ansi-blue); }

.CheckStep .ansibg-m { background-color: var(--color-checks-ansi-magenta); }

.CheckStep .ansibg-c { background-color: var(--color-checks-ansi-cyan); }

.CheckStep .ansibg-w { background-color: var(--color-checks-ansi-white); }

.CheckStep .ansibg-gr { background-color: var(--color-checks-ansi-gray); }

.CheckStep .ansibg-b-br { background-color: var(--color-checks-ansi-black-bright); }

.CheckStep .ansibg-r-br { background-color: var(--color-checks-ansi-red-bright); }

.CheckStep .ansibg-g-br { background-color: var(--color-checks-ansi-green-bright); }

.CheckStep .ansibg-y-br { background-color: var(--color-checks-ansi-yellow-bright); }

.CheckStep .ansibg-bl-br { background-color: var(--color-checks-ansi-blue-bright); }

.CheckStep .ansibg-m-br { background-color: var(--color-checks-ansi-magenta-bright); }

.CheckStep .ansibg-c-br { background-color: var(--color-checks-ansi-cyan-bright); }

.CheckStep .ansibg-w-br { background-color: var(--color-checks-ansi-white-bright); }

.CheckStep .bright { filter: brightness(1.5); }

.code-frequency .addition { fill: rgb(44, 190, 78); fill-opacity: 1; }

.code-frequency .deletion { fill: var(--color-danger-emphasis); fill-opacity: 1; }

.cadd { font-weight: 600; color: var(--color-success-fg); }

.cdel { font-weight: 600; color: var(--color-danger-fg); }

.code-list .file-box { border: 1px solid var(--color-border-default); border-radius: 6px; }

.code-list .title { min-height: 24px; margin: -3px 0px 10px 38px; font-weight: 600; line-height: 1.2; }

.code-list .repo-specific .title, .code-list .repo-specific .full-path { margin-left: 0px; }

.code-list .match-count, .code-list .updated-at { margin: 0px; font-weight: 400; }

.code-list .language { float: right; margin-left: 10px; font-size: 12px; color: rgba(51, 51, 51, 0.75); }

.code-list .avatar { float: left; }

.code-list .code-list-item + .code-list-item { border-top: 1px solid var(--color-border-muted); }

.code-list .blob-num { padding: 0px; }

.code-list .blob-num::before { content: normal; }

.code-list .blob-num a { padding: 0px 10px; color: inherit; }

.code-list .blob-num a:hover { color: var(--color-accent-fg); }

.code-list .blob-code { white-space: pre-wrap; }

.code-list .divider .blob-num, .code-list .divider .blob-code { padding-top: 0px; padding-bottom: 0px; cursor: default; background-color: var(--color-canvas-subtle); }

.code-list .divider .blob-num { height: 18px; padding: 0px 10px; line-height: 15px; background-color: var(--color-canvas-subtle); }

.code-list .full-path { margin: 0px 0px 0px 40px; }

.code-list .full-path .octicon-repo { color: var(--color-fg-muted); }

.code-list .full-path .octicon-lock { color: var(--color-attention-fg); }

.code-list .full-path a { color: var(--color-fg-muted); }

.code-list-item-private .file-box { border: 1px solid var(--color-attention-muted); }

.code-list-item-private .blob-num { background-color: var(--color-attention-subtle); border-right: 1px solid var(--color-attention-muted); }

.code-list-item-private .blob-num a { color: var(--color-attention-fg); }

.code-list-item-private .divider .blob-num, .code-list-item-private .divider .blob-code { color: var(--color-attention-fg); background-color: var(--color-attention-subtle); }

.code-scanning-alert-warning-message { border-color: var(--color-attention-emphasis)  !important; }

.code-scanning-font-size-inherit { font-size: inherit !important; }

.cs-message .md-list { padding-left: 2em; }

.codesearch-head.pagehead h1 { width: 250px; line-height: 33px; }

@media (min-width: 768px) {
  .advanced-search-form .flattened dt { width: 230px; }
  .advanced-search-form .flattened dt label { font-weight: 400; }
  .advanced-search-form .flattened dd { margin-left: 250px; }
  .advanced-search-form .form-checkbox { margin-left: 250px; }
}

.codesearch-results .code-list .title a { overflow-wrap: break-word; }

.codesearch-results .repo-list-item { border-bottom: 0px; }

.codesearch-results .repo-list-item + .repo-list-item { border-top: 1px solid var(--color-border-default); }

.search-form-fluid .TableObject-item--primary { position: relative; padding-right: 8px; }

.search-form-fluid .completed-query { position: absolute; z-index: 1; padding: inherit; margin: 0px; overflow: hidden; white-space: nowrap; }

.search-form-fluid .completed-query span { opacity: 0; }

.search-form-fluid .search-page-label { position: relative; display: block; font-weight: 400; cursor: text; }

.search-form-fluid .search-page-label.focus .completed-query { opacity: 0.6; }

.search-form-fluid .search-page-input { position: relative; z-index: 2; min-height: 0px; padding: 0px; margin: 0px; background: none; border: 0px; box-shadow: none; }

.search-form-fluid .search-page-input:focus { box-shadow: none; }

.topics-row-container { height: 30px; overflow: hidden; }

@media (max-width: 544px) {
  .codesearch-pagination-container a:not(.next_page):not(.previous_page), .codesearch-pagination-container .gap { display: none; }
  .codesearch-pagination-container .previous_page, .codesearch-pagination-container .next_page { width: 100%; }
  .codesearch-pagination-container .current { color: var(--color-fg-muted); background: var(--color-canvas-default); border-color: var(--color-border-default); }
  .codesearch-pagination-container .current::after { content: " of " attr(data-total-pages); }
}

.codespaces-list-box .Box-header:not(:first-child) { border-top-left-radius: 0px; border-top-right-radius: 0px; }

.codespaces-index-list-branch-link { background-color: var(--color-accent-subtle); }

.disabled-sku { color: var(--color-fg-muted); }

.cloud-panel .welcome-image { background: url("/images/modules/site/codespaces/dropdown-background-light.png") center bottom / contain no-repeat; }

@media (prefers-color-scheme: light) {
  .cloud-panel .welcome-image { background: url("/images/modules/site/codespaces/dropdown-background-light.png") center bottom / contain no-repeat; }
}

@media (prefers-color-scheme: dark) {
  .cloud-panel .welcome-image { background: url("/images/modules/site/codespaces/dropdown-background-dark.png") center bottom / contain no-repeat; }
}

@media not all {
  .cloud-panel .welcome-image { background: url("/images/modules/site/codespaces/dropdown-background-light.png") center bottom / contain no-repeat; }
}

.commit-activity-graphs .dots { display: none; }

.commit-activity-master { margin-top: 20px; }

.is-graph-loading .commit-activity-master { display: none; }

rect { shape-rendering: crispedges; }

rect.max { fill: var(--color-attention-fg); }

g.bar { fill: var(--color-success-fg); }

g.mini { fill: var(--color-severe-fg); }

g.active rect { fill: var(--color-danger-fg); }

circle.focus { fill: var(--color-fg-muted); }

.dot text { fill: var(--color-fg-muted); stroke: none; }

.CommunityTemplate-markdown { height: 800px; overflow-y: scroll; font-size: 14px; }

.CommunityTemplate-highlight { padding: 2px 4px; margin: 0px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; font-style: normal; font-weight: 600; color: var(--color-fg-default); cursor: pointer; background-color: var(--color-attention-emphasis); border-radius: 6px; }

.CommunityTemplate-highlight--focus { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.community-checklist .progress-bar { background-image: ; background-position-x: ; background-position-y: ; background-size: ; background-repeat-x: ; background-repeat-y: ; background-attachment: ; background-origin: ; background-clip: ; background-color: transparent; }

.community-checklist .progress { float: right; background-color: var(--color-canvas-subtle); }

.community-checklist .checklist-dot { color: var(--color-attention-fg); }

body.full-width-p0 .container, body.full-width-p0 .container-lg { width: 100%; max-width: none; padding-right: 16px; padding-left: 16px; }

body.full-width-p0 .container-lg.new-discussion-timeline { padding-right: 0px !important; padding-left: 0px !important; }

.community-graph { width: 335px; }

@media (min-width: 544px) {
  .community-graph { width: 428px; }
}

.community-graph .tick-x line { stroke: var(--color-border-muted); stroke-dasharray: 5; }

.community-graph .tick-y line { stroke: var(--color-border-muted); }

.community-graph .tick-labels-x .tick text { font-size: 12px; color: var(--color-fg-muted); transform: translateY(4px); }

.community-graph .tick-labels-y .tick text { font-size: 12px; color: var(--color-fg-muted); transform: translateX(-4px); }

.community-graph .domain { stroke: none; }

.community-graph .tick-y .tick:first-of-type line { stroke: var(--color-neutral-emphasis-plus); }

.community-graph .tick-x .tick:first-of-type line { stroke: var(--color-neutral-emphasis-plus); stroke-dasharray: none; }

.community-graph .axis-label { font-size: 12px; font-weight: 500; fill: var(--color-fg-muted); }

.community-graph .legend-text { font-size: 12px; fill: var(--color-fg-muted); }

.community-graph .discussions-line { fill-opacity: 0; stroke: var(--color-success-fg); stroke-width: 3px; stroke-dasharray: 6, 1; }

.community-graph circle.discussions-line { fill: var(--color-success-fg); fill-opacity: 0; stroke: none; }

.community-graph circle.discussions-line:hover { fill-opacity: 1; }

.community-graph .issues-line, .community-graph .contributors-line { fill-opacity: 0; stroke: var(--color-accent-fg); stroke-width: 3px; }

.community-graph circle.issues-line, .community-graph circle.contributors-line { fill: var(--color-accent-fg); fill-opacity: 0; stroke: none; }

.community-graph circle.issues-line:hover, .community-graph circle.contributors-line:hover { fill-opacity: 1; }

.community-graph .pull-requests-line { fill-opacity: 0; stroke: var(--color-done-fg); stroke-width: 3px; stroke-dasharray: 3; }

.community-graph circle.pull-requests-line { fill: var(--color-done-fg); fill-opacity: 0; stroke: none; }

.community-graph circle.pull-requests-line:hover { fill-opacity: 1; }

.community-graph .logged-in-views { fill: var(--color-accent-fg); }

.community-graph .anonymous-views { fill: var(--color-severe-fg); }

span.no-nl-marker { position: relative; color: var(--color-danger-fg); vertical-align: middle; }

.symlink .no-nl-marker { display: none; }

.contributions-setting-menu { z-index: 80; width: 330px; }

.ContributionCalendar.days-selected .ContributionCalendar-day { opacity: 0.5; }

.ContributionCalendar.days-selected .ContributionCalendar-day.active { opacity: 1; }

.ContributionCalendar-label { font-size: 9px; fill: var(--color-fg-default); }

.ContributionCalendar-day, .ContributionCalendar-day[data-level="0"] { fill: var(--color-calendar-graph-day-bg); shape-rendering: geometricprecision; outline: 1px solid var(--color-calendar-graph-day-border); outline-offset: -1px; }

.ContributionCalendar-day[data-level="1"] { fill: var(--color-calendar-graph-day-L1-bg); outline: 1px solid var(--color-calendar-graph-day-L1-border); }

.ContributionCalendar-day[data-level="2"] { fill: var(--color-calendar-graph-day-L2-bg); outline: 1px solid var(--color-calendar-graph-day-L2-border); }

.ContributionCalendar-day[data-level="3"] { fill: var(--color-calendar-graph-day-L3-bg); outline: 1px solid var(--color-calendar-graph-day-L3-border); }

.ContributionCalendar-day[data-level="4"] { fill: var(--color-calendar-graph-day-L4-bg); outline: 1px solid var(--color-calendar-graph-day-L4-border); }

.ContributionCalendar[data-holiday="halloween"] .ContributionCalendar-day[data-level="1"] { fill: var(--color-calendar-halloween-graph-day-L1-bg); }

.ContributionCalendar[data-holiday="halloween"] .ContributionCalendar-day[data-level="2"] { fill: var(--color-calendar-halloween-graph-day-L2-bg); }

.ContributionCalendar[data-holiday="halloween"] .ContributionCalendar-day[data-level="3"] { fill: var(--color-calendar-halloween-graph-day-L3-bg); }

.ContributionCalendar[data-holiday="halloween"] .ContributionCalendar-day[data-level="4"] { fill: var(--color-calendar-halloween-graph-day-L4-bg); }

.graph-before-activity-overview { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.activity-overview-box { border-top-left-radius: 0px; border-top-right-radius: 0px; }

.contribution-activity .select-menu-button { position: relative; top: -4px; }

.contribution-activity.loading .contribution-activity-listing { display: none; }

.contribution-activity.loading .contribution-activity-show-more { display: none; }

.contribution-activity.loading .contribution-activity-spinner { display: block; }

.contribution-activity-spinner { display: none; }

li.contribution { padding: 10px 0px; list-style: none; }

li.contribution h3 { display: inline-block; margin: 0px; font-size: 14px; }

li.contribution .cmeta { display: block; font-size: 12px; }

li.contribution .d { color: var(--color-fg-default); }

li.contribution .a { color: var(--color-fg-default); }

li.contribution .num { color: var(--color-fg-muted); }

.activity-overview-axis, .activity-overview-point { stroke: var(--color-calendar-graph-day-L4-bg); }

.halloween-activity-overview .activity-overview-axis, .halloween-activity-overview .activity-overview-point { stroke: var(--color-calendar-halloween-graph-day-L4-bg); }

.activity-overview-label { fill: var(--color-fg-muted); }

.activity-overview-percentage { font-size: 10px; fill: var(--color-fg-muted); }

.tint-box { position: relative; margin-bottom: 10px; background: var(--color-canvas-subtle); border-radius: 6px; }

.tint-box.transparent { background: var(--color-canvas-default); }

.tint-box .activity { padding-top: 100px; margin-top: 0px; }

.contrib-person path { fill: var(--color-severe-fg); }

.contrib-person .midlabel { fill: var(--color-neutral-emphasis); }

.coupons .setup-plans td img { margin-top: -2px; vertical-align: middle; }

.coupons .coupon-form-body { width: 270px; padding: 20px; margin: 100px auto 60px; font-size: 14px; text-align: center; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); border-radius: 6px; }

.coupons .coupon-form-body .input-block { margin-bottom: 16px; }

.coupons .coupon-form-body .btn { display: block; width: 100%; }

.coupon-icon { width: 80px; height: 80px; margin: 0px auto 16px; color: var(--color-accent-fg); border: 1px solid var(--color-border-default); border-radius: 40px; }

.coupon-icon .octicon { margin-top: 16px; margin-right: 2px; }

.coupons-list-options .select-menu { display: inline-block; margin-right: 8px; }

.coupons-list-options .pagination { float: right; margin: 0px; }

.user-repos .mini-repo-list-item { padding-right: 6px; }

.user-repos .mini-repo-list-item .repo-and-owner { max-width: 100%; }

.user-repos .mini-repo-list-item .owner { max-width: 145px; }

.repo-private-icon { fill: var(--color-attention-fg); }

.dashboard-rollup-items > .dashboard-rollup-item { border-top: 1px solid var(--color-border-default); }

@keyframes broadCastMaskFade { 
  0% { opacity: 0; }
  30% { opacity: 1; }
  70% { opacity: 1; }
  100% { opacity: 0; }
}

.dashboard h1 { margin-bottom: 0.5em; font-size: 160%; }

.dashboard h1 a { font-size: 70%; font-weight: 400; }

.dashboard .notice { padding: 16px; margin-top: 0px; margin-bottom: 0px; text-align: center; }

.news-full, .page-profile .news { float: none; width: auto; }

.dashboard-break-word { hyphens: auto; word-break: break-word; }

.news .bio g-emoji, .news .repo-description g-emoji { display: inline-block; }

.dashboard-underlined-link:hover, .dashboard-underlined-link:hover * { text-decoration: underline; }

.suggest-icon { width: 48px; height: 48px; padding: 4px; }

.suggest-icon svg, .suggest-icon path { fill: rgb(255, 255, 255); }

.suggest-icon svg::before, .suggest-icon path::before { bottom: -6px; left: -4px; background-color: rgb(158, 123, 255); }

.suggest-icon svg::after, .suggest-icon path::after { top: -5px; right: -5px; width: 5px; height: 5px; background-color: rgb(108, 132, 233); }

.suggest-icon .suggest-icon-bubble { position: absolute; width: 6px; height: 6px; background-color: rgb(108, 132, 233); border-radius: 50%; }

.suggest-icon .suggest-icon-bubble:nth-of-type(2n) { width: 4px; height: 4px; background-color: rgb(158, 123, 255); }

.suggest-icon .suggest-icon-bubble:nth-of-type(1) { bottom: -7px; left: -7px; }

.suggest-icon .suggest-icon-bubble:nth-of-type(2) { top: -4px; right: 4px; }

.suggest-icon .suggest-icon-bubble:nth-of-type(3) { top: -7px; right: -8px; }

.dashboard-notice { position: relative; padding: 15px 15px 15px 55px; margin-bottom: 20px; font-size: 14px; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); border-radius: 6px; }

.dashboard-notice .dismiss { position: absolute; top: 10px; right: 10px; width: 16px; height: 16px; color: var(--color-fg-muted); cursor: pointer; }

.dashboard-notice .dismiss:hover { color: var(--color-fg-muted); }

.dashboard-notice .notice-icon { position: absolute; top: 15px; left: 15px; }

.dashboard-notice .octicon-organization { color: var(--color-accent-fg); }

.dashboard-notice h2 { margin-top: 9px; margin-bottom: 16px; font-size: 18px; font-weight: 400; color: var(--color-fg-default); }

.dashboard-notice p.no-title { padding-right: 5px; }

.dashboard-notice ul { margin-left: 18px; }

.dashboard-notice li { padding-bottom: 15px; }

.dashboard-notice .coupon { padding: 10px; margin: 15px 0px; font-size: 20px; font-weight: 600; text-align: center; background: var(--color-canvas-default); border: 1px dashed var(--color-border-default); }

.dashboards-overview-lead { width: 700px; }

.dashboards-overview-cards .boxed-group { width: 100%; margin: 10px 0px; }

.dashboards-overview-cards .boxed-group .graph-canvas path { stroke-opacity: 0.5; }

.dashboards-overview-cards .is-no-activity .blankslate { display: block; }

.dashboards-overview-cards .is-no-activity .dashboards-overview-graph { display: none; }

.dashboards-overview-cards .blankslate { display: none; padding-top: 47px; background-color: var(--color-canvas-default); border: 0px; box-shadow: none; }

.dashboards-overview-cards .octicon-arrow-down, .dashboards-overview-cards .octicon-arrow-up { display: none; }

.dashboards-overview-cards .is-increase .octicon-arrow-up { display: inline-block; }

.dashboards-overview-cards .is-decrease .octicon-arrow-down { display: inline-block; }

.dashboards-overview-cards .octicon-arrow-down { color: var(--color-danger-fg); }

.dashboards-overview-cards .octicon-arrow-up { color: rgb(29, 179, 79); }

.dashboards-overview-cards .graph-canvas .dots { padding: 43px 0px; }

.dashboards-overview-cards .summary-stats { height: 78px; }

.dashboards-overview-cards .summary-stats .metric-0 { color: rgb(29, 179, 79); }

.dashboards-overview-cards .summary-stats .metric-1 { color: var(--color-accent-fg); }

.dashboards-overview-cards .summary-stats .totals-num { margin: 0px 7px; }

.dashboards-overview-cards .summary-stats .single { width: 100%; }

.dashboards-overview-cards .dashboards-overview-graph { height: 160px; }

.dashboards-overview-cards .dashboards-overview-graph path { fill: none; stroke-width: 2; }

.dashboards-overview-cards .dashboards-overview-graph path.metric-0 { stroke: rgb(29, 179, 79); }

.dashboards-overview-cards .dashboards-overview-graph path.metric-1 { stroke: rgb(29, 127, 179); }

.dashboards-overview-cards .dashboards-overview-graph .y line { stroke: rgb(29, 179, 79); }

.dashboards-overview-cards .dashboards-overview-graph .y.unique line { stroke: rgb(29, 127, 179); }

.dashboards-overview-cards .dashboards-overview-graph .overlay { fill-opacity: 0; }

.dashboards-overview-cards .metric-0 circle { fill: rgb(29, 179, 79); stroke: rgb(255, 255, 255); stroke-width: 2; }

.dashboards-overview-cards .dots.metric-1 circle { fill: rgb(29, 127, 179); stroke: rgb(255, 255, 255); stroke-width: 2; }

dl.form.developer-select-account { margin-top: 0px; }

.developer-wrapper .setup-info-module .features-list { margin-left: 16px; }

.developer-wrapper .setup-info-module .features-list .octicon { margin-left: -17px; }

.developer-thanks h2 { font-size: 38px; font-weight: 400; }

.developer-thanks .hook { margin-top: 2px; margin-bottom: 30px; font-size: 18px; font-weight: 300; color: var(--color-fg-muted); }

.developer-thanks-image { position: relative; bottom: -45px; float: left; width: 400px; }

.developer-thanks-section { margin: 130px 0px 0px 470px; }

.developer-next-steps { font-size: 18px; font-weight: 300; list-style: none; }

.developer-next-steps li { margin-top: 10px; }

.developer-next-steps li:first-child { margin-top: 0px; }

.developer-next-steps .octicon { margin-right: 10px; color: var(--color-success-fg); vertical-align: middle; }

.file-diff-split[data-lock-side-selection="left"] [data-split-side="right"], .file-diff-split[data-lock-side-selection="right"] [data-split-side="left"] { user-select: none; }

.invisible { position: absolute; opacity: 0; }

.timeline-comment.timeline-chosen-answer { border: 2px solid var(--color-success-emphasis); }

.discussion-nested-comment-timeline-item::before { left: 25px; }

@media (min-width: 544px) {
  .discussion-nested-comment-timeline-item::before { left: 30px; }
}

.discussion-primer-next-nested-comment-timeline-item::before { left: 30px; }

.discussion-nested-comment-timeline-item:first-child::before { top: 16px; }

.discussion-nested-comment-group { margin-left: 32px; }

.discussion-nested-comment-paging-form::before { width: 0px; background-color: transparent; }

.discussion-nested-comment-paging-badge .octicon { fill: var(--color-border-muted); transform: rotate(90deg); }

.discussion-nested-comment-paging-form-body { margin-left: 24px; }

:target .discussion-nested-comment-group .timeline-comment { box-shadow: none; }

.discussion-nested-comment-timeline-item:target { box-shadow: var(--color-primer-shadow-focus); }

:target .nested-discussion-timeline-comment { box-shadow: none; }

.inline-comment-form-container.open .discussion-nested-comment-inline-form .previewable-comment-form { display: block; }

.page-responsive .discussion-add-reaction-button { opacity: 1; }

.icon-discussion-answered { color: var(--color-success-fg); }

.icon-discussion-answered, .icon-discussion-answered path { fill: var(--color-success-emphasis); }

.icon-discussion-white { color: var(--color-discussions-state-answered-icon)  !important; }

.icon-discussion-white, .icon-discussion-white path { fill: var(--color-discussions-state-answered-icon)  !important; }

.icon-discussion-gray { color: var(--color-fg-default); }

.icon-discussion-gray, .icon-discussion-gray path { fill: var(--color-fg-default); }

.is-comment-editing .discussion-comment .previewable-comment-form { display: none; }

.is-comment-editing .discussion-comment .timeline-comment-actions, .is-comment-editing .discussion-comment .edit-comment-hide { display: block; }

.discussion-comment .previewable-edit.is-comment-editing .timeline-comment-header { display: flex !important; }

.discussion-timeline-item::before { display: none; }

.discussion-event-timeline-item::before { left: -6px; }

.discussion-event-wrapper:last-child .discussion-event-timeline-item { padding-bottom: 0px !important; }

.discussion-event-wrapper:last-child .discussion-event-timeline-item::before { display: none; }

.bg-discussions-row-emoji-box { background: var(--color-bg-discussions-row-emoji-box); width: 42px !important; height: 42px !important; }

.bg-discussions-row-emoji-box-small { background: var(--color-bg-discussions-row-emoji-box); width: 30px !important; height: 30px !important; }

.discussions-emoji-box { cursor: default; font-size: 14px !important; line-height: 14px !important; vertical-align: 0px !important; }

@media (min-width: 768px) {
  .discussions-emoji-box { font-size: 16px !important; line-height: 16px !important; vertical-align: 0px !important; }
}

.discussion-vote-form .slidey-boi { transition: all 0.4s ease-in-out 0s; transform: perspective(1px) translateY(0%); }

.discussion-vote-form.is-upvoted .slidey-boi { transform: perspective(1px) translateY(-50%); }

.sidebar-emoji-box { width: auto !important; height: auto !important; }

.errored .discussion-category-picker { border-color: var(--color-danger-emphasis); }

.comment-body div[type="discussions-op-text"] { padding: 8px; border-radius: 6px; border: 1px solid var(--color-border-muted)  !important; }

.comment-body div[type="discussions-op-text"] p { margin-bottom: 0px; }

.discussion-Link--primary:visited { color: var(--color-fg-muted)  !important; }

.label-select-menu .color { display: inline-block; width: 14px; height: 14px; margin-top: -1px; margin-right: 2px; vertical-align: middle; border-radius: 7px; }

.label-select-menu .select-menu-item:hover, .label-select-menu .select-menu-item:focus, .label-select-menu .select-menu-item[aria-checked="true"]:hover, .label-select-menu .select-menu-item[aria-checked="true"]:focus { color: inherit; background-color: var(--color-neutral-subtle); }

.label-select-menu .select-menu-item-icon, .label-select-menu .label-options-icon { color: inherit !important; }

.user-has-reacted .octicon { fill: var(--color-accent-fg); }

.discussion-footer-answer-icon { width: 26px; height: 26px; }

.discussion-footer-answer-button { line-height: inherit; padding: 0px 10px !important; }

.discussion-footer-answered-badge { line-height: inherit; padding: 0px 10px 0px 6px !important; }

.discussion-spotlights-sortable > .discussions-spotlight-wrapper:first-child { padding-left: 0px !important; }

.discussion-spotlights-sortable .sortable-drag { background-color: transparent; padding: 0px !important; }

.discussion-spotlight-modal { width: 560px; overflow-y: auto; }

.discussion-spotlight-pattern-container { mix-blend-mode: soft-light; background-position: 20px 20px; background-size: 35px; opacity: 0.5; }

.discussion-spotlight-pattern-zap { background-image: url("/static/images/icons/spotlight/zap-pattern.svg"); }

.discussion-spotlight-pattern-chevron-up { background-image: url("/static/images/icons/spotlight/chevron-up-pattern.svg"); }

.discussion-spotlight-pattern-dot-fill { background-image: url("/static/images/icons/spotlight/dot-fill-pattern.svg"); }

.discussion-spotlight-pattern-dot { background-image: url("/static/images/icons/spotlight/dot-pattern.svg"); }

.discussion-spotlight-pattern-heart-fill { background-image: url("/static/images/icons/spotlight/heart-fill-pattern.svg"); }

.discussion-spotlight-pattern-plus { background-image: url("/static/images/icons/spotlight/plus-pattern.svg"); }

.discussion-spotlight { height: 188px; flex: 1 1 auto; overflow: hidden; }

.discussion-spotlight-preview { height: 160px; }

.discussion-spotlight-gradient { width: 35px; height: 35px; }

.discussion-spotlight-gradient .discussion-spotlight-gradient-selected-indicator { display: none; }

.discussion-spotlight-gradient[aria-selected="true"] { box-shadow: rgba(27, 31, 35, 0.075) 0px 1px 2px inset, rgba(3, 102, 214, 0.3) 0px 0px 0px 0.2em; }

.discussion-spotlight-gradient[aria-selected="true"] .discussion-spotlight-gradient-selected-indicator { display: inline-block; }

.discussion-spotlight-emoji { top: calc(35% - 35px); left: calc(50% - 48px); width: 96px; height: 96px; font-size: 96px; text-shadow: rgba(0, 0, 0, 0.3) 0px 3px 14px; }

.discussion-spotlight-details { pointer-events: none; }

.discussion-spotlight-details > * { pointer-events: auto; }

.discussion-spotlight-handle { cursor: pointer; background: var(--color-primer-canvas-backdrop); }

.donut-chart > .error, .donut-chart > .cancelled, .donut-chart > .action_required, .donut-chart > .timed_out, .donut-chart > .failure { fill: var(--color-checks-donut-error); }

.donut-chart > .expected, .donut-chart > .queued, .donut-chart > .in_progress, .donut-chart > .waiting, .donut-chart > .requested, .donut-chart > .pending { fill: var(--color-checks-donut-pending); }

.donut-chart > .success { fill: var(--color-checks-donut-success); }

.donut-chart > .neutral, .donut-chart > .stale, .donut-chart > .skipped { fill: var(--color-checks-donut-neutral); }

.survey-question-form .other-text-form, .survey-question-form .other-text-form-block { display: none; margin-top: 0px; }

.survey-question-form.is-other-selected .other-text-form { display: inline-block; }

.survey-question-form.is-other-selected .other-text-form-block { display: block; }

.ghe-license-status { padding: 40px 0px; font-size: 16px; text-align: center; }

.ghe-license-status .octocat { width: 225px; margin-bottom: 20px; }

.ghe-license-status h1 { margin-bottom: 10px; }

.ghe-license-status p { margin-bottom: 5px; color: var(--color-fg-muted); }

.ghe-license-expiry-icon { margin: 5px 10px 0px 0px; color: var(--color-attention-fg); }

.feature-preview-dialog { width: 90vw; max-width: 880px; height: 60vh; min-height: 240px; max-height: 700px; }

.feature-preview-dialog .feature-preview-info { height: 60vh; min-height: calc(183px); max-height: calc(100% - 57px); }

.file { position: relative; margin-top: 16px; margin-bottom: 16px; border: 1px solid var(--color-border-default, #ddd); border-radius: 6px; }

.file .drag-and-drop { border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top: 1px dashed var(--color-border-default); }

.file:target { border-color: var(--color-accent-emphasis); box-shadow: var(--color-primer-shadow-focus); }

.file .data.empty { padding: 5px 10px; color: var(--color-fg-muted); }

.file:not(.open) .file-header.file-header--expandable { border-bottom: 0px; border-radius: 6px; }

.file .data.suppressed, .file.open .image { display: none; }

.file.open .data.suppressed { display: block; }

.file .image { position: relative; padding: 30px; text-align: center; background-color: rgb(221, 221, 221); }

.file .image table { margin: 0px auto; }

.file .image td { padding: 0px 5px; color: var(--color-fg-muted); text-align: center; vertical-align: top; }

.file .image td img { max-width: 100%; }

.file .image .border-wrap { position: relative; display: inline-block; line-height: 0; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); }

.file .image a { display: inline-block; line-height: 0; }

.file .image img, .file .image canvas { max-width: 600px; background: url("/images/modules/commit/trans_bg.gif") right bottom rgb(238, 238, 238); border: 1px solid rgb(255, 255, 255); }

.file .image .view img, .file .image .view canvas { position: relative; top: 0px; right: 0px; max-width: inherit; background: url("/images/modules/commit/trans_bg.gif") right bottom rgb(238, 238, 238); }

.file .image .view > span { vertical-align: middle; }

.file .empty { background: none; }

.file-sidebar-container .file { border-top-right-radius: 0px; border-bottom-right-radius: 0px; }

.file-header { padding: 5px 10px; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-default); border-top-left-radius: 6px; border-top-right-radius: 6px; }

.file-header::before { display: table; content: ""; }

.file-header::after { display: table; clear: both; content: ""; }

.file-actions { float: right; padding-top: 2px; font-size: 13px; }

.file-actions select { margin-left: 5px; }

.file-info { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; line-height: 32px; }

.file-info .octicon { vertical-align: text-bottom; }

.sticky-file-header { position: sticky; top: 60px; z-index: 6; }

.sticky-file-header.has-open-dropdown { z-index: 10; }

.file-info-divider { display: inline-block; width: 1px; height: 18px; margin-right: 3px; margin-left: 3px; vertical-align: middle; border-left: 1px solid var(--color-border-default); }

.file-mode { text-transform: capitalize; }

.file-blankslate { border: 0px; border-radius: 0px 0px 6px 6px; }

.diff-progressive-loader { min-height: 150px; }

.load-diff-button, .load-diff-retry { z-index: 1; min-height: 32px; }

.diff-placeholder-svg { clip: rect(1px, 1px, 1px, 1px); clip-path: inset(50%); }

.hidden-diff-reason { z-index: 2; }

.ghae-bootstrap-container { min-height: calc(100vh - 54px); }

.ghae-bootstrap-incomplete-step { color: var(--color-fg-muted); background-color: var(--color-canvas-subtle); }

.ghae-bootstrap-complete-step { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); }

.ghae-enterprise-name-form-error { left: 50%; transform: translateX(-50%); }

.graphs h2.ghead::after { display: block; height: 0px; clear: both; visibility: hidden; content: "."; }

.graphs.wheader h2 { padding: 1px; }

.graphs .area { fill: var(--color-success-emphasis); fill-opacity: 0.5; }

.graphs .path { fill: none; stroke: var(--color-success-emphasis); stroke-opacity: 1; stroke-width: 2px; }

.graphs .dot { fill: var(--color-success-emphasis); stroke: rgb(30, 126, 52); stroke-width: 2px; }

.graphs .dot.padded { stroke: var(--color-canvas-default); stroke-width: 1px; }

.graphs .dot.padded circle:hover { fill: var(--color-accent-emphasis); }

.graphs .d3-tip { fill: var(--color-neutral-emphasis); }

.graphs .d3-tip text { font-size: 11px; fill: var(--color-canvas-default); }

.graphs .dir { float: right; padding-top: 5px; font-size: 12px; font-weight: 400; line-height: 100%; color: var(--color-fg-muted); }

.graphs .selection .overlay { }

.graphs .selection .selection { fill: var(--color-neutral-emphasis); fill-opacity: 0.1; stroke: var(--color-fg-default); stroke-dasharray: 3, 3; stroke-opacity: 0.4; stroke-width: 1px; shape-rendering: crispedges; }

.graph-filter h3 { display: inline-block; font-size: 24px; font-weight: 300; }

.graph-filter .info { margin-bottom: 20px; color: var(--color-fg-muted); }

.graph-canvas .activity { width: 400px; padding: 10px; margin: 100px auto 0px; color: var(--color-fg-default); text-align: center; border-radius: 6px; }

.graph-canvas .dots { margin: 0px auto; }

.graph-canvas > .activity { display: none; }

.graph-canvas .axis { font-size: 10px; }

.graph-canvas .axis line { stroke: var(--color-border-default); shape-rendering: crispedges; }

.graph-canvas .axis text { fill: var(--color-fg-muted); }

.graph-canvas .axis path { display: none; }

.graph-canvas .axis .zero line { stroke: var(--color-accent-emphasis); stroke-dasharray: 3, 3; stroke-width: 1.5; }

.graph-canvas text.axis { fill: var(--color-fg-muted); }

.graph-canvas .graph-loading, .graph-canvas .graph-error, .graph-canvas .graph-no-usable-data, .graph-canvas .graph-empty { display: none; }

.graph-canvas.is-graph-loading > .activity, .graph-canvas.is-graph-without-usable-data > .activity, .graph-canvas.is-graph-empty > .activity { display: block; }

.graph-canvas.is-graph-loading .graph-loading, .graph-canvas.is-graph-empty .graph-empty, .graph-canvas.is-graph-without-usable-data .graph-no-usable-data, .graph-canvas.is-graph-load-error .graph-error { display: block; }

.svg-tip { position: absolute; z-index: 99999; padding: 8px 16px; font-size: 12px; color: var(--color-fg-on-emphasis); text-align: center; background: var(--color-neutral-emphasis-plus); border-radius: 6px; }

.svg-tip.is-visible { display: block; }

.svg-tip::after { position: absolute; bottom: -10px; left: 50%; width: 5px; height: 5px; box-sizing: border-box; margin: 0px 0px 0px -5px; content: " "; border-width: 5px; border-style: solid; border-right-color: transparent; border-bottom-color: transparent; border-left-color: transparent; border-image: initial; border-top-color: var(--color-neutral-emphasis-plus); }

.svg-tip.left::after { left: 10%; }

.svg-tip.right::after { left: 90%; }

.svg-tip.comparison { padding: 0px; text-align: left; pointer-events: none; }

.svg-tip.comparison .title { display: block; padding: 8px; margin: 0px; font-weight: 600; line-height: 1; pointer-events: none; }

.svg-tip.comparison ul { padding: 4px 8px 8px; margin: 0px; white-space: nowrap; list-style: none; }

.svg-tip.comparison li { display: inline-block; padding-top: 16px; }

.svg-tip.comparison .metric-0, .svg-tip.comparison .metric-1 { position: relative; }

.svg-tip.comparison .metric-0::before, .svg-tip.comparison .metric-1::before { position: absolute; top: 0px; right: 0px; left: 0px; height: 4px; content: ""; border: 1px solid var(--color-border-default); border-radius: 6px; }

.svg-tip.comparison .metric-0::before { background-color: var(--color-success-emphasis); }

.svg-tip.comparison .metric-1::before { background-color: var(--color-accent-emphasis); }

.svg-tip-one-line { white-space: nowrap; }

.LoadingDependencies { position: absolute; left: 0px; width: 100%; animation: 0.6s ease-in 0s 1 normal forwards running fadeOut; }

.LoadingDependencies--loading { position: relative; }

.LoadingDependencies--loading .octicon { opacity: 0; animation: 1.25s linear 1s infinite normal forwards running dropBox; }

.LoadingDependencies--loading .octicon:nth-child(2) { position: absolute; left: calc(50% - 27px); animation-delay: 1.61s; }

@keyframes fadeOut { 
  0% { opacity: 1; }
  100% { opacity: 0; }
}

@keyframes dropBox { 
  0% { opacity: 1; transform: translateY(-110%); }
  7% { opacity: 1; transform: translateX(0px); }
  80% { opacity: 1; }
  100% { opacity: 0; transform: translateX(-250%); }
}

.team-breadcrumb .team-breadcrumb-item { display: inline-block; }

.team-breadcrumb .team-breadcrumb-item::after { padding-right: 0.5em; padding-left: 0.5em; color: var(--color-neutral-muted); content: "/"; }

.team-breadcrumb .team-breadcrumb-item-selected::after { content: none; }

.team-discussions-container { min-height: 100vh; }

.team-left-column { max-width: 100%; }

@media (min-width: 768px) {
  .team-left-column { max-width: 350px; }
}

.team-left-column .team-avatar { width: 80px; height: 80px; }

@media (min-width: 768px) {
  .team-left-column .team-avatar { width: 140px; height: 140px; }
}

.team-discussions { max-width: 768px; }

.team-discussions .previewable-comment-form .comment { border: 0px; }

.team-discussions .previewable-comment-form .toolbar-commenting.toolbar-commenting.toolbar-commenting { background: transparent; }

.team-discussions .previewable-comment-form .tabnav-tab.selected { background-color: var(--color-canvas-default); }

.discussion-post { opacity: 1; transition: opacity 400ms ease 0s; }

.discussion-post .timeline-comment::after, .discussion-post .timeline-comment::before { display: none; }

.discussion-post .post-author { margin-top: -6px; }

.discussion-post .post-author-timestamp { margin-top: -3px; }

.discussion-post.fade-out { opacity: 0; }

.discussion-post .timeline-inline-comments { background: var(--color-canvas-subtle); }

.discussion-post .team-discussion-timeline::before { bottom: 20px; }

.discussion-post .reply-comment:first-child { border-top: 1px solid var(--color-border-default); }

.discussion-post .reply-comment:first-child .review-comment { padding-top: 16px; }

.discussion-post .reply-comment .review-comment { padding: 8px 16px; }

.discussion-post .reply-comment .review-comment.is-comment-editing { padding: 0px; background: var(--color-canvas-subtle); }

.discussion-post .comment .comment-reactions { margin-left: 16px; border-top: 0px !important; }

.discussion-post .comment .reaction-summary-item { margin-bottom: 16px; }

.discussion-post .reaction-summary-item:not(.add-reaction-btn) { padding: 0px 8px; font-size: 12px; line-height: 26px; border: 1px solid var(--color-border-default, #d2dff0); border-radius: 6px; }

.discussion-post .reaction-summary-item:not(.add-reaction-btn) .emoji { font-size: 16px; vertical-align: sub; }

.discussion-post .reaction-summary-item:not(.add-reaction-btn) + .reaction-summary-item { margin-left: 8px; }

.discussion-post .reply-comments-holder { position: relative; }

.discussion-post .reply-comments-holder::before { position: absolute; top: 51px; bottom: 0px; left: 29px; width: 2px; content: ""; background-color: var(--color-border-muted); }

.discussion-post .add-reaction-btn { padding: 4px 10px; }

.discussion-post .pin-btn:disabled { pointer-events: none; }

.discussion-post .pinned { color: var(--color-severe-fg); opacity: 1; }

.discussion-post .loading-spinner { display: none; float: left; margin-top: 12px; }

.discussion-post .loading .loading-spinner { display: block; }

.discussion-post ~ .blankslate { display: none; }

.team-discussion-new-post .review-thread-reply-button:disabled { cursor: inherit; background-color: var(--color-canvas-subtle); border: 0px; box-shadow: none; }

.team-project-suggestion-number { font-weight: 300; color: rgb(163, 170, 177); }

.team-discussion-nav-disabled { pointer-events: none; }

.team-group-mapping-search-results .select-menu-loading { display: inherit; }

.team-group-mapping-search-results .select-menu-error { display: none; }

.team-group-mapping-search-results.is-error .select-menu-loading { display: none; }

.team-group-mapping-search-results.is-error .select-menu-error { display: inherit; }

.external-group-search-results .select-menu-loading { display: inherit; }

.external-group-search-results .select-menu-error { display: none; }

.external-group-search-results.is-error .select-menu-loading { display: none; }

.external-group-search-results.is-error .select-menu-error { display: inherit; }

.review_assignment_toggler > .assignment_form { display: none; }

.review_assignment_toggler.on > .assignment_form { display: block; }

.team-member-exclusion-toggler > .member-exclusion { display: none; }

.team-member-exclusion-toggler.on > .member-exclusion { display: block; }

.hooks-listing .boxed-group-action.select-menu { z-index: auto; }

.hooks-listing .boxed-group-inner { padding: 0px 10px; margin-bottom: 10px; }

.hook-item a:hover { text-decoration: none; }

.hook-item .item-status { float: left; width: 16px; margin-right: 8px; text-align: center; }

.hook-item .description { color: var(--color-fg-muted); }

.hook-item .description .css-truncate-target { max-width: 160px; }

.hook-item .icon-for-success, .hook-item .icon-for-failure, .hook-item .icon-for-pending, .hook-item .icon-for-inactive { display: none; }

.hook-item.success .icon-for-success { display: inline-block; color: var(--color-success-fg); }

.hook-item.failure .icon-for-failure { display: inline-block; color: var(--color-danger-fg); }

.hook-item.pending .icon-for-pending { display: inline-block; color: var(--color-fg-muted); }

.hook-item.inactive .icon-for-inactive { display: inline-block; color: var(--color-fg-muted); }

.hook-item .icon-for-enabled, .hook-item .icon-for-disabled { display: none; }

.hook-item.enabled .icon-for-enabled { display: inline-block; color: var(--color-success-fg); }

.hook-item.disabled .icon-for-disabled { display: inline-block; color: var(--color-fg-muted); }

.hook-item .hook-error-message { margin-left: 24px; color: var(--color-danger-fg); }

.hook-url.css-truncate-target { max-width: 360px; }

.hook-events-field .hook-event-selector { display: none; }

.hook-events-field.is-custom .hook-event-selector { display: block; }

.hook-event-selector { margin-left: 10px; }

.hook-event { display: inline-block; width: 310px; padding: 5px 0px 5px 30px; margin: 0px; }

.hook-event p { font-weight: 400; }

.hook-event-choice { font-weight: 400; }

.hooks-oap-warning { margin-top: 0px; }

.hooks-oap-warning ul { margin: 10px 0px; }

.hooks-oap-warning ul li { margin-left: 16px; }

.hook-deliveries-list .spinner { display: inline-block; margin: 0px; vertical-align: top; }

.hook-deliveries-list .hook-delivery-item:hover { background-color: transparent; }

.hook-deliveries-list .item-status { display: inline-block; width: 16px; margin-right: 5px; text-align: center; }

.hook-deliveries-list .item-status .icon-for-success, .hook-deliveries-list .item-status .icon-for-failure, .hook-deliveries-list .item-status .icon-for-pending { display: none; }

.hook-deliveries-list .item-status.success { color: var(--color-success-fg); visibility: visible; }

.hook-deliveries-list .item-status.success .icon-for-success { display: inline-block; }

.hook-deliveries-list .item-status.failure { color: var(--color-danger-fg); }

.hook-deliveries-list .item-status.failure .icon-for-failure { display: inline-block; }

.hook-deliveries-list .item-status.pending { color: var(--color-fg-muted); }

.hook-deliveries-list .item-status.pending .icon-for-pending { display: inline-block; }

.boxed-group-list li.hook-delivery-item { padding: 10px; }

.hook-delivery-time { float: right; margin-right: 10px; font-size: 10px; color: var(--color-fg-muted); }

.hook-delivery-guid { display: inline-block; padding: 2px 6px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 12px; color: var(--color-fg-muted); background-color: var(--color-accent-subtle); border-radius: 6px; }

.hook-delivery-guid .octicon { margin: 1px -2px 0px 0px; color: var(--color-fg-muted); }

.hook-delivery-actions { padding-top: 1px; }

.boxed-group-list > li.hook-delivery-item .btn-sm { margin: 0px; }

.hook-delivery-container hr { margin: 10px 0px; }

.hook-delivery-container pre { padding: 7px 12px; margin: 10px 0px; overflow: auto; font-size: 13px; line-height: 1.5; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); border-radius: 6px; }

.hook-delivery-container .tabnav { margin: 10px 0px; }

.hook-delivery-container h4.remote-call-header { margin: 20px 0px 10px; border-bottom: 1px solid var(--color-border-default); }

.hook-delivery-response-status { display: inline-block; padding: 4px 6px 3px; margin-left: 4px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 10px; line-height: 1.1; color: var(--color-fg-on-emphasis); background-color: var(--color-danger-emphasis); border: 1px solid transparent; border-radius: 6px; }

.hook-delivery-response-status[data-response-status^="2"] { background-color: var(--color-success-emphasis); }

.redelivery-dialog .pending-message { display: block; }

.redelivery-dialog .failure-message { display: none; }

.redelivery-dialog.failed { color: var(--color-danger-fg); background-color: var(--color-danger-subtle); border-color: var(--color-danger-emphasis); }

.redelivery-dialog.failed .pending-message { display: none; }

.redelivery-dialog.failed .failure-message { display: block; }

.item-name { float: left; font-weight: 600; }

.hovercard-icon { width: 16px; }

.integration-meta-head { font-size: 16px; color: var(--color-fg-muted); }

.integrations-select-repos { max-height: 138px; overflow-y: scroll; border-radius: 6px; }

.integrations-select-repos .mini-repo-list-item { padding: 8px 64px 8px 30px; }

.integrations-select-repos .mini-repo-list-item:hover .repo, .integrations-select-repos .mini-repo-list-item:hover .owner { text-decoration: none; }

.integrations-select-repos .mini-repo-list-item .css-truncate-target { max-width: 345px; }

.integrations-select-repos::-webkit-scrollbar { width: 10px; }

.integrations-select-repos::-webkit-scrollbar-thumb { background-color: rgba(0, 0, 0, 0.5); border: solid var(--color-canvas-default) 2px; border-radius: 6px; box-shadow: rgba(255, 255, 255, 0.5) 0px 0px 1px; }

.integrations-select-repos::-webkit-scrollbar-track-piece { background: transparent; }

.integrations-repository-picker { width: 440px; }

.target-avatar { position: relative; top: -2px; }

.issue-list-item + .issue-list-item { border-top: solid 1px var(--color-border-muted); }

.pinned-issue-item .pinned-issue-handle { cursor: grab; }

.pinned-issue-item.is-dragging, .pinned-issue-item.is-dragging .pinned-issue-handle { cursor: grabbing; }

.pinned-issue-item.is-dragging { background-color: var(--color-accent-subtle); }

.pinned-issue-item.sortable-ghost { background-color: var(--color-accent-subtle); opacity: 0; }

.issues-reset-query-wrapper { margin-bottom: 20px; }

.label-link:hover { text-decoration: none; }

.issues-reset-query { font-weight: 600; color: var(--color-fg-muted); }

.issues-reset-query:hover { color: var(--color-accent-fg); text-decoration: none; }

.issues-reset-query:hover .issues-reset-query-icon { background-color: var(--color-accent-emphasis); }

.issues-reset-query-icon { width: 18px; height: 18px; padding: 1px; margin-right: 3px; color: var(--color-fg-on-emphasis); text-align: center; background-color: var(--color-neutral-emphasis); border-radius: 6px; }

.table-list-milestones .stats { gap: 0px 15px; }

.table-list-milestones .table-list-cell { padding: 15px 20px; }

.table-list-milestones .stat { display: inline-block; font-size: 14px; font-weight: 600; line-height: 1.2; color: var(--color-fg-muted); white-space: nowrap; }

.table-list-milestones .stat a { color: inherit; }

.table-list-milestones .stat-label { font-weight: 400; color: var(--color-fg-muted); }

.milestone-title { width: 500px; }

.milestone-title-link { margin-top: 0px; margin-bottom: 5px; font-size: 24px; font-weight: 400; line-height: 1.2; }

.milestone-title-link a { color: var(--color-fg-default, #333); }

.milestone-title-link a:hover { color: var(--color-accent-fg); }

.milestone-progress { width: auto; max-width: 420px; }

.milestone-progress .progress-bar { margin-top: 7px; margin-bottom: 12px; }

.milestone-meta { font-size: 14px; }

.milestone-meta-item { display: inline-block; margin-right: 10px; }

.milestone-meta-item .octicon { width: 16px; text-align: center; }

.milestone-description-html { display: none; }

.milestone-description { margin-top: 5px; }

.milestone-description .expand-more { color: var(--color-accent-fg); cursor: pointer; }

.milestone-description .expand-more:hover { text-decoration: underline; }

.milestone-description.open .milestone-description-plaintext { display: none; }

.milestone-description.open .milestone-description-html { display: block; }

.milestones-flexbox-gap { gap: 10px; }

.issue-reorder-warning { z-index: 110; }

.task-progress { color: var(--color-fg-muted); text-decoration: none; vertical-align: top; }

.task-progress .octicon { margin-right: 5px; color: var(--color-fg-muted, #999); vertical-align: bottom; }

.task-progress .progress-bar { display: inline-block; width: 80px; height: 5px; vertical-align: 2px; background-color: var(--color-neutral-muted); }

.task-progress .progress-bar .progress { background-color: var(--color-border-default); }

.task-progress-counts { display: inline-block; margin-right: 6px; margin-left: -2px; font-size: 12px; }

a.task-progress:hover { color: var(--color-accent-fg); }

a.task-progress:hover .octicon { color: inherit; }

a.task-progress:hover .progress-bar .progress { background-color: var(--color-accent-emphasis); }

.issue-meta-section .octicon { color: var(--color-fg-muted, #ccc); vertical-align: bottom; }

.issue-milestone { max-width: 240px; }

.issue-milestone .css-truncate-target { max-width: 100px; }

.milestone-link .octicon { font-size: 14px; }

.milestone-link:hover .octicon { color: inherit; }

.new-pr-form { margin-top: 15px; margin-bottom: 20px; }

.new-pr-form::before { display: table; content: ""; }

.new-pr-form::after { display: table; clear: both; content: ""; }

.new-pr-form .discussion-timeline::before { display: none; }

.label-select-menu .description { margin-left: 19px; }

.label-select-menu .color { display: inline-block; width: 14px; height: 14px; margin-top: -1px; margin-right: 2px; vertical-align: middle; border-radius: 7px; }

.label-select-menu [aria-checked="true"] .select-menu-item-icon, .label-select-menu [aria-checked="mixed"] .select-menu-item-icon, .label-select-menu .selected .select-menu-item-icon { color: inherit !important; }

.label-select-menu [aria-checked="true"] .octicon-circle-slash, .label-select-menu [aria-checked="mixed"] .octicon-circle-slash, .label-select-menu .selected .octicon-circle-slash { color: var(--color-fg-muted); }

.label-select-menu [aria-checked="true"]:active, .label-select-menu [aria-checked="mixed"]:active, .label-select-menu .selected:active { background-color: transparent !important; }

.label-select-menu .select-menu-item { position: relative; }

.label-select-menu .select-menu-item:hover, .label-select-menu .select-menu-item:focus, .label-select-menu .select-menu-item[aria-selected="true"], .label-select-menu .select-menu-item.navigation-focus { color: inherit; background-color: var(--color-neutral-subtle); }

.label-select-menu .select-menu-item:hover .select-menu-item-icon, .label-select-menu .select-menu-item:focus .select-menu-item-icon, .label-select-menu .select-menu-item[aria-selected="true"] .select-menu-item-icon, .label-select-menu .select-menu-item.navigation-focus .select-menu-item-icon { color: transparent; }

.label-select-menu .select-menu-item:hover .label-options-icon, .label-select-menu .select-menu-item:focus .label-options-icon, .label-select-menu .select-menu-item[aria-selected="true"] .label-options-icon, .label-select-menu .select-menu-item.navigation-focus .label-options-icon { color: inherit; }

.label-select-menu > form { position: relative; }

.subnav .btn + .issues-search { padding-right: 10px; border-right: 1px solid var(--color-border-muted); }

.reaction-sort-item { float: left; width: 39px; padding: 5px; margin-top: 5px; text-align: center; pointer-events: all; border: 1px solid transparent; border-radius: 6px; opacity: 0.7; }

.reaction-sort-item:focus, .reaction-sort-item:hover { text-decoration: none; background-color: var(--color-accent-emphasis); opacity: 1; }

.reaction-sort-item[aria-checked="true"] { background-color: var(--color-accent-subtle); border-color: var(--color-accent-emphasis); opacity: 1; }

.issue-keyword { border-bottom: 1px dotted var(--color-border-default); }

.issue-keyword:hover { border-bottom: 0px; }

.new-label-color-dimensions { width: 24px; height: 24px; }

.select-menu-item[aria-selected="true"] > .octicon.label-options-icon, .select-menu-item.navigation-focus > .octicon.label-options-icon { color: var(--color-fg-default); }

.new-label-color-input:invalid { color: var(--color-danger-fg); }

.issue-form-textarea { height: 100px !important; min-height: 100px !important; }

.issue-forms-wysiwyg-container .comment-form-head { background: var(--color-canvas-subtle)  !important; }

.issue-forms-wysiwyg-container .comment-body { border-bottom: 0px !important; }

.issue-form-body > :first-child { margin-top: 0px !important; }

.repository-lang-stats { position: relative; }

.repository-lang-stats ol.repository-lang-stats-numbers li { display: table-cell; width: 1%; padding: 10px 5px; text-align: center; white-space: nowrap; border-bottom: 0px; }

.repository-lang-stats ol.repository-lang-stats-numbers li span.percent { float: none; }

.repository-lang-stats ol.repository-lang-stats-numbers li > a, .repository-lang-stats ol.repository-lang-stats-numbers li > span { font-weight: 600; color: var(--color-fg-muted); text-decoration: none; }

.repository-lang-stats ol.repository-lang-stats-numbers li .lang { color: var(--color-fg-default); }

.repository-lang-stats ol.repository-lang-stats-numbers li .language-color { display: inline-block; width: 10px; height: 10px; border-radius: 50%; }

.repository-lang-stats ol.repository-lang-stats-numbers li a:hover { background: transparent; }

.repository-lang-stats-graph { width: 100%; overflow: hidden; white-space: nowrap; cursor: pointer; user-select: none; border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: ; border-bottom-width: ; border-left-color: ; border-left-style: ; border-left-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-top: 0px; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.repository-lang-stats-graph .language-color { line-height: 8px; text-indent: -9999px; }

.repository-lang-stats-graph .language-color:first-child { border-bottom-left-radius: 6px; }

.repository-lang-stats-graph .language-color:last-child { border-bottom-right-radius: 6px; }

.repository-lang-stats-graph .language-color:not(:first-child) { border-left: 1px solid var(--color-canvas-default); }

.facebox-loading, .octocat-spinner { min-height: 64px; background-image: url("/images/spinners/octocat-spinner-64.gif"); background-repeat: no-repeat; background-position: center center; }

.octocat-spinner-32 { min-height: 32px; background-image: url("/images/spinners/octocat-spinner-32.gif"); background-repeat: no-repeat; background-position: center center; }

@media only screen and (-webkit-min-device-pixel-ratio: 2), not all, not all, not all, only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
  .facebox-loading, .octocat-spinner { background-image: url("/images/spinners/octocat-spinner-128.gif"); background-size: 64px 64px; }
  .octocat-spinner-32 { background-image: url("/images/spinners/octocat-spinner-64.gif"); background-size: 32px 32px; }
}

.map-container .activity { top: 120px; left: 340px; z-index: 99999; }

.map-container .is-graph-loading .activity { display: block; }

.map { height: 350px; }

.map-background { pointer-events: all; fill: rgb(3, 102, 214); }

.map-background-zoom { cursor: grab; }

.map-land { fill: none; stroke: rgb(37, 106, 174); stroke-width: 2; shape-rendering: crispedges; }

.map-country { fill: rgb(215, 199, 173); shape-rendering: crispedges; cursor: pointer; }

.map-country.hk { stroke: rgb(165, 150, 126); }

.map-country:hover { fill: rgb(200, 178, 142); }

.map-country.active { fill: rgb(246, 229, 202); }

.map-borders { fill: none; stroke: rgb(165, 150, 126); shape-rendering: crispedges; }

.map-graticule { pointer-events: none; fill: none; stroke: rgb(255, 255, 255); stroke-opacity: 0.2; shape-rendering: crispedges; }

.map-graticule :nth-child(2n) { stroke-dasharray: 2, 2; }

.map-legend .map-legend-circle { fill-opacity: 0; stroke: rgb(255, 255, 255); stroke-width: 1.5; }

.map-legend .map-legend-text { font-size: 10px; fill: rgb(255, 255, 255); text-anchor: end; }

.map-legend .map-legend-link { stroke: rgb(255, 255, 255); stroke-width: 1.5; }

.map-point { pointer-events: none; fill: rgb(246, 106, 10); }

.map-point:hover { fill: rgb(227, 98, 9); }

.map-country-info { top: 8px; right: 8px; pointer-events: none; opacity: 0; }

.MarketplaceJumbotron { background-color: var(--color-neutral-emphasis); background-image: url("/images/modules/marketplace/bg-hero.svg"); background-repeat: repeat-y; background-position: center top; background-size: 150%; }

@media (min-width: 768px) {
  .MarketplaceJumbotron { background-repeat: no-repeat; background-size: cover; }
}

.CircleBadge--feature { position: relative; top: 0px; transition: top 0.15s ease-in 0s, box-shadow 0.12s ease-in 0s; }

.MarketplaceFeature { min-width: 250px; }

.MarketplaceFeature-text { opacity: 0.7; transition: opacity 0.12s ease-in 0s; }

.MarketplaceFeature-link:hover .CircleBadge--feature { top: -3px; box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 8px 0px; }

.MarketplaceFeature-link:hover .MarketplaceFeature-text { opacity: 1; }

.MarketplaceFeature-link:active .CircleBadge--feature { top: 0px; }

.MarketplaceSideNav { background-color: var(--color-canvas-subtle); }

@media (min-width: 768px) {
  .MarketplaceSideNav { background-color: var(--color-canvas-default); border-right: 1px solid var(--color-border-default); }
}

.ScreenshotCarousel { border: 1px solid var(--color-border-default); border-radius: 6px; }

.ScreenshotCarousel-screenshot { padding: 16px; }

.ScreenshotCarousel-nav { display: flex; overflow-x: auto; box-shadow: inset 0 1px 0 var(--color-border-default); }

.ScreenshotCarousel-navitem { width: 20%; min-width: 120px; padding: 16px; cursor: pointer; border-right: 1px solid var(--color-border-default); }

.ScreenshotCarousel-navitem:last-child { border-right: 0px; }

.ScreenshotCarousel-navitem.selected { background-color: var(--color-canvas-subtle); box-shadow: rgba(36, 41, 46, 0.15) 0px 0px 4px inset; }

.marketplace-listing-screenshot-container { width: 175px; min-height: 175px; background-repeat: no-repeat; background-position: center center; background-size: cover; }

.marketplace-listing-screenshot-zoom { display: none; cursor: move; }

.marketplace-listing-details-sidebar { order: 2; }

@media (min-width: 768px) {
  .marketplace-listing-details-sidebar { order: 1; }
}

.marketplace-listing-details-description { order: 1; }

@media (min-width: 768px) {
  .marketplace-listing-details-description { order: 2; }
}

.marketplace-listing-screenshot-link { height: 100px; cursor: move; }

.marketplace-listing-screenshot-link:hover .marketplace-listing-screenshot-zoom, .marketplace-listing-screenshot-link:focus .marketplace-listing-screenshot-zoom { top: 0px; left: 0px; display: block; width: 100%; height: 100%; padding-top: 28px; background-color: rgba(255, 255, 255, 0.75); }

.marketplace-integratable-logo { width: 40px; height: 40px; }

.marketplace-listing-save-notice, .marketplace-listing-save-error { display: none; opacity: 0; transition: opacity 0.15s linear 0s; }

.marketplace-listing-save-notice.visible, .marketplace-listing-save-error.visible { display: inline-block; opacity: 1; }

.marketplace-listing-screenshot-delete-form { position: absolute; bottom: -24px; width: 100%; text-align: center; }

.marketplace-plan-dollar-field-container .price-note { display: none; }

.marketplace-plan-dollar-field-container.is-errored .price-note { display: block; }

.marketplace-plan-dollar-field-container.is-errored .form-control { border-color: var(--color-danger-emphasis); }

.marketplace-plan-emphasis { color: var(--color-fg-default); }

.selected .marketplace-plan-emphasis { color: var(--color-fg-on-emphasis); }

.marketplace-plan-unit-name-preview::before { content: "per "; }

.marketplace-plan-per-time { clear: right; }

.marketplace-billing-modal { width: 540px; max-height: 90vh; margin-top: 5vh; }

.marketplace-listing-markdown, .marketplace-url-link { overflow-wrap: break-word; white-space: pre-wrap; }

.marketplace-listing-markdown { line-height: 1.4; }

.marketplace-product-callout { border-color: var(--color-border-default)  !important; }

.marketplace-product-callout::before, .marketplace-product-callout::after { display: none; }

.marketplace-product-callout .branch-action-item-icon { color: var(--color-fg-muted); background-color: var(--color-canvas-subtle); }

.filter-item.selected .Label--secondary { color: var(--color-fg-on-emphasis); border-color: var(--color-fg-on-emphasis); }

.MarketplaceEdit-body { min-height: 570px; }

.MarketplaceEdit-body .pricing-model-selector { width: calc(100% - 12px); max-width: 100% !important; }

.MarketplaceEdit-body .menu { border-right: 0px; border-left: 0px; border-radius: 0px; }

.MarketplaceEdit-body .menu-item { padding: 12px 16px; background: var(--color-canvas-subtle); }

.MarketplaceEdit-body .menu-item.selected { background: var(--color-canvas-default); }

.MarketplaceEdit-body .menu-item:hover { background: var(--color-canvas-subtle); }

.MarketplaceEdit-body .menu-item.selected::before { position: absolute; top: 0px; bottom: 0px; left: 0px; width: 3px; content: ""; background-color: var(--color-severe-emphasis); }

.MarketplaceEdit-body .menu-item:first-child::before { border-top-left-radius: 0px; }

.MarketplaceEdit-body .CircleIcon { display: inline-block; width: 32px; height: 32px; font-weight: 600; line-height: 32px; color: var(--color-fg-muted); text-align: center; background: rgb(230, 235, 241); border-radius: 50%; }

.MarketplaceEdit-body .CircleIcon .octicon { display: inline-block; }

.MarketplaceInsights-graph .insights-month .tick:nth-child(2n) { visibility: hidden; }

.BarChart { border-radius: 6px; }

.BarChart-bar { height: 10px; border-right: 1px solid var(--color-canvas-default); }

.BarChart-bar--green { background-color: var(--color-success-emphasis); }

.BarChart-bar--orange { background-color: var(--color-severe-emphasis); }

.BarChart-bar--yellow { background-color: var(--color-attention-emphasis); }

.CircleBadge--tiny { width: 32px; height: 32px; }

.CircleBadge--github { position: relative; }

.CircleBadge--github.CircleBadge--large::after { right: 5px; bottom: 5px; }

.CircleBadge--github.CircleBadge--small::after { right: -5px; bottom: -5px; }

.CircleBadge--github::after { position: absolute; right: 0px; bottom: 0px; display: block; width: 22px; height: 22px; padding: 3px; line-height: 0; content: ""; background: var(--color-canvas-default) url("data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c3ZnIHdpZHRoPSIyMnB4IiBoZWlnaHQ9IjIycHgiIHZpZXdCb3g9IjAgMCAyMiAyMiIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4gICAgICAgIDx0aXRsZT5TaGFwZSBDb3B5PC90aXRsZT4gICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+ICAgIDxkZWZzPjwvZGVmcz4gICAgPGcgaWQ9IktpdGNoZW4tc2luayIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+ICAgICAgICA8ZyBpZD0iT2N0aWNvbnMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNzAuMDAwMDAwLCAtMTU4NC4wMDAwMDApIiBmaWxsPSIjMUIxRjIzIj4gICAgICAgICAgICA8cGF0aCBkPSJNMzgxLDE1ODQgQzM3NC45MjI1LDE1ODQgMzcwLDE1ODguOTIyNSAzNzAsMTU5NSBDMzcwLDE1OTkuODY3NSAzNzMuMTQ4NzUsMTYwMy45Nzg3NSAzNzcuNTIxMjUsMTYwNS40MzYyNSBDMzc4LjA3MTI1LDE2MDUuNTMyNSAzNzguMjc3NSwxNjA1LjIwMjUgMzc4LjI3NzUsMTYwNC45MTM3NSBDMzc4LjI3NzUsMTYwNC42NTI1IDM3OC4yNjM3NSwxNjAzLjc4NjI1IDM3OC4yNjM3NSwxNjAyLjg2NSBDMzc1LjUsMTYwMy4zNzM3NSAzNzQuNzg1LDE2MDIuMTkxMjUgMzc0LjU2NSwxNjAxLjU3MjUgQzM3NC40NDEyNSwxNjAxLjI1NjI1IDM3My45MDUsMTYwMC4yOCAzNzMuNDM3NSwxNjAwLjAxODc1IEMzNzMuMDUyNSwxNTk5LjgxMjUgMzcyLjUwMjUsMTU5OS4zMDM3NSAzNzMuNDIzNzUsMTU5OS4yOSBDMzc0LjI5LDE1OTkuMjc2MjUgMzc0LjkwODc1LDE2MDAuMDg3NSAzNzUuMTE1LDE2MDAuNDE3NSBDMzc2LjEwNSwxNjAyLjA4MTI1IDM3Ny42ODYyNSwxNjAxLjYxMzc1IDM3OC4zMTg3NSwxNjAxLjMyNSBDMzc4LjQxNSwxNjAwLjYxIDM3OC43MDM3NSwxNjAwLjEyODc1IDM3OS4wMiwxNTk5Ljg1Mzc1IEMzNzYuNTcyNSwxNTk5LjU3ODc1IDM3NC4wMTUsMTU5OC42MyAzNzQuMDE1LDE1OTQuNDIyNSBDMzc0LjAxNSwxNTkzLjIyNjI1IDM3NC40NDEyNSwxNTkyLjIzNjI1IDM3NS4xNDI1LDE1OTEuNDY2MjUgQzM3NS4wMzI1LDE1OTEuMTkxMjUgMzc0LjY0NzUsMTU5MC4wNjM3NSAzNzUuMjUyNSwxNTg4LjU1MTI1IEMzNzUuMjUyNSwxNTg4LjU1MTI1IDM3Ni4xNzM3NSwxNTg4LjI2MjUgMzc4LjI3NzUsMTU4OS42Nzg3NSBDMzc5LjE1NzUsMTU4OS40MzEyNSAzODAuMDkyNSwxNTg5LjMwNzUgMzgxLjAyNzUsMTU4OS4zMDc1IEMzODEuOTYyNSwxNTg5LjMwNzUgMzgyLjg5NzUsMTU4OS40MzEyNSAzODMuNzc3NSwxNTg5LjY3ODc1IEMzODUuODgxMjUsMTU4OC4yNDg3NSAzODYuODAyNSwxNTg4LjU1MTI1IDM4Ni44MDI1LDE1ODguNTUxMjUgQzM4Ny40MDc1LDE1OTAuMDYzNzUgMzg3LjAyMjUsMTU5MS4xOTEyNSAzODYuOTEyNSwxNTkxLjQ2NjI1IEMzODcuNjEzNzUsMTU5Mi4yMzYyNSAzODguMDQsMTU5My4yMTI1IDM4OC4wNCwxNTk0LjQyMjUgQzM4OC4wNCwxNTk4LjY0Mzc1IDM4NS40Njg3NSwxNTk5LjU3ODc1IDM4My4wMjEyNSwxNTk5Ljg1Mzc1IEMzODMuNDIsMTYwMC4xOTc1IDM4My43NjM3NSwxNjAwLjg1NzUgMzgzLjc2Mzc1LDE2MDEuODg4NzUgQzM4My43NjM3NSwxNjAzLjM2IDM4My43NSwxNjA0LjU0MjUgMzgzLjc1LDE2MDQuOTEzNzUgQzM4My43NSwxNjA1LjIwMjUgMzgzLjk1NjI1LDE2MDUuNTQ2MjUgMzg0LjUwNjI1LDE2MDUuNDM2MjUgQzM4OC44NTEyNSwxNjAzLjk3ODc1IDM5MiwxNTk5Ljg1Mzc1IDM5MiwxNTk1IEMzOTIsMTU4OC45MjI1IDM4Ny4wNzc1LDE1ODQgMzgxLDE1ODQgTDM4MSwxNTg0IFoiIGlkPSJTaGFwZS1Db3B5Ij48L3BhdGg+ICAgICAgICA8L2c+ICAgIDwvZz48L3N2Zz4=") center no-repeat; border-radius: 100px; }

body.page-responsive .flash-full .container { width: 100%; max-width: 980px; }

.ClipboardButton { position: relative; }

.ClipboardButton.ClipboardButton--success { border-color: var(--color-success-emphasis); box-shadow: rgba(52, 208, 88, 0.4) 0px 0px 0px 0.2em; }

.ClipboardButton.ClipboardButton--success:focus { box-shadow: rgba(52, 208, 88, 0.4) 0px 0px 0px 0.2em; }

@media (min-width: 768px) {
  .MarketplacePlan--sticky { position: sticky; top: 24px; z-index: 999; }
}

@media (max-width: 544px) {
  .Box--full { right: 0px; bottom: 0px; left: 0px; width: 100%; max-width: none; max-height: none; margin: 0px; border-radius: 0px; transform: none; }
}

.MarketplaceBackground-wrapper { position: relative; }

.MarketplaceBackground-recommendations { position: relative; top: -90px; width: 313px; margin-top: -150px; margin-bottom: -120px; overflow: hidden; }

.MarketplaceBackground-recommendations img { position: relative; top: 0px; right: 225px; width: 549px; }

@media (min-width: 544px) {
  .MarketplaceBackground-recommendations { position: relative; width: 463px; margin-top: -180px; margin-bottom: 70px; overflow: hidden; }
  .MarketplaceBackground-recommendations img { right: 305px; width: 730px; }
}

@media (min-width: 768px) {
  .MarketplaceBackground-recommendations { position: absolute; top: -228px; right: -69px; width: 633px; }
  .MarketplaceBackground-recommendations img { right: 195px; width: 750px; }
}

@media (min-width: 1012px) {
  .MarketplaceBackground-recommendations { top: -268px; right: 0px; width: 1040px; }
  .MarketplaceBackground-recommendations img { right: -115px; width: 900px; }
}

@media (min-width: 1280px) {
  .MarketplaceBackground-recommendations { top: -325px; right: 105px; width: 1040px; }
  .MarketplaceBackground-recommendations img { right: 0px; width: 1040px; }
}

.MarketplaceBackground-buffer { padding-top: 40px; margin-top: -146px; background: var(--color-canvas-subtle); }

@media (min-width: 544px) {
  .MarketplaceBackground-buffer { padding-top: 120px; margin-top: -233px; }
}

@media (min-width: 768px) {
  .MarketplaceBackground-buffer { margin-top: -109px; }
}

@media (min-width: 1012px) {
  .MarketplaceBackground-buffer { margin-top: -89px; }
}

.MarketplaceHeader { overflow: hidden; }

.Link--muted.filter-item.selected { color: var(--color-fg-on-emphasis)  !important; }

.MarketplaceBody { position: relative; }

@media (min-width: 544px) {
  .MarketplaceBody { top: -72px; z-index: 2; }
}

.MarketplaceDetails .octicon { transition: transform 200ms linear 0s; transform: scaleY(1); }

.MarketplaceDetails[open] .octicon { transform: scaleY(-1); }

.MarketplaceAnnouncement { color: rgb(255, 255, 255); background: linear-gradient(90deg, rgb(37, 123, 249), rgb(36, 38, 202)); }

.MarketplaceAnnouncement-icon { width: 80px; opacity: 0.9; }

.MarketplaceAnnouncement-description { opacity: 0.7; }

.member-list-item .table-list-cell-checkbox { width: 30px; }

.member-list-item.adminable .member-info { padding-left: 5px; }

.member-list-item .member-avatar-cell { width: 64px; }

.member-meta .select-menu-modal { width: 310px; }

.member-meta .select-menu-modal-holder { right: 0px; text-align: left; }

.triage-mode .none-selected { display: none; }

.merge-branch-heading { margin: 0px; line-height: 1; color: var(--color-fg-default); }

.merge-branch-description { margin-right: 160px; margin-bottom: -5px; line-height: 1.6em; color: var(--color-fg-muted); }

.alt-merge-options { display: inline-block; margin-bottom: 0px; margin-left: 4px; vertical-align: middle; }

.merged .merge-branch-description .commit-ref .css-truncate-target { max-width: 180px; }

.merge-branch-prh-output { margin-top: 10px; }

.merge-branch-form, .queue-branch-form { display: none; padding-left: 60px; }

.merge-branch-manually { display: none; padding-top: 16px; margin-top: 16px; background-color: transparent; border-top: 1px solid var(--color-border-default); }

.merge-branch-manually p { margin-bottom: 0px; }

.merge-branch-manually h3 { margin-bottom: 10px; }

.merge-branch-manually .intro { padding-bottom: 10px; margin-top: 0px; }

.merge-branch-manually .step { margin: 15px 0px 5px; }

.open .merge-branch-manually { display: block; }

.select-menu-merge-method { width: 310px; }

.select-menu-merge-method .select-menu-item:hover, .select-menu-merge-method .select-menu-item:hover .octicon, .select-menu-merge-method .select-menu-item:hover .select-menu-item-text { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.select-menu-merge-method .select-menu-item:hover .description { color: var(--color-fg-on-emphasis); }

.merge-pr.is-squashing .commit-author-fields { display: none; }

.merge-pr.is-rebasing .commit-form-fields { display: none; transition: opacity 0.15s linear 0s, margin-top 0.25s ease 0.1s; }

.merge-pr .btn-group-merge, .merge-pr .btn-group-merge-group, .merge-pr .merge-queue-info, .merge-pr .merge-queue-group-time-to-merge, .merge-pr.is-squashing .btn-group-squash, .merge-pr.is-rebasing .btn-group-rebase, .merge-pr.is-updating-via-merge .btn-group-update-merge, .merge-pr.is-updating-via-rebase .btn-group-update-rebase, .merge-pr.is-merging-solo .btn-group-merge-solo, .merge-pr.is-merging-solo .merge-queue-solo-time-to-merge, .merge-pr.is-merging-jump .btn-group-merge-jump, .merge-pr.is-merging-group .btn-group-merge-group, .merge-pr.is-merging .btn-group-merge-directly, .merge-pr.is-merging .merging-directly-warning { display: inline-block; }

.merge-pr .merging-body, .merge-pr .rebasing-body, .merge-pr .squashing-body, .merge-pr .merging-body-merge-warning, .merge-pr .merging-directly-warning, .merge-pr.is-merging .merge-queue-info, .merge-pr.is-merging-group .merge-queue-solo-time-to-merge, .merge-pr.is-merging-solo .merge-queue-group-time-to-merge, .merge-pr.is-merging .branch-action-state-error-if-merging .merging-body { display: none; }

.merge-pr.is-merging .merging-body, .merge-pr.is-merging-solo .merging-body, .merge-pr.is-merging-jump .merging-body, .merge-pr.is-merging-group .merging-body, .merge-pr.is-rebasing .rebasing-body, .merge-pr.is-squashing .squashing-body, .merge-pr.is-merging .branch-action-state-error-if-merging .merging-body-merge-warning { display: block; }

.merge-pr .btn-group-squash, .merge-pr .btn-group-merge-solo, .merge-pr .btn-group-merge-jump, .merge-pr .btn-group-merge-directly, .merge-pr .btn-group-rebase, .merge-pr .btn-group-update-merge, .merge-pr .btn-group-update-rebase, .merge-pr.is-squashing .btn-group-merge, .merge-pr.is-rebasing .btn-group-merge, .merge-pr.is-merging-solo .btn-group-merge-group, .merge-pr.is-merging-jump .btn-group-merge-group, .merge-pr.is-merging .btn-group-merge-group { display: none; margin-left: 0px; }

.commit-form-fields { transition: opacity 0.15s linear 0.1s, margin-top 0.25s ease 0s; }

.unavailable-merge-method { display: block; margin-top: 6px; color: var(--color-severe-fg); }

[aria-selected="true"].disabled .unavailable-merge-method, .navigation-focus.disabled .unavailable-merge-method { color: var(--color-fg-on-emphasis); }

.network .network-tree { vertical-align: middle; }

.network .gravatar { margin-right: 4px; vertical-align: middle; border-radius: 6px; }

.network .octicon { display: inline-block; width: 16px; margin-left: 2px; text-align: center; vertical-align: middle; }

.internal-repo-avatar { right: 4px; bottom: -4px; border: solid 2px var(--color-canvas-default); }

.owner-reponame dl.form-group { margin-top: 5px; margin-bottom: 0px; }

.owner-reponame .slash { float: left; padding-top: 32px; margin: 0px 8px; font-size: 21px; color: var(--color-fg-muted); }

.reponame-suggestion { color: var(--color-success-fg); cursor: pointer; }

.upgrade-upsell { padding-left: 33px; }

.cc-upgrade { padding-left: 20px; }

.news .release { margin-top: 0px; margin-bottom: 0px; }

.news blockquote { color: var(--color-fg-muted); }

.news h1 { margin-bottom: 0px; }

.news .alert { position: relative; padding: 0px 0px 1em 45px; overflow: hidden; border-top: 1px solid rgb(239, 243, 246); }

.news .alert .commits { padding-left: 40px; }

.news .alert .css-truncate.css-truncate-target, .news .alert .css-truncate .css-truncate-target { max-width: 180px; }

.news .alert p { margin: 0px; }

.news .alert .markdown-body blockquote { padding: 0px 0px 0px 40px; border-width: 0px; }

.news .alert .octicon { color: var(--color-fg-muted); }

.news .alert .dashboard-event-icon { position: absolute; top: 18px; left: 22px; transform: translateX(-50%); }

.news .alert .body { padding: 1em 0px 0px; overflow: hidden; font-size: 14px; border-bottom: 0px; }

.news .alert .time { font-size: 12px; color: var(--color-fg-muted); }

.news .alert .title { padding: 0px; font-weight: 600; }

.news .alert .title .subtle { color: var(--color-fg-muted); }

.news .alert .gravatar { float: left; margin-right: 0.6em; line-height: 0; background-color: var(--color-canvas-default); border-radius: 6px; }

.news .alert .simple .title { display: inline-block; font-size: 13px; font-weight: 400; color: var(--color-fg-muted); }

.news .alert .simple .time { display: inline-block; }

.news .alert:first-child { border-top: 0px; }

.news .alert:first-child .body { padding-top: 0px; }

.news .alert:first-child .dashboard-event-icon { top: 0px; }

.news .github-welcome .done { color: var(--color-fg-muted); text-decoration: line-through; }

.news .commits li { margin-top: 0.15em; list-style-type: none; }

.news .commits li.more { padding-top: 2px; font-size: 11px; }

.news .commits li .committer { display: none; padding-left: 0.5em; }

.news .commits li img { margin: 0px 1px 0px 0px; vertical-align: middle; background-color: var(--color-canvas-default); border-radius: 6px; }

.news .commits li img.emoji { padding: 0px; margin: 0px; border: 0px; }

.news .commits li .message { display: inline-block; max-width: 390px; margin-top: 2px; overflow: hidden; font-size: 13px; line-height: 1.3; text-overflow: ellipsis; white-space: nowrap; vertical-align: top; }

.news div.message, .news li blockquote { display: inline; font-size: 13px; color: var(--color-fg-muted); }

.notification-routing .notification-email .edit-link { margin-right: 10px; font-weight: 600; }

.notification-routing .notification-email .btn-sm { float: none; margin: -2px 0px 0px; }

.notification-routing .notification-email .edit-form { display: none; }

.notification-routing .notification-email.open .edit-form { display: block; }

.notification-routing .notification-email.open .email-display { display: none; }

.oauth-permissions-details { position: relative; padding: 16px; margin: 0px; list-style: none; border-bottom: 1px solid var(--color-border-muted); }

.oauth-permissions-details:first-child { border-radius: 6px 6px 0px 0px; }

.oauth-permissions-details:last-child { border: 0px; border-radius: 0px 0px 6px 6px; }

.oauth-permissions-details.oauth-public-data-only { border-radius: 6px; }

.oauth-permissions-details .markdown-body { font-size: 13px; }

.oauth-permissions-details .content { display: none; margin-left: 45px; }

.oauth-permissions-details .content .form-checkbox { margin-left: 0px; }

.oauth-permissions-details .content .form-checkbox:last-child { margin-bottom: 0px; }

.oauth-permissions-details .octicon { float: left; color: var(--color-fg-muted); text-align: center; }

.oauth-permissions-details .permission-help { font-size: 13px; }

.oauth-permissions-details .permission-help ul { padding-left: 20px; margin: 1em 0px; }

.oauth-permissions-details .permission-summary { margin-left: 45px; }

.oauth-permissions-details .permission-summary .access-details { position: relative; color: var(--color-fg-muted); }

.oauth-permissions-details .permission-summary em.highlight { position: relative; padding: 2px 3px; margin-right: -2px; margin-left: -3px; font-style: normal; color: var(--color-fg-default); background: var(--color-search-keyword-hl); border-radius: 6px; }

.oauth-permissions-details .permission-title { display: block; color: var(--color-fg-default); }

.oauth-permissions-details a.btn-sm { float: right; margin-top: 4px; }

.oauth-permissions-details.open a.btn-sm { background-color: rgb(220, 220, 220); background-image: none; border-color: rgb(181, 181, 181); box-shadow: rgba(0, 0, 0, 0.15) 0px 2px 4px inset; }

.oauth-permissions-details.open .content { display: block; }

.oauth-permissions-details.default:not(.delete) .no-access, .oauth-permissions-details.default:not(.delete) .default-access, .oauth-permissions-details.none .no-access, .oauth-permissions-details.none .default-access { display: inline; }

.oauth-permissions-details.default:not(.delete) .access-details, .oauth-permissions-details.default:not(.delete) .permission-title, .oauth-permissions-details.none .access-details, .oauth-permissions-details.none .permission-title { color: var(--color-fg-muted); }

.oauth-permissions-details.default:not(.delete) .octicon, .oauth-permissions-details.none .octicon { color: var(--color-fg-muted); }

.oauth-permissions-details.default .default-access { display: inline; }

.oauth-permissions-details.full .full-access { display: inline; }

.oauth-details-toggle { position: absolute; top: 0px; right: 0px; padding: 20px 15px; }

.oauth-details-toggle .octicon-chevron-up { display: none; }

.open .oauth-details-toggle .octicon-chevron-down { display: none; }

.open .oauth-details-toggle .octicon-chevron-up { display: block; }

.oauth-user-permissions .full-access, .oauth-user-permissions .limited-access, .oauth-user-permissions .limited-access-emails-followers, .oauth-user-permissions .limited-access-emails-profile, .oauth-user-permissions .limited-access-followers-profile, .oauth-user-permissions .limited-access-profile, .oauth-user-permissions .limited-access-followers, .oauth-user-permissions .limited-access-emails, .oauth-user-permissions .no-access { display: none; }

.oauth-user-permissions.limited.limited-email .limited-access-emails { display: inline; }

.oauth-user-permissions.limited.limited-email.limited-profile .limited-access-emails, .oauth-user-permissions.limited.limited-email.limited-profile .limited-access-profile { display: none; }

.oauth-user-permissions.limited.limited-email.limited-profile .limited-access-emails-profile { display: inline; }

.oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-emails, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-profile, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-followers, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-emails-profile, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-emails-followers, .oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access-followers-profile { display: none; }

.oauth-user-permissions.limited.limited-email.limited-profile.limited-follow .limited-access { display: inline; }

.oauth-user-permissions.limited.limited-email.limited-follow .limited-access-emails, .oauth-user-permissions.limited.limited-email.limited-follow .limited-access-followers { display: none; }

.oauth-user-permissions.limited.limited-email.limited-follow .limited-access-emails-followers { display: inline; }

.oauth-user-permissions.limited.limited-follow .limited-access-followers { display: inline; }

.oauth-user-permissions.limited.limited-follow.limited-profile .limited-access-followers, .oauth-user-permissions.limited.limited-follow.limited-profile .limited-access-profile { display: none; }

.oauth-user-permissions.limited.limited-follow.limited-profile .limited-access-followers-profile { display: inline; }

.oauth-user-permissions.limited.limited-profile .limited-access-profile { display: inline; }

.oauth-repo-permissions .default-access, .oauth-repo-permissions .public-access, .oauth-repo-permissions .limited-repo-invite-access, .oauth-repo-permissions .full-access { display: none; }

.oauth-repo-permissions.full .full-access { display: inline; }

.oauth-repo-permissions.limited-repo-invite .limited-repo-invite-access { display: inline; }

.oauth-repo-permissions.public .public-access { display: inline; }

.oauth-repo-permissions.default .default-access { display: inline; }

.oauth-delete-repo-permissions .octicon-alert { color: var(--color-danger-fg); }

.oauth-repo-status-permissions .no-access, .oauth-repo-status-permissions .full-access, .oauth-repo-deployment-permissions .no-access, .oauth-repo-deployment-permissions .full-access { display: none; }

.oauth-notifications-permissions .no-access, .oauth-notifications-permissions .read-access, .oauth-notifications-permissions .via-public-access, .oauth-notifications-permissions .via-full-access { display: none; }

.oauth-notifications-permissions.read .read-access { display: inline; }

.oauth-notifications-permissions.via-public .via-public-access { display: inline; }

.oauth-notifications-permissions.via-public .octicon { display: none; }

.oauth-notifications-permissions.via-full .via-full-access { display: inline; }

.oauth-gist-permissions .no-access, .oauth-gist-permissions .full-access { display: none; }

.oauth-granular-permissions .no-access, .oauth-granular-permissions .read-access, .oauth-granular-permissions .write-access, .oauth-granular-permissions .full-access { display: none; }

.oauth-granular-permissions.none .no-access { display: inline; }

.oauth-granular-permissions.read .read-access { display: inline; }

.oauth-granular-permissions.write .write-access { display: inline; }

.oauth-granular-permissions.full .full-access { display: inline; }

.oauth-no-description { color: var(--color-fg-muted); }

.oauth-org-access-details { background: var(--color-canvas-default); }

.oauth-org-access-details .oauth-org-item:hover { background: var(--color-canvas-subtle); }

.oauth-org-access-details a:hover { text-decoration: none; }

.oauth-org-access-details .boxed-group-inner { border: 0px; border-radius: 6px; }

.oauth-org-access-details .oauth-org-item { line-height: 24px; }

.oauth-org-access-details .oauth-org-item:first-child { border-radius: 6px 6px 0px 0px; }

.oauth-org-access-details .oauth-org-item .loading-indicator { display: none; margin: 4px; }

.oauth-org-access-details .oauth-org-item.on .authorized-tools { display: block; }

.oauth-org-access-details .oauth-org-item.on .unauthorized-tools { display: none; }

.oauth-org-access-details .oauth-org-item.on strong { color: var(--color-fg-default); }

.oauth-org-access-details .oauth-org-item.on .octicon-check { display: inline; }

.oauth-org-access-details .oauth-org-item.on .octicon-x { display: none; }

.oauth-org-access-details .oauth-org-item.revoked { background: var(--color-canvas-default); }

.oauth-org-access-details .oauth-org-item.revoked .unauthorized-tools, .oauth-org-access-details .oauth-org-item.revoked .authorized-tools { display: none; }

.oauth-org-access-details .oauth-org-item.revoked .octicon-x { color: var(--color-danger-fg); }

.oauth-org-access-details .oauth-org-item.loading .unauthorized-tools, .oauth-org-access-details .oauth-org-item.loading .authorized-tools { display: none; }

.oauth-org-access-details .oauth-org-item.loading .loading-indicator { display: block; }

.oauth-org-access-details .oauth-org-item .authorized-tools { display: none; }

.oauth-org-access-details .oauth-org-item .unauthorized-tools { display: block; }

.oauth-org-access-details .btn { line-height: 1.5em; }

.oauth-org-access-details .octicon { color: var(--color-fg-muted); }

.oauth-org-access-details .octicon-check { display: none; color: var(--color-success-fg); }

.oauth-org-access-details .octicon-x { display: inline; }

.oauth-org-access-details .octicon-x.org-access-denied { color: var(--color-danger-fg); }

.permission-title { margin-top: 0px; }

.oauth-application-whitelist h2 { display: inline-block; }

.oauth-application-whitelist .request-info { display: block; }

.oauth-application-whitelist .request-info strong { display: inline-block; color: var(--color-fg-default); }

.oauth-application-whitelist .request-info .application-description { display: none; }

.oauth-application-whitelist .request-info.open .application-description { display: block; }

.oauth-application-whitelist .avatar { margin-top: 0px; }

.oauth-application-whitelist .requestor { font-weight: 600; }

.oauth-application-whitelist .octicon-alert { color: var(--color-severe-fg); }

.oauth-application-whitelist .octicon-check, .oauth-application-whitelist .approved-request { color: var(--color-success-fg); }

.oauth-application-whitelist .denied-request { color: var(--color-danger-fg); }

.oauth-application-whitelist .request-indicator { margin-left: 10px; }

.oauth-application-whitelist .edit-link { color: var(--color-fg-muted); }

.oauth-application-whitelist .edit-link:hover { color: var(--color-accent-fg); }

.oauth-application-whitelist .boxed-group-list { margin-top: 1em; }

.oauth-application-whitelist .boxed-group-list li { padding: 10px; }

.boxed-group-inner .oauth-application-info { margin-bottom: 10px; }

.oauth-application-info .application-title { font-size: 30px; color: var(--color-fg-default); }

.oauth-application-info .application-description { margin-top: 3px; margin-bottom: 0px; }

.oauth-application-info .app-info { display: inline-block; margin-right: 10px; color: var(--color-fg-muted); }

.oauth-application-info .app-info .octicon { margin-right: 5px; }

.oauth-application-info .listgroup-item { line-height: inherit; }

.oauth-application-info .app-denied, .oauth-application-info .app-approved { margin-left: 10px; font-size: 13px; font-weight: 400; white-space: nowrap; }

.oauth-application-info .app-approved, .oauth-application-info .octicon-check { color: var(--color-success-fg); }

.oauth-application-info .app-denied, .oauth-application-info .octicon-x { color: var(--color-severe-fg); }

.restrict-oauth-access-button { margin-right: 20px; }

.restrict-oauth-access-info { margin-bottom: 40px; font-size: 14px; }

.restrict-oauth-access-list { padding-left: 25px; }

.restrict-oauth-access-list li { margin-bottom: 10px; }

.restrict-oauth-access-list li:last-child { margin-bottom: 0px; }

.app-transfer-actions form { display: inline; }

.oauth-border { border-top: 1px solid var(--color-border-muted); }

.oauth-border:last-child { border-bottom: 1px solid var(--color-border-muted); }

.developer-app-item .developer-app-avatar-cell { width: 60px; }

.developer-app-item .developer-app-name { font-size: 14px; font-weight: 600; line-height: 1.25; color: var(--color-fg-default); }

.developer-app-item .developer-app-name:hover { color: var(--color-accent-fg); text-decoration: none; }

.developer-app-item .developer-app-info-cell { padding-left: 0px; }

.developer-app-item .developer-app-list-meta { margin-top: 3px; margin-bottom: 2px; font-weight: 400; color: var(--color-fg-muted); }

.org-transfer-requests { margin: 10px 0px 20px; }

.toggle-secret-field .secret-standin { display: block; }

.toggle-secret-field .secret-field { display: none; }

.toggle-secret-field.open .secret-standin { display: none; }

.toggle-secret-field.open .secret-field { display: block; }

.org-insights-graph-canvas .activity { width: 400px; padding: 10px; margin: 100px auto 0px; color: var(--color-fg-default); text-align: center; border-radius: 6px; }

.org-insights-graph-canvas .dots { margin: 0px auto; }

.org-insights-graph-canvas .totals circle { stroke-width: 4; opacity: 0; }

.org-insights-graph-canvas .totals circle:only-child { opacity: 1; }

.org-insights-graph-canvas > .activity { display: none; }

.org-insights-graph-canvas .axis { font-size: 10px; }

.org-insights-graph-canvas .axis line { stroke: rgba(27, 31, 35, 0.1); shape-rendering: crispedges; }

.org-insights-graph-canvas .axis text { font-size: 12px; font-weight: 300; fill: var(--color-fg-muted); }

.org-insights-graph-canvas .axis path { display: none; }

.org-insights-graph-canvas .axis .zero line { stroke: var(--color-accent-emphasis); stroke-dasharray: 3, 3; stroke-width: 1.5; }

.org-insights-graph-canvas path { fill: none; stroke-width: 2; }

.org-insights-graph-canvas .y line { display: none; }

.org-insights-graph-canvas .y.unique line { stroke: rgb(29, 127, 179); }

.org-insights-graph-canvas .overlay { fill-opacity: 0; }

.org-insights-graph-canvas .graph-loading { padding: 110px 0px; }

.org-insights-graph-canvas .graph-loading, .org-insights-graph-canvas .graph-error, .org-insights-graph-canvas .graph-no-usable-data, .org-insights-graph-canvas .graph-empty { display: none; }

.org-insights-graph-canvas.is-graph-loading > .activity, .org-insights-graph-canvas.is-graph-without-usable-data > .activity, .org-insights-graph-canvas.is-graph-empty > .activity { display: block; }

.org-insights-graph-canvas.is-graph-loading .graph-loading, .org-insights-graph-canvas.is-graph-empty .graph-empty, .org-insights-graph-canvas.is-graph-without-usable-data .graph-no-usable-data, .org-insights-graph-canvas.is-graph-load-error .graph-error { display: block; }

.org-insights-svg-tip { position: absolute; z-index: 99999; padding: 10px; pointer-events: none; }

.org-insights-svg-tip.is-visible { display: block; }

.org-insights-svg-tip::after, .org-insights-svg-tip::before { position: absolute; top: 100%; left: 50%; width: 0px; height: 0px; pointer-events: none; content: " "; border: solid transparent; }

.org-insights-svg-tip::after { margin-left: -5px; border-right-color: rgba(255, 255, 255, 0); border-bottom-color: rgba(255, 255, 255, 0); border-left-color: rgba(255, 255, 255, 0); border-width: 5px; border-top-color: var(--color-canvas-default); }

.org-insights-svg-tip::before { margin-left: -6px; border-right-color: rgba(0, 0, 0, 0); border-bottom-color: rgba(0, 0, 0, 0); border-left-color: rgba(0, 0, 0, 0); border-width: 6px; border-top-color: var(--color-border-default); }

.org-insights-svg-tip.comparison { padding: 10px; text-align: left; pointer-events: none; }

.org-insights-svg-tip.comparison ul { margin: 0px; white-space: nowrap; list-style: none; }

.org-insights-svg-tip.comparison li { position: relative; }

.org-insights-svg-tip.comparison li .legend { width: 7px; height: 7px; border-radius: 50%; }

.org-insights-card-legend .metric-0 { color: var(--color-accent-fg); }

.org-insights-card-legend .metric-1 { color: var(--color-success-fg); }

.org-insights-card-legend .metric-2 { color: var(--color-severe-fg); }

.org-insights-card-legend .metric-3 { color: var(--color-done-fg); }

.org-insights-svg-tip .metric-0 .legend, .org-insights-graph-canvas path.metric-0, .org-insights-graph-canvas .metric-0 circle { stroke: var(--color-accent-fg); background-color: var(--color-accent-fg); }

.org-insights-svg-tip .metric-1 .legend, .org-insights-graph-canvas path.metric-1, .org-insights-graph-canvas .metric-1 circle { stroke: var(--color-success-fg); background-color: var(--color-success-fg); }

.org-insights-svg-tip .metric-2 .legend, .org-insights-graph-canvas path.metric-2, .org-insights-graph-canvas .metric-2 circle { stroke: var(--color-severe-emphasis); background-color: var(--color-severe-emphasis); }

.org-insights-svg-tip .metric-3 .legend, .org-insights-graph-canvas path.metric-3, .org-insights-graph-canvas .metric-3 circle { stroke: var(--color-done-emphasis); background-color: var(--color-done-emphasis); }

.org-insights-cards .boxed-group { width: 100%; margin: 10px 0px; }

.org-insights-cards .org-insights-card-legend { display: none; color: var(--color-fg-muted); }

.org-insights-cards .repository-lang-stats-graph { overflow: visible; cursor: default; border: 0px; }

.org-insights-cards .repository-lang-stats-graph .language-color { min-width: 24px; margin-right: -12px; border: 2px solid var(--color-canvas-default); }

.org-insights-cards .is-rendered .org-insights-card-legend { display: block; }

@media (min-width: 544px) {
  .org-insights-cards .is-rendered .org-insights-card-legend { display: flex; }
}

.org-insights-cards .octicon-arrow-down, .org-insights-cards .octicon-arrow-up { display: none; }

.org-insights-cards .is-increase .octicon-arrow-up { display: inline-block; }

.org-insights-cards .is-decrease .octicon-arrow-down { display: inline-block; }

.org-insights-cards .graph-canvas .dots { padding: 43px 0px; }

.invitation-2fa-banner { margin-right: -24px; margin-left: -24px; }

.sign-up-via-invitation .bleed-flush { width: 100%; padding: 0px 20px; margin-left: -20px; border-color: var(--color-border-default); }

.sign-up-via-invitation label { font-size: 13px; }

.orghead { padding-top: 16px; padding-bottom: 0px; margin-bottom: 16px; color: var(--color-fg-default); background-color: var(--color-page-header-bg); border-bottom: 1px solid var(--color-border-default); }

.orghead .orgnav { position: relative; top: 1px; margin-top: 10px; }

.org-repos .TableObject-item--primary { white-space: normal; }

.org-name { font-weight: 400; color: var(--color-fg-default); }

.audit-log-search .member-info { width: 300px; }

.audit-log-search .member-info .member-avatar { float: left; margin-right: 15px; }

.audit-log-search .member-info .member-link { display: block; }

.audit-log-search .member-info .member-list-avatar { margin-right: 0px; }

.audit-log-search .member-info .ghost { display: inline-block; color: var(--color-fg-muted); }

.audit-log-search .blankslate { border-top-left-radius: 0px; border-top-right-radius: 0px; }

.audit-log-search .export-phrase { margin: 5px 0px; }

.audit-results-actions { overflow: auto; }

.audit-search-clear { float: left; margin-bottom: 20px; border: 0px; }

.audit-search-clear .issues-reset-query { margin-bottom: 0px; }

.audit-type { width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.audit-type .octicon { margin-right: 3px; font-weight: 400; vertical-align: bottom; }

.audit-type .repo { color: var(--color-severe-fg); }

.audit-type .team { color: var(--color-success-fg); }

.audit-type .user { color: var(--color-done-fg); }

.audit-type .oauth_access { color: var(--color-danger-fg); }

.audit-type .hook { color: rgb(225, 191, 78); }

.export-phrase { margin-top: 5px; }

.export-phrase pre { padding-left: 10px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; white-space: pre-wrap; border-left: 1px solid var(--color-border-muted); }

.two-factor-enforcement-form .loading-spinner { float: left; margin: 0px 0px 0px -20px; vertical-align: middle; }

.saml-enabled-banner-container { background-color: var(--color-canvas-default); }

.saml-settings-form .test-status-indicator, .oidc-settings-form .test-status-indicator { width: 30px; height: 30px; margin-top: -4px; border-radius: 50%; }

.saml-settings-form .test-status-indicator .octicon, .oidc-settings-form .test-status-indicator .octicon { display: block; margin-top: 7px; margin-right: auto; margin-left: auto; }

.saml-settings-form .form-group.errored, .oidc-settings-form .form-group.errored { margin-bottom: 40px; }

.saml-settings-form .test-status-indicator-error, .oidc-settings-form .test-status-indicator-error { color: var(--color-fg-on-emphasis); background-color: var(--color-danger-emphasis); }

.saml-settings-form .test-status-indicator-success, .oidc-settings-form .test-status-indicator-success { color: var(--color-fg-on-emphasis); background-color: var(--color-success-emphasis); }

.saml-settings-form .details-container .method-field, .oidc-settings-form .details-container .method-field { display: none; }

.saml-settings-form .details-container .method-label, .oidc-settings-form .details-container .method-label { font-weight: 400; }

.saml-settings-form .details-container .details-target, .oidc-settings-form .details-container .details-target { cursor: pointer; }

.saml-settings-form .details-container.open .method-value, .saml-settings-form .details-container.open .details-target, .oidc-settings-form .details-container.open .method-value, .oidc-settings-form .details-container.open .details-target { display: none; }

.saml-settings-form .details-container.open .method-field, .oidc-settings-form .details-container.open .method-field { display: inline-block; }

.saml-settings-form .saml-enforcement-disabled, .oidc-settings-form .saml-enforcement-disabled { opacity: 0.5; }

.form-group .form-control.saml-certificate-field { width: 440px; height: 150px; min-height: 0px; }

.member-avatar { float: left; margin: 1px; }

.member-fullname { color: var(--color-fg-muted); }

.org-toolbar.disabled { pointer-events: none; }

.org-toolbar .subnav-search { width: 320px; margin-right: 20px; margin-left: 0px; }

.org-toolbar .subnav-search-context + .subnav-search { margin-left: -1px; }

.org-toolbar .subnav-search-input { width: 100%; }

.org-toolbar-next { margin-bottom: 24px; }

.org-toolbar-next .subnav-search { width: 240px; }

.auto-search-group { position: relative; }

.auto-search-group .auto-search-input { padding-left: 30px; }

.auto-search-group .spinner, .auto-search-group > .octicon { position: absolute; left: 10px; z-index: 5; width: 16px; height: 16px; }

.auto-search-group .spinner { top: 9px; background-color: var(--color-canvas-default); }

.auto-search-group > .octicon { top: 10px; font-size: 14px; color: var(--color-fg-muted); text-align: center; }

.org-list .list-item { position: relative; padding-top: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--color-border-muted); }

.org-list .list-item::before { display: table; content: ""; }

.org-list .list-item::after { display: table; clear: both; content: ""; }

.org-repos-mini { padding: 0px; margin: 0px; }

.org-repos-mini .org-repo-mini-item:first-child .org-repo-mini-cell { border-top: 0px; }

.org-repos-mini .org-repo-name { margin-top: 0px; margin-bottom: 0px; font-size: 14px; overflow-wrap: break-word; }

.org-repos-mini .org-repo-name .octicon-repo { color: var(--color-fg-muted); }

.org-repos-mini .org-repo-name .octicon-lock { color: var(--color-attention-fg); }

.org-repos-mini .org-repo-name .repo-prefix { font-weight: 400; }

.org-repos-mini .org-repo-name .repo-slash { display: inline-block; margin-right: -4px; margin-left: -4px; }

.org-repo-mini-cell { padding-top: 15px; padding-bottom: 15px; vertical-align: middle; }

.org-repo-meta { width: 165px; }

.org-repo-meta .access-level { cursor: default; }

.with-higher-access .table-list-cell-checkbox { vertical-align: top; }

.permission-level-cell .select-menu-button { width: 90px; text-align: left; }

.permission-level-cell .select-menu-button::after { position: absolute; top: 10px; right: 10px; }

.permission-level-cell .spinner { float: none; opacity: 0; transition: opacity 0.2s ease-in-out 0s; }

.permission-level-cell .is-loading .spinner { opacity: 1; }

.select-menu-option-title { margin-top: 0px; margin-bottom: 0px; }

.reinstate-org-member { position: relative; width: 500px; margin: 40px auto; }

.reinstate-org-member .reinstate-lead { margin-bottom: 30px; font-size: 16px; }

.reinstate-org-member label { cursor: pointer; }

.reinstate-org-member .reinstate-detail-container { margin: 15px 0px; }

.reinstate-org-member .reinstate-title { color: var(--color-fg-default); }

.reinstate-org-member .reinstate-title .octicon { width: 16px; margin-right: 10px; color: var(--color-fg-muted); }

.add-member-wrapper { position: relative; width: 500px; margin: 40px auto; }

.add-member-wrapper .available-seats { color: var(--color-fg-muted); }

.team-stats { padding-right: 15px; padding-left: 15px; margin-right: -15px; margin-bottom: -15px; margin-left: -15px; border-top: 1px solid var(--color-border-muted); }

.stats-group { display: table; width: 100%; table-layout: fixed; }

.stats-group-stat { display: table-cell; padding-top: 10px; padding-bottom: 10px; padding-left: 15px; font-size: 12px; color: var(--color-fg-muted); text-transform: uppercase; }

.stats-group-stat:first-child { padding-left: 0px; border-right: 1px solid var(--color-border-muted); }

.stats-group-stat:hover, .stats-group-stat:hover .stat-number { color: var(--color-accent-fg); text-decoration: none; }

.stats-group-stat.no-link:hover { color: var(--color-fg-muted); text-decoration: none; }

.stats-group-stat.no-link:hover .stat-number { color: var(--color-fg-default); }

.stat-number { display: block; font-size: 16px; color: var(--color-fg-default); }

.permission-title { margin-top: 0px; }

.invite-member-results ul { margin: 0px; }

.team-member-list { list-style: none; }

.team-member-list .table-list-cell { padding-top: 15px; padding-bottom: 15px; }

.team-member-list .team-member-content { margin-left: 50px; }

.team-member-list .team-member-username { margin: 0px; font-size: 14px; font-weight: 600; line-height: 20px; }

.team-member-list .Label--secondary { cursor: default; }

.team-member-list .invite-icon { width: 28px; color: var(--color-fg-muted); }

.menu-item-danger, .menu-item-danger.selected { color: var(--color-danger-fg); }

.menu-item-danger:hover, .menu-item-danger[aria-selected="true"], .menu-item-danger.navigation-focus, .menu-item-danger.selected:hover, .menu-item-danger.selected[aria-selected="true"], .menu-item-danger.selected.navigation-focus { color: var(--color-fg-on-emphasis); background: var(--color-danger-emphasis); }

.team-member-list-avatar { float: left; margin-right: 10px; }

.team-member-list-avatar .octicon { width: 40px; color: var(--color-fg-muted); }

.org-team-form .disabled { opacity: 0.5; }

.org-team-form .css-truncate-target { max-width: 250px; }

.confirm-removal-container .private-fork-count { margin-top: 0px; font-size: 12px; font-weight: 400; color: var(--color-fg-muted); }

.confirm-removal-container .deleting-private-forks-warning { position: relative; padding-left: 26px; }

.confirm-removal-container .deleting-private-forks-warning .octicon { position: absolute; top: 2px; left: 0px; color: var(--color-danger-fg); }

.confirm-removal-list-container { margin-bottom: 15px; border: 1px solid var(--color-border-default); border-radius: 6px; }

.confirm-removal-list-item { padding: 10px; margin: 0px; font-size: 14px; font-weight: 600; border-top: 1px solid var(--color-border-muted); }

.confirm-removal-list-item:first-child { border-top: 0px; }

.confirm-removal-team .octicon, .confirm-removal-repo .octicon { margin-right: 3px; color: var(--color-fg-muted); }

.team-repo-access-list { max-height: 245px; }

.manage-member-meta { list-style: none; }

.manage-member-meta-item { margin-top: 12px; color: var(--color-fg-muted); }

.manage-member-meta-item:first-child { margin-top: 0px; }

.manage-member-meta-item .btn-link { color: var(--color-fg-muted); }

.manage-member-meta-item > .octicon { width: 14px; margin-right: 5px; color: var(--color-fg-muted); text-align: center; }

.manage-member-meta-item > .octicon-alert { color: var(--color-severe-fg); }

.manage-member-button { margin-bottom: 10px; }

.org-user-notice-title { margin-top: 0px; margin-bottom: 0px; }

.org-user-notice-content { margin-top: 10px; margin-bottom: 10px; font-size: 14px; }

.org-user-notice-content strong { color: var(--color-fg-default); }

.org-user-notice-content:last-child { margin-bottom: 0px; }

.org-user-notice-content .octicon { color: var(--color-fg-muted); }

.org-user-notice-icon { float: right; margin: 10px 10px 20px; font-size: 45px; color: var(--color-fg-muted); }

.manage-repo-access-header { margin-top: 30px; margin-bottom: 30px; }

.manage-repo-access-header::before { display: table; content: ""; }

.manage-repo-access-header::after { display: table; clear: both; content: ""; }

.manage-repo-access-header .btn { margin-top: 8px; }

.manage-repo-access-header .tooltipped::after { width: 250px; white-space: normal; }

.manage-repo-access-heading { margin-top: -2px; margin-bottom: 0px; font-size: 24px; font-weight: 400; }

.manage-repo-access-lead { margin-top: 3px; margin-bottom: 0px; font-size: 16px; color: var(--color-fg-muted); }

.manage-repo-access-group { background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.manage-repo-access-title { padding: 12px 15px; margin-top: 0px; margin-bottom: 0px; font-size: 14px; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-muted); border-radius: 6px 6px 0px 0px; }

.manage-repo-access-wrapper { position: relative; padding-left: 25px; }

.manage-repo-access-wrapper::before { position: absolute; top: 15px; bottom: 15px; left: 22px; z-index: 1; display: block; width: 2px; content: ""; background-color: var(--color-canvas-default); }

.manage-repo-access-icon { position: relative; z-index: 2; float: left; padding-top: 2px; padding-bottom: 2px; margin-top: -3px; margin-left: -25px; background: var(--color-canvas-default); }

.manage-repo-access-icon .octicon { font-size: 14px; color: var(--color-fg-default); }

.manage-repo-access-list { list-style: none; }

.manage-repo-access-list-item { padding: 16px; }

.manage-repo-access-list-item:last-child { border-bottom: 0px; border-radius: 0px 0px 6px 6px; }

.manage-repo-access-teams-group { margin-top: -20px; list-style: none; border: 1px solid var(--color-border-default); border-radius: 6px; }

.manage-repo-access-team-item { border-top: 1px solid var(--color-border-muted); }

.manage-repo-access-team-item:first-child { border-top: 0px; }

.manage-repo-access-description { margin-top: 3px; margin-bottom: 0px; overflow: hidden; text-overflow: ellipsis; overflow-wrap: break-word; white-space: nowrap; }

.manage-repo-access-not-active { color: var(--color-fg-default); background-color: var(--color-canvas-subtle); }

.manage-repo-access-not-active .manage-repo-access-icon { background: var(--color-canvas-subtle); }

.manage-access-remove-footer { padding: 16px; border-top: 1px solid var(--color-border-muted); }

.manage-access-remove-footer .tooltipped::after { width: 250px; white-space: normal; }

.manage-access-none { margin: 20px 50px; text-align: center; }

.ldap-group-dn { display: block; font-weight: 400; color: var(--color-fg-muted); }

.ldap-import-groups-container .blankslate { display: none; }

.ldap-import-groups-container.is-empty .blankslate { display: block; }

.ldap-import-groups-container.is-empty .ldap-memberships-list { display: none; }

.ldap-memberships-list { margin-bottom: 30px; }

.ldap-memberships-list .table-list-cell { padding-top: 10px; padding-bottom: 10px; font-size: 13px; vertical-align: middle; }

.ldap-memberships-list .table-list-cell:last-child { width: 92px; }

.ldap-memberships-list .ldap-list-team-name { width: 380px; }

.ldap-memberships-list .ldap-group-dn { font-size: 11px; }

.ldap-memberships-list .ldap-mention-as { width: 260px; }

.ldap-memberships-list .edit { position: absolute; padding: 10px; margin-left: -33px; color: var(--color-accent-fg); cursor: pointer; }

.ldap-memberships-list .edit-fields { display: none; }

.ldap-memberships-list .is-editing .edit-hide { display: none; }

.ldap-memberships-list .is-editing .edit-fields { display: block; }

.ldap-memberships-list .is-editing .spinner { margin-left: 15px; vertical-align: middle; }

.ldap-memberships-list .is-removing { opacity: 0.25; }

.ldap-memberships-list .is-removing .edit { opacity: 0.5; }

.team-name-field { height: 33px; }

.ldap-import-form-actions { margin-top: 30px; }

.invited .team-member-list { margin: -20px 0px; }

.invited .team-member-list .list-item { padding: 10px 0px; border-bottom: 1px solid var(--color-border-muted); }

.invited .team-member-list .list-item::before { display: table; content: ""; }

.invited .team-member-list .list-item::after { display: table; clear: both; content: ""; }

.invited .team-member-list .list-item:last-of-type { border: 0px; }

.invited .team-member-list .list-item .edit-invitation { float: right; margin-top: 6px; }

.invited-banner::before { display: table; content: ""; }

.invited-banner::after { display: table; clear: both; content: ""; }

.invited-banner .btn-sm { float: right; margin-left: 5px; }

.invited-banner p { font-size: 14px; line-height: 1.5; }

.invited-banner .inviter-link { font-weight: 600; }

.manage-member-sso-sessions.has-active-sessions .blankslate { display: none; }

.manage-memberships-nav { position: relative; top: 1px; margin-top: 10px; }

.manage-memberships-tabs-item { cursor: pointer; border-style: solid; border-color: transparent; border-image: initial; border-width: 3px 1px 1px; border-radius: 6px 6px 0px 0px; }

.manage-memberships-tabs-item:hover { color: var(--color-fg-default); }

.manage-memberships-tabs-item.selected { font-weight: 600; color: var(--color-fg-default); background-color: var(--color-canvas-default); border-bottom: 2px solid rgb(210, 105, 17); }

.org-menu-item:not([aria-current="page"]) + .org-sub-menu { display: none; }

.trial-banner-notice { background-image: linear-gradient(rgb(3, 102, 214) 0%, rgb(33, 136, 255) 100%); }

@media (min-width: 768px) {
  .Popover-message--extra-large { min-width: 544px !important; }
}

.theme-picker { margin-bottom: -1px; background-color: var(--color-canvas-default); background-clip: padding-box; border-bottom: 1px solid var(--color-border-default); box-shadow: var(--color-shadow-medium); }

.theme-picker > .container { position: relative; overflow: hidden; text-align: center; }

.theme-picker-thumbs { border-bottom: 1px solid var(--color-border-muted); }

.theme-toggle { width: 32px; height: 32px; padding: 0px; color: var(--color-fg-muted); background: none; border: 0px; }

.theme-toggle:hover { color: var(--color-accent-fg); text-decoration: none; }

.theme-toggle.disabled, .theme-toggle.disabled:hover { color: var(--color-fg-muted); cursor: not-allowed; }

.theme-toggle-full-left, .theme-toggle-full-right { position: absolute; top: 50px; overflow: hidden; }

.theme-toggle-full-left { left: 4px; }

.theme-toggle-full-right { right: 4px; }

.theme-selector { height: 102px; margin: 15px 46px; }

.theme-selector-thumbnail { padding: 2px; border: 1px solid var(--color-border-muted); }

.theme-selector-thumbnail:hover { text-decoration: none; background-color: var(--color-neutral-subtle); }

.theme-selector-thumbnail.selected { padding: 3px; background-color: var(--color-accent-emphasis); border: 0px; }

.theme-selector-thumbnail.selected .theme-selector-img { border: 1px solid var(--color-canvas-default); }

.theme-selector-img { width: 126px; height: 96px; border-radius: 1px; }

.theme-picker-spinner { position: absolute; top: 16px; left: 50%; margin-left: -16px; background-color: var(--color-canvas-default); opacity: 1; transition: all 0.2s ease 0s, opacity 0s ease-in-out 0s; }

.theme-picker-spinner ~ .theme-picker-controls .theme-name { opacity: 0; }

.theme-picker-view-toggle { float: left; }

.theme-picker-view-toggle .for-hiding { display: none; }

.theme-picker-view-toggle.open .for-hiding { display: inline; }

.theme-picker-view-toggle.open .for-showing { display: none; }

.theme-picker-controls { position: absolute; top: 15px; left: 50%; width: 220px; margin-left: -110px; line-height: 34px; text-align: center; }

.theme-picker-controls .theme-toggle { vertical-align: middle; }

.theme-name { display: inline-block; margin-right: 10px; margin-left: 10px; font-size: 20px; line-height: 1; vertical-align: middle; }

.page-preview { z-index: -100; display: block; width: 100%; height: 6000px; padding: 0px; background-color: var(--color-canvas-default); border: 0px; }

.pinned-items-spinner { position: relative; top: 2px; left: 6px; }

.pinned-items-setting-link { font-size: 13px; font-weight: 400; }

.pinned-item-name { color: var(--color-fg-default); }

.pinned-item-checkbox:checked + .pinned-item-name { color: var(--color-fg-default); background-color: var(--color-accent-subtle); }

.pinned-gist-blob-num { min-width: 36px; cursor: default; }

.pinned-gist-blob-num:hover { color: var(--color-fg-muted); cursor: default; }

@media print {
  #serverstats, .Header-old, .Header, .header-search, .reponav, .comment::before, .comment::after, .footer, .pagehead-actions, .discussion-timeline-actions, .timeline-comment-actions, .timeline-new-comment, .thread-subscription-status, .lock-toggle-link, .header, .pr-review-tools, .file-actions, .js-expandable-line, .toolbar-shadow, .gh-header-sticky, .pr-toolbar.is-placeholder, .language-color { display: none !important; }
  .repository-lang-stats-graph { height: 0px; }
  .btn:not(.btn-outline) { background: none; color: var(--color-fg-default)  !important; }
  p, .comment h2 { break-inside: avoid; }
  .markdown-body h2 { break-after: avoid; }
  .topic-tag { padding: 0px; }
  .topic-tag::before { margin-right: -2px; content: "#"; }
  .blob-num { border-right: 2px solid var(--color-border-default); }
  .blob-num-deletion { border-right-color: var(--color-danger-emphasis); }
  .blob-num-addition { border-right-color: var(--color-success-emphasis); }
  .blob-code-addition .x { border-bottom: 2px solid var(--color-success-emphasis); border-radius: 0px; }
  .blob-code-deletion .x { border-bottom: 2px solid var(--color-danger-emphasis); border-radius: 0px; }
  .pr-toolbar.is-stuck { position: static !important; width: 100% !important; }
  .diffstat-block-neutral { border: 4px solid var(--color-border-default); }
  .diffstat-block-deleted { border: 4px solid var(--color-danger-emphasis); }
  .diffstat-block-added { border: 4px solid var(--color-success-emphasis); }
  .State { color: var(--color-fg-default); background: none; border: 1px solid var(--color-border-default); }
  .State--open { color: var(--color-success-fg); border: 1px solid rgb(44, 190, 78); }
  .State--merged { color: var(--color-done-fg); border: 1px solid var(--color-done-emphasis); }
  .State--closed { color: var(--color-danger-fg); border: 1px solid var(--color-danger-emphasis); }
  .markdown-body pre > code { white-space: pre-wrap; }
}

.projects-splash-dialog { position: fixed; top: 0px; right: auto; left: 50%; z-index: 999; width: 90vw; max-width: 700px; max-height: 80vh; margin: 10vh auto; transform: translateX(-50%); }

@media (min-width: 544px) {
  .projects-splash-dialog { margin: 20vh auto; }
}

.projects-splash-banner { background-image: url("/images/modules/memexes/projects-beta-banner-mobile.png"); background-repeat: no-repeat; background-position: left center; background-size: cover; }

@media (min-width: 768px) {
  .projects-splash-banner { background-image: url("/images/modules/memexes/projects-beta-banner.png"); }
}

.projects-splash-banner p { max-width: 100%; }

@media (min-width: 768px) {
  .projects-splash-banner p { max-width: 55%; }
}

@media (min-width: 768px) {
  [data-color-mode="light"][data-light-theme*="dark"] .projects-splash-banner, [data-color-mode="dark"][data-dark-theme*="dark"] .projects-splash-banner { background-image: url("/images/modules/memexes/projects-beta-banner-dark.png"); }
}

@media (prefers-color-scheme: light) and (min-width: 768px) {
  [data-color-mode="auto"][data-light-theme*="dark"] .projects-splash-banner { background-image: url("/images/modules/memexes/projects-beta-banner-dark.png"); }
}

@media (prefers-color-scheme: dark) and (min-width: 768px) {
  [data-color-mode="auto"][data-dark-theme*="dark"] .projects-splash-banner { background-image: url("/images/modules/memexes/projects-beta-banner-dark.png"); }
}

.project-description p:last-child { margin-bottom: 0px !important; }

.project-full-screen .pagehead, .project-full-screen .hide-full-screen, .project-full-screen .Header-old, .project-full-screen .Header { display: block; }

@media (min-width: 544px) {
  .project-full-screen .pagehead, .project-full-screen .hide-full-screen, .project-full-screen .Header-old, .project-full-screen .Header { display: none; }
}

.project-full-screen .project-header { padding-top: 10px; padding-bottom: 10px; color: rgba(255, 255, 255, 0.75); }

@media (min-width: 544px) {
  .project-full-screen .project-header { background-color: var(--color-project-header-bg); }
}

.project-full-screen .project-header:focus { outline: none; }

.project-full-screen .project-header .project-header-link { color: rgba(255, 255, 255, 0.75) !important; }

.project-full-screen .project-header .project-header-link:hover { color: rgb(255, 255, 255) !important; }

.project-full-screen .project-header .pending-cards-status { border-color: var(--color-neutral-emphasis); }

@media (min-width: 544px) {
  .project-full-screen .card-filter-input { color: rgb(255, 255, 255); background-color: rgba(255, 255, 255, 0.125); border: 0px; outline: none; box-shadow: none; }
  .project-full-screen .card-filter-input::placeholder { color: rgba(255, 255, 255, 0.7); }
  .project-full-screen .card-filter-input:focus { background-color: rgba(255, 255, 255, 0.176); }
}

.project-header { background-color: var(--color-canvas-inset); outline: none; }

@media (min-width: 544px) {
  .project-header { background-color: var(--color-canvas-default); }
}

.project-header .select-menu-modal-holder { z-index: 500; }

.project-updated-message { top: 6px; left: 50%; z-index: 50; transform: translate(-50%, 0px); }

.pending-cards-status { top: -2px; right: -9px; width: 14px; height: 14px; background-image: linear-gradient(rgb(84, 163, 255), rgb(0, 110, 237)); background-clip: padding-box; border: 2px solid var(--color-canvas-default); }

.project-columns { overflow-x: auto; }

@media (min-width: 544px) {
  .project-columns-container { height: 0px; overflow-x: visible !important; }
}

.project-column { min-width: 100%; max-width: 100%; background-color: var(--color-canvas-inset); border-width: 0px !important; border-radius: 0px !important; }

.project-column:focus { outline: none; }

@media (min-width: 544px) {
  .project-column { min-width: 355px; max-width: 355px; border-width: 1px !important; border-radius: 6px !important; }
  .project-column:focus { box-shadow: var(--color-btn-shadow-input-focus); border-color: var(--color-accent-emphasis)  !important; }
}

.project-column.moving { box-shadow: var(--color-btn-shadow-input-focus); transform: translateX(4px) translateY(-4px); background-color: var(--color-accent-subtle)  !important; }

.new-project-column { width: 315px; border-color: var(--color-border-default)  !important; }

.project-search-form .loading-indicator { top: 21px; right: 21px; display: none; }

.project-search-form.loading .loading-indicator { display: inline-block; }

.sortable-ghost { background-color: var(--color-canvas-subtle); opacity: 0.5; }

.project-card { background-color: var(--color-canvas-overlay); }

.project-card .project-reference-markdown > p, .project-card:last-child { margin-bottom: 0px !important; }

.project-card:first-child { margin-top: 8px !important; }

@media (min-width: 544px) {
  .project-card:first-child { margin-top: 3px !important; }
}

.project-card ul, .project-card ol { margin-bottom: 8px; margin-left: 16px; }

.project-card blockquote { padding: 0px 0.75em; color: var(--color-fg-muted); border-left: 0.25em solid var(--color-border-default); }

.project-card .contains-task-list { margin-left: 24px; }

.project-card:hover { border-color: var(--color-border-default)  !important; box-shadow: rgba(106, 115, 125, 0.3) 0px 1px 3px !important; }

.project-card:focus { outline: none; }

@media (min-width: 544px) {
  .project-card:focus { border-color: var(--color-accent-emphasis)  !important; box-shadow: var(--color-btn-shadow-input-focus)  !important; }
}

.project-card.moving { transform: translateX(4px) translateY(0px); background-color: var(--color-accent-subtle)  !important; box-shadow: var(--color-btn-shadow-input-focus)  !important; }

.archived-project-cards-pane .project-card .archived-header { color: var(--color-fg-default); display: flex !important; }

.archived-project-cards-pane .project-card .archive-dropdown-item { display: none; }

.issue-card.draggable { cursor: move; }

.issue-card .AvatarStack:hover .from-avatar { margin-right: -4px; }

.issue-card pre { overflow-wrap: break-word; white-space: pre-wrap; }

@keyframes show-pane { 
  0% { transform: translateX(390px); }
  100% { transform: translateX(0px); }
}

.project-pane { z-index: 1; background-color: var(--color-project-sidebar-bg); background-clip: padding-box; box-shadow: rgba(36, 41, 46, 0.05) -3px 0px 5px; }

@media (min-width: 544px) {
  .project-pane { animation: 0.2s cubic-bezier(0, 0, 0, 1) 0s 1 normal none running show-pane; position: absolute !important; width: 360px !important; height: auto !important; }
}

.project-pane .redacted-activity { cursor: help; border-bottom: 1px dotted var(--color-border-default); }

.project-pane .project-body-markdown p:last-child, .project-pane .project-body-markdown ul:last-child, .project-pane .project-body-markdown ol:last-child { margin-bottom: 0px; }

@media (min-width: 544px) {
  .project-pane sidebar-memex-input details-menu { position: relative; right: auto !important; }
}

.project-pane-close { color: var(--color-fg-muted); }

.project-pane-close:hover { color: var(--color-fg-default); }

.project-note-form textarea { resize: vertical; }

.card-menu-container .dropdown-menu, .column-menu-container .dropdown-menu { min-width: 180px; }

.card-octicon { top: 6px; left: 10px; }

.card-note-octicon { top: 8px; }

.is-sending .auto-search-group .chooser-spinner { top: 15px; right: 21px; left: auto; }

.card-filter-input { width: 0px; }

@media (min-width: 544px) {
  .card-filter-input { width: 300px; }
}

.card-filter-autocomplete-dropdown { z-index: 500; float: none; min-width: 240px; max-height: 270px; cursor: pointer; }

.card-filter-autocomplete-dropdown [aria-selected="true"], .card-filter-autocomplete-dropdown .navigation-focus { background-color: var(--color-accent-emphasis); border-radius: 6px; color: var(--color-fg-on-emphasis)  !important; }

.card-filter-autocomplete-dropdown [aria-selected="true"] .autocomplete-text-qualifier, .card-filter-autocomplete-dropdown .navigation-focus .autocomplete-text-qualifier { color: var(--color-fg-on-emphasis)  !important; }

.projects-reset-query:hover .projects-reset-query-icon { background-color: var(--color-accent-emphasis); color: var(--color-fg-on-emphasis)  !important; }

.projects-reset-query-icon { width: 18px; height: 18px; padding: 1px; background-color: var(--color-fg-muted); }

.project-small-menu-dropdown::before, .project-small-menu-dropdown::after { display: none; }

.project-header-controls, .project-header-search { flex-grow: 1; }

@media (min-width: 1012px) {
  .project-header-controls, .project-header-search { flex-grow: 0; }
}

.project-header-subnav-search { flex-grow: 1; }

@media (min-width: 544px) {
  .project-header-subnav-search { flex-grow: 0; }
}

.project-page .application-main { flex-shrink: 0 !important; }

@media (min-width: 544px) {
  .project-page .application-main { flex-shrink: 1 !important; }
}

.project-edit-mode .column-menu-container, .project-edit-mode .column-menu-item { display: none !important; }

.project-edit-mode .project-move-actions { display: flex !important; }

.push-board-over { transition: all 0.2s ease 0s; padding-right: 0px !important; }

@media (min-width: 544px) {
  .push-board-over { padding-right: 360px !important; }
}

.project-touch-scrolling { }

.projects-comment-form .comment-md-support-link { float: none; width: 100%; text-align: center; }

.projects-comment-form .comment-form-actions { width: 100%; padding: 8px 16px; margin: 4px 0px !important; }

.projects-comment-form .comment-form-actions button { width: 100%; margin: 4px 0px !important; }

.projects-comment-form .comment-form-head { border-bottom: 0px; padding: 0px !important; margin: 0px !important; }

.projects-comment-form .comment-form-head .tabnav-tabs { padding: 8px 8px 0px; }

.projects-comment-form .comment-form-head .toolbar-commenting { width: 100%; padding-top: 4px; text-align: center; background-color: var(--color-canvas-default); border-top: 1px solid var(--color-border-default); }

.projects-comment-form .comment-form-head::after { display: block; clear: both; content: " "; }

.projects-comment-form .comment-form-textarea { height: 250px !important; }

.projects-comment-form .preview-content { margin: 0px; border-top: 1px solid var(--color-border-default); }

.projects-comment-form .preview-content .comment-body { padding: 16px; }

.project-issue-body-wrapper { max-height: 200px; overflow: hidden; }

.Details--on .project-issue-body-wrapper { max-height: none; overflow: visible; }

.project-issue-body-blur { height: 32px; background: linear-gradient(to top, var(--color-project-gradient-in), var(--color-project-gradient-out)); }

.Details--on .project-issue-body-blur { height: 0px; }

.project-comment-title-hover .comment-action, .project-comment-body-hover .comment-action { opacity: 0; }

.project-comment-title-hover:hover .comment-action, .project-comment-body-hover:hover .comment-action { opacity: 1; }

.project-comment-body-reaction .timeline-comment-action { padding: 4px 8px; }

.project-comment-reactions .reaction-summary-item { padding: 8px; }

.project-comment-reactions .reaction-summary-item g-emoji { margin: 0px !important; }

.project-name-hover .project-name-edit-action { opacity: 0; }

.project-name-hover:hover .project-name-edit-action { opacity: 1; }

.vcard-names { line-height: 1; }

.vcard-fullname { font-size: 26px; line-height: 1.25; }

.vcard-username { font-size: 20px; font-style: normal; font-weight: 300; line-height: 24px; color: var(--color-fg-muted); }

.vcard-details { list-style: none; }

.vcard-details .css-truncate.css-truncate-target { width: 100%; max-width: 100%; }

.vcard-details .css-truncate.css-truncate-target div { overflow: hidden; text-overflow: ellipsis; }

.vcard-detail { padding-left: 24px; font-size: 14px; }

.vcard-detail .octicon { float: left; width: 16px; margin-top: 3px; margin-left: -24px; color: var(--color-fg-muted); text-align: center; }

.user-profile-bio { overflow: hidden; font-size: 14px; }

.form-group .form-control.user-profile-bio-field { width: 440px; height: 5.35em; min-height: 0px; }

.user-profile-bio-field-container, .user-profile-company-field-container { position: relative; }

.user-profile-bio-message { margin: 5px 0px 0px; font-size: 12px; color: var(--color-fg-default); }

.vcard-detail { padding-left: 22px; }

.vcard-detail .octicon { margin-left: -22px; }

.user-profile-sticky-bar { position: fixed; top: 0px; z-index: 90; width: 233px; word-break: break-all; pointer-events: none; opacity: 0; transition: all 0.2s ease 0s; }

.user-profile-sticky-bar.is-stuck { pointer-events: auto; opacity: 1; }

.user-profile-mini-vcard { position: relative; top: 1px; z-index: 110; height: 54px; }

.user-profile-mini-avatar { width: 32px; }

.mini-follow-button { padding: 0px 8px; line-height: 1.5; opacity: 0; transition: opacity 0.2s ease 0s; }

.is-follow-stuck .mini-follow-button { opacity: 1; }

.user-profile-following-container .user-following-container.on .follow, .user-profile-following-container .user-following-container .unfollow { display: none; }

.user-profile-following-container .user-following-container .follow, .user-profile-following-container .user-following-container.on .unfollow { display: block; }

.vcard-names-container { position: sticky; top: 0px; }

.vcard-names-container.is-stuck { pointer-events: none; }

.vcard-names-container.is-stuck .vcard-names { opacity: 0; }

.vcard-names-container.is-stuck::after { opacity: 1; }

.user-profile-nav { background-color: var(--color-canvas-default); border-bottom: 1px solid var(--color-border-default); box-shadow: none; }

.user-profile-nav.is-stuck { z-index: 90; }

.user-profile-nav .UnderlineNav-item { line-height: 20px; }

.pinned-item-list-item .pinned-item-handle { color: var(--color-fg-muted); }

.pinned-item-list-item .pinned-item-handle:hover { cursor: grab; }

.pinned-item-list-item.is-dragging, .pinned-item-list-item.is-dragging .pinned-item-handle { cursor: grabbing; }

.pinned-item-list-item.is-dragging { background-color: var(--color-accent-subtle); }

.pinned-item-list-item.sortable-ghost { background-color: var(--color-accent-subtle); opacity: 0; }

.pinned-item-list-item.empty { border-style: dashed; border-width: 1px; align-items: center; justify-content: center; }

.pinned-item-list-item-content { display: flex; width: 100%; flex-direction: column; }

.pinned-item-desc { flex: 1 0 auto; }

.pinned-item-meta { display: inline-block; }

.pinned-item-meta + .pinned-item-meta { margin-left: 16px; }

.user-repo-search-results-summary { white-space: normal; }

.pull-request-tab-content { display: none; }

.pull-request-tab-content.is-visible { display: block; }

.discussion-timeline p.explain { margin: 0px; font-size: 12px; }

.pull-request-ref-restore { display: none; }

.pull-request-ref-restore-text { display: block; }

.pull-discussion-timeline.is-pull-restorable .pull-request-ref-restore.last { display: block; }

.files-bucket { margin-bottom: 15px; }

.full-width .diffbar .container, .split-diff .diffbar .container { padding-right: 0px; padding-left: 0px; }

.stale-files-tab { float: left; padding: 5px 10px; margin-top: -5px; margin-bottom: -5px; color: var(--color-severe-fg); background-color: var(--color-severe-subtle); border-radius: 6px; }

.stale-files-tab-link { font-weight: 600; color: inherit; }

.pr-toolbar { position: sticky; top: 0px; z-index: 29; height: 60px; padding: 0px 16px; margin: -16px -16px 0px; }

.pr-toolbar .subset-files-tab { float: left; padding: 0px 8px; font-size: 13px; border-radius: 6px; }

.pr-toolbar .float-right .diffbar-item { margin-right: 0px; }

.pr-toolbar .float-right .diffbar-item + .diffbar-item { margin-left: 20px; }

.pr-toolbar.is-stuck { height: 60px; background-color: var(--color-canvas-default); }

.toolbar-shadow { position: fixed; top: 60px; right: 0px; left: 0px; z-index: 28; display: none; height: 5px; background: linear-gradient(rgba(0, 0, 0, 0.075), rgba(0, 0, 0, 0)) 0px 0px repeat-x; border-top: 1px solid rgba(0, 0, 0, 0.15); }

.is-stuck + .toolbar-shadow { display: block; }

.files-next-bucket .file, .files-next-bucket .full-commit { margin-top: 0px; margin-bottom: 20px; }

.diffbar { background-color: var(--color-canvas-default); }

.diffbar .show-if-stuck { display: none; }

.diffbar .container { width: auto; }

.diffbar .table-of-contents { margin-bottom: 0px; }

.diffbar .table-of-contents ol { margin-bottom: -15px; }

.diffbar .table-of-contents li { border-top: 1px solid var(--color-border-muted); }

.diffbar .table-of-contents li:first-child { border-top: 0px; }

.diffbar [role^="menuitem"]:focus:not(.is-range-selected) .text-emphasized, .diffbar [role^="menuitem"]:hover:not(.is-range-selected) .text-emphasized { color: var(--color-fg-on-emphasis); }

.is-stuck .diffbar .show-if-stuck { display: block; }

.is-stuck .diffbar .diffstat { display: none; }

.is-stuck .diffbar .stale-files-tab { margin-top: -8px; }

.diffbar-range-menu .select-menu-modal { width: 380px; }

.diffbar-range-menu .css-truncate-target { max-width: 280px; }

.diffbar-range-menu .select-menu-item:not(.select-menu-action) { padding: 8px 10px; }

.diffbar-range-menu .emoji { vertical-align: bottom; }

.diffbar-range-menu .in-range:not(.is-range-selected) { background-color: var(--color-accent-subtle); border-bottom-color: var(--color-border-subtle); }

.diffbar-range-menu .in-range:focus:not(.is-range-selected), .diffbar-range-menu .in-range:hover:not(.is-range-selected) { background-color: var(--color-accent-emphasis); }

.diffbar-range-menu .is-range-selected { color: var(--color-fg-default); cursor: default; background-color: var(--color-attention-subtle); border-bottom-color: rgba(38, 44, 49, 0.15); outline: none; }

.diffbar-range-menu .is-range-selected .text-emphasized { color: var(--color-attention-fg); }

.diffbar-range-menu .is-range-selected .description { color: inherit; }

.diffbar-range-menu .is-last-in-range { cursor: pointer; background-color: var(--color-attention-subtle); }

.diffbar-item { float: left; margin-left: 16px; font-size: 13px; vertical-align: middle; }

.conflict-resolver .conflict-loader, .conflict-resolver.loading .resolve-file-form { display: none; }

.conflict-resolver .resolve-file-form, .conflict-resolver.loading .conflict-loader { display: block; }

.conflict-resolver.loading { position: relative; height: calc(100vh + 51px); padding-top: 50px; border: 1px solid var(--color-border-default); }

.conflict-resolver .file-header { padding: 9px 10px; }

.conflicts-nav { height: 100vh; border-width: 0px 0px 1px; }

.conflict-nav-item .discussion-item-icon { display: none; }

.conflict-nav-item.resolved .discussion-item-icon { display: block; margin-left: -5px; }

.conflict-nav-item.resolved .octicon-file-code { display: none; }

.conflict-nav-item.selected::before { border-radius: 0px; }

.conflict-nav-item .octicon { width: 22px; }

.conflict-nav-item .css-truncate-target { max-width: 80%; }

.is-resolved .file-actions { display: none; }

.is-resolved .resolved-notice { display: block; }

.resolved-notice { display: none; }

.add-comment-label, .review-cancel-button, .is-review-pending .start-review-label { display: none; }

.start-review-label, .is-review-pending .add-comment-label { display: inline-block; }

.is-review-pending .review-simple-reply-button { display: none; }

.is-review-pending .review-cancel-button { display: block; }

.is-review-pending .review-title-with-count { display: block; }

.review-title-with-count { display: none; }

.pr-review-tools .Counter { display: none; }

.is-review-pending .pr-review-tools .Counter { display: inline-block; }

.pr-review-tools .previewable-comment-form .comment-form-head { border-top-left-radius: 0px !important; border-top-right-radius: 0px !important; }

.pull-request-suggested-changes-menu { top: 30px; left: initial; z-index: 99; width: 700px; padding: 8px; margin: 0px; border: 1px solid var(--color-border-subtle); transform: initial; }

.pull-request-suggested-changes-menu::after, .pull-request-suggested-changes-menu::before { display: none; }

.pull-request-suggested-changes-menu .select-menu-header { border-radius: 6px 6px 0px 0px; }

.pull-request-suggested-changes-menu .form-actions { border-radius: 0px 0px 6px 6px; }

.pull-request-suggested-changes-menu .preview-content { max-height: 365px; }

.pull-request-suggested-changes-menu .comment-body { border-bottom: 0px !important; }

.review-comment-contents { margin-left: 44px; }

.review-comment::after, .review-comment-loader::after, .review-comment.is-comment-editing::after { position: absolute; top: 31px; left: 29px; z-index: -1; width: 3px; height: 100%; content: ""; background-color: var(--color-canvas-subtle); }

.review-comment { position: relative; padding: 8px 16px; color: var(--color-fg-default); }

.review-comment:first-child { padding-top: 16px; }

.review-comment:last-child { padding-bottom: 16px; }

.review-comment .comment-body, .review-comment .comment-reactions { padding: 0px; }

.review-comment .comment-body { padding-top: 4px; }

.review-comment .comment-body .suggested-change-form-container:nth-last-of-type(2) { margin-bottom: 0px !important; }

.review-comment .comment-reactions { margin-top: 5px; border-top: 0px !important; }

.review-comment .comment-reactions .add-reaction-btn { padding: 4px 10px; }

.review-comment .comment-reactions.has-reactions { margin-top: 12px; }

.review-comment .show-more-popover.dropdown-menu-sw { right: -5px; margin-top: 5px; }

.review-comment .reaction-summary-item:not(.add-reaction-btn) { padding: 0px 8px; font-size: 12px; line-height: 26px; border: 1px solid var(--color-border-default, #d2dff0); border-radius: 6px; }

.review-comment .reaction-summary-item:not(.add-reaction-btn) .emoji { font-size: 16px; vertical-align: sub; }

.review-comment .reaction-summary-item:not(.add-reaction-btn) + .reaction-summary-item { margin-left: 8px; }

.review-comment:last-child::after, .review-comment:last-child .review-comment-contents::after { display: none; }

.review-comment .timeline-comment-action { padding: 0px 5px; }

.review-comment .is-comment-editing { position: relative; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.review-comment .is-comment-editing::after { top: 100%; bottom: 0px; left: 19px; height: 20px; }

.review-comment .is-comment-editing .timeline-comment-actions, .review-comment .is-comment-editing .edit-comment-hide { display: none; }

.review-comment .is-comment-editing .previewable-comment-form { display: block; }

.review-comment.is-comment-loading .previewable-comment-form { opacity: 0.5; }

.timeline-comment.is-comment-editing .discussion-item-header { display: none; }

.review-thread-reply { padding: 8px 16px; background-color: var(--color-canvas-subtle); border-top: 1px solid var(--color-border-default); border-radius: 0px 0px 6px 6px; }

.review-thread-reply .inline-comment-form { margin: -8px -16px; background-color: var(--color-canvas-default); border: 0px; }

.review-thread-reply-button { display: inline-block; min-height: 28px; padding: 3px 8px; margin-left: 8px; cursor: text; }

.review-summary-form-wrapper { position: relative; display: none; margin-bottom: 24px; margin-left: -19px; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; }

.is-pending .review-summary-form-wrapper, .is-comment-editing .review-summary-form-wrapper { display: block; }

.is-pending .review-summary-form-wrapper { border-color: var(--color-attention-emphasis); }

.tooltipped-left::after { right: auto; left: 0px; }

.tooltipped-left::before { right: auto; left: 0px; }

.pulse-authors-graph { position: relative; height: 150px; }

.pulse-authors-graph > svg { width: 100%; }

.pulse-authors-graph .bar rect { fill: var(--color-severe-emphasis); fill-opacity: 0.7; }

.pulse-authors-graph .bar rect:hover { fill-opacity: 1; }

.readme.contributing > div { max-height: 250px; overflow: auto; }

.readme .markdown-body, .readme .plain { overflow-wrap: break-word; }

.readme .plain pre { font-size: 14px; white-space: pre-wrap; }

.file .readme table[data-table-type="yaml-metadata"] { font-size: 12px; line-height: 1; }

.file .readme table[data-table-type="yaml-metadata"] table { margin: 0px; }

.Label--draft { color: var(--color-danger-fg); border-color: var(--color-danger-emphasis); }

.Label--prerelease { color: var(--color-severe-fg); border-color: var(--color-severe-emphasis); }

.uploaded-files { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.uploaded-files.not-populated + .drop-target .drop-target-label { border-top: 1px var(--color-border-default); border-top-left-radius: 6px; border-top-right-radius: 6px; }

.uploaded-files.is-populated { border-top-color: ; border-top-style: ; border-top-width: ; border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-style: ; border-bottom-width: ; border-left-color: ; border-left-style: ; border-left-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-bottom-color: var(--color-border-muted); }

.uploaded-files.is-populated + .drop-target .drop-target-label { border-top: 0px; border-top-left-radius: 0px; border-top-right-radius: 0px; }

.uploaded-files > li.delete { background: var(--color-canvas-default); }

.uploaded-files > li.delete:nth-child(2) { border-top-left-radius: 6px; border-top-right-radius: 6px; }

.uploaded-files > li.delete .delete-pending { display: block !important; }

.uploaded-files > li.delete .live { display: none !important; }

.uploaded-files > li:nth-child(2) { border-top: 0px !important; }

.uploaded-files .remove:hover { color: var(--color-danger-fg)  !important; }

.upload-progress { height: 3px; margin-top: 3px; border-radius: 30px; }

.upload-progress .upload-meter { background-image: linear-gradient(rgb(141, 210, 247), rgb(88, 184, 244)); border-radius: 30px; }

@media (min-width: 768px) {
  .release-main-section { border-left: 2px solid var(--color-border-default); }
}

.release-feed-inline-last-p p:last-of-type { display: inline; }

.manifest-commit-form { margin-top: 20px; }

.repo-file-upload-outline { width: 100%; height: 100%; }

.repo-file-upload-target { position: relative; }

.repo-file-upload-target.is-uploading .repo-file-upload-text.initial-text, .repo-file-upload-target.is-failed .repo-file-upload-text.initial-text, .repo-file-upload-target.is-default .repo-file-upload-text.initial-text { display: none; }

.repo-file-upload-target.is-uploading .repo-file-upload-text.alternate-text, .repo-file-upload-target.is-failed .repo-file-upload-text.alternate-text, .repo-file-upload-target.is-default .repo-file-upload-text.alternate-text { display: block; }

.repo-file-upload-target.is-uploading.dragover .repo-file-upload-text, .repo-file-upload-target.is-failed.dragover .repo-file-upload-text, .repo-file-upload-target.is-default.dragover .repo-file-upload-text { display: none; }

.repo-file-upload-target .repo-file-upload-text.initial-text { display: block; }

.repo-file-upload-target .repo-file-upload-text.alternate-text { display: none; }

.repo-file-upload-target .repo-file-upload-text, .repo-file-upload-target .repo-file-upload-drop-text { margin-bottom: 5px; }

.repo-file-upload-target .repo-file-upload-choose { display: inline-block; margin-top: 0px; font-size: 18px; }

.repo-file-upload-target .manual-file-chooser { margin-left: 0px; }

.repo-file-upload-target .repo-file-upload-outline { position: absolute; top: 3%; left: 1%; width: 98%; height: 94%; }

.repo-file-upload-target.is-failed .repo-file-upload-outline, .repo-file-upload-target.is-bad-file .repo-file-upload-outline, .repo-file-upload-target.is-too-big .repo-file-upload-outline, .repo-file-upload-target.is-too-many .repo-file-upload-outline, .repo-file-upload-target.is-empty .repo-file-upload-outline { height: 85%; }

.repo-file-upload-target.dragover .repo-file-upload-text { display: none; }

.repo-file-upload-target.dragover .repo-file-upload-choose { visibility: hidden; }

.repo-file-upload-target.dragover .repo-file-upload-drop-text { display: block; }

.repo-file-upload-target.dragover .repo-file-upload-outline { border: 6px dashed var(--color-border-default); border-radius: 6px; }

.repo-file-upload-target .repo-file-upload-drop-text { display: none; }

.repo-file-upload-errors { display: none; }

.repo-file-upload-errors .error { display: none; }

.is-failed .repo-file-upload-errors, .is-bad-file .repo-file-upload-errors, .is-too-big .repo-file-upload-errors, .is-too-many .repo-file-upload-errors, .is-hidden-file .repo-file-upload-errors, .is-empty .repo-file-upload-errors { position: absolute; right: 0px; bottom: 0px; left: 0px; display: block; padding: 5px 8px; line-height: 1.5; text-align: left; background-color: var(--color-canvas-default); border-top: 1px solid var(--color-border-default); border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; }

.is-file-list .repo-file-upload-errors { border-bottom-right-radius: 0px; border-bottom-left-radius: 0px; }

.is-failed .repo-file-upload-errors .failed-request, .is-bad-file .repo-file-upload-errors .failed-request { display: inline-block; }

.is-too-big .repo-file-upload-errors .too-big { display: inline-block; }

.is-hidden-file .repo-file-upload-errors .hidden-file { display: inline-block; }

.is-too-many .repo-file-upload-errors .too-many { display: inline-block; }

.is-empty .repo-file-upload-errors .empty { display: inline-block; }

.repo-file-upload-tree-target { position: fixed; top: 0px; left: 0px; z-index: 1000; width: 100%; height: 100%; padding: 12px; color: var(--color-fg-default); visibility: hidden; background: var(--color-canvas-default); opacity: 0; transition: visibility 0.2s ease 0s, opacity 0.2s ease 0s; }

.repo-file-upload-tree-target .repo-file-upload-outline { border: 6px dashed var(--color-border-default); border-radius: 6px; }

.dragover .repo-file-upload-tree-target { visibility: visible; opacity: 1; }

.dragover .repo-file-upload-tree-target .repo-file-upload-slate { top: 50%; opacity: 1; }

.repo-file-upload-slate { position: absolute; top: 50%; width: 100%; text-align: center; transform: translateY(-50%); }

.repo-file-upload-slate h2 { margin-top: 5px; }

.repo-upload-breadcrumb { margin-bottom: 18px; }

.labels-list .blankslate { display: none; }

.labels-list .table-list-header { display: block; }

.labels-list.is-empty .blankslate { display: block; }

.labels-list.is-empty .table-list-header { display: none; }

.label-select-menu-item .g-emoji { font-size: 12px; line-height: 1; vertical-align: baseline; }

.label-edit::before { display: table; content: ""; }

.label-edit::after { display: table; clear: both; content: ""; }

.label-edit label { display: block; margin-bottom: 8px; }

.label-edit .error { float: left; margin-top: 8px; margin-left: 10px; color: var(--color-danger-fg); }

.label-edit.loading { display: block; }

.label-characters-remaining { color: var(--color-fg-muted); }

.repo-list { position: relative; }

.repo-list-item { position: relative; padding-top: 30px; padding-bottom: 30px; list-style: none; border-bottom: 1px solid var(--color-border-muted); }

.repo-list-item-with-avatar { padding-left: 42px; }

.repo-list-item-hanging-avatar { float: left; margin-left: -42px; }

.mini-repo-list-item { position: relative; display: block; padding: 6px 64px 6px 30px; font-size: 14px; border-top: 1px solid var(--color-border-default); }

.mini-repo-list-item:hover { text-decoration: none; }

.mini-repo-list-item:hover .repo, .mini-repo-list-item:hover .owner { text-decoration: underline; }

.mini-repo-list-item .repo-icon { float: left; margin-top: 2px; margin-left: -20px; color: var(--color-fg-muted); }

.mini-repo-list-item .repo-and-owner { max-width: 220px; }

.mini-repo-list-item .owner { max-width: 110px; }

.mini-repo-list-item .repo { font-weight: 600; }

.mini-repo-list-item .stars { position: absolute; top: 0px; right: 10px; margin-top: 6px; font-size: 12px; color: var(--color-fg-muted); }

.mini-repo-list-item .repo-description { display: block; max-width: 100%; font-size: 12px; line-height: 21px; color: var(--color-fg-muted); }

.private .mini-repo-list-item { background-color: var(--color-attention-subtle); }

.private .mini-repo-list-item .repo-icon { color: var(--color-attention-fg); }

.filter-bar { padding: 10px; background-color: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-muted); }

.filter-bar::before { display: table; content: ""; }

.filter-bar::after { display: table; clear: both; content: ""; }

.user-repos .filter-bar { text-align: center; }

.form-group.errored label .commit-ref { background-color: var(--color-danger-subtle); }

.repo-menu-item:not([aria-current="page"]) + .repo-sub-menu { display: none; }

.feature-callout .new-label-hidden { display: none; }

.feature-callout .new-feature-label.new-label-hidden { display: inline; }

.repository-og-image { width: 100%; max-width: 640px; height: 320px; object-fit: cover; object-position: center center; background-repeat: no-repeat; background-position: center center; background-size: cover; }

.timeout { width: auto; height: 300px; padding: 0px; margin: 20px 0px; background-color: transparent; border: 0px; }

.timeout h3 { padding-top: 100px; color: var(--color-fg-muted); }

.repo-language-color { position: relative; top: 1px; display: inline-block; width: 12px; height: 12px; border: 1px solid var(--color-primer-border-contrast); border-radius: 50%; }

.iconbutton .octicon { margin-right: 0px; }

.file-navigation::before { display: table; content: ""; }

.file-navigation::after { display: table; clear: both; content: ""; }

.file-navigation .select-menu-button .css-truncate-target { max-width: 200px; }

.file-navigation .breadcrumb { float: left; margin-top: 0px; margin-left: 5px; font-size: 16px; line-height: 26px; }

.file-navigation + .breadcrumb { margin-bottom: 10px; }

.include-fragment-error { display: none; }

.is-error .include-fragment-error { display: block; }

.prereceive-feedback { padding: 16px; margin-bottom: 16px; border-width: 1px 1px 1px 6px; border-style: solid; border-color: rgb(223, 226, 229) rgb(223, 226, 229) rgb(223, 226, 229) rgb(202, 162, 26); border-image: initial; border-radius: 6px; }

.prereceive-feedback-heading { margin-top: 0px; margin-bottom: 10px; color: var(--color-attention-fg); }

.file-navigation-options { float: right; margin-left: 3px; }

.file-navigation-options .dropdown-menu { width: 360px; padding: 16px; }

.file-navigation-options .dropdown-divider { margin: 0px; }

.file-navigation-option { position: relative; display: inline-block; margin-left: 3px; }

.file-navigation-option .select-menu { display: inline-block; margin-right: 0px; margin-bottom: 0px; vertical-align: middle; }

.file-navigation-option .select-menu-button .octicon:only-child { margin-left: 2px; }

.file-navigation-option .zeroclipboard-button { padding-right: 8px; }

.file-navigation-option .input-group { width: 290px; }

.file-navigation-option .input-group .form-control { width: calc(100% + 2px); height: 28px; min-height: 0px; margin-right: -1px; margin-left: -1px; border-radius: 0px; }

.file-navigation-option .input-group .select-menu-button { position: relative; z-index: 2; }

.Loadmore-workflows[open] summary { display: none; }

.repository-item-checkbox:checked + .repository-item-name { background-color: var(--color-accent-subtle); }

.custom-role-icon { background-color: var(--color-canvas-subtle); }

.profile-picture { margin: 10px 0px 0px; }

.profile-picture > p { float: left; margin: 0px; line-height: 30px; }

.profile-picture > img { float: left; margin: 0px 10px 0px 0px; border-radius: 6px; }

.app-owner { margin: 15px 0px 0px; }

[data-menu-button-contents] .runner-size-menu-dot { display: none; }

[data-menu-button-contents] .runner-size-menu-col-3 { width: 24.9999%; }

.edit-profile-avatar { width: 200px; }

.edit-profile-avatar .drag-and-drop { padding: 0px; color: var(--color-fg-muted); border-width: 0px; }

.edit-profile-avatar input { cursor: pointer; }

.edit-profile-avatar.is-bad-file { border: 0px; }

.edit-profile-avatar .manual-file-chooser { position: absolute; top: 0px; left: 0px; height: 34px; padding: 0px; cursor: pointer; }

.avatar-upload .flash { width: 100%; padding: 30px 15px; border: dashed 1px var(--color-danger-emphasis); box-shadow: none; }

.avatar-upload .upload-state { display: none; padding: 10px 0px; }

.avatar-upload .upload-state p { margin: 0px; font-size: 12px; color: var(--color-fg-muted); }

.avatar-upload .avatar-upload .octicon { display: inline-block; }

.is-uploading .avatar-upload .loading { display: block; padding: 0px; }

.is-uploading .avatar-upload .loading img { vertical-align: top; }

.is-uploading .avatar-upload .button-change-avatar { display: none; }

.is-bad-file .avatar-upload .bad-file { display: block; margin: 0px; }

.is-too-big .avatar-upload .too-big { display: block; margin: 0px; }

.is-bad-dimensions .avatar-upload .bad-dimensions { display: block; margin: 0px; }

.is-bad-format .avatar-upload .bad-format { display: block; margin: 0px; }

.is-failed .avatar-upload .failed-request { display: block; margin: 0px; }

.is-empty .avatar-upload .file-empty { display: block; margin: 0px; }

dl.new-email-form { padding: 10px 10px 0px; margin: 0px -10px 10px; border-top: 1px solid var(--color-border-default); }

.selected-user-key { background-color: var(--color-attention-subtle); }

.user-key-type { padding-right: 20px; padding-left: 10px; text-align: center; }

.user-key-email-badge { display: inline-table; margin-right: 4px; }

.user-key-email { display: table-cell; padding: 1px 5px; font-size: 12px; line-height: 1.4; border: 1px solid var(--color-border-default); border-radius: 6px; }

.user-key-email.unverified { border-top-right-radius: 0px; border-bottom-right-radius: 0px; }

.user-key-email-unverified { display: table-cell; padding-right: 5px; padding-left: 5px; font-size: 11px; color: var(--color-fg-muted); background-color: rgb(236, 235, 236); border-top-color: ; border-top-style: ; border-top-width: ; border-right-color: ; border-right-style: ; border-right-width: ; border-bottom-color: ; border-bottom-style: ; border-bottom-width: ; border-image-source: ; border-image-slice: ; border-image-width: ; border-image-outset: ; border-image-repeat: ; border-left: 0px; border-top-right-radius: 6px; border-bottom-right-radius: 6px; }

.user-key-details { width: 400px; line-height: 1.6; white-space: normal; }

.user-key-details code { font-size: 13px; }

.recent-user-key-access { color: rgb(30, 126, 52); }

.oauth-app-info-container .float-left-container { float: left; text-align: left; }

.oauth-app-info-container .float-right-container { float: right; text-align: right; }

.oauth-app-info-container dl.keys { margin: 10px 0px; }

.oauth-app-info-container dl.keys dt { margin-top: 10px; font-weight: 600; color: var(--color-fg-muted); }

.oauth-app-info-container dl.keys dd { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; color: var(--color-fg-default); }

.oauth-app-info-container .user-count { font-size: 30px; font-weight: 300; color: var(--color-fg-muted); }

.logo-upload { position: relative; display: inline-block; }

.logo-upload a.delete, .logo-upload span.delete { position: absolute; left: 88px; display: none; padding: 8px 10px; }

.logo-upload a.delete:hover, .logo-upload span.delete:hover { color: var(--color-danger-fg); }

.logo-upload-container { display: inline-block; }

.logo-upload-container .logo-upload-label .manual-file-chooser { top: 0px; left: 0px; width: 130px; height: 34px; padding: 0px; margin-left: 0px; cursor: pointer; }

.logo-upload-container .upload-state { padding: 10px 0px; }

.logo-upload-container .upload-state p { margin: 0px; font-size: 12px; color: var(--color-fg-muted); }

.logo-box { width: 120px; height: 120px; background-color: var(--color-canvas-subtle); border: 1px solid var(--color-border-default); border-radius: 6px; }

.logo-box img { display: none; width: 118px; height: 118px; border-radius: 6px; }

.logo-placeholder { color: var(--color-fg-muted); text-align: center; }

.logo-placeholder p { margin: 0px; font-size: 14px; }

.has-uploaded-logo .logo-placeholder, .has-uploaded-logo .or { display: none; }

.has-uploaded-logo:hover a.delete, .has-uploaded-logo:hover span.delete { display: block; }

.has-uploaded-logo .logo-box img { display: block; }

.access-token { border-bottom: 1px solid var(--color-border-muted); }

.access-token:last-child { border: 0px; }

.access-token .last-used { margin-right: 10px; }

.access-token.new-token { background-color: rgba(108, 198, 68, 0.1); }

.access-token.new-token .octicon-check { color: var(--color-success-fg); }

.access-token .token-description { max-width: 450px; color: var(--color-fg-default); }

.access-token .token { font-size: 14px; }

.access-token .token-type { min-width: 76px; }

.regenerate-token-cta .btn-danger { margin-left: 30px; }

.personal-access-tokens label { display: inline; }

.personal-access-tokens label p { display: inline-block; margin: 0px; font-size: 13px; font-weight: 400; }

.personal-access-tokens .child-scopes { margin-left: 20px; list-style: none; }

.personal-access-tokens .child-scopes .token-scope { width: 200px; font-weight: 400; }

.personal-access-tokens .child-scopes .child-scopes { margin-left: 0px; }

.token-scope { display: inline-block; width: 220px; padding: 2px 0px; margin: 0px; font-size: 13px; color: var(--color-fg-default); }

.token-scope input { margin-right: 5px; }

.callback-urls dl dd .form-control { width: 100%; }

.callback-urls.has-many .callback-url-action-cell { display: table-cell; }

.callback-description { margin-top: 20px; }

.callback-description .octicon { padding-left: 0px; }

.callback-url .label { display: none; width: 64px; text-align: center; }

.callback-url.is-default-callback .label { display: inline-block; }

.callback-url.is-default-callback .btn { display: none; }

.callback-url-wrap { display: table; width: 100%; }

.callback-url-action-cell { display: none; width: 70px; text-align: right; }

.boxed-group.application-show-group dl.form-group > dd .form-control.wide { width: 460px; }

.boxed-group.application-show-group dl.form-group > dd .form-control.short { height: 50px; min-height: 50px; }

.application-show-group .errored .note { display: none; }

.application-show-group .drag-and-drop { padding: 0px; text-align: left; background-color: transparent; border: 0px; }

.application-show-group .drag-and-drop img { margin-bottom: 1px; vertical-align: bottom; }

.application-show-group .drag-and-drop span { padding: 0px; }

.application-show-group .dragover .logo-box { box-shadow: rgb(201, 255, 0) 0px 0px 3px; }

.application-show-group .is-uploading .loading { display: inline-block; }

.application-show-group .is-uploading .default { display: none; }

.application-show-group .is-failed .failed-request { display: inline-block; }

.application-show-group .is-failed .default { display: none; }

.application-show-group .is-bad-file .bad-file { display: inline-block; }

.application-show-group .is-bad-file .default { display: none; }

.application-show-group .is-too-big .file-too-big { display: inline-block; }

.application-show-group .is-too-big .default { display: none; }

.application-show-group .is-bad-format .bad-format { display: inline-block; }

.application-show-group .is-bad-format .default { display: none; }

.application-show-group .is-default .default { display: block; }

.post-recovery-token .octospinner, .post-recovery-token .create-recovery-token-error { display: none; }

.post-recovery-token.loading .octospinner { display: block; }

.post-recovery-token.failed .create-recovery-token-error { display: block; }

table.security-history-detail { width: 100%; font-size: 12px; }

table.security-history-detail td { max-width: 200px; overflow-wrap: break-word; }

.email-preference-exceptions { font-size: 12px; }

.email-preference-exceptions h5 { margin: 15px 0px 5px; color: var(--color-fg-muted); }

.email-preference-exceptions .exception-list { list-style: none; }

.email-preference-exceptions .exception { max-width: 400px; padding: 5px 5px 5px 0px; border-top: 1px solid var(--color-border-muted); }

.email-preference-exceptions .exception:last-child { border-bottom: 1px solid var(--color-border-muted); }

.email-preference-exceptions.opt-in-list { display: none; }

.transactional-only .email-preference-exceptions.opt-in-list { display: block; }

.transactional-only .email-preference-exceptions.opt-out-list { display: none; }

.u2f-registration { position: relative; padding-bottom: 8px; margin-bottom: 8px; border-bottom: 1px solid var(--color-border-muted); }

.u2f-registration.is-sending .u2f-registration-delete { display: none; }

.u2f-registration.is-sending .spinner { position: relative; top: 3px; }

.u2f-registration-icon { position: absolute; left: -24px; color: var(--color-fg-muted); }

.new-u2f-registration { position: relative; }

.new-u2f-registration .add-u2f-registration-form:not(.for-trusted-device) { display: none; margin-bottom: 10px; }

.new-u2f-registration.is-active .add-u2f-registration-link { display: none; }

.new-u2f-registration.is-active .add-u2f-registration-form { display: block; }

.new-u2f-registration .webauthn-request-interaction, .new-u2f-registration .webauthn-request-error { display: none; }

.new-u2f-registration.is-sending .webauthn-request-interaction { display: block; }

.new-u2f-registration.is-showing-error .webauthn-request-error { display: block; }

.webauthn-box .webauthn-sorry { display: block; }

.webauthn-box .new-u2f-registration { display: none; }

.webauthn-box.available .webauthn-sorry { display: none; }

.webauthn-box.available .new-u2f-registration { display: block; }

.spinner { display: none; }

.is-sending .spinner { display: inline-block; }

.confirmation-phrase { font-style: italic; font-weight: 400; }

.session-device .session-state-indicator.recent { background-color: var(--color-success-emphasis); box-shadow: rgba(108, 198, 68, 0.5) 0px 0px 10px; }

.session-device .session-state-indicator.revoked { background-color: var(--color-danger-emphasis); box-shadow: rgba(198, 108, 68, 0.5) 0px 0px 10px; }

.session-device .session-state-indicator.not-recent { background-image: linear-gradient(rgb(170, 170, 170), rgb(204, 204, 204)); box-shadow: rgb(255, 255, 255) 0px 1px 0px; }

.collaborators .collab-list { border-bottom-width: 0px; }

.collaborators .collab-list-item:first-child .collab-list-cell { border-top-width: 0px; }

.collaborators .collab-list-cell { padding-top: 15px; padding-bottom: 15px; vertical-align: middle; }

.collaborators .collab-meta { width: 140px; }

.collaborators .collab-remove { padding-right: 20px; text-align: right; }

.collaborators .collab-remove .remove-link { color: var(--color-fg-muted); }

.collaborators .collab-remove .remove-link:hover { color: var(--color-danger-fg); }

.collaborators .collab-team-link { width: 300px; }

.collaborators .collab-team-link:hover { text-decoration: none; }

.collaborators .collab-team-link .avatar { float: left; margin-top: 1px; margin-right: 10px; }

.collaborators .collab-team-link.disabled { pointer-events: none; }

.collaborators .collab-info { height: 100%; color: var(--color-fg-default); }

.collaborators .collab-info .description { padding-right: 50px; margin-top: 3px; margin-bottom: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.collaborators .collab-info .collab-name { display: block; font-size: 14px; }

.collaborators .collab-info .collab-message { position: relative; top: 25%; display: block; }

.collaborators .copy-invite-modal { left: 0px; width: 300px; }

@media (min-width: 768px) {
  .collaborators .copy-invite-modal { right: 0px; left: unset; width: 352px; }
}

.collaborators .copy-invite-modal::before, .collaborators .copy-invite-modal::after { display: none; }

.access-sub-heading { float: right; font-weight: 400; line-height: 1.4; color: var(--color-fg-muted); }

.access-form-wrapper { padding: 10px; background-color: var(--color-canvas-subtle); border-top: 1px solid var(--color-border-default); border-radius: 0px 0px 6px 6px; }

.access-flash { padding: 8px; margin-right: 10px; margin-bottom: 10px; margin-left: 10px; }

.repo-access-group .blankslate { display: none; }

.repo-access-group.is-empty .blankslate { display: block; }

.repo-access-group.no-form .add-team-form { display: none; }

.oauth-pending-deletion-list-item { background-color: var(--color-canvas-subtle); box-shadow: rgb(238, 238, 238) 0px 0px 8px inset; }

.oauth-pending-deletion-list-item:hover { background-color: var(--color-canvas-subtle); }

.oauth-pending-deletion-list-item .oauth-pending-deletion { display: inline-block; width: 19%; line-height: 30px; }

.oauth-pending-deletion-list-item .active { display: none; }

.oauth-pending-deletion { display: none; width: 100%; }

.boxed-group-list .access-level { color: var(--color-fg-muted); }

.boxed-group-list .access-level.css-truncate-target { max-width: 500px; }

.settings-next { font-size: 14px; line-height: 1.5; }

.settings-next label { font-size: 14px; }

.settings-next .note { font-size: 13px; }

.settings-next .form-checkbox input[type="radio"], .settings-next .form-checkbox input[type="checkbox"] { margin-top: 4px; }

dl.form-group > dd textarea.compact { height: 100px; min-height: 0px; }

.form-hr { margin-top: 15px; margin-bottom: 15px; border-bottom-color: var(--color-border-default, #e5e5e5); }

.listgroup { list-style: none; border: 1px solid var(--color-border-default, #e5e5e5); border-radius: 6px; }

.listgroup-item { min-height: inherit; padding: 10px; font-size: 13px; line-height: 26px; color: var(--color-fg-muted); }

.listgroup-item::before { display: table; content: ""; }

.listgroup-item::after { display: table; clear: both; content: ""; }

.listgroup-item + .listgroup-item { border-top: 1px solid var(--color-border-default, #e5e5e5); }

.listgroup-item.listgroup-item-preview { line-height: inherit; }

.listgroup-item.listgroup-item-preview .BtnGroup { margin-top: 5px; }

.listgroup-item .css-truncate-target { max-width: 200px; }

.listgroup-item-title { display: block; font-weight: 600; }

.listgroup-item-body { display: block; }

.listgroup-header { border-top: 0px; border-bottom: 1px solid var(--color-border-default, #e5e5e5); }

.listgroup-overflow { max-height: 240px; overflow-y: auto; background-color: var(--color-canvas-subtle, #f5f5f5); }

.listgroup-sm .listgroup-item { padding-top: 5px; padding-bottom: 5px; }

.protected-branches { margin-top: 15px; margin-bottom: 15px; }

.protected-branch-options { margin-left: 20px; opacity: 0.5; }

.protected-branch-options.active { opacity: 1; }

.protected-branch-reviews.on .require-code-owner-review, .protected-branch-reviews.on .reviews-dismiss-on-push, .protected-branch-reviews.on .reviews-include-dismiss, .protected-branch-reviews.on .allow-force-pushes, .protected-branch-reviews.on .require-approving-reviews { display: block; }

.protected-branch-reviews .require-code-owner-review, .protected-branch-reviews .reviews-dismiss-on-push, .protected-branch-reviews .reviews-include-dismiss, .protected-branch-reviews .allow-force-pushes, .protected-branch-reviews .require-approving-reviews { display: none; }

.authorized-pushers { width: 440px; }

.authorized-pushers .add-protected-branch-user-or-team { display: block; }

.authorized-pushers .user-or-team-limit-reached { display: none; padding: 10px; font-size: 13px; }

.authorized-pushers.at-limit .add-protected-branch-user-or-team { display: none; }

.authorized-pushers.at-limit .user-or-team-limit-reached { display: block; width: 440px; }

.protected-branch-authorized-pushers-table, .protected-branch-pushers-table { margin-top: 10px; }

.protected-branch-authorized-pushers-table .boxed-group-inner, .protected-branch-pushers-table .boxed-group-inner { max-height: 350px; overflow-y: auto; }

.protected-branch-authorized-pushers-table .table-list, .protected-branch-pushers-table .table-list { border-bottom: 0px; }

.protected-branch-authorized-pushers-table .table-list-cell, .protected-branch-pushers-table .table-list-cell { vertical-align: middle; }

.protected-branch-authorized-pushers-table .table-list-cell:first-child, .protected-branch-pushers-table .table-list-cell:first-child { width: 100%; }

.protected-branch-authorized-pushers-table .avatar, .protected-branch-authorized-pushers-table .octicon-jersey, .protected-branch-authorized-pushers-table .octicon-organization, .protected-branch-pushers-table .avatar, .protected-branch-pushers-table .octicon-jersey, .protected-branch-pushers-table .octicon-organization { width: 36px; margin-right: 10px; text-align: center; }

.user-already-added::after { display: inline-block; padding: 1px 5px; margin-left: 6px; font-size: 11px; line-height: 1.4; color: var(--color-fg-on-emphasis); content: "Already added"; background: var(--color-severe-emphasis); border-radius: 6px; }

.protected-branch-admin-permission { float: left; padding: 3px; margin: -2px 0px -2px -4px; line-height: normal; border: 1px solid transparent; border-radius: 6px; }

.protected-branch-admin-permission.active { animation: 1s ease-in-out 0s 1 normal none running toggle-color; }

@keyframes toggle-color { 
  0% { background-color: transparent; }
  50% { color: rgb(76, 74, 66); background-color: rgb(255, 249, 234); border-color: rgb(223, 216, 194); }
  100% { background-color: transparent; }
}

.automated-check-options { margin-top: 10px; }

.automated-check-options .listgroup-item label { font-size: inherit; }

.automated-check-options .listgroup-item input[type="checkbox"] { float: none; margin-top: -2px; margin-right: 5px; margin-left: 0px; }

.automated-check-options .label { margin-top: 4px; }

.repository-merge-features .form-group.errored label { color: inherit; }

.repository-merge-features .form-group.errored .error { position: inherit; padding: 0px; margin-top: 0px; margin-left: 6px; font-size: 11px; color: var(--color-danger-fg); background: transparent; border: 0px; }

.repository-merge-features .form-group.errored .error::before, .repository-merge-features .form-group.errored .error::after { display: none; }

.repository-settings-actions [role="tab"][aria-selected="true"] { font-weight: 600; color: var(--color-fg-default); border-color: var(--color-severe-emphasis); }

.repository-settings-actions [role="tab"][aria-selected="true"] .UnderlineNav-octicon { color: var(--color-fg-muted); }

.radio-label-theme-discs { padding: 0px; transition: padding 0.25s cubic-bezier(0.25, 0.46, 0.45, 0.94) 0s; }

:focus + .radio-label-theme-discs { border-color: var(--color-accent-emphasis); outline: none; box-shadow: var(--color-primer-shadow-focus); }

:checked + .radio-label-theme-discs { border-color: var(--color-accent-emphasis); }

:checked + .radio-label-theme-discs, .radio-label-theme-discs:hover { padding: 8px; }

.settings-protected-domains .protected-domain-delete-dialog { color: var(--color-fg-default); white-space: normal; }

.settings-protected-domains .protected-domain-delete-dialog .repos-to-unpublish { max-height: 16rem; list-style: none; }

.qr-code-table { display: inline-block; padding: 20px; margin: 30px auto; border: 1px solid var(--color-border-muted); border-radius: 6px; box-shadow: rgba(0, 0, 0, 0.04) 0px 2px 2px 0px; }

.qr-code-table tr { background: transparent; border: 0px; }

.qr-code-table th, .qr-code-table td { padding: 0px; border: 0px; }

.qr-code-table td { width: 3px; height: 3px; }

.qr-code-table .black { background: rgb(0, 0, 0); }

.qr-code-table .white { background: rgb(255, 255, 255); }

.two-factor-recovery-codes { margin: 30px 0px; font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; font-size: 21px; }

.two-factor-recovery-code-mark { width: 24px; height: 24px; font-size: 24px; line-height: 16px; color: var(--color-fg-muted); }

.two-factor-recovery-code { display: inline-block; width: 48%; line-height: 1.6; text-align: center; }

.two-factor-recovery-code::before { position: relative; top: -3px; margin-right: 10px; font-size: 10px; color: var(--color-fg-muted); content: "●"; }

.recovery-codes-saving-options { margin-left: 35px; }

.recovery-codes-saving-options .recovery-code-save-button { width: 115px; margin-right: 15px; text-align: center; }

.recovery-codes-warning { margin: 0px -15px; }

.recovery-codes-warning .recovery-codes-warning-octicon { height: 40px; margin-right: 15px; }

.btn-two-factor-state { min-width: 70px; }

.two-factor-steps { padding: 16px 16px 0px; margin: 32px 0px; border: 1px solid var(--color-border-default); border-radius: 6px; }

.two-factor-toggle .two-factor-status { color: var(--color-fg-muted); border-bottom: 1px solid var(--color-border-muted); }

.two-factor-settings-group { border-bottom: 1px solid var(--color-border-muted); }

.two-factor-settings-group li { line-height: 1.5; list-style: none; }

.github-access-banner { position: relative; padding: 10px 20px 10px 70px; margin: 0px 0px 20px; font-size: 14px; border: 1px solid var(--color-border-default); border-radius: 6px; }

.github-access-banner .octicon { position: absolute; top: 20px; left: 20px; color: var(--color-danger-fg); }

.setup-wrapper { width: 750px; padding-top: 30px; margin: 0px auto; }

.setup-wrapper::before { display: table; content: ""; }

.setup-wrapper::after { display: table; clear: both; content: ""; }

.setup-header { padding-bottom: 20px; margin: 0px auto 30px; overflow: hidden; text-align: left; border-bottom: 1px solid var(--color-border-default); }

.setup-header h1 { margin-top: 0px; margin-bottom: 0px; font-size: 45px; font-weight: 400; line-height: 1.1; letter-spacing: -1px; }

.setup-header h1 .octicon { color: var(--color-fg-muted); }

.setup-header .lead { margin-top: 2px; margin-bottom: 0px; font-size: 21px; }

.setup-header .lead a { color: var(--color-fg-muted); }

.setup-header .lead a:hover { color: var(--color-accent-fg); text-decoration: none; }

.setup-org { padding-bottom: 0px; border-bottom: 0px; }

.setup-main { float: left; width: 450px; }

.setup-secondary { float: right; width: 250px; }

.setup-secondary .info { padding-top: 0px; padding-bottom: 0px; margin-top: -10px; font-size: 12px; line-height: 18px; color: var(--color-fg-muted); text-align: center; }

.setup-info-module { margin-bottom: 30px; background-color: var(--color-canvas-default); border: 1px solid var(--color-border-default); border-radius: 6px; box-shadow: rgba(0, 0, 0, 0.075) 0px 1px 3px; }

.setup-info-module h2 { padding: 16px; margin-bottom: 16px; overflow: hidden; font-size: 16px; border-bottom: 1px solid var(--color-border-default); }

.setup-info-module h2 .price { float: right; font-weight: 600; color: var(--color-fg-muted); }

.setup-info-module h3 { padding: 0px 15px; margin: 0px 0px -7px; font-size: 14px; }

.setup-info-module p { padding: 0px 15px; margin: 15px 0px; }

.features-list { padding: 0px 15px 15px; margin: 0px; font-size: 14px; list-style: none; }

.features-list li { margin-top: 10px; }

.features-list li:first-child { margin-top: 0px; }

.features-list .list-divider { margin: 15px -15px; border-top: 1px solid var(--color-border-muted); }

.features-list .octicon-check { margin-right: 5px; color: var(--color-success-fg); }

.features-list .octicon-question { font-size: 12px; color: var(--color-fg-muted); }

.features-list .tooltipped::after { width: 250px; white-space: normal; }

.setup-form-container .setup-form-title { font-size: 16px; }

.setup-form-container .secure { float: right; margin-top: 2px; font-size: 11px; color: var(--color-success-fg); text-transform: uppercase; }

.setup-form-container hr { margin-top: 25px; margin-bottom: 25px; }

.setup-form-container .form-actions { padding-top: 0px; padding-bottom: 0px; text-align: left; }

.team-member-container { margin-bottom: 20px; }

.team-member-container .team-member-username { line-height: 1.2; }

.setup-form { padding-bottom: 15px; }

.setup-form .form-group.successed .error { display: none; }

.setup-form .form-group dd .form-control { width: 100%; }

.setup-form .form-group dd .form-control.short { width: 250px; }

.setup-form dd { position: relative; }

.setup-form dd .octicon { position: absolute; top: 8px; right: 25px; }

.setup-form .octicon-alert { color: var(--color-danger-fg); }

.setup-form .octicon-check { color: var(--color-success-fg); }

.setup-form .tos-info, .setup-form .setup-organization-next { margin: 15px 0px; border-top: 1px solid var(--color-border-muted); border-bottom: 1px solid var(--color-border-muted); }

.setup-form .tos-info { padding: 15px 0px; }

.setup-form .setup-organization-next { padding-top: 15px; padding-bottom: 15px; }

.setup-form .setup-plans { border-collapse: separate; border: 1px solid var(--color-border-default); }

.setup-form .setup-plans tr.selected { background-color: var(--color-accent-subtle); }

.setup-form .setup-plans .name { font-weight: 600; }

.setup-form .setup-plans .choose-plan input[type="radio"] { display: none; }

.setup-creditcard-form .country-form, .setup-creditcard-form .state-form { float: left; margin: 0px; overflow-wrap: normal; }

.setup-creditcard-form .country-form, .setup-creditcard-form .postal-code-form { margin-top: 0px; margin-bottom: 15px; }

.setup-creditcard-form .form-group select.select-country { width: 182px; margin-right: 5px; }

.setup-creditcard-form .form-group select:invalid { color: var(--color-fg-muted); }

.setup-creditcard-form .form-group select.select-state { width: 113px; }

.setup-creditcard-form .form-group .input-vat { width: 288px; }

.setup-creditcard-form .form-group input.input-postal-code { width: 180px; }

.setup-creditcard-form.is-vat-country .vat-field { display: block; }

.setup-creditcard-form.is-international .form-group select.select-country { width: 300px; }

.setup-creditcard-form.is-international .state-form { display: none; }

.setup-creditcard-form.no-postcodes .postal-code-form { display: none; }

.setup-creditcard-form dd .octicon-credit-card { position: inherit; }

.setup-creditcard-form .vat-field { display: none; }

.setup-creditcard-form .vat-field.prefilled { display: block; }

.setup-creditcard-form .help-text { font-size: 80%; font-weight: 400; color: var(--color-fg-muted); }

.user-identification-questions { float: none; width: auto; margin-top: 40px; }

.user-identification-questions .question { margin-bottom: 30px; }

.user-identification-questions .response-group label { font-weight: 400; }

.user-identification-questions .form-checkbox { margin: 8px 0px; }

.user-identification-questions .disclaimer { margin: 40px 0px 0px; text-align: center; }

.user-identification-questions.redesign .question { margin-bottom: 96px; }

.user-identification-questions.redesign .topic-input-container .tag-input { width: 100%; border-width: 0px 0px 6px; border-top-style: initial; border-right-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-left-color: initial; border-image: initial; border-bottom-style: solid; border-bottom-color: rgb(0, 0, 0); box-shadow: 0px 0px 0px; }

.signup-plan-summary-subhead { border-bottom: 6px solid; }

.signup-btn:disabled { opacity: 0.5 !important; }

.collection-search-results em { padding: 0.1em; background-color: rgb(250, 255, 166); }

.draft-tag { padding: 5px 10px; font-weight: 600; color: rgb(238, 238, 238); background-color: rgb(64, 64, 64); }

.showcase-page-pattern { position: relative; z-index: -1; height: 100px; margin-top: -21px; margin-bottom: -70px; }

.showcase-page-pattern::after { position: absolute; inset: 0px; display: block; content: ""; background-image: linear-gradient(rgba(255, 255, 255, 0.85), white); }

.showcase-page-repo-list { border-top: 1px solid var(--color-border-muted); }

.slash-command-menu-item .command-description { color: var(--color-fg-muted); }

.slash-command-menu-item[aria-selected="true"] { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.slash-command-menu-item[aria-selected="true"] .command-description { color: var(--color-fg-on-emphasis); }

.modal-anchor::before { position: fixed; inset: 0px; z-index: 99; display: block; cursor: default; content: " "; background: var(--color-primer-canvas-backdrop); }

.sortable-button-item:first-of-type .sortable-button[data-direction="up"], .sortable-button-item:last-of-type .sortable-button[data-direction="down"] { display: none; }

@keyframes sponsors-progress-animation { 
  0% { background-position: 100% center; }
  100% { background-position: 0% center; }
}

.sponsors-goal-progress-bar { background: rgb(236, 108, 185); transition: width 0.5s ease-in 0s; }

.sponsors-goal-progress-bar:hover { cursor: pointer; background: linear-gradient(90deg, rgb(255, 211, 61) 0%, rgb(234, 74, 170) 17%, rgb(179, 75, 255) 34%, rgb(1, 254, 255) 51%, rgb(255, 211, 61) 68%, rgb(234, 74, 170) 85%, rgb(179, 75, 255) 100%) 0% 0% / 300% 100%; animation: 2s linear 0s infinite normal none running sponsors-progress-animation; }

.sponsors-goal-completed-bar { background: linear-gradient(90deg, rgb(255, 211, 61) 0%, rgb(234, 74, 170) 17%, rgb(179, 75, 255) 34%, rgb(1, 254, 255) 51%, rgb(255, 211, 61) 68%, rgb(234, 74, 170) 85%, rgb(179, 75, 255) 100%) 0% 0% / 300% 100%; transition: width 0.5s ease-in 0s; animation: 2s linear 0s infinite normal none running sponsors-progress-animation; }

.sponsors-goals-avatar-border { background-color: var(--color-canvas-default); border: 1px solid var(--color-fg-on-emphasis); }

.sponsors-goals-heart-anim { width: 100px; height: 100px; cursor: pointer; background: url("/images/modules/site/sponsors/heart-explosion.png") 0px 0px / 600px 100px no-repeat; transition: background-position 0s steps(5) 0s; }

.sponsors-goals-heart-anim.is-active { background-position: -500px 0px; transition-duration: 0.3s; }

.open > .sponsors-foldable { max-height: 700px; }

.open .sponsors-foldable-opened { display: block; }

.open .sponsors-foldable-closed { display: none; }

.sponsors-foldable { max-height: 0px; box-sizing: border-box; overflow-y: auto; transition: max-height 0.25s ease-in-out 0s; }

.sponsors-foldable-opened { display: none; }

.sponsors-foldable-closed { display: block; }

.sponsor-card { width: 100%; height: 450px; border: 0px; }

@media (min-width: 544px) {
  .sponsor-card { height: 260px; }
}

.sponsor-cell { padding: 8px; vertical-align: middle; border-right: 1px solid var(--color-neutral-muted); border-bottom: 1px solid var(--color-neutral-muted); }

.sponsor-cell:first-child { width: 45px; padding-left: 32px; border-right-width: 0px; }

.sponsor-cell:last-child { padding-left: 8px; border-right-width: 0px; }

.sponsor-header-cell { padding-right: 16px; font-weight: 600; text-align: left; border-top: 1px solid var(--color-neutral-muted); }

.sponsor-row-number { color: var(--color-fg-subtle); }

@media (prefers-reduced-motion: no-preference) {
  .tier-category:hover .tier-emoji { animation: 0.1s ease 0.1s 4 alternate none running wiggle; }
}

@keyframes wiggle { 
  0% { transform: rotate(-25deg); }
  100% { transform: rotate(15deg) scale(1.2); }
}

.tab-size[data-tab-size="1"] { tab-size: 1; }

.tab-size[data-tab-size="2"] { tab-size: 2; }

.tab-size[data-tab-size="3"] { tab-size: 3; }

.tab-size[data-tab-size="4"] { tab-size: 4; }

.tab-size[data-tab-size="5"] { tab-size: 5; }

.tab-size[data-tab-size="6"] { tab-size: 6; }

.tab-size[data-tab-size="7"] { tab-size: 7; }

.tab-size[data-tab-size="8"] { tab-size: 8; }

.tab-size[data-tab-size="9"] { tab-size: 9; }

.tab-size[data-tab-size="10"] { tab-size: 10; }

.tab-size[data-tab-size="11"] { tab-size: 11; }

.tab-size[data-tab-size="12"] { tab-size: 12; }

.team-label-ldap { display: inline-block; padding: 0px 9px; line-height: 25px; color: var(--color-fg-muted); text-transform: uppercase; cursor: default; border: 1px solid var(--color-border-muted); border-radius: 6px; box-shadow: none; }

.team-label-ldap.header-label-ldap { padding: 3px 5px; }

.team-member-ellipsis { width: 25px; height: 25px; line-height: 24px; }

.team-member-ellipsis:hover { color: var(--color-accent-fg); background: var(--color-canvas-subtle); }

.team-listing .nested-teams-checkbox { padding-left: 3px; }

.team-listing .nested-teams-checkbox.show { padding-right: 11px; }

.team-listing .nested-teams-checkbox.indent-1 { padding-left: 30px; }

.team-listing .nested-teams-checkbox.indent-2 { padding-left: 54px; }

.team-listing .nested-teams-checkbox.indent-3 { padding-left: 78px; }

.team-listing .nested-teams-checkbox.indent-4 { padding-left: 102px; }

.team-listing .nested-teams-checkbox.indent-5 { padding-left: 126px; }

.team-listing .nested-teams-checkbox.indent-6 { padding-left: 150px; }

.team-listing .nested-teams-checkbox.indent-7 { padding-left: 174px; }

.team-listing .nested-teams-checkbox.indent-8 { padding-left: 198px; }

.team-listing .nested-teams-checkbox.indent-9 { padding-left: 222px; }

.team-listing .nested-teams-checkbox.indent-10 { padding-left: 246px; }

.team-listing .nested-teams-checkbox.indent-11 { padding-left: 270px; }

.team-listing .nested-teams-checkbox.indent-12 { padding-left: 294px; }

.team-listing .nested-teams-checkbox.indent-13 { padding-left: 318px; }

.team-listing .nested-teams-checkbox.indent-14 { padding-left: 342px; }

.team-listing .nested-teams-checkbox.indent-15 { padding-left: 366px; }

.team-listing .team-info { width: 280px; }

.team-listing .team-short-info { width: 170px; }

.team-listing .nested-team-info { width: 650px; }

.team-listing .nested-team-name { max-width: 268px; }

.team-listing .shortened-teams-avatars { margin-left: auto; }

.team-listing .shortened-teams-avatars.width-0 { width: 300px; }

.team-listing .shortened-teams-avatars.width-1 { width: 233px; }

.team-listing .shortened-teams-avatars.width-2 { width: 167px; }

.team-listing .shortened-teams-avatars.width-3 { width: 99px; }

.team-listing .team-members-count { width: 124px; }

.team-listing .team-show-more-cell { width: 980px; }

.team-listing .team-buttons { width: 150px; }

.team-listing .octicon-wrapper { width: 16px; }

.team-listing .is-open.root-team { background-color: var(--color-canvas-subtle); }

.team-listing .is-open .expand-nested-team { font-weight: 600; }

.team-listing .is-open .octicon-chevron-down { transform: rotate(180deg); }

.traffic-graph { min-height: 150px; }

.traffic-graph .activity { margin-top: 0px; }

.traffic-graph .activity .dots { margin-top: 40px; }

.traffic-graph .path { fill: none; stroke-width: 2; }

.traffic-graph path.total { stroke: var(--color-success-emphasis); }

.traffic-graph path.unique { stroke: var(--color-accent-emphasis); }

.traffic-graph .axis .tick:first-of-type line { stroke: var(--color-success-emphasis); stroke-width: 2px; }

.traffic-graph .y line { stroke: var(--color-success-emphasis); }

.traffic-graph .y.unique line { stroke: var(--color-accent-emphasis); }

.traffic-graph .overlay { fill-opacity: 0; }

.uniques-graph .axis .tick:last-child line { stroke: var(--color-accent-emphasis); stroke-width: 2px; }

.svg-tip .date { color: var(--color-fg-on-emphasis); }

.top-domains .dots { display: block; margin: 167px auto 0px; }

table.capped-list { width: 100%; line-height: 100%; }

table.capped-list th { padding: 8px; text-align: left; background: var(--color-canvas-subtle); border-bottom: 1px solid var(--color-border-default); }

table.capped-list td { padding: 8px; font-size: 12px; vertical-align: middle; border-bottom: 1px solid var(--color-border-muted); }

table.capped-list th.middle, table.capped-list td.middle { text-align: center; }

table.capped-list .favicon { width: 16px; height: 16px; margin: 0px 5px; vertical-align: middle; }

table.capped-list .octicon { margin-right: 10px; color: var(--color-fg-muted); vertical-align: -3px; }

table.capped-list tr:nth-child(2n) { background-color: var(--color-canvas-subtle); }

.capped-list-label { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.traffic-graph-stats .summary-stats { width: 100%; }

.traffic-graph-stats .summary-stats::before { display: table; content: ""; }

.traffic-graph-stats .summary-stats::after { display: table; clear: both; content: ""; }

.traffic-graph-stats .summary-stats li { display: block; float: left; width: 50%; }

.totals circle { fill: var(--color-success-emphasis); stroke: var(--color-canvas-default); stroke-width: 2; }

.uniques circle { fill: var(--color-accent-emphasis); stroke: var(--color-canvas-default); stroke-width: 2; }

ul.web-views li { width: 140px; }

ul.clones li { width: 170px; }

.tree-finder-input, .tree-finder-input:focus { font-size: inherit; box-shadow: none; appearance: none; }

.tree-browser .octicon-chevron-right { color: transparent; }

.tree-browser-result .octicon-file { color: var(--color-fg-muted); }

.tree-browser-result:hover, .tree-browser-result[aria-selected="true"] { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.tree-browser-result:hover .octicon-file, .tree-browser-result[aria-selected="true"] .octicon-file { color: inherit; }

.tree-browser-result[aria-selected="true"] .octicon-chevron-right { color: inherit; }

.tree-browser-result .css-truncate-target { max-width: 870px; }

.tree-browser-result mark { font-weight: 600; color: inherit; background: none; }

.typeahead-result { position: relative; display: block; min-width: 100%; padding: 10px; margin-top: 0px; color: var(--color-fg-default); cursor: pointer; }

.typeahead-result::before { display: table; content: ""; }

.typeahead-result::after { display: table; clear: both; content: ""; }

.typeahead-result:first-child { border-top: 0px; }

.typeahead-result:focus, .typeahead-result:hover, .typeahead-result[aria-selected="true"], .typeahead-result.navigation-focus { text-decoration: none; }

.typeahead-result[aria-selected="true"], .typeahead-result:hover, .typeahead-result.navigation-focus { color: var(--color-fg-on-emphasis); background-color: var(--color-accent-emphasis); }

.typeahead-result[aria-selected="true"] .octicon-plus, .typeahead-result:hover .octicon-plus, .typeahead-result.navigation-focus .octicon-plus { color: var(--color-fg-on-emphasis); }

.typeahead-result.disabled { pointer-events: none; opacity: 0.5; }

.member-suggestion { padding-left: 44px; }

.member-suggestion .avatar { float: left; margin-right: 10px; margin-left: -34px; }

.member-suggestion .member-suggestion-info { width: 90%; margin-top: 2px; margin-bottom: 0px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.member-suggestion .member-name { font-size: 12px; color: var(--color-fg-muted); }

.member-suggestion .member-email { margin-top: 0px; margin-bottom: 0px; }

.member-suggestion .octicon-plus, .member-suggestion .octicon-check { position: absolute; top: 50%; right: 15px; margin-top: -8px; color: var(--color-fg-muted); }

.member-suggestion .already-member-note, .member-suggestion .non-member-note, .member-suggestion .non-member-action { margin-top: 0px; margin-bottom: 0px; color: var(--color-fg-muted); }

.member-suggestion .non-member-action { display: none; }

.member-suggestion[aria-selected="true"] .member-name, .member-suggestion[aria-selected="true"] .non-member-note, .member-suggestion[aria-selected="true"] .already-member-note, .member-suggestion[aria-selected="true"] .non-member-action, .member-suggestion[aria-selected="true"] .member-email, .member-suggestion:hover .member-name, .member-suggestion:hover .non-member-note, .member-suggestion:hover .already-member-note, .member-suggestion:hover .non-member-action, .member-suggestion:hover .member-email, .member-suggestion.navigation-focus .member-name, .member-suggestion.navigation-focus .non-member-note, .member-suggestion.navigation-focus .already-member-note, .member-suggestion.navigation-focus .non-member-action, .member-suggestion.navigation-focus .member-email { color: var(--color-fg-on-emphasis); }

.member-suggestion[aria-selected="true"] .non-member-note, .member-suggestion:hover .non-member-note, .member-suggestion.navigation-focus .non-member-note { display: none; }

.member-suggestion[aria-selected="true"] .non-member-action, .member-suggestion:hover .non-member-action, .member-suggestion.navigation-focus .non-member-action { display: block; }

.member-suggestion[aria-selected="true"] .octicon, .member-suggestion:hover .octicon, .member-suggestion.navigation-focus .octicon { color: var(--color-fg-on-emphasis); }

.member-suggestion.not-a-member .member-info, .member-suggestion.disabled .member-info { margin-top: -2px; }

.non-member-result { padding-left: 31px; }

.team-suggestion { padding-left: 32px; }

.team-suggestion .octicon { float: left; margin-top: 2px; margin-left: -22px; }

.team-suggestion .team-suggestion-info { margin: 2px 0px 0px; }

.team-suggestion .team-suggestion-info .css-truncate-target { max-width: none; }

.team-suggestion .team-size, .team-suggestion .team-description { font-size: 12px; color: var(--color-fg-muted); }

.team-suggestion[aria-selected="true"] .team-size, .team-suggestion[aria-selected="true"] .team-description, .team-suggestion.navigation-focus .team-size, .team-suggestion.navigation-focus .team-description { color: var(--color-fg-on-emphasis); }

.email-suggestion { padding-left: 32px; }

.email-suggestion .octicon-mail { margin-left: -20px; color: var(--color-fg-muted); }

.email-suggestion .member-suggestion-info { margin-top: 1px; }

.repo-access-add-team .team-name { font-size: 13px; }

.repo-access-add-team .team-description { display: block; }

.repo-access-add-team .team-size, .repo-access-add-team .team-description { font-size: 12px; color: var(--color-fg-muted); }

.repo-access-add-team[aria-selected="true"] .team-size, .repo-access-add-team[aria-selected="true"] .team-description, .repo-access-add-team.navigation-focus .team-size, .repo-access-add-team.navigation-focus .team-description { color: var(--color-fg-on-emphasis); }

#user-content-toc { overflow: visible; }

#user-content-toc tr { border-top: 0px; }

#user-content-toc td { padding: 0px 20px; background-color: var(--color-canvas-subtle); border: 0px; border-radius: 6px; }

#user-content-toc ul { padding-left: 0px; font-weight: 600; list-style: none; }

#user-content-toc ul li { padding-left: 0.2em; }

#user-content-toc ul ul { font-weight: 400; }

#user-content-toc ul ul li::before { float: left; margin-top: -0.2em; margin-right: 0.2em; font-size: 1.2em; line-height: 1; color: var(--color-fg-muted); content: "⌞"; }

#user-content-toc ul ul ul { padding-left: 0.9em; }

#user-content-toctitle h2 { margin-top: 1em; margin-bottom: 0.5em; font-size: 1.25em; border-bottom: 0px; }

.user-list-info { min-height: 48px; padding: 0px; font-size: 18px; font-weight: 400; line-height: 20px; }

.wiki-rightbar .markdown-body .anchor { display: none; }

.wiki-rightbar .markdown-body h1 { font-size: 1.6em; }

.wiki-rightbar .markdown-body h2 { font-size: 1.4em; }

.wiki-rightbar p:last-child, .wiki-rightbar ul:last-child, .wiki-rightbar ol:last-child { margin-bottom: 0px; }

.wiki-footer .markdown-body, .wiki-rightbar .markdown-body { font-size: 13px; }

.wiki-footer .markdown-body.wiki-writable > :nth-child(2), .wiki-rightbar .markdown-body.wiki-writable > :nth-child(2) { margin-top: 0px !important; }

.wiki-footer .markdown-body img { background: none; }

.wiki-pages-box .wiki-more-pages { display: none; }

.wiki-pages-box.wiki-show-more .wiki-more-pages, .wiki-pages-box .filterable-active .wiki-more-pages { display: block; }

.wiki-pages-box.wiki-show-more .wiki-more-pages-link, .wiki-pages-box .filterable-active .wiki-more-pages-link { display: none; }

.js-wiki-sidebar-toc-toggle-chevron { transition: transform 250ms ease-in-out 0s; transform: rotate(-90deg); }

.js-wiki-sidebar-toc-toggle-chevron.js-wiki-sidebar-toc-toggle-chevron-open { transform: rotate(0deg); }

.visual-graph { transition: opacity 0.1s ease-out 0s; }

.WorkflowGraph { cursor: grab; }

.WorkflowGraph.dragging * { cursor: grabbing !important; }

.WorkflowGraph.dragging .WorkflowJob:hover { background: none !important; }

.WorkflowGraph.dragging a:hover, .WorkflowGraph.dragging .btn-link:hover { text-decoration: none !important; }

.WorkflowStage { margin-right: 56px !important; }

.WorkflowCard { z-index: 1; width: 260px; background-color: var(--color-workflow-card-bg); transition: background-color 0.12s ease-out 0s, border-color 0.12s ease-out 0s, box-shadow 0.12s ease-out 0s; }

.WorkflowCard.active { z-index: 3; box-shadow: var(--color-shadow-medium)  !important; }

.WorkflowCard.active--in .WorkflowCard-port--input::after { background-color: var(--color-workflow-card-connector-highlight-bg); }

.WorkflowCard.active--out .WorkflowCard-port--output::after { background-color: var(--color-workflow-card-connector-highlight-bg); }

.visual-graph.active .WorkflowCard:not(.active) { background-color: var(--color-workflow-card-inactive-bg); border-color: var(--color-border-muted)  !important; }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowJob, .visual-graph.active .WorkflowCard:not(.active) .MatrixComponent-pending, .visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-heading--content { opacity: 0.5; }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-port::before { background-color: var(--color-workflow-card-inactive-bg); }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-port::after { background-color: var(--color-workflow-card-connector-inactive-bg); }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-port--input { background-image: linear-gradient(270deg, var(--color-workflow-card-inactive-bg) 0%, var(--color-workflow-card-inactive-bg) 50%, var(--color-border-default) 50%, var(--color-border-default) 100%); }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-port--output { background-image: linear-gradient(90deg, var(--color-workflow-card-inactive-bg) 0%, var(--color-workflow-card-inactive-bg) 50%, var(--color-border-default) 50%, var(--color-border-default) 100%); }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-heading { background-color: var(--color-workflow-card-inactive-bg); box-shadow: inset 0 1px 0 var(--color-border-muted),inset 1px 0 0 var(--color-border-muted),inset -1px 0 0 var(--color-border-muted),0 -1px 2px var(--color-workflow-card-header-shadow); }

.visual-graph.active .WorkflowCard:not(.active) .WorkflowCard-heading::after { box-shadow: inset 1px 0 0 var(--color-border-muted),inset 0 -1px 0 var(--color-border-muted),-1px 3px var(--color-workflow-card-inactive-bg); }

.visual-graph.active .WorkflowConnector:not(.active) { stroke: var(--color-workflow-card-connector-inactive); }

.WorkflowCard.WorkflowCard-group { width: 292px; }

.WorkflowCard.has-title { border-top-left-radius: 0px !important; }

.WorkflowCard-heading { top: -21px; left: -1px; background-color: var(--color-workflow-card-bg); box-shadow: inset 0 1px 0 var(--color-border-default),inset 1px 0 0 var(--color-border-default),inset -1px 0 0 var(--color-border-default),0 -1px 2px var(--color-workflow-card-header-shadow); transition: background-color 0.12s ease-out 0s, box-shadow 0.12s ease-out 0s; }

.WorkflowCard-heading--content { transition: opacity 0.12s ease-out 0s; }

.WorkflowCard-heading::after { position: absolute; top: 5px; width: 20px; height: 16px; margin-left: 15px; content: ""; border-bottom-left-radius: 6px; box-shadow: inset 1px 0 0 var(--color-border-default),inset 0 -1px 0 var(--color-border-default),-1px 3px var(--color-workflow-card-bg); transition: box-shadow 0.12s ease-out 0s; }

.WorkflowCard-group .WorkflowCard-port { top: 30px; }

.WorkflowCard-group .WorkflowJob:hover { background: var(--color-canvas-subtle); }

.WorkflowCard-port { top: 14px; width: 16px; height: 16px; }

.WorkflowCard-port::before { position: absolute; top: 1px; left: 1px; width: 14px; height: 14px; content: ""; background-color: var(--color-workflow-card-bg); border-radius: 50%; transition: background-color 0.12s ease-out 0s; }

.WorkflowCard-port::after { position: absolute; top: 4px; left: 4px; width: 8px; height: 8px; content: ""; background-color: var(--color-workflow-card-connector-bg); border-radius: 50%; transition: background-color 0.12s ease-out 0s; }

.WorkflowCard-port--input { left: -8px; background-image: linear-gradient(270deg, var(--color-workflow-card-bg) 0%, var(--color-workflow-card-bg) 50%, var(--color-border-default) 50%, var(--color-border-default) 100%); }

.WorkflowCard-port--output { right: -8px; background-image: linear-gradient(90deg, var(--color-workflow-card-bg) 0%, var(--color-workflow-card-bg) 50%, var(--color-border-default) 50%, var(--color-border-default) 100%); }

.WorkflowJob-deployment-progress .Progress { background: none; }

.WorkflowJob-deployment-progress .WorkflowJob-deployment-progress-complete { background-color: var(--color-workflow-card-progress-complete-bg)  !important; }

.WorkflowJob-deployment-progress .WorkflowJob-deployment-progress-incomplete { background-color: var(--color-workflow-card-progress-incomplete-bg)  !important; }

.WorkflowJob { padding: 12px; transition: opacity 0.12s ease-out 0s; }

.WorkflowJob-title { height: 20px; line-height: 20px; }

.WorkflowJob-title::after { position: absolute; inset: 0px; content: ""; }

.MatrixComponent-pending { padding: 12px; transition: opacity 0.12s ease-out 0s; }

.MatrixComponent-collapse--title { line-height: 20px; }

.WorkflowConnectors { z-index: 0; pointer-events: none; transform-origin: left top; }

.WorkflowConnectors.active { z-index: 2; }

.WorkflowConnector { stroke: var(--color-workflow-card-connector); stroke-width: 2px; transition: stroke 0.12s ease-out 0s, stroke-width 0.12s ease-out 0s, opacity 0.12s ease-out 0s; }

.WorkflowConnector--hl { opacity: 0; }

.WorkflowConnector--hl.active { stroke: var(--color-workflow-card-connector-highlight); stroke-width: 3px; opacity: 1; }

.zoom-btn { padding: 5px; line-height: 16px; }

.zoom-btn .octicon { color: var(--color-fg-default); }

.zoom-btn.disabled .octicon { color: var(--color-fg-muted); }

@media (min-width: 1012px) {
  .actions-workflow-navigation { max-width: 340px; }
}

@media (min-width: 768px) {
  .actions-workflow-navigation { top: 16px; max-height: calc(100vh - 16px); }
}

.actions-workflow-navigation .row { height: 40px; line-height: 20px; text-decoration: none; transition: background-color 0.15s ease 0s; }

.actions-workflow-navigation .row:hover { background-color: var(--color-canvas-subtle); }

.actions-workflow-navigation .row-selected { font-weight: 600; background-color: var(--color-canvas-subtle); }

.actions-workflow-navigation .row-section { background: transparent !important; }

.actions-workflow-navigation .row-parent { background: transparent; }

.actions-workflow-navigation .row-parent:hover { background-color: transparent; }

.actions-workflow-navigation .row-child { height: 32px; }

.actions-workflow-navigation .row-child:hover { color: var(--color-fg-default)  !important; }

.actions-workflow-table.sticky th { position: sticky; top: 0px; z-index: 1; background-color: var(--color-primer-canvas-sticky); }

.actions-workflow-table th { height: auto; line-height: 44px; text-align: left; }

.actions-workflow-table td { height: 64px; padding-top: 12px; padding-bottom: 12px; line-height: 20px; }

.actions-workflow-table td.compact { height: 48px; }

.actions-workflow-table th:first-child, .actions-workflow-table td:first-child { padding-left: 16px; }

@media (min-width: 768px) {
  .actions-workflow-table th:first-child, .actions-workflow-table td:first-child { padding-left: 20px; }
}

.actions-workflow-table th:last-child, .actions-workflow-table td:last-child { padding-right: 20px; }

.actions-workflow-stats .col { min-width: 72px; }

.actions-workflow-stats .col-triggered-content { min-width: 128px; min-height: 24px; }

@media (max-width: 768px) {
  .actions-fullwidth-module { position: relative; margin-right: -16px !important; margin-left: -16px !important; border-right: 0px !important; border-left: 0px !important; }
  .actions-fullwidth-module.actions-fullwidth-module { border-radius: 0px !important; }
  .actions-fullwidth-module::after { position: absolute; right: 0px; bottom: -17px; left: 0px; z-index: 0; height: 16px; content: ""; background-color: var(--color-canvas-subtle); }
}

@keyframes expand { 
  0% { opacity: 0.5; transform: translateY(-4px); }
  100% { opacity: 1; transform: translateY(0px); }
}

.workflow-nav-mobile-details .octicon-chevron-right { transition: transform 0.09s ease-out 0s; }

.workflow-nav-mobile-details[open] .octicon-chevron-right { transform: rotate(90deg); }

.workflow-nav-mobile-details[open] .job-list { animation: 0.2s ease 0s 1 normal none running expand; }

.workflow-nav-mobile-details .job-list { position: relative; }

.workflow-nav-mobile-details .job-link { height: 40px; }

.workflow-nav-mobile-details .job-link:hover { background: var(--color-neutral-subtle); }

.ActionsApprovalOverlay-environment { min-height: 64px; cursor: pointer; }

.ActionsApprovalOverlay-environment .AvatarStack-body { background: transparent !important; }

.ActionsApprovalOverlay-environment:hover, .ActionsApprovalOverlay-environment.selected-approval-environment { background: var(--color-neutral-subtle); border-color: var(--color-neutral-subtle)  !important; }

.uxr_CheckRun-search { width: auto; }

.uxr_CheckRun-header { position: sticky; top: 0px; z-index: 1; }

.uxr_CheckRun-header::after { position: absolute; right: 0px; bottom: -9px; left: 0px; height: 8px; content: ""; background-color: inherit; }

.uxr_CheckStep-header { position: sticky; top: 88px; transition: background-color 0.15s ease 0s; }

.annotation--contracted div:first-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.annotation--expanded div:first-child { word-break: break-word; white-space: pre-wrap; }

.enterprise-settings .field-with-errors { min-width: 0px; padding: 0px; }
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: image/png
Content-Transfer-Encoding: binary
Content-Location: https://avatars.githubusercontent.com/u/96439587?s=40&v=4

�PNG

   IHDR  �  �   �.�b  �IDATx���Am�@FѶAē�DrX��:�ig�|	��c| <��� 3�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$���M��u�Ӿů����	ɫ��9��e$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$����po���z?y���s���r�	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$�� v@��	b$���9�X��߹���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A���H; A쀄�   ��.��.J�    IEND�B`�
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: image/jpeg
Content-Transfer-Encoding: binary
Content-Location: https://avatars.githubusercontent.com/u/41493567?s=48&v=4

���� � 		
 $.' ",#(7),01444'9=82<.342			2!!22222222222222222222222222222222222222222222222222��  0 0" ���          	
   } !1AQa"q2���#B��R��$3br�	
%&'()*456789:CDEFGHIJSTUVWXYZcdefghijstuvwxyz�������������������������������������������������������������������������       	
  w !1AQaq"2�B����	#3R�br�
$4�%�&'()*56789:CDEFGHIJSTUVWXYZcdefghijstuvwxyz��������������������������������������������������������������������������   ? ���}w��sy1�V�4�}��X�/���_����i�ng�A�˰V 9 s����s�ό��u�Y��� �6�P=2>c��Lо+��@(�kS\@������G�[��\qVG*�U��`�j�bA,x u4�}��G�鶷���q
J�ـ#�Պ�~\^���H�Q����h6N�	E$! �۶�jC<��z�����6�ĺ�����i#,K�Q�#�<׉���íBK�5�G�� h�J̎?�#��a�׾�F�~<So�����Z\tߴ�#OC��N�� �ƣ�{맲g���E����e����ob |�>&>�?�:n����1���iSʓ�Ki ��-M��>�s�y_?����[���|��>� M��e�� l���[���D�Z}��*�Q�'���@�SB�>"��k׏?�����O'��l���x�w��.��kq����f��@�D2B�u���/x�i����ɒ�kx��OC��gdC���4�~�A6������2]�uٸ䢟OS��@���z歡�o��h�w�VC`� �A+����D�����A�t�e�`.��<��J�s�ӷz}UYz��t�鯧��Q�[�@��Cꧪ�q@6���o�m��&�Hu�d���O;�� ~�GZ<�����i�"����cΣ���?~���{/��'��UM69�P��i�u���?�	�á� ��OS�ƪ�l�>���e72/���
ՏS��<[[���&x�3���m��[�������~�z��/\�t8���u[� �(O�A ��M[�|;�xgLM?H����y!G.}X�c�kR����
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb----
Content-Type: text/html
Content-ID: <frame-5B39253A2AEADC7375343C68344218FF@mhtml.blink>
Content-Transfer-Encoding: binary

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head><body></body></html>
------MultipartBoundary--iwnaNYmkwRIsCh3eAD8YKaSYUb0ID1kAfVG0dc5Mxb------
